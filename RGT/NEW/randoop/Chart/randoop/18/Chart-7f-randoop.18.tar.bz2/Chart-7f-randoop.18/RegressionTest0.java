import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        try {
            java.lang.Number number3 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = null;
        try {
            timePeriodValues1.add(timePeriodValue6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy((int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        try {
            timePeriodValues1.update(7, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        boolean boolean5 = year0.equals((java.lang.Object) 0L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        try {
            timePeriodValues1.update(13, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        try {
//            java.lang.Number number5 = timePeriodValues3.getValue((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        timePeriodValues3.setNotify(true);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        try {
            timePeriodValues1.update((int) (byte) 10, (java.lang.Number) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        java.util.Date date13 = simpleTimePeriod11.getStart();
        java.util.Date date14 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date7, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        boolean boolean11 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.lang.Number number8 = null;
        try {
            timePeriodValues6.update((int) 'a', number8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0 + "'", comparable10.equals(0));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
        timePeriodValues1.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue26 = timePeriodValues1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.util.Date date6 = day4.getEnd();
//        int int7 = day0.compareTo((java.lang.Object) day4);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day4.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable10 = null;
        try {
            timePeriodValues1.setKey(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        timePeriodValue8.setValue((java.lang.Number) 100);
        java.lang.Object obj14 = timePeriodValue8.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560409200000L, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        try {
            timePeriodValues1.update((int) (short) -1, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.util.Date date6 = day4.getEnd();
//        int int7 = day0.compareTo((java.lang.Object) day4);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone20 = null;
        try {
            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        try {
            timePeriodValues1.update(0, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        java.lang.String str25 = day23.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod26, (java.lang.Number) 1577865599999L);
//        long long29 = regularTimePeriod26.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
        timePeriodValues1.setRangeDescription("");
        try {
            timePeriodValues1.delete((int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        timePeriodValues3.delete((int) (short) 10, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        int int13 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560409200000L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        int int7 = timePeriodValues6.getMinEndIndex();
        try {
            timePeriodValues6.delete((int) (short) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.String str12 = timePeriodValue8.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone20 = null;
        try {
            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = null;
        try {
            timePeriodValues1.add(timePeriodValue23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        int int8 = day7.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 1.0f);
        java.lang.Number number8 = timePeriodValue7.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        try {
            java.lang.Number number12 = timePeriodValues10.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        java.lang.Object obj11 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        java.lang.String str25 = day23.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod26, (java.lang.Number) 1577865599999L);
//        try {
//            org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValues1.getTimePeriod((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 3");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues15.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues6.getTimePeriod(0);
        boolean boolean15 = timePeriodValues6.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
        timePeriodValue24.setValue((java.lang.Number) (-1.0f));
        timePeriodValues6.add(timePeriodValue24);
        java.lang.Object obj28 = timePeriodValue24.clone();
        timePeriodValues1.add(timePeriodValue24);
        java.lang.Object obj30 = timePeriodValue24.clone();
        java.lang.Class<?> wildcardClass31 = timePeriodValue24.getClass();
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(class33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long1, "hi!", "hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (short) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        int int3 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 11);
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year19.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 100L);
        java.lang.String str8 = day5.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        timePeriodValue8.setValue((java.lang.Number) 100);
        java.lang.String str14 = timePeriodValue8.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Object obj9 = null;
        try {
            int int10 = simpleTimePeriod2.compareTo(obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        try {
            java.lang.Number number6 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        long long9 = simpleTimePeriod2.getEndMillis();
        long long10 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.String str7 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date4, date9);
//        java.util.Date date11 = simpleTimePeriod10.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        long long16 = simpleTimePeriod14.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) (byte) 1);
//        long long19 = simpleTimePeriod14.getEndMillis();
//        try {
//            int int20 = simpleTimePeriod10.compareTo((java.lang.Object) long19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        timePeriodValues8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        int int20 = timePeriodValues19.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), 1560452399999L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = day17.getFirstMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        java.lang.String str12 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener13);
        boolean boolean15 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        boolean boolean18 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "Time", "2019");
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
//        long long7 = day2.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        java.util.Date date14 = simpleTimePeriod12.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        int int16 = day15.getDayOfMonth();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (double) 0L);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day15.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.delete(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        long long9 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Date date3 = day0.getStart();
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        int int6 = day0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        timePeriodValues10.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = year26.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        timePeriodValues1.setDomainDescription("Time");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (double) 100L);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year12.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        java.util.Calendar calendar22 = null;
        try {
            year19.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues1.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-1969");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date4, timeZone19);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        timePeriodValues1.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        long long20 = simpleTimePeriod11.getStartMillis();
        long long21 = simpleTimePeriod11.getStartMillis();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str26 = timePeriodFormatException25.toString();
        java.lang.String str27 = timePeriodFormatException25.toString();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        try {
            int int36 = simpleTimePeriod11.compareTo((java.lang.Object) timePeriodFormatException25);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean9 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean9);
        java.lang.String str11 = seriesChangeEvent10.toString();
        java.lang.String str12 = seriesChangeEvent10.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=true]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=true]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=true]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=true]"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        int int13 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        try {
            timePeriodValues6.update(9, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year14.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues1.createCopy((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
//        long long9 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        java.lang.String str12 = day10.toString();
//        java.lang.String str13 = day10.toString();
//        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) day10);
//        int int16 = day10.compareTo((java.lang.Object) 1969);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 100, (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        java.lang.String str12 = day10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        try {
//            int int15 = simpleTimePeriod8.compareTo((java.lang.Object) date14);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timePeriodValues1.getNotify();
        java.lang.Object obj9 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long8 = simpleTimePeriod7.getEndMillis();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues4.getTimePeriod(0);
//        boolean boolean13 = timePeriodValues4.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        long long18 = simpleTimePeriod16.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 10L);
//        timePeriodValue22.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues4.add(timePeriodValue22);
//        java.lang.Object obj26 = timePeriodValue22.clone();
//        java.lang.Object obj27 = timePeriodValue22.clone();
//        java.lang.Object obj28 = timePeriodValue22.clone();
//        int int29 = day0.compareTo((java.lang.Object) timePeriodValue22);
//        timePeriodValue22.setValue((java.lang.Number) 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        int int13 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.update((int) (short) 10, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 0L);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        java.lang.Object obj13 = timePeriodValues12.clone();
        int int14 = timePeriodValues12.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Date date6 = year0.getEnd();
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(2019, (int) '4');
        java.lang.String str15 = timePeriodValues14.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue11.getPeriod();
        timePeriodValues1.add(timePeriodValue11);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriod13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        java.lang.Object obj10 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Date date3 = day0.getStart();
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, (java.lang.Number) 5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day4.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar9 = null;
        try {
            day8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getFirstMillisecond();
//        java.util.Date date8 = day0.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.String str7 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date4, date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day11.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int16 = timePeriodValues15.getMaxStartIndex();
        int int17 = timePeriodValues15.getMinEndIndex();
        boolean boolean18 = timePeriodValues15.isEmpty();
        java.lang.Class<?> wildcardClass19 = timePeriodValues15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        java.util.Date date24 = simpleTimePeriod22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date33, date35);
        java.lang.Class<?> wildcardClass37 = date35.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        long long42 = simpleTimePeriod40.getEndMillis();
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date35, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date24, timeZone44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long51 = simpleTimePeriod50.getEndMillis();
        long long52 = simpleTimePeriod50.getEndMillis();
        long long53 = simpleTimePeriod50.getStartMillis();
        long long54 = simpleTimePeriod50.getStartMillis();
        java.util.Date date55 = simpleTimePeriod50.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int58 = timePeriodValues57.getItemCount();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.previous();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) regularTimePeriod60, (double) 100);
        java.lang.String str63 = timePeriodValues57.getDescription();
        java.lang.String str64 = timePeriodValues57.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long68 = simpleTimePeriod67.getEndMillis();
        long long69 = simpleTimePeriod67.getEndMillis();
        java.util.Date date70 = simpleTimePeriod67.getEnd();
        long long71 = simpleTimePeriod67.getEndMillis();
        java.lang.Number number72 = null;
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) simpleTimePeriod67, number72);
        java.util.Date date74 = simpleTimePeriod67.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long78 = simpleTimePeriod77.getEndMillis();
        java.util.Date date79 = simpleTimePeriod77.getStart();
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date79, timeZone80);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date74, timeZone80);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long86 = simpleTimePeriod85.getEndMillis();
        long long87 = simpleTimePeriod85.getEndMillis();
        java.util.Date date88 = simpleTimePeriod85.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date74, timeZone89);
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date55, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date24, timeZone89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Time" + "'", str64.equals("Time"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 10L + "'", long71 == 10L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 10L + "'", long87 == 10L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        try {
//            timePeriodValues1.update(2, (java.lang.Number) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        long long8 = day7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (short) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener11);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(12, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues1.createCopy((-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        int int16 = timePeriodValues1.getMinStartIndex();
        int int17 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str18 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (double) 100L);
        java.lang.String str16 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int22 = timePeriodValues21.getItemCount();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) regularTimePeriod24, (double) 100);
        java.lang.String str27 = timePeriodValues21.getDescription();
        java.lang.String str28 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long32 = simpleTimePeriod31.getEndMillis();
        long long33 = simpleTimePeriod31.getEndMillis();
        java.util.Date date34 = simpleTimePeriod31.getEnd();
        long long35 = simpleTimePeriod31.getEndMillis();
        java.lang.Number number36 = null;
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, number36);
        java.util.Date date38 = simpleTimePeriod31.getStart();
        java.util.Date date39 = simpleTimePeriod31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long43 = simpleTimePeriod42.getEndMillis();
        long long44 = simpleTimePeriod42.getEndMillis();
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod42, (double) 1.0f);
        java.util.Date date48 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date39, date48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date18, date39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 0.0d);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        try {
            timePeriodValues1.update((int) (short) 1, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getItemCount();
        boolean boolean11 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues15.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        timePeriodValues1.setDomainDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener20);
        java.lang.Comparable comparable22 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        java.util.Date date8 = day6.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date8, timeZone9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        java.util.Date date16 = simpleTimePeriod13.getStart();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str18 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        try {
            timePeriodValues1.delete(11, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        long long9 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        timePeriodValues3.setDomainDescription("13-June-2019");
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        try {
            timePeriodValues1.delete(4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        long long18 = simpleTimePeriod16.getEndMillis();
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        long long21 = simpleTimePeriod16.getStartMillis();
        long long22 = simpleTimePeriod16.getStartMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 1577865599999L);
        long long25 = simpleTimePeriod16.getStartMillis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMaxStartIndex();
//        int int3 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int6 = timePeriodValues5.getItemCount();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 10L);
//        long long13 = regularTimePeriod8.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        int int12 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (short) 100, 2);
        try {
            java.lang.Number number19 = timePeriodValues1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int8 = timePeriodValues7.getItemCount();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
//        java.lang.String str13 = timePeriodValues7.getDescription();
//        java.lang.String str14 = timePeriodValues7.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long18 = simpleTimePeriod17.getEndMillis();
//        long long19 = simpleTimePeriod17.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod17.getEnd();
//        long long21 = simpleTimePeriod17.getEndMillis();
//        java.lang.Number number22 = null;
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, number22);
//        java.util.Date date24 = simpleTimePeriod17.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long29 = simpleTimePeriod28.getEndMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date24, timeZone32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date5, timeZone32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date40 = simpleTimePeriod38.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date5, date40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
//        org.junit.Assert.assertNotNull(date40);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str14 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100L);
        timePeriodValues3.add(timePeriodValue11);
        try {
            timePeriodValues3.update(9, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        int int4 = timePeriodValues3.getItemCount();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (double) (byte) -1);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        int int16 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        boolean boolean7 = day0.equals((java.lang.Object) (-1.0d));
//        long long8 = day0.getMiddleMillisecond();
//        int int9 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        boolean boolean6 = year0.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        long long8 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Object obj2 = null;
        int int3 = year0.compareTo(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        int int5 = day4.getYear();
//        java.util.Calendar calendar6 = null;
//        try {
//            day4.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        long long18 = simpleTimePeriod16.getEndMillis();
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        long long21 = simpleTimePeriod16.getStartMillis();
        long long22 = simpleTimePeriod16.getStartMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) 10L);
        timePeriodValue21.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue21);
        timePeriodValue21.setValue((java.lang.Number) 100);
        boolean boolean27 = timePeriodValues1.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) 28799999L);
        timePeriodValues1.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        java.util.Date date13 = simpleTimePeriod11.getStart();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 10L);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (-1.0d));
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int20 = timePeriodValues19.getItemCount();
        timePeriodValues19.setDomainDescription("hi!");
        java.lang.Comparable comparable23 = timePeriodValues19.getKey();
        timePeriodValues19.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues19.createCopy((int) (short) 0, (int) (byte) -1);
        boolean boolean31 = timePeriodValues1.equals((java.lang.Object) timePeriodValues30);
        boolean boolean32 = timePeriodValues30.isEmpty();
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 1560409200000L);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int5 = timePeriodValues4.getItemCount();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod7, (double) 100);
        java.lang.String str10 = timePeriodValues4.getDescription();
        try {
            int int11 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        long long15 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
        timePeriodValues1.add(timePeriodValue19);
        int int23 = timePeriodValues1.getMinStartIndex();
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Object obj25 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(obj25);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        long long15 = day10.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day10, (double) 13);
//        long long18 = day10.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        long long14 = simpleTimePeriod12.getEndMillis();
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date7, timeZone43);
        java.util.Calendar calendar47 = null;
        try {
            long long48 = year46.getLastMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.Number number12 = timePeriodValue8.getValue();
        java.lang.String str13 = timePeriodValue8.toString();
        java.lang.String str14 = timePeriodValue8.toString();
        timePeriodValue8.setValue((java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues1.getDescription();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("");
        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        long long9 = year7.getLastMillisecond();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) long9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        try {
            timePeriodValues1.update(7, (java.lang.Number) (-14400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int16 = timePeriodValues15.getMaxStartIndex();
        int int17 = timePeriodValues15.getMinEndIndex();
        boolean boolean18 = timePeriodValues15.isEmpty();
        java.lang.Class<?> wildcardClass19 = timePeriodValues15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        java.util.Date date24 = simpleTimePeriod22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date33, date35);
        java.lang.Class<?> wildcardClass37 = date35.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        long long42 = simpleTimePeriod40.getEndMillis();
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date35, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date24, timeZone44);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(class48);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues1.getDataItem(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        java.lang.String str15 = timePeriodValues9.getDescription();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        long long23 = simpleTimePeriod19.getEndMillis();
        java.lang.Number number24 = null;
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, number24);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date26, timeZone32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long38 = simpleTimePeriod37.getEndMillis();
        long long39 = simpleTimePeriod37.getEndMillis();
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date26, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date7, timeZone41);
        long long45 = year44.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-31507200000L) + "'", long45 == (-31507200000L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        java.lang.String str12 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        java.util.Date date17 = simpleTimePeriod15.getStart();
        java.util.Date date18 = simpleTimePeriod15.getStart();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (byte) 10);
        java.lang.Object obj21 = timePeriodValues1.clone();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue23 = timePeriodValues1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj21);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10.0d);
//        timePeriodValue8.setValue((java.lang.Number) 1577865599999L);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timePeriod11);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(2019, (int) '4');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean9 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean9);
        java.lang.String str11 = seriesChangeEvent10.toString();
        java.lang.Object obj12 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=true]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=true]"));
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + true + "'", obj12.equals(true));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.lang.String str28 = day0.toString();
//        java.util.Calendar calendar29 = null;
//        try {
//            day0.peg(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        int int11 = timePeriodValues1.getItemCount();
        timePeriodValues1.setRangeDescription("1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue11.getPeriod();
        timePeriodValues1.add(timePeriod13, (java.lang.Number) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriod13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        boolean boolean9 = timePeriodValues8.getNotify();
        java.lang.Comparable comparable10 = timePeriodValues8.getKey();
        int int11 = timePeriodValues8.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Calendar calendar20 = null;
        try {
            year19.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.String str7 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 10L);
        boolean boolean13 = timePeriodValues1.isEmpty();
        timePeriodValues1.delete((int) '4', 0);
        int int17 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        timePeriodValues1.setRangeDescription("TimePeriodValue[13-June-2019,1577865599999]");
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        int int11 = timePeriodValues10.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues10.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        long long14 = simpleTimePeriod12.getEndMillis();
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day18.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues6.getTimePeriod(0);
        boolean boolean15 = timePeriodValues6.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
        timePeriodValue24.setValue((java.lang.Number) (-1.0f));
        timePeriodValues6.add(timePeriodValue24);
        java.lang.Object obj28 = timePeriodValue24.clone();
        timePeriodValues1.add(timePeriodValue24);
        timePeriodValues1.setDescription("hi!");
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        long long10 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        long long4 = day0.getLastMillisecond();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str17 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560365999999L);
//        timePeriodValue6.setValue((java.lang.Number) 1560409200000L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int11 = timePeriodValues10.getMaxStartIndex();
//        int int12 = timePeriodValues10.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int15 = timePeriodValues14.getItemCount();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, (double) 100);
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, (double) 10L);
//        boolean boolean22 = timePeriodValue6.equals((java.lang.Object) 10L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        long long14 = simpleTimePeriod12.getEndMillis();
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
        java.util.Calendar calendar19 = null;
        try {
            day18.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        java.lang.String str15 = timePeriodFormatException13.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str19 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str25 = timePeriodFormatException13.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Object obj9 = timePeriodValue8.clone();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue8.getPeriod();
        timePeriodValue8.setValue((java.lang.Number) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        java.util.Date date17 = simpleTimePeriod15.getStart();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int22 = timePeriodValues21.getItemCount();
        timePeriodValues21.setDomainDescription("hi!");
        java.lang.Comparable comparable25 = timePeriodValues21.getKey();
        java.lang.String str26 = timePeriodValues21.getDomainDescription();
        int int27 = timePeriodValues21.getMaxMiddleIndex();
        int int28 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean29 = simpleTimePeriod15.equals((java.lang.Object) int28);
        try {
            int int30 = simpleTimePeriod2.compareTo((java.lang.Object) int28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Date date3 = day0.getStart();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = day0.equals(obj4);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue11.getPeriod();
        timePeriodValues1.add(timePeriod13, (java.lang.Number) (byte) 100);
        int int16 = timePeriodValues1.getItemCount();
        try {
            timePeriodValues1.update((int) 'a', (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        long long3 = year1.getLastMillisecond();
        long long4 = year1.getLastMillisecond();
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        java.util.Date date7 = year1.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        java.lang.String str15 = timePeriodValues9.getDescription();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        long long23 = simpleTimePeriod19.getEndMillis();
        java.lang.Number number24 = null;
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, number24);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date26, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone32);
        java.util.TimeZone timeZone36 = null;
        try {
            org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date7, timeZone36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod35);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.String str7 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date4, date9);
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) '4', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long59 = simpleTimePeriod58.getEndMillis();
        java.util.Date date60 = simpleTimePeriod58.getStart();
        java.util.Date date61 = simpleTimePeriod58.getStart();
        java.util.Date date62 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int65 = timePeriodValues64.getItemCount();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) regularTimePeriod67, (double) 100);
        java.lang.String str70 = timePeriodValues64.getDescription();
        java.lang.String str71 = timePeriodValues64.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long75 = simpleTimePeriod74.getEndMillis();
        long long76 = simpleTimePeriod74.getEndMillis();
        java.util.Date date77 = simpleTimePeriod74.getEnd();
        long long78 = simpleTimePeriod74.getEndMillis();
        java.lang.Number number79 = null;
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod74, number79);
        java.util.Date date81 = simpleTimePeriod74.getStart();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long86 = simpleTimePeriod85.getEndMillis();
        long long87 = simpleTimePeriod85.getEndMillis();
        java.util.Date date88 = simpleTimePeriod85.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date81, timeZone89);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date62, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date18, timeZone89);
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Time" + "'", str71.equals("Time"));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 10L + "'", long87 == 10L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18, timeZone26);
        long long29 = year28.getFirstMillisecond();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year28.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        long long8 = day6.getLastMillisecond();
        java.lang.String str9 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues1.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        int int13 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        boolean boolean7 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        long long8 = day6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Date date3 = day0.getStart();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = day0.equals(obj4);
//        java.util.Date date6 = day0.getEnd();
//        long long7 = day0.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        timePeriodValues1.delete(0, (int) (short) 0);
//        timePeriodValues1.fireSeriesChanged();
//        int int12 = timePeriodValues1.getMinMiddleIndex();
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (short) 100, 2);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getStart();
//        java.lang.String str20 = day18.toString();
//        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
//        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) day18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues17.addChangeListener(seriesChangeListener23);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues1.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        int int10 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int13 = timePeriodValues12.getMaxEndIndex();
        timePeriodValues12.fireSeriesChanged();
        int int15 = timePeriodValues12.getMaxMiddleIndex();
        java.lang.String str16 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        java.util.Date date21 = simpleTimePeriod19.getStart();
        java.util.Date date22 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day23);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 100);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean28 = timePeriodValues1.equals((java.lang.Object) timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        boolean boolean9 = timePeriodValues8.getNotify();
        int int10 = timePeriodValues8.getMaxEndIndex();
        int int11 = timePeriodValues8.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues8.createCopy(31, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues4.getMinEndIndex();
        boolean boolean8 = year0.equals((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long8 = day4.getMiddleMillisecond();
//        int int9 = day0.compareTo((java.lang.Object) day4);
//        java.util.Calendar calendar10 = null;
//        try {
//            day0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        timePeriodValues9.fireSeriesChanged();
        timePeriodValues9.setNotify(true);
        boolean boolean18 = simpleTimePeriod2.equals((java.lang.Object) true);
        long long19 = simpleTimePeriod2.getEndMillis();
        long long20 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDomainDescription("hi!");
//        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        long long13 = day11.getSerialIndex();
//        java.util.Date date14 = day11.getEnd();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day11, 0.0d);
//        int int17 = timePeriodValues10.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 5);
//        java.lang.Object obj8 = timePeriodValue7.clone();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(obj8);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int12 = timePeriodValues11.getMaxStartIndex();
        int int13 = timePeriodValues11.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int16 = timePeriodValues15.getItemCount();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) 100);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) 10L);
        boolean boolean23 = timePeriodValues11.isEmpty();
        timePeriodValues11.delete((int) '4', 0);
        try {
            int int27 = simpleTimePeriod2.compareTo((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 5);
//        timePeriodValue7.setValue((java.lang.Number) (short) 10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str18 = timePeriodFormatException6.toString();
        java.lang.String str19 = timePeriodFormatException6.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (-1.0d) + "'", comparable6.equals((-1.0d)));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str7 = year0.toString();
        int int8 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 0L);
//        java.lang.String str7 = timePeriodValue6.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str7.equals("TimePeriodValue[13-June-2019,0]"));
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        timePeriodValues3.add(timePeriodValue8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long15 = simpleTimePeriod14.getEndMillis();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 'a');
        timePeriodValues11.delete(0, (int) (short) 0);
        timePeriodValues11.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long27 = simpleTimePeriod26.getEndMillis();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValues23.getTimePeriod(0);
        boolean boolean32 = timePeriodValues11.equals((java.lang.Object) timePeriod31);
        timePeriodValues3.add(timePeriod31, (java.lang.Number) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(timePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        int int7 = timePeriodValues1.getMinMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        boolean boolean10 = timePeriodValues1.getNotify();
        int int11 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long11 = simpleTimePeriod10.getEndMillis();
        long long12 = simpleTimePeriod10.getEndMillis();
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13, timeZone14);
        boolean boolean16 = year6.equals((java.lang.Object) date13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (double) (byte) -1);
        long long15 = day12.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57600000L) + "'", long15 == (-57600000L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getItemCount();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long11 = simpleTimePeriod10.getEndMillis();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues7.getTimePeriod(0);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) timePeriod15);
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getFirstMillisecond();
//        long long2 = year0.getLastMillisecond();
//        long long3 = year0.getLastMillisecond();
//        boolean boolean5 = year0.equals((java.lang.Object) 1);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        int int12 = day9.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        long long14 = day9.getFirstMillisecond();
//        long long15 = day9.getSerialIndex();
//        boolean boolean16 = year0.equals((java.lang.Object) long15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        int int8 = timePeriodValues1.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.util.Calendar calendar28 = null;
//        try {
//            day0.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        java.util.Date date8 = day6.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date8, timeZone9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8);
        timePeriodValues9.fireSeriesChanged();
        try {
            timePeriodValues9.update((int) (short) 10, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long9 = simpleTimePeriod8.getEndMillis();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (double) 'a');
//        timePeriodValues5.delete(0, (int) (short) 0);
//        timePeriodValues5.fireSeriesChanged();
//        int int16 = timePeriodValues5.getMinMiddleIndex();
//        timePeriodValues5.setNotify(true);
//        int int19 = day0.compareTo((java.lang.Object) timePeriodValues5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long7 = simpleTimePeriod6.getEndMillis();
        java.util.Date date8 = simpleTimePeriod6.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod6, (java.lang.Number) 10L);
        java.lang.String str11 = timePeriodValues3.getDescription();
        try {
            java.lang.Number number13 = timePeriodValues3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.String str7 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.String str7 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        boolean boolean11 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.String str7 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "Time", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.lang.Number number14 = null;
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, number14);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int8 = timePeriodValues7.getItemCount();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
//        java.lang.String str13 = timePeriodValues7.getDescription();
//        java.lang.String str14 = timePeriodValues7.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long18 = simpleTimePeriod17.getEndMillis();
//        long long19 = simpleTimePeriod17.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod17.getEnd();
//        long long21 = simpleTimePeriod17.getEndMillis();
//        java.lang.Number number22 = null;
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, number22);
//        java.util.Date date24 = simpleTimePeriod17.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long29 = simpleTimePeriod28.getEndMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date24, timeZone32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date5, timeZone32);
//        long long36 = year35.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2, "Value", "org.jfree.data.general.SeriesChangeEvent[source=true]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        timePeriodValues1.delete(0, (int) (short) 0);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
//        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
//        timePeriodValues1.setRangeDescription("");
//        java.lang.Object obj25 = timePeriodValues1.clone();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 0.0d);
//        long long30 = day26.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (double) 1560365999999L);
//        timePeriodValues1.add(timePeriodValue32);
//        int int34 = timePeriodValues1.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getItemCount();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.Number number12 = timePeriodValue8.getValue();
        java.lang.String str13 = timePeriodValue8.toString();
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
        java.lang.Object obj15 = timePeriodValue8.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        java.lang.String str13 = seriesChangeEvent11.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setNotify(false);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long8 = simpleTimePeriod7.getEndMillis();
//        long long9 = simpleTimePeriod7.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) 10L);
//        long long14 = simpleTimePeriod7.getStartMillis();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        java.lang.String str17 = day15.toString();
//        java.lang.String str18 = day15.toString();
//        boolean boolean19 = simpleTimePeriod7.equals((java.lang.Object) day15);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) '4');
//        java.lang.String str22 = timePeriodValues1.getDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str22);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        try {
            timePeriodValues1.delete((int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        boolean boolean9 = timePeriodValues8.getNotify();
        int int10 = timePeriodValues8.getMaxEndIndex();
        java.lang.String str11 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
        java.lang.Number number12 = timePeriodValue11.getValue();
        java.lang.Object obj13 = null;
        boolean boolean14 = timePeriodValue11.equals(obj13);
        boolean boolean15 = year0.equals(obj13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,1577865599999]");
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long59 = simpleTimePeriod58.getEndMillis();
        java.util.Date date60 = simpleTimePeriod58.getStart();
        java.util.Date date61 = simpleTimePeriod58.getStart();
        java.util.Date date62 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int65 = timePeriodValues64.getItemCount();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) regularTimePeriod67, (double) 100);
        java.lang.String str70 = timePeriodValues64.getDescription();
        java.lang.String str71 = timePeriodValues64.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long75 = simpleTimePeriod74.getEndMillis();
        long long76 = simpleTimePeriod74.getEndMillis();
        java.util.Date date77 = simpleTimePeriod74.getEnd();
        long long78 = simpleTimePeriod74.getEndMillis();
        java.lang.Number number79 = null;
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod74, number79);
        java.util.Date date81 = simpleTimePeriod74.getStart();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long86 = simpleTimePeriod85.getEndMillis();
        long long87 = simpleTimePeriod85.getEndMillis();
        java.util.Date date88 = simpleTimePeriod85.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date81, timeZone89);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date62, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date18, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = year93.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Time" + "'", str71.equals("Time"));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 10L + "'", long87 == 10L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
//        long long9 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getStart();
//        java.lang.String str12 = day10.toString();
//        java.lang.String str13 = day10.toString();
//        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) day10);
//        long long15 = day10.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        long long5 = day0.getSerialIndex();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        int int9 = day7.getDayOfMonth();
//        boolean boolean11 = day7.equals((java.lang.Object) false);
//        java.util.Date date12 = day7.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day7);
//        boolean boolean14 = day0.equals((java.lang.Object) day7);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setDomainDescription("31-December-1969");
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 5);
//        java.util.Date date8 = day0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) 10, 13);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (double) 'a');
        timePeriodValues10.setNotify(true);
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        java.lang.String str20 = timePeriodValues10.getRangeDescription();
        timePeriodValues10.fireSeriesChanged();
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) timePeriodValues10);
        try {
            timePeriodValues10.update(12, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str18 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str23 = timePeriodFormatException22.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.String str25 = timePeriodFormatException22.toString();
        java.lang.String str26 = timePeriodFormatException22.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 1560452399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.delete(31, 0);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        int int9 = day5.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day5, (double) 10);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getMonth();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        timePeriodValues9.fireSeriesChanged();
        timePeriodValues9.setNotify(true);
        boolean boolean18 = simpleTimePeriod2.equals((java.lang.Object) true);
        java.util.Date date19 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int5 = timePeriodValues4.getItemCount();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod7, (double) 100);
//        java.lang.String str10 = timePeriodValues4.getDescription();
//        java.lang.String str11 = timePeriodValues4.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        long long16 = simpleTimePeriod14.getEndMillis();
//        java.util.Date date17 = simpleTimePeriod14.getEnd();
//        long long18 = simpleTimePeriod14.getEndMillis();
//        java.lang.Number number19 = null;
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, number19);
//        java.util.Date date21 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        int int23 = year22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
//        boolean boolean25 = day0.equals((java.lang.Object) year22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues1.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) (short) 1);
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "Time", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        int int9 = timePeriodValues8.getMaxEndIndex();
//        int int10 = timePeriodValues8.getMinStartIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        int int12 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (short) 100, 2);
        timePeriodValues17.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener20);
        java.lang.Class<?> wildcardClass22 = timePeriodValues17.getClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1969);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 1560495599999L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setRangeDescription("1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(1969, 3);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues1.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        try {
            timePeriodValues1.delete((-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int11 = timePeriodValues10.getItemCount();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (double) 100);
        java.util.Date date16 = regularTimePeriod13.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        java.util.Date date24 = simpleTimePeriod21.getStart();
        java.util.Date date25 = simpleTimePeriod21.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int28 = timePeriodValues27.getItemCount();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) regularTimePeriod30, (double) 100);
        java.lang.String str33 = timePeriodValues27.getDescription();
        java.lang.String str34 = timePeriodValues27.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long38 = simpleTimePeriod37.getEndMillis();
        long long39 = simpleTimePeriod37.getEndMillis();
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        long long41 = simpleTimePeriod37.getEndMillis();
        java.lang.Number number42 = null;
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod37, number42);
        java.util.Date date44 = simpleTimePeriod37.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date44, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date25, timeZone52);
        java.lang.Class class56 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long60 = simpleTimePeriod59.getEndMillis();
        java.util.Date date61 = simpleTimePeriod59.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long65 = simpleTimePeriod64.getEndMillis();
        long long66 = simpleTimePeriod64.getEndMillis();
        java.util.Date date67 = simpleTimePeriod64.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date61, timeZone68);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long74 = simpleTimePeriod73.getEndMillis();
        long long75 = simpleTimePeriod73.getEndMillis();
        java.util.Date date76 = simpleTimePeriod73.getEnd();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        java.util.Date date78 = day77.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod(date76, date78);
        java.lang.Class<?> wildcardClass80 = date78.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long84 = simpleTimePeriod83.getEndMillis();
        long long85 = simpleTimePeriod83.getEndMillis();
        java.util.Date date86 = simpleTimePeriod83.getEnd();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date86, timeZone87);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date78, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date61, timeZone87);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date25, timeZone87);
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date8, timeZone87);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 10L + "'", long84 == 10L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 10L + "'", long85 == 10L);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod90);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        try {
            timePeriodValues1.delete(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        java.lang.String str2 = year0.toString();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getMiddleMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        java.util.Date date9 = day7.getEnd();
//        int int10 = day3.compareTo((java.lang.Object) day7);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100);
//        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValue13);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = year0.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(10, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int13 = timePeriodValues12.getItemCount();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 100);
        java.lang.String str18 = timePeriodValues12.getDescription();
        java.lang.String str19 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        long long26 = simpleTimePeriod22.getEndMillis();
        java.lang.Number number27 = null;
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, number27);
        java.util.Date date29 = simpleTimePeriod22.getStart();
        java.util.Date date30 = simpleTimePeriod22.getStart();
        long long31 = simpleTimePeriod22.getStartMillis();
        long long32 = simpleTimePeriod22.getStartMillis();
        long long33 = simpleTimePeriod22.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxEndIndex();
        try {
            timePeriodValues1.delete(0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMaxStartIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        long long15 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
        timePeriodValues1.add(timePeriodValue19);
        java.lang.Object obj23 = timePeriodValue19.clone();
        java.lang.Number number24 = timePeriodValue19.getValue();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) number24);
        java.lang.Object obj26 = seriesChangeEvent25.getSource();
        java.lang.String str27 = seriesChangeEvent25.toString();
        java.lang.String str28 = seriesChangeEvent25.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0f) + "'", number24.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + obj26 + "' != '" + (-1.0f) + "'", obj26.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str27.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str28.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean9 = timePeriodValues1.getNotify();
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        boolean boolean5 = year0.equals((java.lang.Object) 0L);
        int int6 = year0.getYear();
        long long7 = year0.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        int int8 = day6.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues1.getDescription();
        timePeriodValues1.setDomainDescription("31-December-1969");
        try {
            java.lang.Number number11 = timePeriodValues1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long59 = simpleTimePeriod58.getEndMillis();
        java.util.Date date60 = simpleTimePeriod58.getStart();
        java.util.Date date61 = simpleTimePeriod58.getStart();
        java.util.Date date62 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int65 = timePeriodValues64.getItemCount();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) regularTimePeriod67, (double) 100);
        java.lang.String str70 = timePeriodValues64.getDescription();
        java.lang.String str71 = timePeriodValues64.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long75 = simpleTimePeriod74.getEndMillis();
        long long76 = simpleTimePeriod74.getEndMillis();
        java.util.Date date77 = simpleTimePeriod74.getEnd();
        long long78 = simpleTimePeriod74.getEndMillis();
        java.lang.Number number79 = null;
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod74, number79);
        java.util.Date date81 = simpleTimePeriod74.getStart();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long86 = simpleTimePeriod85.getEndMillis();
        long long87 = simpleTimePeriod85.getEndMillis();
        java.util.Date date88 = simpleTimePeriod85.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date81, timeZone89);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date62, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date18, timeZone89);
        org.jfree.data.time.TimePeriodValues timePeriodValues96 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year93, "org.jfree.data.general.SeriesChangeEvent[source=true]", "hi!");
        java.util.Date date97 = year93.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Time" + "'", str71.equals("Time"));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 10L + "'", long87 == 10L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(date97);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        long long15 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
        timePeriodValues1.add(timePeriodValue19);
        java.lang.Object obj23 = timePeriodValue19.clone();
        java.lang.Number number24 = timePeriodValue19.getValue();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, 0.0d);
        int int29 = day25.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 13);
        boolean boolean32 = timePeriodValue19.equals((java.lang.Object) timePeriodValue31);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0f) + "'", number24.equals((-1.0f)));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getMaxStartIndex();
        int int10 = timePeriodValues8.getMinEndIndex();
        boolean boolean11 = timePeriodValues8.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues8.getClass();
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long11 = simpleTimePeriod10.getEndMillis();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues7.getTimePeriod(0);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) timePeriod15);
        timePeriodValues1.setRangeDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        java.lang.Object obj13 = timePeriodValues12.clone();
        java.lang.String str14 = timePeriodValues12.getRangeDescription();
        timePeriodValues12.setKey((java.lang.Comparable) 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int8 = timePeriodValues7.getMaxEndIndex();
        timePeriodValues7.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValues12.getTimePeriod(0);
        boolean boolean21 = timePeriodValues12.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long25 = simpleTimePeriod24.getEndMillis();
        long long26 = simpleTimePeriod24.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (java.lang.Number) 10L);
        timePeriodValue30.setValue((java.lang.Number) (-1.0f));
        timePeriodValues12.add(timePeriodValue30);
        java.lang.Object obj34 = timePeriodValue30.clone();
        timePeriodValues7.add(timePeriodValue30);
        java.lang.Object obj36 = timePeriodValue30.clone();
        timePeriodValues1.add(timePeriodValue30);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(timePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(obj36);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
//        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
//        timePeriodValue8.setValue((java.lang.Number) 100);
//        timePeriodValue8.setValue((java.lang.Number) 7);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        java.lang.String str18 = day16.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day16);
//        timePeriodValues19.setDomainDescription("13-June-2019");
//        int int22 = timePeriodValues19.getMaxMiddleIndex();
//        boolean boolean23 = timePeriodValues19.isEmpty();
//        boolean boolean24 = timePeriodValue8.equals((java.lang.Object) boolean23);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        boolean boolean9 = timePeriodValues1.getNotify();
        boolean boolean10 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        java.lang.String str5 = timePeriodValues1.getDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.lang.String str7 = timePeriodValues1.getDescription();
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getStart();
//        long long13 = day11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int16 = timePeriodValues15.getItemCount();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) 100);
//        java.lang.String str21 = timePeriodValues15.getDescription();
//        java.lang.String str22 = timePeriodValues15.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long26 = simpleTimePeriod25.getEndMillis();
//        long long27 = simpleTimePeriod25.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod25.getEnd();
//        long long29 = simpleTimePeriod25.getEndMillis();
//        java.lang.Number number30 = null;
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, number30);
//        java.util.Date date32 = simpleTimePeriod25.getStart();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        int int34 = year33.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.previous();
//        boolean boolean36 = day11.equals((java.lang.Object) year33);
//        int int38 = year33.compareTo((java.lang.Object) (short) 10);
//        int int39 = year33.getYear();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str10 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Date date3 = day0.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        int int7 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getItemCount();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
        java.lang.String str14 = timePeriodValues8.getDescription();
        java.lang.String str15 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        long long22 = simpleTimePeriod18.getEndMillis();
        java.lang.Number number23 = null;
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
        java.util.Date date25 = simpleTimePeriod18.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long30 = simpleTimePeriod29.getEndMillis();
        long long31 = simpleTimePeriod29.getEndMillis();
        java.util.Date date32 = simpleTimePeriod29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date25, timeZone33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date6, timeZone33);
        java.lang.Class class37 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long46 = simpleTimePeriod45.getEndMillis();
        long long47 = simpleTimePeriod45.getEndMillis();
        java.util.Date date48 = simpleTimePeriod45.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date42, timeZone49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long55 = simpleTimePeriod54.getEndMillis();
        long long56 = simpleTimePeriod54.getEndMillis();
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        java.util.Date date59 = day58.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date57, date59);
        java.lang.Class<?> wildcardClass61 = date59.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long65 = simpleTimePeriod64.getEndMillis();
        long long66 = simpleTimePeriod64.getEndMillis();
        java.util.Date date67 = simpleTimePeriod64.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date59, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date42, timeZone68);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date6, timeZone68);
        long long73 = year72.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-31507200000L) + "'", long73 == (-31507200000L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int13 = timePeriodValues12.getItemCount();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 100);
        java.lang.String str18 = timePeriodValues12.getDescription();
        java.lang.String str19 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        long long26 = simpleTimePeriod22.getEndMillis();
        java.lang.Number number27 = null;
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, number27);
        java.util.Date date29 = simpleTimePeriod22.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long34 = simpleTimePeriod33.getEndMillis();
        long long35 = simpleTimePeriod33.getEndMillis();
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date29, timeZone37);
        timePeriodValues1.setKey((java.lang.Comparable) date29);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        timePeriodValues1.setDescription("");
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        try {
            java.lang.Number number8 = timePeriodValues1.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (-1.0d) + "'", comparable6.equals((-1.0d)));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1.0d) + "'", obj2.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getItemCount();
        timePeriodValues1.delete((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesException: ", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
//        java.lang.Object obj6 = seriesChangeEvent5.getSource();
//        boolean boolean7 = timePeriodValues3.equals(obj6);
//        java.lang.Object obj8 = timePeriodValues3.clone();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (-1.0d) + "'", obj6.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(obj8);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 1.0f);
        java.util.Date date28 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date19, date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
//        java.lang.Class<?> wildcardClass9 = date7.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long13 = simpleTimePeriod12.getEndMillis();
//        long long14 = simpleTimePeriod12.getEndMillis();
//        java.util.Date date15 = simpleTimePeriod12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
//        long long19 = day18.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
        timePeriodValues1.setRangeDescription("");
        java.lang.Object obj25 = timePeriodValues1.clone();
        timePeriodValues1.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.util.Date date7 = day5.getEnd();
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        java.util.Date date11 = day9.getEnd();
//        int int12 = day5.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day5.next();
//        int int14 = day0.compareTo((java.lang.Object) regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setDescription("Time");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 1.0f);
        java.lang.Object obj8 = timePeriodValue7.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues6.setDomainDescription("Time");
        java.lang.Object obj9 = timePeriodValues6.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, 0.0d);
        int int14 = day10.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 13);
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day10, (double) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        timePeriodValues1.setKey((java.lang.Comparable) day10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 9L);
        java.lang.Object obj11 = timePeriodValue10.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        java.lang.String str2 = year0.toString();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getMiddleMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        java.util.Date date9 = day7.getEnd();
//        int int10 = day3.compareTo((java.lang.Object) day7);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100);
//        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValue13);
//        java.lang.Number number15 = null;
//        timePeriodValue13.setValue(number15);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        long long15 = day10.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day10, (double) 13);
//        boolean boolean19 = day10.equals((java.lang.Object) 12);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        timePeriodValues5.setDomainDescription("hi!");
        java.lang.Comparable comparable9 = timePeriodValues5.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues5.createCopy(2, (int) 'a');
        java.lang.Comparable comparable13 = timePeriodValues5.getKey();
        int int14 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener15);
        int int17 = year0.compareTo((java.lang.Object) seriesChangeListener15);
        long long18 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560365999999L);
//        timePeriodValue6.setValue((java.lang.Number) 1560409200000L);
//        java.lang.Number number9 = timePeriodValue6.getValue();
//        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue6.getPeriod();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560409200000L + "'", number9.equals(1560409200000L));
//        org.junit.Assert.assertNotNull(timePeriod10);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 100.0d);
        java.lang.Number number10 = timePeriodValue9.getValue();
        java.lang.Object obj11 = timePeriodValue9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
//        long long7 = day2.getFirstMillisecond();
//        long long8 = day2.getSerialIndex();
//        long long9 = day2.getSerialIndex();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day2.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        timePeriodValues3.add(timePeriodValue8);
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        java.lang.Number number10 = null;
        try {
            timePeriodValues8.update(7, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        long long3 = day1.getSerialIndex();
//        java.util.Date date4 = day1.getEnd();
//        java.util.Date date5 = day1.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long9 = simpleTimePeriod8.getEndMillis();
//        long long10 = simpleTimePeriod8.getEndMillis();
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date5, timeZone12);
//        try {
//            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date0, timeZone12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//    }
//}

