import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        long long25 = day23.getSerialIndex();
//        int int26 = day23.getDayOfMonth();
//        boolean boolean27 = timePeriodValue19.equals((java.lang.Object) int26);
//        java.lang.Object obj28 = timePeriodValue19.clone();
//        timePeriodValue19.setValue((java.lang.Number) (-1));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(obj28);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        java.util.Date date4 = day0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        timePeriodValues3.setDomainDescription("13-June-2019");
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        try {
//            timePeriodValues3.delete(0, 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int3 = timePeriodValues2.getItemCount();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) regularTimePeriod5, (double) 100);
        java.util.Date date8 = regularTimePeriod5.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date0, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day2);
//        int int8 = day2.getMonth();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getFirstMillisecond();
//        long long8 = day0.getFirstMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 1560409200000L);
//        long long12 = simpleTimePeriod11.getStartMillis();
//        int int13 = day0.compareTo((java.lang.Object) simpleTimePeriod11);
//        java.lang.Class<?> wildcardClass14 = day0.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9L + "'", long12 == 9L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.lang.String str7 = day6.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day6.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1));
        long long24 = year19.getSerialIndex();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year19.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1969L + "'", long24 == 1969L);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.lang.String str7 = timePeriodValues1.getDescription();
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        long long13 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date14 = simpleTimePeriod11.getEnd();
//        long long15 = simpleTimePeriod11.getEndMillis();
//        java.lang.Number number16 = null;
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
//        java.util.Date date18 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        long long24 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date25 = simpleTimePeriod22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int31 = timePeriodValues30.getItemCount();
//        timePeriodValues30.setDomainDescription("hi!");
//        java.lang.Comparable comparable34 = timePeriodValues30.getKey();
//        timePeriodValues30.setKey((java.lang.Comparable) 0);
//        timePeriodValues30.setNotify(true);
//        int int39 = timePeriodValues30.getMaxMiddleIndex();
//        java.lang.String str40 = timePeriodValues30.getRangeDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = timePeriodValues30.createCopy(2019, (int) '4');
//        int int44 = year28.compareTo((java.lang.Object) timePeriodValues43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long50 = simpleTimePeriod49.getEndMillis();
//        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod54 = timePeriodValues46.getTimePeriod(0);
//        boolean boolean55 = timePeriodValues46.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long59 = simpleTimePeriod58.getEndMillis();
//        long long60 = simpleTimePeriod58.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 10L);
//        timePeriodValue64.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues46.add(timePeriodValue64);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.previous();
//        long long70 = day68.getSerialIndex();
//        int int71 = day68.getDayOfMonth();
//        boolean boolean72 = timePeriodValue64.equals((java.lang.Object) int71);
//        java.lang.Number number73 = timePeriodValue64.getValue();
//        java.lang.String str74 = timePeriodValue64.toString();
//        org.jfree.data.time.TimePeriod timePeriod75 = timePeriodValue64.getPeriod();
//        boolean boolean76 = year28.equals((java.lang.Object) timePeriodValue64);
//        java.lang.Number number77 = timePeriodValue64.getValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertNotNull(timePeriodValues43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43629L + "'", long70 == 43629L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 13 + "'", int71 == 13);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + number73 + "' != '" + (-1.0f) + "'", number73.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(timePeriod75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + number77 + "' != '" + (-1.0f) + "'", number77.equals((-1.0f)));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getItemCount();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
        java.lang.String str14 = timePeriodValues8.getDescription();
        java.lang.String str15 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        long long22 = simpleTimePeriod18.getEndMillis();
        java.lang.Number number23 = null;
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
        java.util.Date date25 = simpleTimePeriod18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long29 = simpleTimePeriod28.getEndMillis();
        java.util.Date date30 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date25, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date4, timeZone31);
        long long35 = day34.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-57600000L) + "'", long35 == (-57600000L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue8.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(timePeriod12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        long long15 = day10.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day10, (double) 13);
//        org.jfree.data.time.SerialDate serialDate18 = day10.getSerialDate();
//        int int19 = day10.getDayOfMonth();
//        java.util.Calendar calendar20 = null;
//        try {
//            day10.peg(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        java.lang.Object obj13 = timePeriodValues12.clone();
        java.lang.String str14 = timePeriodValues12.getRangeDescription();
        timePeriodValues12.setRangeDescription("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Object obj9 = timePeriodValue8.clone();
        java.lang.Number number10 = timePeriodValue8.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10L + "'", number10.equals(10L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        timePeriodValues1.setNotify(true);
        int int6 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 6);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getFirstMillisecond();
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str11 = timePeriodFormatException10.toString();
//        java.lang.String str12 = timePeriodFormatException10.toString();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str16 = timePeriodFormatException15.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        int int22 = day0.compareTo((java.lang.Object) timePeriodFormatException6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        timePeriodValues9.setDomainDescription("hi!");
        java.lang.Comparable comparable13 = timePeriodValues9.getKey();
        timePeriodValues9.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues9.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues9.createCopy((int) (short) 0, (int) (byte) -1);
        int int21 = timePeriodValues9.getMinMiddleIndex();
        timePeriodValues9.setNotify(false);
        int int24 = timePeriodValues9.getMinStartIndex();
        int int25 = day7.compareTo((java.lang.Object) timePeriodValues9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.util.Date date6 = day4.getEnd();
//        int int7 = day0.compareTo((java.lang.Object) day4);
//        java.util.Date date8 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100);
//        java.util.Date date11 = day4.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy((-1), (int) (short) 10);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues5.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        long long25 = day23.getSerialIndex();
//        int int26 = day23.getDayOfMonth();
//        boolean boolean27 = timePeriodValue19.equals((java.lang.Object) int26);
//        java.lang.Number number28 = timePeriodValue19.getValue();
//        timePeriodValue19.setValue((java.lang.Number) (-14400001L));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0f) + "'", number28.equals((-1.0f)));
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int5 = timePeriodValues4.getItemCount();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod7, (double) 100);
//        java.lang.String str10 = timePeriodValues4.getDescription();
//        java.lang.String str11 = timePeriodValues4.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        long long16 = simpleTimePeriod14.getEndMillis();
//        java.util.Date date17 = simpleTimePeriod14.getEnd();
//        long long18 = simpleTimePeriod14.getEndMillis();
//        java.lang.Number number19 = null;
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, number19);
//        java.util.Date date21 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        int int23 = year22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
//        boolean boolean25 = day0.equals((java.lang.Object) year22);
//        int int27 = year22.compareTo((java.lang.Object) (short) 10);
//        java.lang.Class<?> wildcardClass28 = year22.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 0.0d);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        int int3 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        int int10 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
//        long long11 = day7.getLastMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day7.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.delete(8, 1);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        timePeriodValues1.delete(0, (int) (short) 0);
//        timePeriodValues1.fireSeriesChanged();
//        int int12 = timePeriodValues1.getMinMiddleIndex();
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        int int17 = day15.getDayOfMonth();
//        java.util.Date date18 = day15.getStart();
//        timePeriodValues1.setKey((java.lang.Comparable) day15);
//        timePeriodValues1.setRangeDescription("13-June-2019");
//        java.lang.String str22 = timePeriodValues1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "TimePeriodValue[13-June-2019,1577865599999]", "TimePeriodValue[13-June-2019,0]", "1969");
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        long long8 = day7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        boolean boolean10 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        long long15 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
        timePeriodValues1.add(timePeriodValue19);
        int int23 = timePeriodValues1.getMinStartIndex();
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int31 = timePeriodValues30.getItemCount();
        timePeriodValues30.setDomainDescription("hi!");
        java.lang.Comparable comparable34 = timePeriodValues30.getKey();
        timePeriodValues30.setKey((java.lang.Comparable) 0);
        timePeriodValues30.setNotify(true);
        int int39 = timePeriodValues30.getMaxMiddleIndex();
        java.lang.String str40 = timePeriodValues30.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = timePeriodValues30.createCopy(2019, (int) '4');
        int int44 = year28.compareTo((java.lang.Object) timePeriodValues43);
        timePeriodValues43.delete(6, 0);
        java.lang.Comparable comparable48 = timePeriodValues43.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 0 + "'", comparable48.equals(0));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, 1562097599999L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.lang.String str7 = timePeriodValues1.getDescription();
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        long long13 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date14 = simpleTimePeriod11.getEnd();
//        long long15 = simpleTimePeriod11.getEndMillis();
//        java.lang.Number number16 = null;
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
//        java.util.Date date18 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date24 = simpleTimePeriod22.getStart();
//        java.util.Date date25 = simpleTimePeriod22.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        boolean boolean32 = year26.equals((java.lang.Object) class27);
//        boolean boolean33 = year19.equals((java.lang.Object) boolean32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getStart();
//        java.lang.String str36 = day34.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
//        java.util.Date date38 = day34.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.previous();
//        int int40 = year19.compareTo((java.lang.Object) day34);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setDescription("Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Date date3 = day0.getStart();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = day0.equals(obj4);
//        java.util.Date date6 = day0.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        long long9 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        timePeriodValue8.setValue((java.lang.Number) (byte) 100);
        java.lang.Object obj14 = timePeriodValue8.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long8 = simpleTimePeriod7.getEndMillis();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues4.getTimePeriod(0);
//        boolean boolean13 = timePeriodValues4.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        long long18 = simpleTimePeriod16.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 10L);
//        timePeriodValue22.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues4.add(timePeriodValue22);
//        java.lang.Object obj26 = timePeriodValue22.clone();
//        java.lang.Object obj27 = timePeriodValue22.clone();
//        java.lang.Object obj28 = timePeriodValue22.clone();
//        int int29 = day0.compareTo((java.lang.Object) timePeriodValue22);
//        timePeriodValue22.setValue((java.lang.Number) 2);
//        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue22.getPeriod();
//        timePeriodValue22.setValue((java.lang.Number) (-57600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(timePeriod32);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        timePeriodValues1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "Time", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues8.removePropertyChangeListener(propertyChangeListener9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long31 = simpleTimePeriod30.getEndMillis();
//        java.util.Date date32 = simpleTimePeriod30.getStart();
//        java.util.Date date33 = simpleTimePeriod30.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        java.lang.String str35 = year34.toString();
//        boolean boolean36 = day0.equals((java.lang.Object) str35);
//        java.util.Date date37 = day0.getEnd();
//        int int38 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969" + "'", str35.equals("1969"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.util.Date date7 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        timePeriodValues9.setDomainDescription("hi!");
        java.lang.Comparable comparable13 = timePeriodValues9.getKey();
        timePeriodValues9.setKey((java.lang.Comparable) 0);
        timePeriodValues9.setNotify(true);
        int int18 = timePeriodValues9.getMaxMiddleIndex();
        java.lang.String str19 = timePeriodValues9.getRangeDescription();
        java.lang.String str20 = timePeriodValues9.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long24 = simpleTimePeriod23.getEndMillis();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        java.util.Date date26 = simpleTimePeriod23.getStart();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod23, (java.lang.Number) (byte) 10);
        java.lang.Object obj29 = timePeriodValues9.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long33 = simpleTimePeriod32.getEndMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        long long36 = simpleTimePeriod32.getStartMillis();
        java.util.Date date37 = simpleTimePeriod32.getStart();
        java.util.Date date38 = simpleTimePeriod32.getEnd();
        timePeriodValues9.setKey((java.lang.Comparable) date38);
        try {
            int int40 = simpleTimePeriod2.compareTo((java.lang.Object) date38);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
        java.lang.String str11 = timePeriodValues5.getDescription();
        java.lang.String str12 = timePeriodValues5.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (byte) 1);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Object obj21 = null;
        boolean boolean22 = timePeriodValue19.equals(obj21);
        timePeriodValues5.add(timePeriodValue19);
        boolean boolean24 = year0.equals((java.lang.Object) timePeriodValues5);
        java.util.Date date25 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 1 + "'", number20.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod7, (java.lang.Number) (byte) 1);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue11.getPeriod();
        timePeriodValues1.add(timePeriodValue11);
        int int15 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        boolean boolean7 = day0.equals((java.lang.Object) (-1.0d));
//        java.util.Date date8 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        int int6 = day2.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        int int5 = day0.getDayOfMonth();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.lang.String str7 = timePeriodValues1.getDescription();
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        long long13 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date14 = simpleTimePeriod11.getEnd();
//        long long15 = simpleTimePeriod11.getEndMillis();
//        java.lang.Number number16 = null;
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
//        java.util.Date date18 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
//        java.lang.Object obj20 = timePeriodValues19.clone();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        long long23 = day21.getLastMillisecond();
//        int int24 = day21.getDayOfMonth();
//        timePeriodValues19.setKey((java.lang.Comparable) day21);
//        java.util.Date date26 = day21.getEnd();
//        long long27 = day21.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-57600000L) + "'", long9 == (-57600000L));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
//        long long7 = day2.getFirstMillisecond();
//        int int8 = day2.getMonth();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (double) 'a');
        java.lang.String str17 = timePeriodValues10.getDescription();
        boolean boolean19 = timePeriodValues10.equals((java.lang.Object) (short) 1);
        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) (short) 1);
        java.util.Date date21 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (-1L));
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        java.lang.String str5 = timePeriodValues1.getDescription();
        int int6 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getMaxStartIndex();
        int int10 = timePeriodValues8.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int13 = timePeriodValues12.getItemCount();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 100);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 10L);
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        int int9 = day5.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day5, (double) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValues15.getTimePeriod(0);
        boolean boolean24 = timePeriodValues15.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long28 = simpleTimePeriod27.getEndMillis();
        long long29 = simpleTimePeriod27.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod27, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod27, (java.lang.Number) 10L);
        timePeriodValue33.setValue((java.lang.Number) (-1.0f));
        timePeriodValues15.add(timePeriodValue33);
        java.lang.Number number37 = timePeriodValue33.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int40 = timePeriodValues39.getItemCount();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
        timePeriodValues39.add((org.jfree.data.time.TimePeriod) regularTimePeriod42, (double) 100);
        java.lang.String str45 = timePeriodValues39.getDescription();
        java.lang.String str46 = timePeriodValues39.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long50 = simpleTimePeriod49.getEndMillis();
        long long51 = simpleTimePeriod49.getEndMillis();
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        long long53 = simpleTimePeriod49.getEndMillis();
        java.lang.Number number54 = null;
        timePeriodValues39.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, number54);
        java.util.Date date56 = simpleTimePeriod49.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long60 = simpleTimePeriod59.getEndMillis();
        java.util.Date date61 = simpleTimePeriod59.getStart();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61, timeZone62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date56, timeZone62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long68 = simpleTimePeriod67.getEndMillis();
        long long69 = simpleTimePeriod67.getEndMillis();
        java.util.Date date70 = simpleTimePeriod67.getEnd();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date56, timeZone71);
        boolean boolean74 = timePeriodValue33.equals((java.lang.Object) timeZone71);
        timePeriodValues1.add(timePeriodValue33);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(timePeriod23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0f) + "'", number37.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
//        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
//        java.lang.Number number12 = timePeriodValue8.getValue();
//        java.lang.String str13 = timePeriodValue8.toString();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int17 = timePeriodValues16.getMaxStartIndex();
//        int int18 = timePeriodValues16.getMinEndIndex();
//        boolean boolean19 = timePeriodValues16.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        long long24 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date25 = simpleTimePeriod22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day27, (double) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long35 = simpleTimePeriod34.getEndMillis();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod39 = timePeriodValues31.getTimePeriod(0);
//        boolean boolean40 = timePeriodValues31.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long44 = simpleTimePeriod43.getEndMillis();
//        long long45 = simpleTimePeriod43.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod43, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod43, (java.lang.Number) 10L);
//        timePeriodValue49.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues31.add(timePeriodValue49);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        long long55 = day53.getSerialIndex();
//        int int56 = day53.getDayOfMonth();
//        boolean boolean57 = timePeriodValue49.equals((java.lang.Object) int56);
//        java.lang.Number number58 = timePeriodValue49.getValue();
//        java.lang.String str59 = timePeriodValue49.toString();
//        timePeriodValues16.add(timePeriodValue49);
//        boolean boolean61 = timePeriodValue8.equals((java.lang.Object) timePeriodValues16);
//        java.lang.String str62 = timePeriodValues16.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 13 + "'", int56 == 13);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1.0f) + "'", number58.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Value" + "'", str62.equals("Value"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        int int9 = day5.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day5, (double) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day5.next();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 2);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560365999999L);
//        long long7 = day0.getSerialIndex();
//        long long8 = day0.getLastMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date13 = simpleTimePeriod11.getStart();
//        java.util.Date date14 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        int int16 = year15.getYear();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        long long21 = simpleTimePeriod19.getEndMillis();
//        java.util.Date date22 = simpleTimePeriod19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
//        boolean boolean25 = year15.equals((java.lang.Object) date22);
//        boolean boolean26 = day0.equals((java.lang.Object) date22);
//        long long27 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        int int5 = timePeriodValues1.getMaxEndIndex();
        try {
            timePeriodValues1.delete(7, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues15.createCopy((int) (byte) -1, 5);
        timePeriodValues15.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(timePeriodValues18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues6.getTimePeriod(0);
        boolean boolean15 = timePeriodValues6.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
        timePeriodValue24.setValue((java.lang.Number) (-1.0f));
        timePeriodValues6.add(timePeriodValue24);
        java.lang.Object obj28 = timePeriodValue24.clone();
        timePeriodValues1.add(timePeriodValue24);
        java.lang.Object obj30 = timePeriodValue24.clone();
        java.lang.Class<?> wildcardClass31 = timePeriodValue24.getClass();
        java.lang.Object obj32 = timePeriodValue24.clone();
        java.lang.Number number33 = timePeriodValue24.getValue();
        java.lang.Number number34 = timePeriodValue24.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0f) + "'", number33.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0f) + "'", number34.equals((-1.0f)));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1562097599999L, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        int int9 = day5.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day5, (double) 10);
        java.lang.String str14 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        timePeriodValues1.setNotify(false);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues1.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        java.lang.Object obj13 = timePeriodValues12.clone();
        java.lang.String str14 = timePeriodValues12.getRangeDescription();
        try {
            timePeriodValues12.update((int) (byte) 100, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        long long18 = simpleTimePeriod16.getEndMillis();
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        long long21 = simpleTimePeriod16.getStartMillis();
        long long22 = simpleTimePeriod16.getStartMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long28 = simpleTimePeriod27.getEndMillis();
        long long29 = simpleTimePeriod27.getEndMillis();
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod27, (double) 1.0f);
        java.util.Date date33 = simpleTimePeriod27.getEnd();
        int int34 = simpleTimePeriod16.compareTo((java.lang.Object) simpleTimePeriod27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        int int6 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        timePeriodValues1.setRangeDescription("");
        boolean boolean16 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        timePeriodValues1.delete(0, (int) (short) 0);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
//        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
//        timePeriodValues1.setRangeDescription("");
//        java.lang.Object obj25 = timePeriodValues1.clone();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 0.0d);
//        long long30 = day26.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (double) 1560365999999L);
//        timePeriodValues1.add(timePeriodValue32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener34);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMaxStartIndex();
//        int int3 = timePeriodValues1.getMinEndIndex();
//        boolean boolean4 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long8 = simpleTimePeriod7.getEndMillis();
//        long long9 = simpleTimePeriod7.getEndMillis();
//        java.util.Date date10 = simpleTimePeriod7.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (double) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValues16.getTimePeriod(0);
//        boolean boolean25 = timePeriodValues16.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long29 = simpleTimePeriod28.getEndMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 10L);
//        timePeriodValue34.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues16.add(timePeriodValue34);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        long long40 = day38.getSerialIndex();
//        int int41 = day38.getDayOfMonth();
//        boolean boolean42 = timePeriodValue34.equals((java.lang.Object) int41);
//        java.lang.Number number43 = timePeriodValue34.getValue();
//        java.lang.String str44 = timePeriodValue34.toString();
//        timePeriodValues1.add(timePeriodValue34);
//        java.lang.Comparable comparable46 = timePeriodValues1.getKey();
//        int int47 = timePeriodValues1.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43629L + "'", long40 == 43629L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 13 + "'", int41 == 13);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0f) + "'", number43.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + (-1.0d) + "'", comparable46.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560409200000L, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setNotify(false);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.String str12 = seriesChangeEvent11.toString();
        java.lang.String str13 = seriesChangeEvent11.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.previous();
        java.util.Date date17 = day14.getStart();
        java.lang.Class class18 = null;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getFirstMillisecond();
        long long21 = year19.getLastMillisecond();
        long long22 = year19.getLastMillisecond();
        long long23 = year19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.next();
        java.util.Date date25 = year19.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int28 = timePeriodValues27.getItemCount();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) regularTimePeriod30, (double) 100);
        java.lang.String str33 = timePeriodValues27.getDescription();
        java.lang.String str34 = timePeriodValues27.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long38 = simpleTimePeriod37.getEndMillis();
        long long39 = simpleTimePeriod37.getEndMillis();
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        long long41 = simpleTimePeriod37.getEndMillis();
        java.lang.Number number42 = null;
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod37, number42);
        java.util.Date date44 = simpleTimePeriod37.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long48 = simpleTimePeriod47.getEndMillis();
        java.util.Date date49 = simpleTimePeriod47.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date44, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date25, timeZone50);
        java.lang.Class<?> wildcardClass54 = timeZone50.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date17, timeZone50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNull(regularTimePeriod55);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = seriesException1.toString();
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 1.0f);
//        int int8 = day5.getYear();
//        long long9 = day5.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day5);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) -1);
//        java.util.Date date13 = day5.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.delete((int) 'a', (-1));
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getMaxStartIndex();
        int int11 = timePeriodValues9.getMinEndIndex();
        boolean boolean12 = timePeriodValues9.isEmpty();
        java.lang.Class<?> wildcardClass13 = timePeriodValues9.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        java.util.Date date20 = simpleTimePeriod17.getStart();
        java.util.Date date21 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long26 = simpleTimePeriod25.getEndMillis();
        java.util.Date date27 = simpleTimePeriod25.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int32 = timePeriodValues31.getItemCount();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) regularTimePeriod34, (double) 100);
        java.lang.String str37 = timePeriodValues31.getDescription();
        java.lang.String str38 = timePeriodValues31.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long42 = simpleTimePeriod41.getEndMillis();
        long long43 = simpleTimePeriod41.getEndMillis();
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        long long45 = simpleTimePeriod41.getEndMillis();
        java.lang.Number number46 = null;
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, number46);
        java.util.Date date48 = simpleTimePeriod41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long52 = simpleTimePeriod51.getEndMillis();
        java.util.Date date53 = simpleTimePeriod51.getStart();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date53, timeZone54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date48, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date27, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date21, timeZone54);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod58, (double) 1562097599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long4 = simpleTimePeriod3.getEndMillis();
        java.util.Date date5 = simpleTimePeriod3.getStart();
        java.util.Date date6 = simpleTimePeriod3.getStart();
        java.util.Date date7 = simpleTimePeriod3.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        java.lang.String str15 = timePeriodValues9.getDescription();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        long long23 = simpleTimePeriod19.getEndMillis();
        java.lang.Number number24 = null;
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, number24);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date26, timeZone34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date7, timeZone34);
        java.lang.Class class38 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long42 = simpleTimePeriod41.getEndMillis();
        java.util.Date date43 = simpleTimePeriod41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long47 = simpleTimePeriod46.getEndMillis();
        long long48 = simpleTimePeriod46.getEndMillis();
        java.util.Date date49 = simpleTimePeriod46.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date43, timeZone50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long56 = simpleTimePeriod55.getEndMillis();
        long long57 = simpleTimePeriod55.getEndMillis();
        java.util.Date date58 = simpleTimePeriod55.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.util.Date date60 = day59.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date58, date60);
        java.lang.Class<?> wildcardClass62 = date60.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long66 = simpleTimePeriod65.getEndMillis();
        long long67 = simpleTimePeriod65.getEndMillis();
        java.util.Date date68 = simpleTimePeriod65.getEnd();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date68, timeZone69);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date60, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone69);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date7, timeZone69);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(date0, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date13 = simpleTimePeriod11.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13, timeZone14);
//        int int16 = day8.compareTo((java.lang.Object) timeZone14);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        boolean boolean10 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 100.0d);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 31);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        boolean boolean7 = day0.equals((java.lang.Object) (-1.0d));
//        int int8 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getItemCount();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
        java.lang.String str14 = timePeriodValues8.getDescription();
        java.lang.String str15 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        long long22 = simpleTimePeriod18.getEndMillis();
        java.lang.Number number23 = null;
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
        java.util.Date date25 = simpleTimePeriod18.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long30 = simpleTimePeriod29.getEndMillis();
        long long31 = simpleTimePeriod29.getEndMillis();
        java.util.Date date32 = simpleTimePeriod29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date25, timeZone33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date6, timeZone33);
        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
        java.lang.String str38 = day36.toString();
        int int39 = day36.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31-December-1969" + "'", str38.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int8 = timePeriodValues7.getItemCount();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
        java.lang.String str13 = timePeriodValues7.getDescription();
        java.lang.String str14 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getEndMillis();
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        long long21 = simpleTimePeriod17.getEndMillis();
        java.lang.Number number22 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, number22);
        java.util.Date date24 = simpleTimePeriod17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int27 = timePeriodValues26.getItemCount();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) regularTimePeriod29, (double) 100);
        java.lang.String str32 = timePeriodValues26.getDescription();
        java.lang.String str33 = timePeriodValues26.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long37 = simpleTimePeriod36.getEndMillis();
        long long38 = simpleTimePeriod36.getEndMillis();
        java.util.Date date39 = simpleTimePeriod36.getEnd();
        long long40 = simpleTimePeriod36.getEndMillis();
        java.lang.Number number41 = null;
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod36, number41);
        java.util.Date date43 = simpleTimePeriod36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long47 = simpleTimePeriod46.getEndMillis();
        java.util.Date date48 = simpleTimePeriod46.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date43, timeZone49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long55 = simpleTimePeriod54.getEndMillis();
        long long56 = simpleTimePeriod54.getEndMillis();
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57, timeZone58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date43, timeZone58);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date24, timeZone58);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date5, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues6.getTimePeriod(0);
        boolean boolean15 = timePeriodValues6.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
        timePeriodValue24.setValue((java.lang.Number) (-1.0f));
        timePeriodValues6.add(timePeriodValue24);
        java.lang.Object obj28 = timePeriodValue24.clone();
        timePeriodValues1.add(timePeriodValue24);
        int int30 = timePeriodValues1.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValues1.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.String str6 = timePeriodFormatException5.toString();
        boolean boolean7 = year0.equals((java.lang.Object) timePeriodFormatException5);
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.lang.String str28 = day0.toString();
//        java.lang.String str29 = day0.toString();
//        long long30 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate31 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 10L);
        boolean boolean13 = timePeriodValues1.isEmpty();
        timePeriodValues1.delete((int) '4', 0);
        timePeriodValues1.delete((int) (byte) 100, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', 1577865599999L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        long long6 = year4.getLastMillisecond();
        long long7 = year4.getLastMillisecond();
        long long8 = year4.getLastMillisecond();
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        int int11 = simpleTimePeriod2.compareTo((java.lang.Object) year4);
        int int12 = year4.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.lang.Class<?> wildcardClass8 = simpleTimePeriod2.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        java.lang.String str10 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        int int4 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        long long12 = year10.getMiddleMillisecond();
        boolean boolean14 = year10.equals((java.lang.Object) 1546329600000L);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int12 = timePeriodValues11.getItemCount();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (double) 100);
        java.lang.String str17 = timePeriodValues11.getDescription();
        java.lang.String str18 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long22 = simpleTimePeriod21.getEndMillis();
        long long23 = simpleTimePeriod21.getEndMillis();
        java.util.Date date24 = simpleTimePeriod21.getEnd();
        long long25 = simpleTimePeriod21.getEndMillis();
        java.lang.Number number26 = null;
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, number26);
        java.util.Date date28 = simpleTimePeriod21.getStart();
        java.util.Date date29 = simpleTimePeriod21.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long33 = simpleTimePeriod32.getEndMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 1.0f);
        java.util.Date date38 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long43 = simpleTimePeriod42.getEndMillis();
        long long44 = simpleTimePeriod42.getEndMillis();
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        java.util.Date date47 = day46.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date45, date47);
        java.lang.Class<?> wildcardClass49 = date47.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long53 = simpleTimePeriod52.getEndMillis();
        long long54 = simpleTimePeriod52.getEndMillis();
        java.util.Date date55 = simpleTimePeriod52.getEnd();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date55, timeZone56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date47, timeZone56);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date38, timeZone56);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date9, timeZone56);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
        java.util.Date date8 = regularTimePeriod4.getStart();
        java.lang.Class class9 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        java.util.Date date14 = simpleTimePeriod12.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getEndMillis();
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date14, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long27 = simpleTimePeriod26.getEndMillis();
        long long28 = simpleTimePeriod26.getEndMillis();
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date29, date31);
        java.lang.Class<?> wildcardClass33 = date31.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long37 = simpleTimePeriod36.getEndMillis();
        long long38 = simpleTimePeriod36.getEndMillis();
        java.util.Date date39 = simpleTimePeriod36.getEnd();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date31, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone40);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date8, timeZone40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod43);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.lang.Class<?> wildcardClass6 = simpleTimePeriod2.getClass();
        long long7 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) (byte) 100);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        int int5 = day0.compareTo((java.lang.Object) day2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int8 = timePeriodValues7.getItemCount();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
        java.lang.String str13 = timePeriodValues7.getDescription();
        java.lang.String str14 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getEndMillis();
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        long long21 = simpleTimePeriod17.getEndMillis();
        java.lang.Number number22 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, number22);
        java.util.Date date24 = simpleTimePeriod17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int27 = timePeriodValues26.getItemCount();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) regularTimePeriod29, (double) 100);
        java.lang.String str32 = timePeriodValues26.getDescription();
        java.lang.String str33 = timePeriodValues26.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long37 = simpleTimePeriod36.getEndMillis();
        long long38 = simpleTimePeriod36.getEndMillis();
        java.util.Date date39 = simpleTimePeriod36.getEnd();
        long long40 = simpleTimePeriod36.getEndMillis();
        java.lang.Number number41 = null;
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod36, number41);
        java.util.Date date43 = simpleTimePeriod36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long47 = simpleTimePeriod46.getEndMillis();
        java.util.Date date48 = simpleTimePeriod46.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date43, timeZone49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long55 = simpleTimePeriod54.getEndMillis();
        long long56 = simpleTimePeriod54.getEndMillis();
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57, timeZone58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date43, timeZone58);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date24, timeZone58);
        boolean boolean62 = day2.equals((java.lang.Object) day61);
        int int63 = day2.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int6 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) 10L);
        boolean boolean13 = timePeriodValues1.isEmpty();
        timePeriodValues1.delete((int) '4', 0);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        timePeriodValues1.delete(0, (int) (short) 0);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod(0);
//        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) timePeriod21);
//        timePeriodValues1.setRangeDescription("");
//        java.lang.Object obj25 = timePeriodValues1.clone();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 0.0d);
//        long long30 = day26.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (double) 1560365999999L);
//        timePeriodValues1.add(timePeriodValue32);
//        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue32.getPeriod();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//        org.junit.Assert.assertNotNull(timePeriod34);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        java.util.Date date13 = simpleTimePeriod11.getStart();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 10L);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (-1.0d));
        java.lang.String str18 = timePeriodValues1.getDomainDescription();
        int int19 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 5);
//        int int8 = day0.getMonth();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day0.equals(obj9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        int int8 = timePeriodValues7.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        long long20 = year19.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10.0d);
//        timePeriodValue8.setValue((java.lang.Number) 1577865599999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int13 = timePeriodValues12.getMaxEndIndex();
//        timePeriodValues12.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long21 = simpleTimePeriod20.getEndMillis();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValues17.getTimePeriod(0);
//        boolean boolean26 = timePeriodValues17.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (java.lang.Number) 10L);
//        timePeriodValue35.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues17.add(timePeriodValue35);
//        java.lang.Object obj39 = timePeriodValue35.clone();
//        timePeriodValues12.add(timePeriodValue35);
//        java.lang.Object obj41 = timePeriodValue35.clone();
//        boolean boolean42 = timePeriodValue8.equals((java.lang.Object) timePeriodValue35);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertNotNull(obj39);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1));
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year19.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.lang.String str28 = day0.toString();
//        java.lang.String str29 = day0.toString();
//        java.util.Date date30 = day0.getEnd();
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = day0.getLastMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date30);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        long long9 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int11 = timePeriodValues10.getItemCount();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (double) 100);
        java.util.Date date16 = regularTimePeriod13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        try {
            int int18 = simpleTimePeriod2.compareTo((java.lang.Object) date16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 1.0f);
        java.util.Date date28 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date19, date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long33 = simpleTimePeriod32.getEndMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date35, date37);
        java.lang.Class<?> wildcardClass39 = date37.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long43 = simpleTimePeriod42.getEndMillis();
        long long44 = simpleTimePeriod42.getEndMillis();
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date37, timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date28, timeZone46);
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int53 = timePeriodValues52.getItemCount();
        timePeriodValues52.setDomainDescription("hi!");
        java.lang.Comparable comparable56 = timePeriodValues52.getKey();
        timePeriodValues52.setRangeDescription("13-June-2019");
        boolean boolean59 = timePeriodValues52.getNotify();
        boolean boolean60 = year49.equals((java.lang.Object) timePeriodValues52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + comparable56 + "' != '" + (-1.0d) + "'", comparable56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int4 = timePeriodValues3.getItemCount();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod6, (double) 100);
        java.util.Date date9 = regularTimePeriod6.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int13 = timePeriodValues12.getItemCount();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 100);
        java.lang.String str18 = timePeriodValues12.getDescription();
        java.lang.String str19 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        long long26 = simpleTimePeriod22.getEndMillis();
        java.lang.Number number27 = null;
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, number27);
        java.util.Date date29 = simpleTimePeriod22.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long34 = simpleTimePeriod33.getEndMillis();
        long long35 = simpleTimePeriod33.getEndMillis();
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date29, timeZone37);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date9, timeZone37);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date1, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 'a');
        timePeriodValues16.delete(0, (int) (short) 0);
        timePeriodValues16.setDescription("");
        int int28 = timePeriodValues16.getMaxEndIndex();
        int int29 = day14.compareTo((java.lang.Object) int28);
        int int30 = year13.compareTo((java.lang.Object) day14);
        long long31 = year13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        int int7 = timePeriodValues1.getMinMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        int int27 = day17.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 13 + "'", int27 == 13);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) 10, 13);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener9);
        timePeriodValues8.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        java.lang.Class<?> wildcardClass6 = simpleTimePeriod2.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getStart();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) 10L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (-1.0d));
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long29 = simpleTimePeriod28.getEndMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date31, date33);
//        java.lang.Class<?> wildcardClass35 = date33.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        long long40 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date41 = simpleTimePeriod38.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date33, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date25, timeZone42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int48 = timePeriodValues47.getItemCount();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) regularTimePeriod50, (double) 100);
//        java.lang.Class<?> wildcardClass53 = regularTimePeriod50.getClass();
//        java.util.Date date54 = regularTimePeriod50.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        int int56 = year55.getYear();
//        java.lang.Object obj57 = null;
//        int int58 = year55.compareTo(obj57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.previous();
//        long long61 = day59.getSerialIndex();
//        java.util.Date date62 = day59.getEnd();
//        java.util.Date date63 = day59.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long67 = simpleTimePeriod66.getEndMillis();
//        long long68 = simpleTimePeriod66.getEndMillis();
//        java.util.Date date69 = simpleTimePeriod66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date63, timeZone70);
//        boolean boolean73 = year55.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date54, timeZone70);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 43629L + "'", long61 == 43629L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Object obj9 = timePeriodValue8.clone();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue(timePeriod11, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue13.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(timePeriod14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.util.Date date6 = day4.getEnd();
//        int int7 = day0.compareTo((java.lang.Object) day4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.util.Date date9 = day0.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day10.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 9L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
//        java.lang.String str9 = timePeriodValues8.getDomainDescription();
//        java.lang.String str10 = timePeriodValues8.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
//        boolean boolean13 = day0.equals((java.lang.Object) propertyChangeListener11);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1));
        long long24 = year19.getSerialIndex();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year19.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1969L + "'", long24 == 1969L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.setNotify(true);
        boolean boolean10 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', 1577865599999L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        long long6 = year4.getLastMillisecond();
        long long7 = year4.getLastMillisecond();
        long long8 = year4.getLastMillisecond();
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        int int11 = simpleTimePeriod2.compareTo((java.lang.Object) year4);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10.0d);
//        timePeriodValue8.setValue((java.lang.Number) 1577865599999L);
//        java.lang.String str11 = timePeriodValue8.toString();
//        java.lang.Number number12 = timePeriodValue8.getValue();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,1577865599999]" + "'", str11.equals("TimePeriodValue[13-June-2019,1577865599999]"));
//        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1577865599999L + "'", number12.equals(1577865599999L));
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
//        int int5 = day0.compareTo((java.lang.Object) day2);
//        long long6 = day2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        try {
            timePeriodValues1.update((int) (byte) 10, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day5, "TimePeriodValue[13-June-2019,0]", "1969");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
//        java.lang.Class<?> wildcardClass9 = date7.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long13 = simpleTimePeriod12.getEndMillis();
//        long long14 = simpleTimePeriod12.getEndMillis();
//        java.util.Date date15 = simpleTimePeriod12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        long long21 = day19.getSerialIndex();
//        java.util.Date date22 = day19.getEnd();
//        boolean boolean23 = day18.equals((java.lang.Object) day19);
//        int int24 = day18.getYear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setRangeDescription("hi!");
        boolean boolean7 = timePeriodValues1.getNotify();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        try {
            timePeriodValues1.update(3, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1L) + "'", comparable8.equals((-1L)));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        int int16 = timePeriodValues1.getMinStartIndex();
        int int17 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        boolean boolean14 = timePeriodValues1.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        long long19 = simpleTimePeriod17.getEndMillis();
        long long20 = simpleTimePeriod17.getStartMillis();
        long long21 = simpleTimePeriod17.getStartMillis();
        long long22 = simpleTimePeriod17.getEndMillis();
        timePeriodValues1.setKey((java.lang.Comparable) long22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int7 = timePeriodValues6.getMaxEndIndex();
//        timePeriodValues6.fireSeriesChanged();
//        int int9 = timePeriodValues6.getMaxMiddleIndex();
//        java.lang.String str10 = timePeriodValues6.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        java.util.Date date15 = simpleTimePeriod13.getStart();
//        java.util.Date date16 = simpleTimePeriod13.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues6.removeChangeListener(seriesChangeListener21);
//        timePeriodValues6.setNotify(false);
//        boolean boolean25 = day0.equals((java.lang.Object) timePeriodValues6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(date5, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
//        long long4 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1969);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31507200000L) + "'", long2 == (-31507200000L));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "Time", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.lang.String str9 = timePeriodValues8.getDomainDescription();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        java.lang.String str14 = timePeriodValues8.getDescription();
//        java.lang.String str15 = timePeriodValues8.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        long long20 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        long long22 = simpleTimePeriod18.getEndMillis();
//        java.lang.Number number23 = null;
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
//        java.util.Date date25 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        int int27 = day0.compareTo((java.lang.Object) year26);
//        java.lang.String str28 = day0.toString();
//        java.lang.String str29 = day0.toString();
//        java.util.Date date30 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        boolean boolean11 = timePeriodValue6.equals((java.lang.Object) 3);
        java.lang.Object obj12 = timePeriodValue6.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        java.util.Date date17 = simpleTimePeriod15.getStart();
        java.util.Date date18 = simpleTimePeriod15.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.lang.Class class20 = null;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        boolean boolean25 = year19.equals((java.lang.Object) class20);
        boolean boolean26 = timePeriodValue6.equals((java.lang.Object) year19);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timePeriod27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        java.util.Date date5 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        long long7 = day6.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getLastMillisecond();
//        long long11 = year8.getLastMillisecond();
//        long long12 = year8.getLastMillisecond();
//        java.lang.String str13 = year8.toString();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long17 = simpleTimePeriod16.getEndMillis();
//        long long18 = simpleTimePeriod16.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 10L);
//        timePeriodValue22.setValue((java.lang.Number) (-1.0f));
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue22);
//        java.lang.Number number26 = timePeriodValue22.getValue();
//        java.lang.String str27 = timePeriodValue22.toString();
//        java.lang.String str28 = timePeriodValue22.toString();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getStart();
//        int int31 = day29.getDayOfMonth();
//        boolean boolean33 = day29.equals((java.lang.Object) false);
//        java.util.Date date34 = day29.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day29.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod35);
//        boolean boolean37 = timePeriodValue22.equals((java.lang.Object) regularTimePeriod35);
//        boolean boolean38 = year8.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date39 = regularTimePeriod35.getEnd();
//        int int40 = day6.compareTo((java.lang.Object) regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0f) + "'", number26.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-18060) + "'", int40 == (-18060));
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1));
        long long24 = year19.getSerialIndex();
        long long25 = year19.getFirstMillisecond();
        long long26 = year19.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1969L + "'", long24 == 1969L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31507200000L) + "'", long25 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31507200000L) + "'", long26 == (-31507200000L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,1577865599999]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        boolean boolean11 = timePeriodValue6.equals((java.lang.Object) 3);
        java.lang.Object obj12 = timePeriodValue6.clone();
        java.lang.Number number13 = timePeriodValue6.getValue();
        java.lang.Object obj14 = timePeriodValue6.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 1 + "'", number13.equals((byte) 1));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        java.util.Date date11 = simpleTimePeriod9.getStart();
        java.util.Date date12 = simpleTimePeriod9.getStart();
        java.util.Date date13 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int24 = timePeriodValues23.getItemCount();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) regularTimePeriod26, (double) 100);
        java.lang.String str29 = timePeriodValues23.getDescription();
        java.lang.String str30 = timePeriodValues23.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long34 = simpleTimePeriod33.getEndMillis();
        long long35 = simpleTimePeriod33.getEndMillis();
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        long long37 = simpleTimePeriod33.getEndMillis();
        java.lang.Number number38 = null;
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, number38);
        java.util.Date date40 = simpleTimePeriod33.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long44 = simpleTimePeriod43.getEndMillis();
        java.util.Date date45 = simpleTimePeriod43.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date40, timeZone46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date19, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone46);
        java.util.Date date51 = regularTimePeriod50.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate2);
        int int4 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.lang.Object obj6 = new java.lang.Object();
        int int7 = year0.compareTo(obj6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        boolean boolean10 = year0.equals((java.lang.Object) day8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = regularTimePeriod11.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setNotify(true);
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(true);
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        timePeriodValues3.delete(13, 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        long long11 = simpleTimePeriod9.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (java.lang.Number) (byte) 1);
        java.lang.Number number14 = timePeriodValue13.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        java.util.Date date20 = simpleTimePeriod17.getStart();
        java.util.Date date21 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int24 = timePeriodValues23.getItemCount();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) regularTimePeriod26, (double) 100);
        java.lang.String str29 = timePeriodValues23.getDescription();
        java.lang.String str30 = timePeriodValues23.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long34 = simpleTimePeriod33.getEndMillis();
        long long35 = simpleTimePeriod33.getEndMillis();
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        long long37 = simpleTimePeriod33.getEndMillis();
        java.lang.Number number38 = null;
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, number38);
        java.util.Date date40 = simpleTimePeriod33.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long45 = simpleTimePeriod44.getEndMillis();
        long long46 = simpleTimePeriod44.getEndMillis();
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date40, timeZone48);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date21, timeZone48);
        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
        boolean boolean53 = timePeriodValue13.equals((java.lang.Object) serialDate52);
        java.lang.String str54 = timePeriodValue13.toString();
        timePeriodValues3.add(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (byte) 1 + "'", number14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day7.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (double) (byte) -1);
        int int15 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Comparable comparable16 = timePeriodValues1.getKey();
        int int17 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
//        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
//        java.lang.Number number12 = timePeriodValue8.getValue();
//        java.lang.String str13 = timePeriodValue8.toString();
//        java.lang.String str14 = timePeriodValue8.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        int int17 = day15.getDayOfMonth();
//        boolean boolean19 = day15.equals((java.lang.Object) false);
//        java.util.Date date20 = day15.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day15.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod21);
//        boolean boolean23 = timePeriodValue8.equals((java.lang.Object) regularTimePeriod21);
//        java.lang.String str24 = timePeriodValue8.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        int int3 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) (byte) 10);
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int8 = timePeriodValues7.getMaxStartIndex();
//        int int9 = timePeriodValues7.getMinEndIndex();
//        boolean boolean10 = timePeriodValues7.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        java.util.Date date16 = simpleTimePeriod13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day18, (double) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long26 = simpleTimePeriod25.getEndMillis();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValues22.getTimePeriod(0);
//        boolean boolean31 = timePeriodValues22.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long35 = simpleTimePeriod34.getEndMillis();
//        long long36 = simpleTimePeriod34.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (java.lang.Number) 10L);
//        timePeriodValue40.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues22.add(timePeriodValue40);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
//        long long46 = day44.getSerialIndex();
//        int int47 = day44.getDayOfMonth();
//        boolean boolean48 = timePeriodValue40.equals((java.lang.Object) int47);
//        java.lang.Number number49 = timePeriodValue40.getValue();
//        java.lang.String str50 = timePeriodValue40.toString();
//        timePeriodValues7.add(timePeriodValue40);
//        java.lang.Object obj52 = timePeriodValue40.clone();
//        int int53 = day0.compareTo(obj52);
//        java.util.Calendar calendar54 = null;
//        try {
//            long long55 = day0.getFirstMillisecond(calendar54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43629L + "'", long46 == 43629L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 13 + "'", int47 == 13);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0f) + "'", number49.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        java.lang.Object obj23 = timePeriodValue19.clone();
//        java.lang.Object obj24 = timePeriodValue19.clone();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        java.lang.String str27 = day25.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day25.previous();
//        java.util.Date date29 = day25.getStart();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getStart();
//        java.lang.String str32 = day30.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.previous();
//        java.util.Date date34 = day30.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date29, date34);
//        java.util.Date date36 = simpleTimePeriod35.getStart();
//        boolean boolean37 = timePeriodValue19.equals((java.lang.Object) date36);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        long long20 = simpleTimePeriod11.getStartMillis();
        java.util.Date date21 = simpleTimePeriod11.getStart();
        java.util.Date date22 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod11, "org.jfree.data.general.SeriesException: ", "org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        boolean boolean27 = timePeriodValues1.getNotify();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        java.util.Date date6 = simpleTimePeriod4.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        long long8 = day7.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        boolean boolean10 = year0.equals((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        java.lang.Object obj5 = null;
        boolean boolean6 = year1.equals(obj5);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date15, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long28 = simpleTimePeriod27.getEndMillis();
        long long29 = simpleTimePeriod27.getEndMillis();
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date30, date32);
        java.lang.Class<?> wildcardClass34 = date32.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long38 = simpleTimePeriod37.getEndMillis();
        long long39 = simpleTimePeriod37.getEndMillis();
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date32, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone41);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date9, timeZone41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (-14400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.delete((int) (short) 10, 2);
        int int7 = timePeriodValues1.getMaxEndIndex();
        try {
            timePeriodValues1.update((int) 'a', (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(1969, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod1, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getItemCount();
        boolean boolean6 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        int int4 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        int int13 = timePeriodValues1.getMinMiddleIndex();
        try {
            java.lang.Number number15 = timePeriodValues1.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        java.lang.Number number7 = timePeriodValue6.getValue();
        java.lang.Number number8 = timePeriodValue6.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        java.util.Date date13 = simpleTimePeriod11.getStart();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 10L);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (-1.0d));
        java.lang.String str18 = timePeriodValues1.getDomainDescription();
        java.lang.String str19 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        int int5 = day0.compareTo((java.lang.Object) day2);
        int int6 = day0.getMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str16 = timePeriodFormatException13.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.util.Date date7 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int11 = timePeriodValues10.getItemCount();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (double) 100);
        java.lang.String str16 = timePeriodValues10.getDescription();
        java.lang.String str17 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long21 = simpleTimePeriod20.getEndMillis();
        long long22 = simpleTimePeriod20.getEndMillis();
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        long long24 = simpleTimePeriod20.getEndMillis();
        java.lang.Number number25 = null;
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, number25);
        java.util.Date date27 = simpleTimePeriod20.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long32 = simpleTimePeriod31.getEndMillis();
        long long33 = simpleTimePeriod31.getEndMillis();
        java.util.Date date34 = simpleTimePeriod31.getEnd();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date27, timeZone35);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int40 = timePeriodValues39.getItemCount();
        timePeriodValues39.setDomainDescription("hi!");
        java.lang.Comparable comparable43 = timePeriodValues39.getKey();
        timePeriodValues39.setKey((java.lang.Comparable) 0);
        timePeriodValues39.setNotify(true);
        int int48 = timePeriodValues39.getMaxMiddleIndex();
        java.lang.String str49 = timePeriodValues39.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues39.createCopy(2019, (int) '4');
        int int53 = year37.compareTo((java.lang.Object) timePeriodValues52);
        int int54 = year37.getYear();
        int int55 = day8.compareTo((java.lang.Object) year37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + (-1.0d) + "'", comparable43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Value" + "'", str49.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long4 = simpleTimePeriod3.getEndMillis();
//        long long5 = simpleTimePeriod3.getEndMillis();
//        java.util.Date date6 = simpleTimePeriod3.getEnd();
//        java.lang.Class<?> wildcardClass7 = simpleTimePeriod3.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod19.getStart();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 10L);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (-1.0d));
//        java.util.Date date26 = simpleTimePeriod19.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long30 = simpleTimePeriod29.getEndMillis();
//        long long31 = simpleTimePeriod29.getEndMillis();
//        java.util.Date date32 = simpleTimePeriod29.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date32, date34);
//        java.lang.Class<?> wildcardClass36 = date34.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        long long41 = simpleTimePeriod39.getEndMillis();
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date34, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date26, timeZone43);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.previous();
//        long long49 = day47.getSerialIndex();
//        java.util.Date date50 = day47.getEnd();
//        java.util.Date date51 = day47.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long55 = simpleTimePeriod54.getEndMillis();
//        long long56 = simpleTimePeriod54.getEndMillis();
//        java.util.Date date57 = simpleTimePeriod54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57, timeZone58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date51, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date26, timeZone58);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43629L + "'", long49 == 43629L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.lang.String str7 = year0.toString();
        long long8 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "Value", "Value");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long7 = simpleTimePeriod6.getEndMillis();
        java.util.Date date8 = simpleTimePeriod6.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod6, (java.lang.Number) 10L);
        java.lang.String str11 = timePeriodValues3.getDescription();
        timePeriodValues3.delete(100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(str11);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Date date6 = regularTimePeriod5.getStart();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = regularTimePeriod5.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        timePeriodValues9.setDomainDescription("hi!");
        java.lang.Comparable comparable13 = timePeriodValues9.getKey();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues9.getNotify();
        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        java.lang.String str11 = timePeriodValues1.getDescription();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "Value", "Value");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        java.lang.String str13 = timePeriodValues11.getRangeDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        long long16 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100L);
        timePeriodValues11.add(timePeriodValue19);
        boolean boolean21 = day6.equals((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.Date date6 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(date5, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        long long5 = day0.getSerialIndex();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day0.equals(obj6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 0.0d);
        java.lang.Object obj13 = null;
        int int14 = day9.compareTo(obj13);
        try {
            int int15 = simpleTimePeriod8.compareTo((java.lang.Object) int14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        int int8 = timePeriodValues1.getMaxEndIndex();
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDomainDescription("hi!");
//        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
//        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
//        int int10 = timePeriodValues1.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int13 = timePeriodValues12.getItemCount();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (double) 100);
//        timePeriodValues12.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 1.0f);
//        int int24 = day21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        long long26 = day21.getFirstMillisecond();
//        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day21, (double) 13);
//        org.jfree.data.time.SerialDate serialDate29 = day21.getSerialDate();
//        int int30 = day21.getDayOfMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) (short) 0);
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener35);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues1.clone();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        int int12 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (short) 100, 2);
        timePeriodValues17.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener20);
        try {
            java.lang.Number number23 = timePeriodValues17.getValue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10.0d);
//        timePeriodValue8.setValue((java.lang.Number) 1577865599999L);
//        java.lang.String str11 = timePeriodValue8.toString();
//        timePeriodValue8.setValue((java.lang.Number) 2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,1577865599999]" + "'", str11.equals("TimePeriodValue[13-June-2019,1577865599999]"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        boolean boolean7 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long8 = simpleTimePeriod7.getEndMillis();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 'a');
        timePeriodValues16.delete(0, (int) (short) 0);
        timePeriodValues16.setDescription("");
        int int28 = timePeriodValues16.getMaxEndIndex();
        int int29 = day14.compareTo((java.lang.Object) int28);
        int int30 = year13.compareTo((java.lang.Object) day14);
        java.lang.String str31 = year13.toString();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year13.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        java.lang.String str5 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        java.util.Date date7 = day3.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
//        boolean boolean11 = day3.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 0.0d);
//        java.lang.Object obj14 = timePeriodValue13.clone();
//        timePeriodValues1.add(timePeriodValue13);
//        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(timePeriod16);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        java.util.Date date5 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int8 = day6.compareTo((java.lang.Object) 1560495599999L);
//        long long9 = day6.getFirstMillisecond();
//        long long10 = day6.getLastMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getStart();
//        int int13 = day11.getDayOfMonth();
//        boolean boolean15 = day11.equals((java.lang.Object) false);
//        java.util.Date date16 = day11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day11.previous();
//        boolean boolean18 = day6.equals((java.lang.Object) regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-57600000L) + "'", long9 == (-57600000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        timePeriodValues1.fireSeriesChanged();
        int int12 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (short) 100, 2);
        java.lang.Comparable comparable18 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        boolean boolean8 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1.0d) + "'", comparable11.equals((-1.0d)));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        long long16 = simpleTimePeriod11.getStartMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) '#');
        boolean boolean19 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod11);
        long long20 = simpleTimePeriod11.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 1.0f);
        java.util.Date date28 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date19, date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10.0d);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = year9.getYear();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        boolean boolean14 = year9.equals((java.lang.Object) 0L);
//        long long15 = year9.getSerialIndex();
//        boolean boolean16 = timePeriodValue8.equals((java.lang.Object) year9);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        boolean boolean4 = day0.equals((java.lang.Object) false);
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int8 = timePeriodValues7.getItemCount();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
//        java.lang.String str13 = timePeriodValues7.getDescription();
//        java.lang.String str14 = timePeriodValues7.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long18 = simpleTimePeriod17.getEndMillis();
//        long long19 = simpleTimePeriod17.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod17.getEnd();
//        long long21 = simpleTimePeriod17.getEndMillis();
//        java.lang.Number number22 = null;
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, number22);
//        java.util.Date date24 = simpleTimePeriod17.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long29 = simpleTimePeriod28.getEndMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date24, timeZone32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date5, timeZone32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int38 = timePeriodValues37.getItemCount();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) regularTimePeriod40, (double) 100);
//        java.lang.String str43 = timePeriodValues37.getDescription();
//        java.lang.String str44 = timePeriodValues37.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long48 = simpleTimePeriod47.getEndMillis();
//        long long49 = simpleTimePeriod47.getEndMillis();
//        java.util.Date date50 = simpleTimePeriod47.getEnd();
//        long long51 = simpleTimePeriod47.getEndMillis();
//        java.lang.Number number52 = null;
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, number52);
//        java.util.Date date54 = simpleTimePeriod47.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int57 = timePeriodValues56.getItemCount();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        timePeriodValues56.add((org.jfree.data.time.TimePeriod) regularTimePeriod59, (double) 100);
//        java.lang.String str62 = timePeriodValues56.getDescription();
//        java.lang.String str63 = timePeriodValues56.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long67 = simpleTimePeriod66.getEndMillis();
//        long long68 = simpleTimePeriod66.getEndMillis();
//        java.util.Date date69 = simpleTimePeriod66.getEnd();
//        long long70 = simpleTimePeriod66.getEndMillis();
//        java.lang.Number number71 = null;
//        timePeriodValues56.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, number71);
//        java.util.Date date73 = simpleTimePeriod66.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long77 = simpleTimePeriod76.getEndMillis();
//        java.util.Date date78 = simpleTimePeriod76.getStart();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date78, timeZone79);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date73, timeZone79);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long85 = simpleTimePeriod84.getEndMillis();
//        long long86 = simpleTimePeriod84.getEndMillis();
//        java.util.Date date87 = simpleTimePeriod84.getEnd();
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date87, timeZone88);
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date73, timeZone88);
//        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date54, timeZone88);
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date5, timeZone88);
//        long long93 = day92.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Time" + "'", str63.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 10L + "'", long85 == 10L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1560495599999L + "'", long93 == 1560495599999L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long6 = simpleTimePeriod5.getEndMillis();
//        long long7 = simpleTimePeriod5.getEndMillis();
//        java.util.Date date8 = simpleTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod5, (double) 1.0f);
//        java.util.Date date11 = simpleTimePeriod5.getStart();
//        int int12 = day0.compareTo((java.lang.Object) date11);
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("Time");
//        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
//        boolean boolean17 = day0.equals((java.lang.Object) seriesException15);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getSerialIndex();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getSerialIndex();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long49 = simpleTimePeriod48.getEndMillis();
        long long50 = simpleTimePeriod48.getEndMillis();
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long59 = simpleTimePeriod58.getEndMillis();
        java.util.Date date60 = simpleTimePeriod58.getStart();
        java.util.Date date61 = simpleTimePeriod58.getStart();
        java.util.Date date62 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int65 = timePeriodValues64.getItemCount();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) regularTimePeriod67, (double) 100);
        java.lang.String str70 = timePeriodValues64.getDescription();
        java.lang.String str71 = timePeriodValues64.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long75 = simpleTimePeriod74.getEndMillis();
        long long76 = simpleTimePeriod74.getEndMillis();
        java.util.Date date77 = simpleTimePeriod74.getEnd();
        long long78 = simpleTimePeriod74.getEndMillis();
        java.lang.Number number79 = null;
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod74, number79);
        java.util.Date date81 = simpleTimePeriod74.getStart();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long86 = simpleTimePeriod85.getEndMillis();
        long long87 = simpleTimePeriod85.getEndMillis();
        java.util.Date date88 = simpleTimePeriod85.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date81, timeZone89);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date62, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date18, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = year93.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Time" + "'", str71.equals("Time"));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 10L + "'", long87 == 10L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        int int16 = timePeriodValues1.getMinStartIndex();
        try {
            java.lang.Object obj17 = timePeriodValues1.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        long long17 = simpleTimePeriod15.getEndMillis();
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date18, date20);
        java.lang.Class<?> wildcardClass22 = date20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long26 = simpleTimePeriod25.getEndMillis();
        long long27 = simpleTimePeriod25.getEndMillis();
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date20, timeZone29);
        boolean boolean32 = timePeriodValues1.equals((java.lang.Object) day31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        try {
            java.lang.Object obj11 = timePeriodValues1.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        java.util.Date date8 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        long long12 = day10.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) 2);
//        timePeriodValues9.add(timePeriodValue15);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        org.jfree.data.time.SerialDate serialDate27 = day17.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate27);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.delete(0, (int) (short) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
//        java.lang.Class<?> wildcardClass9 = date7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        java.util.Date date16 = simpleTimePeriod13.getEnd();
//        long long17 = simpleTimePeriod13.getEndMillis();
//        long long18 = simpleTimePeriod13.getStartMillis();
//        java.util.Date date19 = simpleTimePeriod13.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        long long22 = day20.getSerialIndex();
//        java.util.Date date23 = day20.getEnd();
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long28 = simpleTimePeriod27.getEndMillis();
//        long long29 = simpleTimePeriod27.getEndMillis();
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date24, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date19, timeZone31);
//        try {
//            java.lang.Class<?> wildcardClass35 = regularTimePeriod34.getClass();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43629L + "'", long22 == 43629L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 6);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int10 = timePeriodValues9.getItemCount();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 100);
        java.lang.String str15 = timePeriodValues9.getDescription();
        java.lang.String str16 = timePeriodValues9.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        long long23 = simpleTimePeriod19.getEndMillis();
        java.lang.Number number24 = null;
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, number24);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date26, timeZone34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date7, timeZone34);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        java.lang.String str12 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        java.util.Date date17 = simpleTimePeriod15.getStart();
        java.util.Date date18 = simpleTimePeriod15.getStart();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (byte) 10);
        java.util.Date date21 = simpleTimePeriod15.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int9 = timePeriodValues8.getItemCount();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
        java.lang.String str14 = timePeriodValues8.getDescription();
        java.lang.String str15 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getEndMillis();
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        long long22 = simpleTimePeriod18.getEndMillis();
        java.lang.Number number23 = null;
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number23);
        java.util.Date date25 = simpleTimePeriod18.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long30 = simpleTimePeriod29.getEndMillis();
        long long31 = simpleTimePeriod29.getEndMillis();
        java.util.Date date32 = simpleTimePeriod29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date25, timeZone33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date6, timeZone33);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date6);
        java.util.Calendar calendar38 = null;
        try {
            year37.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
//        int int2 = year1.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        int int5 = day3.getDayOfMonth();
//        boolean boolean7 = day3.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        int int11 = year1.compareTo((java.lang.Object) day10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 1.0f);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        java.lang.String str2 = year0.toString();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getMiddleMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        java.util.Date date9 = day7.getEnd();
//        int int10 = day3.compareTo((java.lang.Object) day7);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100);
//        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValue13);
//        timePeriodValue13.setValue((java.lang.Number) (short) -1);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long6 = simpleTimePeriod5.getEndMillis();
        long long7 = simpleTimePeriod5.getEndMillis();
        java.util.Date date8 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date8, date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod11);
        long long13 = simpleTimePeriod11.getStartMillis();
        int int14 = year0.compareTo((java.lang.Object) simpleTimePeriod11);
        long long15 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1546329600000L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 1.0f);
//        int int5 = day2.getYear();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day2);
//        long long8 = day2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-18060));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setDomainDescription("31-December-1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        timePeriodValues1.setDomainDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setDescription("TimePeriodValue[13-June-2019,0]");
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 'a');
        java.lang.String str13 = timePeriodValues6.getDescription();
        boolean boolean15 = timePeriodValues6.equals((java.lang.Object) (short) 1);
        boolean boolean16 = simpleTimePeriod2.equals((java.lang.Object) (short) 1);
        java.util.Date date17 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.lang.Class class7 = null;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
        boolean boolean12 = year6.equals((java.lang.Object) class7);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year6.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        int int16 = timePeriodValues1.getMinStartIndex();
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        timePeriodValue8.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue8);
        java.lang.Number number12 = timePeriodValue8.getValue();
        java.lang.String str13 = timePeriodValue8.toString();
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertNotNull(timePeriod14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100);
        int int16 = day12.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        boolean boolean10 = timePeriodValues1.getNotify();
        java.lang.Class<?> wildcardClass11 = timePeriodValues1.getClass();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Number number9 = timePeriodValue8.getValue();
        java.lang.Object obj10 = timePeriodValue8.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10L + "'", number9.equals(10L));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.lang.String str7 = timePeriodValues1.getDescription();
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        long long13 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date14 = simpleTimePeriod11.getEnd();
//        long long15 = simpleTimePeriod11.getEndMillis();
//        java.lang.Number number16 = null;
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
//        java.util.Date date18 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        long long24 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date25 = simpleTimePeriod22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date18, timeZone26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int31 = timePeriodValues30.getItemCount();
//        timePeriodValues30.setDomainDescription("hi!");
//        java.lang.Comparable comparable34 = timePeriodValues30.getKey();
//        timePeriodValues30.setKey((java.lang.Comparable) 0);
//        timePeriodValues30.setNotify(true);
//        int int39 = timePeriodValues30.getMaxMiddleIndex();
//        java.lang.String str40 = timePeriodValues30.getRangeDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = timePeriodValues30.createCopy(2019, (int) '4');
//        int int44 = year28.compareTo((java.lang.Object) timePeriodValues43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long50 = simpleTimePeriod49.getEndMillis();
//        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod54 = timePeriodValues46.getTimePeriod(0);
//        boolean boolean55 = timePeriodValues46.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long59 = simpleTimePeriod58.getEndMillis();
//        long long60 = simpleTimePeriod58.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 10L);
//        timePeriodValue64.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues46.add(timePeriodValue64);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.previous();
//        long long70 = day68.getSerialIndex();
//        int int71 = day68.getDayOfMonth();
//        boolean boolean72 = timePeriodValue64.equals((java.lang.Object) int71);
//        java.lang.Number number73 = timePeriodValue64.getValue();
//        java.lang.String str74 = timePeriodValue64.toString();
//        org.jfree.data.time.TimePeriod timePeriod75 = timePeriodValue64.getPeriod();
//        boolean boolean76 = year28.equals((java.lang.Object) timePeriodValue64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year28.previous();
//        java.lang.Object obj78 = null;
//        int int79 = year28.compareTo(obj78);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertNotNull(timePeriodValues43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43629L + "'", long70 == 43629L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 13 + "'", int71 == 13);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + number73 + "' != '" + (-1.0f) + "'", number73.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(timePeriod75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        timePeriodValues1.setRangeDescription("");
        java.lang.Object obj8 = timePeriodValues1.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, 9L);
        timePeriodValues1.setKey((java.lang.Comparable) 9L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        long long15 = day10.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day10, (double) 13);
//        org.jfree.data.time.SerialDate serialDate18 = day10.getSerialDate();
//        java.lang.String str19 = day10.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
//        java.util.Date date7 = regularTimePeriod4.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        long long9 = day8.getSerialIndex();
//        int int10 = day8.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43628L + "'", long9 == 43628L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long8 = simpleTimePeriod7.getEndMillis();
//        long long9 = simpleTimePeriod7.getEndMillis();
//        java.util.Date date10 = simpleTimePeriod7.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 'a');
//        timePeriodValues16.delete(0, (int) (short) 0);
//        timePeriodValues16.setDescription("");
//        int int28 = timePeriodValues16.getMaxEndIndex();
//        int int29 = day14.compareTo((java.lang.Object) int28);
//        int int30 = year13.compareTo((java.lang.Object) day14);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getStart();
//        int int33 = day31.getDayOfMonth();
//        boolean boolean35 = day31.equals((java.lang.Object) false);
//        java.util.Date date36 = day31.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day31);
//        java.lang.Class<?> wildcardClass38 = seriesChangeEvent37.getClass();
//        boolean boolean39 = year13.equals((java.lang.Object) seriesChangeEvent37);
//        int int40 = year13.getYear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1969 + "'", int40 == 1969);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, 100.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        java.util.Date date14 = simpleTimePeriod12.getStart();
        java.util.Date date15 = simpleTimePeriod12.getStart();
        java.util.Date date16 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int19 = timePeriodValues18.getItemCount();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) regularTimePeriod21, (double) 100);
        java.lang.String str24 = timePeriodValues18.getDescription();
        java.lang.String str25 = timePeriodValues18.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long29 = simpleTimePeriod28.getEndMillis();
        long long30 = simpleTimePeriod28.getEndMillis();
        java.util.Date date31 = simpleTimePeriod28.getEnd();
        long long32 = simpleTimePeriod28.getEndMillis();
        java.lang.Number number33 = null;
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, number33);
        java.util.Date date35 = simpleTimePeriod28.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getEndMillis();
        java.util.Date date42 = simpleTimePeriod39.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date35, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date16, timeZone43);
        org.jfree.data.time.SerialDate serialDate47 = day46.getSerialDate();
        java.lang.String str48 = day46.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day46, "", "");
        int int52 = day6.compareTo((java.lang.Object) day46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-1969" + "'", str48.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 100, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        int int5 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(2, (int) 'a');
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) '#');
        long long10 = simpleTimePeriod2.getStartMillis();
        java.util.Date date11 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.util.Date date6 = day4.getEnd();
//        int int7 = day0.compareTo((java.lang.Object) day4);
//        java.util.Date date8 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100);
//        timePeriodValue10.setValue((java.lang.Number) (-1));
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.lang.Class class7 = null;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
        boolean boolean12 = year6.equals((java.lang.Object) class7);
        java.lang.String str13 = year6.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year6.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long11 = simpleTimePeriod10.getEndMillis();
        java.util.Date date12 = simpleTimePeriod10.getStart();
        java.util.Date date13 = simpleTimePeriod10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day14);
        int int16 = timePeriodValues15.getMinStartIndex();
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day17.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setRangeDescription("");
        boolean boolean14 = timePeriodValues1.getNotify();
        int int15 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        long long20 = year18.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 1969L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        java.lang.String str8 = timePeriodValues1.getDescription();
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMinStartIndex();
        java.lang.Object obj3 = null;
        boolean boolean4 = timePeriodValues1.equals(obj3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setRangeDescription("hi!");
        boolean boolean7 = timePeriodValues1.getNotify();
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long5 = simpleTimePeriod4.getEndMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        long long13 = year11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long5 = simpleTimePeriod4.getEndMillis();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod4, (double) 'a');
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
//        boolean boolean10 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long14 = simpleTimePeriod13.getEndMillis();
//        long long15 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 10L);
//        timePeriodValue19.setValue((java.lang.Number) (-1.0f));
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        long long25 = day23.getSerialIndex();
//        int int26 = day23.getDayOfMonth();
//        boolean boolean27 = timePeriodValue19.equals((java.lang.Object) int26);
//        java.lang.Number number28 = timePeriodValue19.getValue();
//        java.lang.String str29 = timePeriodValue19.toString();
//        java.lang.String str30 = timePeriodValue19.toString();
//        timePeriodValue19.setValue((java.lang.Number) (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0f) + "'", number28.equals((-1.0f)));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.util.Date date7 = regularTimePeriod4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        timePeriodValues1.setDomainDescription("Value");
        java.lang.Class<?> wildcardClass20 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDomainDescription("hi!");
//        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        timePeriodValues1.setNotify(true);
//        int int10 = timePeriodValues1.getMaxMiddleIndex();
//        java.lang.String str11 = timePeriodValues1.getRangeDescription();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (double) 100L);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        long long18 = day16.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) (byte) 10);
//        int int21 = year12.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year12.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues1.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy(2019, 100);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues1.createCopy((int) 'a', 9);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        int int20 = year19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (-1.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        java.util.Date date8 = day0.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date13 = simpleTimePeriod11.getStart();
//        java.util.Date date14 = simpleTimePeriod11.getStart();
//        long long15 = simpleTimePeriod11.getStartMillis();
//        int int16 = day0.compareTo((java.lang.Object) long15);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDomainDescription("");
//        boolean boolean6 = timePeriodValues1.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int9 = timePeriodValues8.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 100);
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day17, (double) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) (-1));
//        java.lang.String str27 = timePeriodValues1.getDomainDescription();
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener29);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int8 = day6.compareTo((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long13 = simpleTimePeriod12.getEndMillis();
        long long14 = simpleTimePeriod12.getEndMillis();
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date7, timeZone16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int21 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (double) 100);
        java.lang.String str26 = timePeriodValues20.getDescription();
        java.lang.String str27 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long31 = simpleTimePeriod30.getEndMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        long long34 = simpleTimePeriod30.getEndMillis();
        java.lang.Number number35 = null;
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, number35);
        java.util.Date date37 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date37, timeZone43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date7, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long50 = simpleTimePeriod49.getEndMillis();
        long long51 = simpleTimePeriod49.getEndMillis();
        long long52 = simpleTimePeriod49.getStartMillis();
        long long53 = simpleTimePeriod49.getStartMillis();
        java.util.Date date54 = simpleTimePeriod49.getEnd();
        java.util.Date date55 = simpleTimePeriod49.getStart();
        boolean boolean56 = year46.equals((java.lang.Object) date55);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date55);
        java.lang.String str58 = timePeriodValues57.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Value" + "'", str58.equals("Value"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 10L);
        java.lang.Object obj9 = timePeriodValue8.clone();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue8.getPeriod();
        java.lang.Number number13 = timePeriodValue8.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10L + "'", number13.equals(10L));
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        timePeriodValues3.setDomainDescription("13-June-2019");
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
//        int int9 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 1);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue6.getPeriod();
        java.lang.Class<?> wildcardClass9 = timePeriod8.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(4, 0);
        int int15 = timePeriodValues14.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setRangeDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int11 = timePeriodValues10.getItemCount();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (double) 100);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (-1.0d));
        int int18 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Date date4 = year0.getStart();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long11 = simpleTimePeriod10.getEndMillis();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 'a');
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues7.getTimePeriod(0);
        boolean boolean16 = timePeriodValues7.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 10L);
        timePeriodValue25.setValue((java.lang.Number) (-1.0f));
        timePeriodValues7.add(timePeriodValue25);
        java.lang.Object obj29 = timePeriodValue25.clone();
        java.lang.Number number30 = timePeriodValue25.getValue();
        boolean boolean31 = year0.equals((java.lang.Object) number30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year0.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1.0f) + "'", number30.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(1969, 3);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(1969, 1969);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long16 = simpleTimePeriod15.getEndMillis();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) 10L);
        timePeriodValue21.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue21);
        java.lang.String str25 = seriesChangeEvent24.toString();
        boolean boolean26 = timePeriodValues12.equals((java.lang.Object) seriesChangeEvent24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 31, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1.0d) + "'", obj5.equals((-1.0d)));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) (-1L));
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(1969, 3);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod4, (double) 100);
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long12 = simpleTimePeriod11.getEndMillis();
        long long13 = simpleTimePeriod11.getEndMillis();
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        long long15 = simpleTimePeriod11.getEndMillis();
        java.lang.Number number16 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, number16);
        java.util.Date date18 = simpleTimePeriod11.getStart();
        java.util.Date date19 = simpleTimePeriod11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long23 = simpleTimePeriod22.getEndMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 1.0f);
        java.util.Date date28 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date19, date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long33 = simpleTimePeriod32.getEndMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date35, date37);
        java.lang.Class<?> wildcardClass39 = date37.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long43 = simpleTimePeriod42.getEndMillis();
        long long44 = simpleTimePeriod42.getEndMillis();
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date37, timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date28, timeZone46);
        long long50 = year49.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-31507200000L) + "'", long50 == (-31507200000L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) 0, (int) (byte) -1);
        int int13 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setNotify(false);
        try {
            java.lang.Number number17 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long17 = simpleTimePeriod16.getEndMillis();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        java.util.Date date19 = simpleTimePeriod16.getStart();
        java.util.Date date20 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int23 = timePeriodValues22.getItemCount();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) regularTimePeriod25, (double) 100);
        java.lang.String str28 = timePeriodValues22.getDescription();
        java.lang.String str29 = timePeriodValues22.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long33 = simpleTimePeriod32.getEndMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        long long36 = simpleTimePeriod32.getEndMillis();
        java.lang.Number number37 = null;
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, number37);
        java.util.Date date39 = simpleTimePeriod32.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long44 = simpleTimePeriod43.getEndMillis();
        long long45 = simpleTimePeriod43.getEndMillis();
        java.util.Date date46 = simpleTimePeriod43.getEnd();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date39, timeZone47);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date20, timeZone47);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date11, timeZone47);
        java.lang.Class<?> wildcardClass52 = date11.getClass();
        java.util.Date date53 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date11, date53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        boolean boolean5 = year0.equals((java.lang.Object) 1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        java.lang.String str8 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int2 = timePeriodValues1.getMaxStartIndex();
//        int int3 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (short) 10, 10);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
//        int int9 = timePeriodValues1.getMinEndIndex();
//        boolean boolean10 = timePeriodValues1.getNotify();
//        java.lang.Class<?> wildcardClass11 = timePeriodValues1.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        java.util.Date date16 = simpleTimePeriod14.getStart();
//        java.util.Date date17 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getFirstMillisecond();
//        long long22 = year20.getLastMillisecond();
//        long long23 = year20.getLastMillisecond();
//        long long24 = year20.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year20.next();
//        java.util.Date date26 = year20.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
//        int int29 = timePeriodValues28.getItemCount();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) regularTimePeriod31, (double) 100);
//        java.lang.String str34 = timePeriodValues28.getDescription();
//        java.lang.String str35 = timePeriodValues28.getDomainDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        long long40 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date41 = simpleTimePeriod38.getEnd();
//        long long42 = simpleTimePeriod38.getEndMillis();
//        java.lang.Number number43 = null;
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, number43);
//        java.util.Date date45 = simpleTimePeriod38.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long49 = simpleTimePeriod48.getEndMillis();
//        java.util.Date date50 = simpleTimePeriod48.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date45, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date26, timeZone51);
//        java.lang.Class<?> wildcardClass55 = timeZone51.getClass();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date17, timeZone51);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.previous();
//        long long59 = day57.getSerialIndex();
//        java.util.Date date60 = day57.getEnd();
//        java.util.Date date61 = day57.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long65 = simpleTimePeriod64.getEndMillis();
//        long long66 = simpleTimePeriod64.getEndMillis();
//        java.util.Date date67 = simpleTimePeriod64.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date61, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone68);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560365999999L, 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8);
        int int10 = timePeriodValues9.getMaxEndIndex();
        java.lang.String str11 = timePeriodValues9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560365999999L);
//        long long7 = day0.getSerialIndex();
//        long long8 = day0.getLastMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long12 = simpleTimePeriod11.getEndMillis();
//        java.util.Date date13 = simpleTimePeriod11.getStart();
//        java.util.Date date14 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        int int16 = year15.getYear();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        long long21 = simpleTimePeriod19.getEndMillis();
//        java.util.Date date22 = simpleTimePeriod19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
//        boolean boolean25 = year15.equals((java.lang.Object) date22);
//        boolean boolean26 = day0.equals((java.lang.Object) date22);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.Object obj28 = seriesChangeEvent27.getSource();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(obj28);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d));
        int int2 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        timePeriodValues1.setNotify(true);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (double) 100L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', 1577865599999L);
        long long19 = simpleTimePeriod18.getStartMillis();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        long long22 = year20.getLastMillisecond();
        long long23 = year20.getLastMillisecond();
        long long24 = year20.getLastMillisecond();
        java.lang.String str25 = year20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year20.previous();
        int int27 = simpleTimePeriod18.compareTo((java.lang.Object) year20);
        java.util.Date date28 = year20.getStart();
        boolean boolean29 = year12.equals((java.lang.Object) date28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }
}

