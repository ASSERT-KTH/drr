import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint8 = null;
        xYStepAreaRenderer7.setBasePaint(paint8);
        java.awt.Stroke stroke11 = null;
        xYStepAreaRenderer7.setSeriesOutlineStroke((int) ' ', stroke11);
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        int int21 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range22 = xYStepAreaRenderer7.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepAreaRenderer1.getBaseItemLabelGenerator();
        xYStepAreaRenderer1.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Font font13 = xYStepAreaRenderer1.lookupLegendTextFont((-459));
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot0.getDomainAxisLocation((-458));
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = null;
        piePlot6.setOutlineStroke(stroke7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setNoDataMessage("hi!");
        java.awt.Paint paint12 = piePlot9.getBaseSectionOutlinePaint();
        piePlot6.setBaseSectionOutlinePaint(paint12);
        standardChartTheme5.setRangeGridlinePaint(paint12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme5.setErrorIndicatorPaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        standardChartTheme5.setTitlePaint((java.awt.Paint) color17);
        combinedRangeXYPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        combinedRangeXYPlot0.setOrientation(plotOrientation20);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint4 = null;
        xYStepAreaRenderer3.setBasePaint(paint4);
        java.awt.Stroke stroke7 = null;
        xYStepAreaRenderer3.setSeriesOutlineStroke((int) ' ', stroke7);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        waferMapPlot9.setDataset(waferMapDataset10);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot9);
        xYStepAreaRenderer3.setRangeBase((double) (-1L));
        java.awt.Paint paint15 = xYStepAreaRenderer3.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator16);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        double double66 = categoryPlot51.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot51.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        periodAxis7.setLabelAngle((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator((-16777216), 0, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setSeparatorPaint(paint2);
        double double4 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D5, point2D6, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Paint paint2 = standardChartTheme1.getGridBandAlternatePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setInsets(rectangleInsets1, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        java.util.Collection collection13 = xYStepAreaRenderer1.getAnnotations();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        paintMap0.clear();
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot4.getFixedLegendItems();
        double double7 = categoryPlot4.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot4.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker10, layer11);
        java.util.List list13 = categoryPlot4.getAnnotations();
        jFreeChart3.setSubtitles(list13);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Shape shape11 = periodAxis7.getLeftArrow();
        java.lang.Class class12 = periodAxis7.getAutoRangeTimePeriodClass();
        periodAxis7.setUpperMargin(1.0E-5d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            timeSeriesCollection1.setSelected(2, 31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        java.awt.Font font7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) waferMapPlot8, false);
        jFreeChart10.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart10.getLegend((int) (byte) 0);
        jFreeChart10.setTextAntiAlias(false);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeries1, jFreeChart10);
        java.lang.Object obj18 = chartChangeEvent17.getSource();
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        boolean boolean3 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.entity.AxisEntity axisEntity6 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) numberAxis1, "First", "DomainOrder.NONE");
        numberAxis1.setFixedAutoRange((double) (byte) 1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Comparable comparable1 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Paint paint2 = categoryPlot0.getDomainCrosshairPaint();
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        segmentedTimeline3.addException((long) 100, (long) 64);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        java.lang.Object obj4 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) (byte) 10);
        try {
            org.jfree.chart.util.Size2D size2D9 = blockContainer0.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(true);
        try {
            xYStepAreaRenderer1.setSeriesItemLabelsVisible((-452), (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 644288400000L, (double) 100, 0.2d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        boolean boolean9 = polarPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot7.zoomDomainAxes((double) 1L, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = polarPlot7.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        java.awt.Shape shape12 = periodAxis8.getLeftArrow();
        java.util.Locale locale13 = periodAxis8.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator14 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", locale13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(locale13);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        piePlot11.setNoDataMessage("hi!");
        java.awt.Paint paint14 = piePlot11.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke15 = piePlot11.getBaseSectionOutlineStroke();
        polarPlot7.setRadiusGridlineStroke(stroke15);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer18.setBaseSeriesVisible(false);
        java.awt.Stroke stroke22 = xYStepAreaRenderer18.lookupSeriesOutlineStroke((-458));
        polarPlot7.setRadiusGridlineStroke(stroke22);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape9 = xYStepAreaRenderer3.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) categoryAxis10, "");
        int int13 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Font font14 = categoryAxis10.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font14);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("DomainOrder.NONE", font14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = labelBlock16.getTextAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer20.setBaseSeriesVisible(false);
        boolean boolean23 = textBlockAnchor18.equals((java.lang.Object) xYStepAreaRenderer20);
        labelBlock16.setContentAlignmentPoint(textBlockAnchor18);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str3.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setTextAlignment(horizontalAlignment4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle2.getVerticalAlignment();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) date2);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        numberAxis0.configure();
        double double4 = numberAxis0.getUpperMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        java.lang.String str6 = numberAxis0.getLabel();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        boolean boolean17 = polarPlot16.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) polarPlot16, "{0}: ({1}, {2})");
        org.jfree.chart.title.Title title20 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape8, title20, "AxisLocation.BOTTOM_OR_RIGHT", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getUpperDate();
        java.util.Date date2 = dateRange0.getUpperDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = standardChartTheme7.getDrawingSupplier();
        java.awt.Font font10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) waferMapPlot11, false);
        jFreeChart13.removeLegend();
        standardChartTheme7.apply(jFreeChart13);
        java.awt.Paint paint16 = standardChartTheme7.getDomainGridlinePaint();
        java.awt.Paint paint17 = standardChartTheme7.getGridBandPaint();
        dateAxis1.setTickMarkPaint(paint17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(dateTickUnit19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        try {
            java.lang.Number number15 = xYSeriesCollection4.getX((-13120), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        boolean boolean4 = piePlot0.isCircular();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            piePlot0.setInsets(rectangleInsets5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(true);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState1.setCrosshairState(xYCrosshairState4);
        int int6 = xYCrosshairState4.getRangeAxisIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, valueAxis18, polarItemRenderer19);
        boolean boolean21 = polarPlot20.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) polarPlot20, "{0}: ({1}, {2})");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = xYStepAreaRenderer25.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator32 = xYStepAreaRenderer25.getBaseItemLabelGenerator();
        xYStepAreaRenderer25.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.StandardChartTheme standardChartTheme37 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint38 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme37.setLegendBackgroundPaint(paint38);
        xYStepAreaRenderer25.setBasePaint(paint38, false);
        try {
            org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem(attributedString0, "series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE", "hi!", "Category Plot", shape12, paint38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNull(xYItemLabelGenerator32);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long10 = segmentedTimeline3.getTimeFromLong(0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart4.createBufferedImage(5, 4, (double) (byte) 10, (double) 0L, chartRenderingInfo9);
        jFreeChart4.setTitle("Category Plot");
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart4.removeProgressListener(chartProgressListener13);
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.data.xy.XYSeries xYSeries13 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        xYSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection(xYSeries13);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, valueAxis17, polarItemRenderer18);
        boolean boolean20 = polarPlot19.isAngleLabelsVisible();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot19.setRadiusGridlineStroke(stroke21);
        categoryPlot0.setRangeZeroBaselineStroke(stroke21);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray27, doubleArray28, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray30);
        categoryPlot0.setDataset((int) (short) 0, categoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset31, (int) '#');
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(pieDataset34);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis8.drawTickMarks(graphics2D11, 0.0d, rectangle2D13, rectangleEdge14, axisState15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) (-452), (java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        java.text.AttributedString attributedString27 = legendItem14.getAttributedLabel();
        java.lang.String str28 = legendItem14.getLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(attributedString27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str28.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double3 = piePlot1.getExplodePercent((java.lang.Comparable) 33.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer4.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape10 = xYStepAreaRenderer4.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint14 = xYStepAreaRenderer4.getItemPaint(1, (int) '4', true);
        combinedRangeXYPlot0.setRangeTickBandPaint(paint14);
        combinedRangeXYPlot0.setRangeCrosshairValue((double) 10, false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.lang.Object obj1 = xYBarRenderer0.clone();
        xYBarRenderer0.setBarAlignmentFactor(0.5d);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setLabelLinksVisible(false);
        try {
            piePlot0.setInteriorGap((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (97.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "SerialDate.weekInMonthToString(): invalid code.", textAnchor5, textAnchor6, (-1.0d));
        valueMarker1.setLabelTextAnchor(textAnchor6);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint12 = null;
        xYStepAreaRenderer11.setBasePaint(paint12);
        java.awt.Stroke stroke15 = null;
        xYStepAreaRenderer11.setSeriesOutlineStroke((int) ' ', stroke15);
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        xYSeries18.removeChangeListener(seriesChangeListener19);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        int int25 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection21, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range26 = xYStepAreaRenderer11.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection21);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer28.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape34 = xYStepAreaRenderer28.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity(shape34, (org.jfree.chart.axis.Axis) categoryAxis35, "");
        xYStepAreaRenderer11.setBaseLegendShape(shape34);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity39 = new org.jfree.chart.entity.LegendItemEntity(shape34);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint42 = null;
        xYStepAreaRenderer41.setBasePaint(paint42);
        java.awt.Stroke stroke45 = null;
        xYStepAreaRenderer41.setSeriesOutlineStroke((int) ' ', stroke45);
        xYStepAreaRenderer41.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries50 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        xYSeries50.removeChangeListener(seriesChangeListener51);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection(xYSeries50);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection53, valueAxis54, polarItemRenderer55);
        org.jfree.data.Range range57 = xYStepAreaRenderer41.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53, true);
        legendItemEntity39.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection53);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit64 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType65 = dateTickUnit64.getUnitType();
        double double66 = dateTickUnit64.getSize();
        dateAxis63.setTickUnit(dateTickUnit64, false, false);
        categoryPlot61.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        categoryPlot61.setRangeAxis(10, valueAxis73);
        boolean boolean75 = xYSeriesCollection53.hasListener((java.util.EventListener) categoryPlot61);
        boolean boolean76 = textAnchor6.equals((java.lang.Object) categoryPlot61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot61.zoomRangeAxes(4.0d, plotRenderingInfo78, point2D79, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker82 = null;
        try {
            categoryPlot61.addDomainMarker(categoryMarker82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(dateTickUnit64);
        org.junit.Assert.assertNotNull(dateTickUnitType65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 8.64E7d + "'", double66 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke8);
        java.awt.Stroke stroke13 = xYStepAreaRenderer1.getItemStroke((int) (short) 10, 6, false);
        java.awt.Font font15 = xYStepAreaRenderer1.getSeriesItemLabelFont(15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(font15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = lineBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopOutset((double) 12);
        double double9 = rectangleInsets5.calculateBottomOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        double double66 = categoryPlot51.getAnchorValue();
        java.awt.Paint paint67 = categoryPlot51.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType18 = dateTickUnit17.getUnitType();
        double double19 = dateTickUnit17.getSize();
        dateAxis16.setTickUnit(dateTickUnit17, false, false);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot14.getColumnRenderingOrder();
        java.awt.Paint paint26 = categoryPlot14.getDomainCrosshairPaint();
        double double27 = categoryPlot14.getAnchorValue();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(4);
        int int34 = year33.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year33);
        double double36 = periodAxis35.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        barRenderer3D2.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) periodAxis35, rectangle2D37, 1.0d);
        java.util.List list40 = categoryPlot14.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace41);
        java.util.List list43 = categoryPlot14.getCategories();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnitType18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.64E7d + "'", double19 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(list43);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint11 = xYStepAreaRenderer1.getBaseFillPaint();
        xYStepAreaRenderer1.setBaseCreateEntities(true, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("DatasetRenderingOrder.FORWARD", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "hi!", "", "6/13/19 1:07 PM");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect(4.0d, (double) (byte) 1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean10 = combinedRangeXYPlot0.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker6, layer8, true);
        combinedRangeXYPlot0.zoom((double) 10L);
        combinedRangeXYPlot0.setWeight(15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(4);
        int int10 = year9.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(4);
        int int13 = year12.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year12);
        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(4);
        int int22 = year21.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year21);
        int int24 = year18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        timeSeries3.add(regularTimePeriod25, 1.0E-5d, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        java.awt.Shape shape30 = legendItemEntity29.getArea();
        legendItemEntity29.setSeriesKey((java.lang.Comparable) 8.64E7d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Color color2 = java.awt.Color.getColor("index.html", (-458));
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-458) + "'", int3 == (-458));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setDatasetIndex((-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYCrosshairState0.updateCrosshairPoint((double) 64, (double) 9, (-1), 2958465, (double) (-2208960000000L), 33.0d, plotOrientation9);
        xYCrosshairState0.setCrosshairDistance(0.0d);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) 0.0f, (java.lang.Number) 10);
        boolean boolean9 = xYSeries1.getNotify();
        int int10 = xYSeries1.getItemCount();
        org.junit.Assert.assertNull(xYDataItem8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getLabelFont();
        boolean boolean2 = numberAxis0.isInverted();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        double double13 = barRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.util.List list10 = null;
        try {
            jFreeChart7.setSubtitles(list10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation((-1));
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer3D2.setBaseURLGenerator(categoryURLGenerator4, true);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        org.jfree.data.Range range5 = timeSeriesCollection1.getDomainBounds(true);
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot0.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = dateTickUnit4.getUnitType();
        double double6 = dateTickUnit4.getSize();
        dateAxis3.setTickUnit(dateTickUnit4, false, false);
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot1.getColumnRenderingOrder();
        java.awt.Paint paint13 = categoryPlot1.getDomainCrosshairPaint();
        java.awt.Paint paint14 = categoryPlot1.getRangeZeroBaselinePaint();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        java.awt.Stroke stroke26 = periodAxis22.getTickMarkStroke();
        periodAxis22.setMinorTickMarksVisible(true);
        org.jfree.data.Range range29 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis22);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = valueMarker31.getLabelOffset();
        categoryPlot1.setAxisOffset(rectangleInsets32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot34.getFixedLegendItems();
        categoryPlot34.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot34.setDomainAxisLocation(axisLocation39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot34.getDomainAxisLocation();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint44 = null;
        xYStepAreaRenderer43.setBasePaint(paint44);
        java.awt.Stroke stroke47 = null;
        xYStepAreaRenderer43.setSeriesOutlineStroke((int) ' ', stroke47);
        org.jfree.data.xy.XYSeries xYSeries50 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        xYSeries50.removeChangeListener(seriesChangeListener51);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection(xYSeries50);
        int int57 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection53, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range58 = xYStepAreaRenderer43.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = xYStepAreaRenderer60.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape66 = xYStepAreaRenderer60.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity69 = new org.jfree.chart.entity.AxisEntity(shape66, (org.jfree.chart.axis.Axis) categoryAxis67, "");
        xYStepAreaRenderer43.setBaseLegendShape(shape66);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity71 = new org.jfree.chart.entity.LegendItemEntity(shape66);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer73 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint74 = null;
        xYStepAreaRenderer73.setBasePaint(paint74);
        java.awt.Stroke stroke77 = null;
        xYStepAreaRenderer73.setSeriesOutlineStroke((int) ' ', stroke77);
        xYStepAreaRenderer73.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries82 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener83 = null;
        xYSeries82.removeChangeListener(seriesChangeListener83);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection85 = new org.jfree.data.xy.XYSeriesCollection(xYSeries82);
        org.jfree.chart.axis.ValueAxis valueAxis86 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer87 = null;
        org.jfree.chart.plot.PolarPlot polarPlot88 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection85, valueAxis86, polarItemRenderer87);
        org.jfree.data.Range range89 = xYStepAreaRenderer73.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection85);
        org.jfree.data.Range range91 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection85, true);
        legendItemEntity71.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection85);
        boolean boolean93 = axisLocation41.equals((java.lang.Object) legendItemEntity71);
        categoryPlot1.setDomainAxisLocation(axisLocation41, false);
        xYPlot0.setRangeAxisLocation(axisLocation41, false);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.64E7d + "'", double6 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertNotNull(itemLabelPosition62);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNull(range89);
        org.junit.Assert.assertNull(range91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setLabelLinksVisible(false);
        double double5 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        double double13 = categoryPlot0.getAnchorValue();
        boolean boolean14 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getLastItemIndex();
        java.awt.geom.Line2D line2D3 = null;
        xYItemRendererState1.workingLine = line2D3;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Multiple Pie Plot", timeZone1);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        java.awt.Stroke stroke12 = periodAxis8.getTickMarkStroke();
        java.lang.Class class13 = periodAxis8.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(4);
        int int17 = year16.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(4);
        int int20 = year19.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo22 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray23 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo22 };
        periodAxis21.setLabelInfo(periodAxisLabelInfoArray23);
        java.awt.Stroke stroke25 = periodAxis21.getTickMarkStroke();
        java.lang.Class class26 = periodAxis21.getAutoRangeTimePeriodClass();
        periodAxis8.setMinorTickTimePeriodClass(class26);
        java.lang.Class class28 = periodAxis8.getMinorTickTimePeriodClass();
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(uRL29);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = null;
        piePlot2.setOutlineStroke(stroke3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot2.setBaseSectionOutlinePaint(paint8);
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Font font11 = standardChartTheme1.getExtraLargeFont();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]" + "'", str4.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        xYSeries1.add((java.lang.Number) 0.4d, (java.lang.Number) 3.0d, false);
        boolean boolean10 = xYSeries1.getAutoSort();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        try {
            polarPlot7.zoomRangeAxes(3.0d, (double) 900000L, plotRenderingInfo13, point2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        boolean boolean2 = xYAreaRenderer1.isOutline();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setNoDataMessage("hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint8 = null;
        xYStepAreaRenderer7.setBasePaint(paint8);
        java.awt.Stroke stroke11 = null;
        xYStepAreaRenderer7.setSeriesOutlineStroke((int) ' ', stroke11);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer7.setSeriesPaint(4, paint14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getOutlineStroke();
        xYStepAreaRenderer7.setBaseOutlineStroke(stroke17, false);
        piePlot3.setLabelLinkStroke(stroke17);
        xYAreaRenderer1.setBaseStroke(stroke17, false);
        org.jfree.chart.LegendItem legendItem25 = xYAreaRenderer1.getLegendItem((int) (short) 100, 64);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(legendItem25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) '#');
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) (byte) 10, (double) (-458));
        org.jfree.chart.block.BorderArrangement borderArrangement16 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1, (org.jfree.chart.block.Arrangement) columnArrangement15, (org.jfree.chart.block.Arrangement) borderArrangement16);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle17);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj9 = barRenderer3D8.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle3.getPosition();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(4);
        int int11 = year10.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo13 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo13 };
        periodAxis12.setLabelInfo(periodAxisLabelInfoArray14);
        java.awt.Stroke stroke16 = periodAxis12.getTickMarkStroke();
        java.lang.Class class17 = periodAxis12.getAutoRangeTimePeriodClass();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis12);
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot18);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline29 = dateAxis28.getTimeline();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) dateAxis28, "DatasetRenderingOrder.FORWARD");
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape22, 8.64E7d, 1.0d);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 10.0f, (float) 2, 0.0f);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(timeline29);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer1.getBasePositiveItemLabelPosition();
        xYStepAreaRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYStepAreaRenderer1.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        polarPlot7.setAngleGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean12 = polarPlot7.equals((java.lang.Object) rectangleEdge11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color13);
        int int15 = polarPlot7.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.geom.Rectangle2D rectangle2D2 = blockContainer0.getBounds();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            boolean boolean4 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("DomainOrder.NONE");
        java.lang.String str2 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Font font2 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.getShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        java.awt.Font font7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) waferMapPlot8, false);
        jFreeChart10.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart10.getLegend((int) (byte) 0);
        jFreeChart10.setTextAntiAlias(false);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeries1, jFreeChart10);
        try {
            org.jfree.chart.plot.XYPlot xYPlot18 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.WaferMapPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(renderingHints16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "SerialDate.weekInMonthToString(): invalid code.", textAnchor2, textAnchor3, (-1.0d));
        java.lang.String str6 = numberTick5.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str6.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D3);
        size2D4.setHeight((double) 1.0f);
        java.lang.Object obj7 = size2D4.clone();
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean10 = categoryPlot0.removeRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) valueMarker6, layer8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes(1.0E-8d, plotRenderingInfo12, point2D13, true);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        int int22 = combinedRangeXYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range24 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis23);
        java.util.List list25 = combinedRangeXYPlot0.getSubplots();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Font font11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) waferMapPlot12, false);
        jFreeChart14.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart14.getLegend((int) (byte) 0);
        java.awt.Paint paint18 = jFreeChart14.getBorderPaint();
        standardChartTheme1.setDomainGridlinePaint(paint18);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint21 = null;
        try {
            standardChartTheme1.setGridBandPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.clearSectionOutlineStrokes(true);
        boolean boolean11 = xYSeries1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType13 = dateTickUnit12.getUnitType();
        java.awt.Paint paint14 = piePlot5.getSectionOutlinePaint((java.lang.Comparable) dateTickUnit12);
        int int15 = dateTickUnit12.getMultiple();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(dateTickUnitType13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape9 = xYStepAreaRenderer3.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) categoryAxis10, "");
        int int13 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Font font14 = categoryAxis10.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font14);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        xYSeries17.removeChangeListener(seriesChangeListener18);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection(xYSeries17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection20, valueAxis21, polarItemRenderer22);
        boolean boolean24 = polarPlot23.isAngleLabelsVisible();
        polarPlot23.setAngleGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean28 = polarPlot23.equals((java.lang.Object) rectangleEdge27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        polarPlot23.setRadiusGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("AxisLocation.BOTTOM_OR_RIGHT", font14, (java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d, false);
        double double25 = combinedRangeXYPlot0.getGap();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 5.0d + "'", double25 == 5.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.geom.GeneralPath generalPath2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.RenderingSource renderingSource4 = null;
        combinedRangeXYPlot0.select(generalPath2, rectangle2D3, renderingSource4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot8 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo6, point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getCategoryLabelPositionOffset();
        java.awt.Font font12 = categoryAxis8.getTickLabelFont();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis8.getCategoryLabelPositions();
        categoryAxis8.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(4);
        int int35 = year34.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(4);
        int int38 = year37.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) year37);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo40 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray41 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo40 };
        periodAxis39.setLabelInfo(periodAxisLabelInfoArray41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { periodAxis39, dateAxis44 };
        combinedRangeXYPlot31.setRangeAxes(valueAxisArray45);
        boolean boolean47 = combinedRangeXYPlot31.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = null;
        combinedRangeXYPlot31.datasetChanged(datasetChangeEvent48);
        org.jfree.chart.LegendItemCollection legendItemCollection50 = null;
        combinedRangeXYPlot31.setFixedLegendItems(legendItemCollection50);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState54 = xYStepAreaRenderer1.initialise(graphics2D29, rectangle2D30, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot31, xYDataset52, plotRenderingInfo53);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint57 = null;
        xYStepAreaRenderer56.setBasePaint(paint57);
        java.awt.Stroke stroke60 = null;
        xYStepAreaRenderer56.setSeriesOutlineStroke((int) ' ', stroke60);
        org.jfree.data.xy.XYSeries xYSeries63 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        xYSeries63.removeChangeListener(seriesChangeListener64);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection66 = new org.jfree.data.xy.XYSeriesCollection(xYSeries63);
        int int70 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection66, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range71 = xYStepAreaRenderer56.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection66);
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection66);
        xYItemRendererState54.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection66);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray41);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState54);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertEquals((double) number72, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity10 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart8, "Category Plot");
        java.awt.RenderingHints renderingHints11 = jFreeChart8.getRenderingHints();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(renderingHints11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = strokeMap0.getStroke((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double1 = dateRange0.getCentralValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("6/13/19 1:07 PM");
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        java.text.DateFormat dateFormat5 = standardXYToolTipGenerator3.getXDateFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        boolean boolean4 = rectangleAnchor0.equals((java.lang.Object) shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        java.lang.Class class12 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint15 = null;
        xYStepAreaRenderer14.setBasePaint(paint15);
        java.awt.Stroke stroke18 = null;
        xYStepAreaRenderer14.setSeriesOutlineStroke((int) ' ', stroke18);
        java.awt.Paint paint21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer14.setSeriesPaint(4, paint21);
        boolean boolean23 = xYStepAreaRenderer14.getPlotArea();
        xYStepAreaRenderer14.removeAnnotations();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(4);
        int int34 = year33.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo36 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray37 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo36 };
        periodAxis35.setLabelInfo(periodAxisLabelInfoArray37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { periodAxis35, dateAxis40 };
        combinedRangeXYPlot27.setRangeAxes(valueAxisArray41);
        boolean boolean43 = combinedRangeXYPlot27.isRangeMinorGridlinesVisible();
        boolean boolean44 = combinedRangeXYPlot27.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = combinedRangeXYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer47);
        int int49 = combinedRangeXYPlot27.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range51 = combinedRangeXYPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis50);
        org.jfree.data.xy.XYSeries xYSeries53 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        xYSeries53.removeChangeListener(seriesChangeListener54);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection56 = new org.jfree.data.xy.XYSeriesCollection(xYSeries53);
        int int60 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection56, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection56, false);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection56, false);
        java.lang.Number number65 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection56);
        xYSeriesCollection56.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState68 = xYStepAreaRenderer14.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot27, (org.jfree.data.xy.XYDataset) xYSeriesCollection56, plotRenderingInfo67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double71 = rectangleInsets69.trimHeight((double) (-452));
        combinedRangeXYPlot27.setAxisOffset(rectangleInsets69);
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis74.setInverted(false);
        java.util.Date date77 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis74.setMinimumDate(date77);
        org.jfree.chart.StandardChartTheme standardChartTheme80 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier81 = standardChartTheme80.getDrawingSupplier();
        java.awt.Font font83 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot84 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart86 = new org.jfree.chart.JFreeChart("", font83, (org.jfree.chart.plot.Plot) waferMapPlot84, false);
        jFreeChart86.removeLegend();
        standardChartTheme80.apply(jFreeChart86);
        java.awt.Paint paint89 = standardChartTheme80.getDomainGridlinePaint();
        java.awt.Paint paint90 = standardChartTheme80.getGridBandPaint();
        dateAxis74.setTickMarkPaint(paint90);
        combinedRangeXYPlot27.setRangeTickBandPaint(paint90);
        periodAxis7.setMinorTickMarkPaint(paint90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray37);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertEquals((double) number65, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState68);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-458.0d) + "'", double71 == (-458.0d));
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(drawingSupplier81);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(paint90);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(3);
        boolean boolean7 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) Double.NaN);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint4);
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke10 = null;
        piePlot9.setOutlineStroke(stroke10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setNoDataMessage("hi!");
        java.awt.Paint paint15 = piePlot12.getBaseSectionOutlinePaint();
        piePlot9.setBaseSectionOutlinePaint(paint15);
        standardChartTheme8.setRangeGridlinePaint(paint15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme8.setErrorIndicatorPaint((java.awt.Paint) color18);
        float[] floatArray26 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray27 = color18.getColorComponents(floatArray26);
        int int28 = color18.getGreen();
        combinedRangeXYPlot0.setDomainCrosshairPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke30 = null;
        try {
            combinedRangeXYPlot0.setDomainGridlineStroke(stroke30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 64 + "'", int28 == 64);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        int int9 = segmentedTimeline7.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Comparable comparable1 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Paint paint2 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(comparable1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Shape shape11 = periodAxis7.getLeftArrow();
        org.jfree.chart.plot.Plot plot12 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape11, plot12, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "{0}: ({1}, {2})");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        polarPlot7.setOutlineVisible(true);
        polarPlot7.setRadiusGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType14 = org.jfree.data.RangeType.POSITIVE;
        numberAxis13.setRangeType(rangeType14);
        numberAxis13.configure();
        double double17 = numberAxis13.getUpperMargin();
        java.awt.Font font18 = numberAxis13.getTickLabelFont();
        numberAxis13.setTickLabelsVisible(true);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle4.getPosition();
        textTitle2.setPosition(rectangleEdge5);
        textTitle2.setHeight(0.0d);
        textTitle2.setURLText("DatasetRenderingOrder.FORWARD");
        java.awt.Font font11 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        double double2 = dateAxis1.getUpperMargin();
        dateAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Paint paint10 = standardChartTheme1.getItemLabelPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        xYStepAreaRenderer1.setShapesVisible(false);
        java.lang.Boolean boolean7 = xYStepAreaRenderer1.getSeriesVisibleInLegend(10);
        xYStepAreaRenderer1.setBaseCreateEntities(true, false);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = standardChartTheme12.getDrawingSupplier();
        java.awt.Paint paint14 = standardChartTheme12.getItemLabelPaint();
        xYStepAreaRenderer1.setBaseLegendTextPaint(paint14);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        int int18 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range19 = xYStepAreaRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        xYStepAreaRenderer4.setBaseLegendShape(shape27);
        boolean boolean32 = multiplePiePlot0.equals((java.lang.Object) xYStepAreaRenderer4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str34 = combinedRangeXYPlot33.getPlotType();
        java.awt.Paint paint35 = combinedRangeXYPlot33.getDomainCrosshairPaint();
        combinedRangeXYPlot33.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker39.getLabelAnchor();
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean43 = combinedRangeXYPlot33.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker39, layer41, true);
        boolean boolean44 = multiplePiePlot0.equals((java.lang.Object) boolean43);
        org.jfree.chart.util.TableOrder tableOrder45 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined Range XYPlot" + "'", str34.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        java.awt.Paint paint15 = legendItem14.getLabelPaint();
        java.awt.Paint paint16 = legendItem14.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Comparable comparable1 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Paint paint2 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        try {
            int int4 = categoryPlot0.getRangeAxisIndex(valueAxis3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(comparable1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getLabelFont();
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        double double18 = combinedRangeXYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setPlotArea(true);
        boolean boolean10 = xYStepAreaRenderer1.isSeriesVisibleInLegend((int) ' ');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer12.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer17.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer12.setSeriesPositiveItemLabelPosition(0, itemLabelPosition19);
        xYStepAreaRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition19, false);
        double double23 = itemLabelPosition19.getAngle();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image3, "DomainOrder.NONE", "", "DomainOrder.NONE");
        java.lang.String str8 = projectInfo7.getName();
        java.awt.Image image9 = projectInfo7.getLogo();
        projectInfo7.setName("Combined Range XYPlot");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "series" + "'", str8.equals("series"));
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        boolean boolean17 = polarPlot16.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) polarPlot16, "{0}: ({1}, {2})");
        java.lang.Object obj20 = plotEntity19.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D3);
        java.lang.Object obj5 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockContainer0.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo19, point2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator5);
        int int7 = barRenderer3D2.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer3D2.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator9);
        barRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        try {
            barRenderer3D2.setSeriesURLGenerator((-13120), categoryURLGenerator14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        double double6 = rectangleInsets3.calculateTopOutset((double) (-2208927600001L));
        double double8 = rectangleInsets3.calculateBottomInset((double) 'a');
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        valueMarker1.setValue((double) (short) 0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint13 = null;
        xYStepAreaRenderer12.setBasePaint(paint13);
        java.awt.Stroke stroke16 = null;
        xYStepAreaRenderer12.setSeriesOutlineStroke((int) ' ', stroke16);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot18 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        waferMapPlot18.setDataset(waferMapDataset19);
        xYStepAreaRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot18);
        xYStepAreaRenderer12.setRangeBase((double) (-1L));
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer12.setBaseItemLabelFont(font24);
        xYStepAreaRenderer1.setBaseItemLabelFont(font24);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj11 = standardGradientPaintTransformer10.clone();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        xYAreaRenderer1.setOutline(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer16.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str20 = combinedRangeXYPlot19.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace21 = combinedRangeXYPlot19.getFixedDomainAxisSpace();
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal(paint22, paint23);
        combinedRangeXYPlot19.setDomainCrosshairPaint(paint23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer27.setSeriesPaint(4, paint34);
        boolean boolean36 = xYStepAreaRenderer27.getPlotArea();
        xYStepAreaRenderer27.removeAnnotations();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { periodAxis48, dateAxis53 };
        combinedRangeXYPlot40.setRangeAxes(valueAxisArray54);
        boolean boolean56 = combinedRangeXYPlot40.isRangeMinorGridlinesVisible();
        boolean boolean57 = combinedRangeXYPlot40.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = combinedRangeXYPlot40.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker59, layer60);
        int int62 = combinedRangeXYPlot40.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range64 = combinedRangeXYPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis63);
        org.jfree.data.xy.XYSeries xYSeries66 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
        xYSeries66.removeChangeListener(seriesChangeListener67);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection69 = new org.jfree.data.xy.XYSeriesCollection(xYSeries66);
        int int73 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection69, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection69);
        xYSeriesCollection69.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer27.initialise(graphics2D38, rectangle2D39, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot40, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState83 = xYAreaRenderer1.initialise(graphics2D15, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo82);
        int int84 = xYSeriesCollection69.getSeriesCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Combined Range XYPlot" + "'", str20.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNull(range75);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertEquals((double) number78, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(xYItemRendererState83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        java.text.NumberFormat numberFormat2 = standardXYToolTipGenerator0.getXFormat();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        java.awt.color.ColorSpace colorSpace13 = color6.getColorSpace();
        barRenderer3D5.setBaseItemLabelPaint((java.awt.Paint) color6, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType21 = dateTickUnit20.getUnitType();
        double double22 = dateTickUnit20.getSize();
        dateAxis19.setTickUnit(dateTickUnit20, false, false);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot17.getColumnRenderingOrder();
        java.awt.Paint paint29 = categoryPlot17.getDomainCrosshairPaint();
        double double30 = categoryPlot17.getAnchorValue();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(4);
        int int34 = year33.getYear();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(4);
        int int37 = year36.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) year36);
        double double39 = periodAxis38.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer3D5.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis38, rectangle2D40, 1.0d);
        org.jfree.data.time.DateRange dateRange43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange44 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange43);
        periodAxis38.setRange((org.jfree.data.Range) dateRange44, false, false);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator48 = numberFormat2.formatToCharacterIterator((java.lang.Object) dateRange44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(dateTickUnitType21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.64E7d + "'", double22 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange43);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle4.getPosition();
        textTitle2.setPosition(rectangleEdge5);
        textTitle2.visible = true;
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str2 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getDomainAxisLocation((-458));
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(4);
        int int11 = year10.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo13 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo13 };
        periodAxis12.setLabelInfo(periodAxisLabelInfoArray14);
        java.awt.Stroke stroke16 = periodAxis12.getTickMarkStroke();
        combinedRangeXYPlot1.setDomainGridlineStroke(stroke16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke16, rectangleInsets18);
        org.jfree.chart.StandardChartTheme standardChartTheme21 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke23 = null;
        piePlot22.setOutlineStroke(stroke23);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        piePlot25.setNoDataMessage("hi!");
        java.awt.Paint paint28 = piePlot25.getBaseSectionOutlinePaint();
        piePlot22.setBaseSectionOutlinePaint(paint28);
        standardChartTheme21.setRangeGridlinePaint(paint28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme21.setErrorIndicatorPaint((java.awt.Paint) color31);
        float[] floatArray39 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray40 = color31.getColorComponents(floatArray39);
        float[] floatArray41 = color0.getComponents(floatArray40);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined Range XYPlot" + "'", str2.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str5 = combinedRangeXYPlot4.getPlotType();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = combinedRangeXYPlot4.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker10, layer12, true);
        combinedRangeXYPlot4.mapDatasetToDomainAxis(255, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot19.getFixedLegendItems();
        categoryPlot19.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot19.setDomainAxisLocation(axisLocation24);
        combinedRangeXYPlot4.setRangeAxisLocation(0, axisLocation24);
        categoryPlot0.setRangeAxisLocation((int) (byte) 1, axisLocation24, false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined Range XYPlot" + "'", str5.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        boolean boolean7 = xYStepAreaRenderer1.getItemCreateEntity(0, 2, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range3 = timeSeriesCollection1.getDomainBounds(false);
        try {
            java.lang.Number number6 = timeSeriesCollection1.getEndX((-452), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        try {
            java.lang.Number number24 = xYSeriesCollection13.getX(10, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 'a');
        double double6 = rectangleConstraint5.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint5.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        boolean boolean13 = periodAxis7.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = periodAxis7.getLast();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        double double4 = dateTickUnit2.getSize();
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        java.util.Date date9 = dateRange8.getUpperDate();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9);
        dateAxis1.setMaximumDate(date9);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.64E7d + "'", double4 == 8.64E7d);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint11 = xYStepAreaRenderer1.getItemPaint(1, (int) '4', true);
        java.awt.Shape shape12 = xYStepAreaRenderer1.getBaseLegendShape();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYStepAreaRenderer14.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setBaseNegativeItemLabelPosition(itemLabelPosition16, false);
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition16.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        int int8 = year2.getYear();
        int int9 = year2.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) (-1.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer3D2.getLegendItemLabelGenerator();
        java.awt.Paint paint15 = barRenderer3D2.lookupSeriesOutlinePaint((-452));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        java.awt.color.ColorSpace colorSpace26 = color19.getColorSpace();
        barRenderer3D18.setBaseItemLabelPaint((java.awt.Paint) color19, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = barRenderer3D18.getLegendItemLabelGenerator();
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator29);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint3 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint4 = standardChartTheme1.getItemLabelPaint();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        org.jfree.data.DomainOrder domainOrder10 = xYSeriesCollection4.getDomainOrder();
        xYSeriesCollection4.validateObject();
        try {
            java.lang.Comparable comparable13 = xYSeriesCollection4.getSeriesKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(domainOrder10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean12 = standardXYURLGenerator10.equals((java.lang.Object) rectangleAnchor11);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean12);
        java.lang.Object obj14 = chartChangeEvent13.getSource();
        java.awt.Font font16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", font16, (org.jfree.chart.plot.Plot) waferMapPlot17, false);
        jFreeChart19.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart19.getLegend((int) (byte) 0);
        boolean boolean23 = jFreeChart19.isNotify();
        chartChangeEvent13.setChart(jFreeChart19);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) multiplePiePlot8, jFreeChart19, 0, 2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + false + "'", obj14.equals(false));
        org.junit.Assert.assertNull(legendTitle22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        axisState0.setCursor((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        double double66 = categoryPlot51.getAnchorValue();
        categoryPlot51.clearRangeMarkers();
        boolean boolean68 = categoryPlot51.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        dateAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        double double8 = dateAxis7.getUpperMargin();
        java.util.Date date9 = dateAxis7.getMaximumDate();
        dateAxis1.setMinimumDate(date9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.lang.String str9 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = null;
        try {
            categoryPlot0.setDomainAxes(categoryAxisArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint4 = null;
        xYStepAreaRenderer3.setBasePaint(paint4);
        xYStepAreaRenderer3.setAutoPopulateSeriesFillPaint(true);
        int int8 = objectList1.indexOf((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (-458));
        java.lang.String str5 = verticalAlignment1.toString();
        java.lang.String str6 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.TOP" + "'", str5.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.TOP" + "'", str6.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        numberAxis0.configure();
        double double4 = numberAxis0.getUpperMargin();
        java.awt.Font font5 = numberAxis0.getTickLabelFont();
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str9 = combinedRangeXYPlot8.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace10 = combinedRangeXYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = combinedRangeXYPlot8.getAxisOffset();
        numberAxis0.setTickLabelInsets(rectangleInsets11);
        java.text.NumberFormat numberFormat14 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat14, numberFormat15);
        numberAxis0.setNumberFormatOverride(numberFormat15);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Combined Range XYPlot" + "'", str9.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        java.awt.Paint paint18 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        combinedRangeXYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        int int36 = combinedRangeXYPlot14.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range38 = combinedRangeXYPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        int int47 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection43, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYStepAreaRenderer1.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo54);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer1.setBaseItemLabelPaint(paint56);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        int int18 = combinedRangeXYPlot0.getSeriesCount();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke22 = piePlot21.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder(paint20, stroke22, rectangleInsets23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer26.setBaseSeriesVisible(false);
        xYStepAreaRenderer26.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint31 = xYStepAreaRenderer26.getBasePaint();
        boolean boolean32 = rectangleInsets23.equals((java.lang.Object) xYStepAreaRenderer26);
        java.awt.Font font35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font35, (java.awt.Paint) color36);
        xYStepAreaRenderer26.setLegendTextFont(6, font35);
        java.awt.Paint paint40 = xYStepAreaRenderer26.getSeriesOutlinePaint(9);
        combinedRangeXYPlot0.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer26);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation42 = null;
        try {
            boolean boolean43 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(paint40);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        org.jfree.data.DomainOrder domainOrder10 = xYSeriesCollection4.getDomainOrder();
        xYSeriesCollection4.validateObject();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertEquals((double) number12, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Font font11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) waferMapPlot12, false);
        jFreeChart14.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart14.getLegend((int) (byte) 0);
        java.awt.Paint paint18 = jFreeChart14.getBorderPaint();
        standardChartTheme1.setDomainGridlinePaint(paint18);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = null;
        piePlot23.setOutlineStroke(stroke24);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        piePlot26.setNoDataMessage("hi!");
        java.awt.Paint paint29 = piePlot26.getBaseSectionOutlinePaint();
        piePlot23.setBaseSectionOutlinePaint(paint29);
        standardChartTheme22.setRangeGridlinePaint(paint29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme22.setErrorIndicatorPaint((java.awt.Paint) color32);
        float[] floatArray40 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray41 = color32.getColorComponents(floatArray40);
        int int42 = color32.getGreen();
        standardChartTheme1.setPlotOutlinePaint((java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 64 + "'", int42 == 64);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.lang.Object obj1 = xYBarRenderer0.clone();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape9 = xYStepAreaRenderer3.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint13 = xYStepAreaRenderer3.getItemPaint(1, (int) '4', true);
        java.awt.Shape shape14 = xYStepAreaRenderer3.getBaseLegendShape();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition18, false);
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition18);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean3 = standardXYURLGenerator1.equals((java.lang.Object) rectangleAnchor2);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean3);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        java.awt.Font font7 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) waferMapPlot8, false);
        jFreeChart10.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart10.getLegend((int) (byte) 0);
        boolean boolean14 = jFreeChart10.isNotify();
        chartChangeEvent4.setChart(jFreeChart10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockContainer17.getMargin();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer17.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        try {
            jFreeChart10.draw(graphics2D16, rectangle2D19, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + false + "'", obj5.equals(false));
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        valueMarker1.setLabel("index.html");
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        periodAxis7.setMinorTickMarksVisible(true);
        java.util.Locale locale14 = periodAxis7.getLocale();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1);
        try {
            periodAxis7.setRangeWithMargins(range15, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        try {
            java.util.Collection collection5 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image3, "DomainOrder.NONE", "", "DomainOrder.NONE");
        java.lang.String str8 = projectInfo7.toString();
        java.util.List list9 = null;
        projectInfo7.setContributors(list9);
        projectInfo7.setName("AxisLocation.BOTTOM_OR_RIGHT");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE" + "'", str8.equals("series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        java.lang.Comparable comparable27 = null;
        legendItem14.setSeriesKey(comparable27);
        java.awt.Paint paint29 = legendItem14.getOutlinePaint();
        java.text.AttributedString attributedString30 = legendItem14.getAttributedLabel();
        java.awt.Paint paint31 = null;
        try {
            legendItem14.setFillPaint(paint31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(attributedString30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        boolean boolean5 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray7, doubleArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3, (org.jfree.data.general.Dataset) categoryDataset10, (java.lang.Comparable) numberTickUnit13);
        categoryPlot0.setDataset(categoryDataset10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getMaximumCategoryLabelLines();
        categoryAxis8.setFixedDimension((double) (short) -1);
        double double14 = categoryAxis8.getLabelAngle();
        categoryAxis8.setCategoryLabelPositionOffset((int) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis8.getCategorySeriesMiddle((int) ' ', (-458), (int) (byte) 10, (int) (short) 100, 0.05d, rectangle2D22, rectangleEdge23);
        java.lang.Comparable comparable26 = null;
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray29, doubleArray30, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset33);
        org.jfree.data.general.PieDataset pieDataset36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (java.lang.Comparable) Double.NaN);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape40 = numberAxis39.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity42 = new org.jfree.chart.entity.TitleEntity(shape40, (org.jfree.chart.title.Title) textTitle41);
        org.jfree.chart.title.Title title43 = titleEntity42.getTitle();
        org.jfree.data.xy.XYSeries xYSeries45 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        xYSeries45.removeChangeListener(seriesChangeListener46);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection48 = new org.jfree.data.xy.XYSeriesCollection(xYSeries45);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection48, valueAxis49, polarItemRenderer50);
        boolean boolean52 = polarPlot51.isAngleLabelsVisible();
        polarPlot51.setAngleGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean56 = polarPlot51.equals((java.lang.Object) rectangleEdge55);
        title43.setPosition(rectangleEdge55);
        try {
            double double58 = categoryAxis8.getCategorySeriesMiddle((java.lang.Comparable) 31, comparable26, categoryDataset33, (double) (-2208960000000L), rectangle2D38, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(pieDataset36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(title43);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        double double51 = xYSeriesCollection43.getDomainUpperBound(true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        try {
            xYSeriesCollection43.removeSeries(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font1, (java.awt.Paint) color2);
        java.awt.Color color4 = color2.brighter();
        java.awt.Color color5 = color4.brighter();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("6/13/19 1:07 PM", font1, paint2, (float) (byte) 10);
        java.awt.Font font5 = textFragment4.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        int int36 = combinedRangeXYPlot14.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range38 = combinedRangeXYPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        int int47 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection43, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYStepAreaRenderer1.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double58 = rectangleInsets56.trimHeight((double) (-452));
        combinedRangeXYPlot14.setAxisOffset(rectangleInsets56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis61.setInverted(false);
        java.util.Date date64 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis61.setMinimumDate(date64);
        org.jfree.chart.StandardChartTheme standardChartTheme67 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier68 = standardChartTheme67.getDrawingSupplier();
        java.awt.Font font70 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot71 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart73 = new org.jfree.chart.JFreeChart("", font70, (org.jfree.chart.plot.Plot) waferMapPlot71, false);
        jFreeChart73.removeLegend();
        standardChartTheme67.apply(jFreeChart73);
        java.awt.Paint paint76 = standardChartTheme67.getDomainGridlinePaint();
        java.awt.Paint paint77 = standardChartTheme67.getGridBandPaint();
        dateAxis61.setTickMarkPaint(paint77);
        combinedRangeXYPlot14.setRangeTickBandPaint(paint77);
        combinedRangeXYPlot14.setRangePannable(true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-458.0d) + "'", double58 == (-458.0d));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(drawingSupplier68);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart4.getLegend((int) (byte) 0);
        boolean boolean8 = jFreeChart4.isNotify();
        jFreeChart4.setAntiAlias(true);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint14 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.StandardChartTheme standardChartTheme16 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = standardChartTheme16.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier17);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier17);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint15 = null;
        xYStepAreaRenderer14.setBasePaint(paint15);
        java.awt.Stroke stroke18 = null;
        xYStepAreaRenderer14.setSeriesOutlineStroke((int) ' ', stroke18);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        xYSeries21.removeChangeListener(seriesChangeListener22);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection(xYSeries21);
        int int28 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection24, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range29 = xYStepAreaRenderer14.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer31.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape37 = xYStepAreaRenderer31.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity40 = new org.jfree.chart.entity.AxisEntity(shape37, (org.jfree.chart.axis.Axis) categoryAxis38, "");
        xYStepAreaRenderer14.setBaseLegendShape(shape37);
        periodAxis7.setDownArrow(shape37);
        boolean boolean43 = periodAxis7.isInverted();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.LegendItem legendItem8 = xYStepAreaRenderer1.getLegendItem(1, (-1));
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        boolean boolean4 = blockContainer0.equals((java.lang.Object) 10.0f);
        double double5 = blockContainer0.getHeight();
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint6, stroke8, rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder10.getInsets();
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder10);
        blockContainer0.clear();
        blockContainer0.clear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        double double2 = dateAxis1.getUpperMargin();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis1.getTickUnit();
        dateAxis1.setMinorTickCount((int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = dateTickUnit4.getUnitType();
        double double6 = dateTickUnit4.getSize();
        dateAxis3.setTickUnit(dateTickUnit4, false, false);
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        barRenderer3D0.setPlot(categoryPlot1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str14 = combinedRangeXYPlot13.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot13.getDomainAxisLocation((-458));
        categoryPlot1.setDomainAxisLocation(axisLocation16);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.64E7d + "'", double6 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = null;
        piePlot2.setOutlineStroke(stroke3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot2.setBaseSectionOutlinePaint(paint8);
        standardChartTheme1.setRangeGridlinePaint(paint8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        standardChartTheme1.setChartBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis14.setInverted(false);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis14.setMinimumDate(date17);
        org.jfree.chart.StandardChartTheme standardChartTheme20 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = standardChartTheme20.getDrawingSupplier();
        java.awt.Font font23 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("", font23, (org.jfree.chart.plot.Plot) waferMapPlot24, false);
        jFreeChart26.removeLegend();
        standardChartTheme20.apply(jFreeChart26);
        java.awt.Paint paint29 = standardChartTheme20.getDomainGridlinePaint();
        java.awt.Paint paint30 = standardChartTheme20.getGridBandPaint();
        dateAxis14.setTickMarkPaint(paint30);
        standardChartTheme1.setBaselinePaint(paint30);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font3, (java.awt.Paint) color4);
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 4, (java.awt.Paint) color4);
        boolean boolean7 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        double double5 = piePlot0.getMinimumArcAngleToDraw();
        boolean boolean6 = piePlot0.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.setRangePannable(false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer11.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape17 = xYStepAreaRenderer11.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint21 = xYStepAreaRenderer11.getItemPaint(1, (int) '4', true);
        combinedRangeXYPlot7.setRangeTickBandPaint(paint21);
        piePlot0.setBaseSectionPaint(paint21);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = lineBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) 'a');
        double double9 = rectangleInsets5.calculateRightInset((double) 0L);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        try {
            xYSeriesCollection13.setSelected(31, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        categoryPlot0.setCrosshairDatasetIndex((-458), false);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint3 = piePlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        xYSeries1.add((java.lang.Number) 0.4d, (java.lang.Number) 3.0d, false);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.xy.XYDataItem xYDataItem12 = null;
        try {
            org.jfree.data.xy.XYDataItem xYDataItem13 = xYSeries1.addOrUpdate(xYDataItem12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme1.setLegendBackgroundPaint(paint2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint15 = xYStepAreaRenderer5.getItemPaint(1, (int) '4', true);
        standardChartTheme1.setCrosshairPaint(paint15);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle17 = standardChartTheme1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRange(true);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity6 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) textTitle5);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape14 = xYStepAreaRenderer8.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape14);
        numberAxis0.setRightArrow(shape4);
        numberAxis0.setInverted(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str22 = combinedRangeXYPlot21.getPlotType();
        java.awt.Paint paint23 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        combinedRangeXYPlot21.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = combinedRangeXYPlot21.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker27, layer29, true);
        combinedRangeXYPlot21.zoom((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font35 = numberAxis34.getLabelFont();
        boolean boolean36 = combinedRangeXYPlot21.equals((java.lang.Object) numberAxis34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.BlockContainer blockContainer38 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockContainer38.getMargin();
        java.awt.geom.Rectangle2D rectangle2D40 = blockContainer38.getBounds();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState();
        double double54 = axisState53.getMax();
        axisState53.cursorLeft(100.0d);
        axisState53.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle60.getPosition();
        java.util.List list62 = periodAxis48.refreshTicks(graphics2D52, axisState53, rectangle2D59, rectangleEdge61);
        combinedRangeXYPlot21.drawDomainTickBands(graphics2D37, rectangle2D40, list62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.TOP;
        double double65 = numberAxis0.java2DToValue((double) 5, rectangle2D40, rectangleEdge64);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Combined Range XYPlot" + "'", str22.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.NEGATIVE_INFINITY + "'", double65 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image3, "DomainOrder.NONE", "", "DomainOrder.NONE");
        projectInfo7.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "SerialDate.weekInMonthToString(): invalid code.", textAnchor5, textAnchor6, (-1.0d));
        valueMarker1.setLabelTextAnchor(textAnchor6);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint12 = null;
        xYStepAreaRenderer11.setBasePaint(paint12);
        java.awt.Stroke stroke15 = null;
        xYStepAreaRenderer11.setSeriesOutlineStroke((int) ' ', stroke15);
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        xYSeries18.removeChangeListener(seriesChangeListener19);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        int int25 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection21, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range26 = xYStepAreaRenderer11.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection21);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer28.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape34 = xYStepAreaRenderer28.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity(shape34, (org.jfree.chart.axis.Axis) categoryAxis35, "");
        xYStepAreaRenderer11.setBaseLegendShape(shape34);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity39 = new org.jfree.chart.entity.LegendItemEntity(shape34);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint42 = null;
        xYStepAreaRenderer41.setBasePaint(paint42);
        java.awt.Stroke stroke45 = null;
        xYStepAreaRenderer41.setSeriesOutlineStroke((int) ' ', stroke45);
        xYStepAreaRenderer41.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries50 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        xYSeries50.removeChangeListener(seriesChangeListener51);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection(xYSeries50);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection53, valueAxis54, polarItemRenderer55);
        org.jfree.data.Range range57 = xYStepAreaRenderer41.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53, true);
        legendItemEntity39.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection53);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit64 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType65 = dateTickUnit64.getUnitType();
        double double66 = dateTickUnit64.getSize();
        dateAxis63.setTickUnit(dateTickUnit64, false, false);
        categoryPlot61.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        categoryPlot61.setRangeAxis(10, valueAxis73);
        boolean boolean75 = xYSeriesCollection53.hasListener((java.util.EventListener) categoryPlot61);
        boolean boolean76 = textAnchor6.equals((java.lang.Object) categoryPlot61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot61.zoomRangeAxes(4.0d, plotRenderingInfo78, point2D79, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation82 = null;
        try {
            boolean boolean84 = categoryPlot61.removeAnnotation(categoryAnnotation82, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(dateTickUnit64);
        org.junit.Assert.assertNotNull(dateTickUnitType65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 8.64E7d + "'", double66 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("VerticalAlignment.TOP");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        java.awt.Paint paint7 = legendTitle6.getBackgroundPaint();
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle6.setLegendItemGraphicLocation(rectangleAnchor9);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 100.0f, false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, false);
        timeSeries3.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection11);
        timeSeries3.removeAgedItems((long) 9, true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nSerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", "6/13/19 1:07 PM", "hi!");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, (double) 12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer3D2.setSeriesToolTipGenerator(0, categoryToolTipGenerator4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = standardChartTheme7.getDrawingSupplier();
        java.awt.Font font10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) waferMapPlot11, false);
        jFreeChart13.removeLegend();
        standardChartTheme7.apply(jFreeChart13);
        java.awt.Paint paint16 = standardChartTheme7.getDomainGridlinePaint();
        java.awt.Paint paint17 = standardChartTheme7.getGridBandPaint();
        dateAxis1.setTickMarkPaint(paint17);
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        xYSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection(xYSeries20);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        piePlot24.setNoDataMessage("hi!");
        java.awt.Paint paint27 = piePlot24.getBaseSectionOutlinePaint();
        piePlot24.clearSectionOutlineStrokes(true);
        boolean boolean30 = xYSeries20.equals((java.lang.Object) piePlot24);
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType32 = dateTickUnit31.getUnitType();
        java.awt.Paint paint33 = piePlot24.getSectionOutlinePaint((java.lang.Comparable) dateTickUnit31);
        dateAxis1.setTickUnit(dateTickUnit31);
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font43 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot44 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("", font43, (org.jfree.chart.plot.Plot) waferMapPlot44, false);
        int int47 = jFreeChart46.getSubtitleCount();
        java.awt.Paint paint48 = jFreeChart46.getBorderPaint();
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape39, (java.awt.Paint) color40, stroke41, paint48);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = xYStepAreaRenderer51.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape57 = xYStepAreaRenderer51.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity60 = new org.jfree.chart.entity.AxisEntity(shape57, (org.jfree.chart.axis.Axis) categoryAxis58, "");
        legendItem49.setLine(shape57);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline64 = dateAxis63.getTimeline();
        org.jfree.chart.entity.AxisEntity axisEntity66 = new org.jfree.chart.entity.AxisEntity(shape57, (org.jfree.chart.axis.Axis) dateAxis63, "DatasetRenderingOrder.FORWARD");
        java.awt.Shape shape69 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape57, 8.64E7d, 1.0d);
        dateAxis1.setDownArrow(shape57);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnitType32);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(timeline64);
        org.junit.Assert.assertNotNull(shape69);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke4 = piePlot0.getBaseSectionOutlineStroke();
        java.awt.Paint paint5 = piePlot0.getShadowPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        java.lang.Object obj3 = numberAxis0.clone();
        java.text.NumberFormat numberFormat4 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator6 = new org.jfree.chart.urls.StandardXYURLGenerator("ERROR : Relative To String");
        xYStepAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator6);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getLegendTextPaint(100);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = dateTickUnit4.getUnitType();
        double double6 = dateTickUnit4.getSize();
        dateAxis3.setTickUnit(dateTickUnit4, false, false);
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot1.getColumnRenderingOrder();
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, valueAxis18, polarItemRenderer19);
        boolean boolean21 = polarPlot20.isAngleLabelsVisible();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot20.setRadiusGridlineStroke(stroke22);
        categoryPlot1.setRangeZeroBaselineStroke(stroke22);
        categoryPlot0.setDomainGridlineStroke(stroke22);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.64E7d + "'", double6 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer6.setSeriesOutlinePaint((int) (byte) 100, paint8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer6.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj16 = standardGradientPaintTransformer15.clone();
        xYAreaRenderer6.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        xYAreaRenderer6.setOutline(false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockContainer21.getMargin();
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer21.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str25 = combinedRangeXYPlot24.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace26 = combinedRangeXYPlot24.getFixedDomainAxisSpace();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal(paint27, paint28);
        combinedRangeXYPlot24.setDomainCrosshairPaint(paint28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint33 = null;
        xYStepAreaRenderer32.setBasePaint(paint33);
        java.awt.Stroke stroke36 = null;
        xYStepAreaRenderer32.setSeriesOutlineStroke((int) ' ', stroke36);
        java.awt.Paint paint39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer32.setSeriesPaint(4, paint39);
        boolean boolean41 = xYStepAreaRenderer32.getPlotArea();
        xYStepAreaRenderer32.removeAnnotations();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(4);
        int int49 = year48.getYear();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(4);
        int int52 = year51.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo54 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray55 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo54 };
        periodAxis53.setLabelInfo(periodAxisLabelInfoArray55);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { periodAxis53, dateAxis58 };
        combinedRangeXYPlot45.setRangeAxes(valueAxisArray59);
        boolean boolean61 = combinedRangeXYPlot45.isRangeMinorGridlinesVisible();
        boolean boolean62 = combinedRangeXYPlot45.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer65 = null;
        boolean boolean66 = combinedRangeXYPlot45.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker64, layer65);
        int int67 = combinedRangeXYPlot45.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range69 = combinedRangeXYPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis68);
        org.jfree.data.xy.XYSeries xYSeries71 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener72 = null;
        xYSeries71.removeChangeListener(seriesChangeListener72);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection74 = new org.jfree.data.xy.XYSeriesCollection(xYSeries71);
        int int78 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection74, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range80 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection74, false);
        org.jfree.data.Range range82 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection74, false);
        java.lang.Number number83 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection74);
        xYSeriesCollection74.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState86 = xYStepAreaRenderer32.initialise(graphics2D43, rectangle2D44, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot45, (org.jfree.data.xy.XYDataset) xYSeriesCollection74, plotRenderingInfo85);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState88 = xYAreaRenderer6.initialise(graphics2D20, rectangle2D23, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot24, (org.jfree.data.xy.XYDataset) xYSeriesCollection74, plotRenderingInfo87);
        java.awt.geom.Point2D point2D89 = null;
        org.jfree.chart.plot.PlotState plotState90 = new org.jfree.chart.plot.PlotState();
        java.util.Map map91 = plotState90.getSharedAxisStates();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D4, rectangle2D23, point2D89, plotState90, plotRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Combined Range XYPlot" + "'", str25.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray55);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNull(range69);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNull(range80);
        org.junit.Assert.assertNull(range82);
        org.junit.Assert.assertEquals((double) number83, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState86);
        org.junit.Assert.assertNotNull(xYItemRendererState88);
        org.junit.Assert.assertNotNull(map91);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        xYSeries1.add((java.lang.Number) 0.4d, (java.lang.Number) 10.0d);
        boolean boolean7 = xYSeries1.isEmpty();
        xYSeries1.add((java.lang.Number) 9223372036854775807L, (java.lang.Number) 100.0f, true);
        try {
            org.jfree.data.xy.XYSeries xYSeries14 = xYSeries1.createCopy((int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getUpperDate();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Number number11 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getUpperDate();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Number number11 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        int int12 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 4, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", false);
        java.text.ParsePosition parsePosition5 = null;
        java.lang.Number number6 = logFormat3.parse("DatasetRenderingOrder.FORWARD", parsePosition5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator6 = new org.jfree.chart.urls.StandardXYURLGenerator("ERROR : Relative To String");
        xYStepAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str10 = combinedRangeXYPlot9.getPlotType();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(4);
        int int14 = year13.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(4);
        int int17 = year16.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo19 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray20 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo19 };
        periodAxis18.setLabelInfo(periodAxisLabelInfoArray20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState();
        double double24 = axisState23.getMax();
        axisState23.cursorLeft(100.0d);
        axisState23.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle30.getPosition();
        java.util.List list32 = periodAxis18.refreshTicks(graphics2D22, axisState23, rectangle2D29, rectangleEdge31);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(4);
        int int37 = year36.getYear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(4);
        int int40 = year39.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo42 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray43 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo42 };
        periodAxis41.setLabelInfo(periodAxisLabelInfoArray43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { periodAxis41, dateAxis46 };
        combinedRangeXYPlot33.setRangeAxes(valueAxisArray47);
        boolean boolean49 = combinedRangeXYPlot33.isRangeMinorGridlinesVisible();
        boolean boolean50 = combinedRangeXYPlot33.canSelectByRegion();
        boolean boolean51 = combinedRangeXYPlot33.isRangePannable();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = blockContainer53.getMargin();
        java.awt.geom.Rectangle2D rectangle2D55 = blockContainer53.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot56.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot56.getFixedLegendItems();
        double double59 = categoryPlot56.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = categoryPlot56.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker62, layer63);
        java.util.List list65 = categoryPlot56.getAnnotations();
        java.util.Collection collection66 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list65);
        combinedRangeXYPlot33.drawRangeTickBands(graphics2D52, rectangle2D55, list65);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity68 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D55);
        xYStepAreaRenderer1.fillRangeGridBand(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D55, 0.0d, 8.0d);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation72 = null;
        try {
            combinedRangeXYPlot9.addAnnotation(xYAnnotation72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Combined Range XYPlot" + "'", str10.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray43);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(collection66);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Paint paint10 = standardChartTheme1.getItemLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        standardChartTheme1.setPlotOutlinePaint(paint12);
        java.awt.Paint paint14 = null;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal(paint12, paint14);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setNoDataMessage("hi!");
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint7);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection14, valueAxis15, polarItemRenderer16);
        boolean boolean18 = polarPlot17.isAngleLabelsVisible();
        boolean boolean19 = polarPlot17.isDomainZoomable();
        java.awt.Stroke stroke20 = polarPlot17.getAngleGridlineStroke();
        piePlot0.setSectionOutlineStroke((java.lang.Comparable) "ERROR : Relative To String", stroke20);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Stroke stroke4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets5.calculateBottomInset((double) (short) 10);
        try {
            org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder(paint3, stroke4, rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setDatasetIndex((-1));
        double double3 = xYCrosshairState0.getAnchorX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Color color2 = java.awt.Color.BLUE;
        standardChartTheme1.setWallPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = standardChartTheme1.getSubtitlePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "{0}: ({1}, {2})", "series");
        org.jfree.chart.ui.Library[] libraryArray11 = basicProjectInfo10.getLibraries();
        boolean boolean12 = pieLabelLinkStyle5.equals((java.lang.Object) basicProjectInfo10);
        basicProjectInfo10.setName("ThreadContext");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint3 = null;
        xYStepAreaRenderer2.setBasePaint(paint3);
        java.awt.Stroke stroke6 = null;
        xYStepAreaRenderer2.setSeriesOutlineStroke((int) ' ', stroke6);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        xYSeries9.removeChangeListener(seriesChangeListener10);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries9);
        int int16 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection12, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range17 = xYStepAreaRenderer2.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYStepAreaRenderer19.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape25 = xYStepAreaRenderer19.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape25, (org.jfree.chart.axis.Axis) categoryAxis26, "");
        xYStepAreaRenderer2.setBaseLegendShape(shape25);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape25);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint33 = null;
        xYStepAreaRenderer32.setBasePaint(paint33);
        java.awt.Stroke stroke36 = null;
        xYStepAreaRenderer32.setSeriesOutlineStroke((int) ' ', stroke36);
        xYStepAreaRenderer32.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries41 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        xYSeries41.removeChangeListener(seriesChangeListener42);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection44 = new org.jfree.data.xy.XYSeriesCollection(xYSeries41);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection44, valueAxis45, polarItemRenderer46);
        org.jfree.data.Range range48 = xYStepAreaRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44, true);
        legendItemEntity30.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection44);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate52 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection44);
        boolean boolean53 = blockBorder0.equals((java.lang.Object) intervalXYDelegate52);
        double double54 = intervalXYDelegate52.getIntervalWidth();
        try {
            double double57 = intervalXYDelegate52.getEndXValue(10, (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        objectList1.clear();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.Stroke stroke2 = periodAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        polarPlot7.setAngleLabelsVisible(false);
        polarPlot7.setAngleGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        boolean boolean17 = polarPlot16.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) polarPlot16, "{0}: ({1}, {2})");
        org.jfree.data.general.DatasetGroup datasetGroup20 = polarPlot16.getDatasetGroup();
        java.awt.Paint paint21 = polarPlot16.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(datasetGroup20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE2" + "'", str1.equals("ItemLabelAnchor.OUTSIDE2"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 4, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", false);
        java.lang.Object obj4 = logFormat3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        int int2 = numberFormat1.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (-459), numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        java.awt.Paint paint15 = legendItem14.getLinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        java.awt.Image image5 = jFreeChart4.getBackgroundImage();
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        periodAxis7.setMinorTickMarksVisible(false);
        periodAxis7.setMinorTickMarkOutsideLength((float) (-16777216));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font1, (java.awt.Paint) color2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) (-1));
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        int int5 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke8 = valueMarker7.getOutlineStroke();
        java.lang.String str9 = valueMarker7.getLabel();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer10);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        valueMarker7.setLabelAnchor(rectangleAnchor14);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.lang.String str9 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge((int) (byte) 100);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo11 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray12 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo11 };
        periodAxis10.setLabelInfo(periodAxisLabelInfoArray12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { periodAxis10, dateAxis15 };
        combinedRangeXYPlot2.setRangeAxes(valueAxisArray16);
        boolean boolean18 = combinedRangeXYPlot2.isRangeMinorGridlinesVisible();
        boolean boolean19 = combinedRangeXYPlot2.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean21 = gradientPaintTransformType0.equals((java.lang.Object) shape1);
        org.jfree.chart.util.ObjectList objectList23 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int25 = objectList23.indexOf((java.lang.Object) segmentedTimeline24);
        java.lang.Object obj27 = objectList23.get(64);
        boolean boolean28 = gradientPaintTransformType0.equals((java.lang.Object) objectList23);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
        numberFormat2.setMaximumFractionDigits((int) (short) 0);
        java.util.Currency currency6 = numberFormat2.getCurrency();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(currency6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        java.awt.Stroke stroke12 = xYStepAreaRenderer1.lookupSeriesOutlineStroke((-16777216));
        java.awt.Stroke stroke13 = xYStepAreaRenderer1.getBaseOutlineStroke();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        xYStepAreaRenderer1.setLegendTextPaint(0, paint15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        java.lang.Class class12 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(4);
        int int16 = year15.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo21 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray22 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo21 };
        periodAxis20.setLabelInfo(periodAxisLabelInfoArray22);
        java.awt.Stroke stroke24 = periodAxis20.getTickMarkStroke();
        java.lang.Class class25 = periodAxis20.getAutoRangeTimePeriodClass();
        periodAxis7.setMinorTickTimePeriodClass(class25);
        boolean boolean27 = org.jfree.chart.util.SerialUtilities.isSerializable(class25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        double double13 = periodAxis7.getAutoRangeMinimumSize();
        org.jfree.data.Range range14 = null;
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude(range14, (double) 1);
        double double17 = range16.getUpperBound();
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range16, (double) 900000L);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(range19);
        double double22 = dateRange20.constrain(0.0d);
        periodAxis7.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType18 = dateTickUnit17.getUnitType();
        double double19 = dateTickUnit17.getSize();
        dateAxis16.setTickUnit(dateTickUnit17, false, false);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot14.getColumnRenderingOrder();
        java.awt.Paint paint26 = categoryPlot14.getDomainCrosshairPaint();
        double double27 = categoryPlot14.getAnchorValue();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(4);
        int int34 = year33.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year33);
        double double36 = periodAxis35.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        barRenderer3D2.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) periodAxis35, rectangle2D37, 1.0d);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = null;
        barRenderer3D2.setBaseURLGenerator(categoryURLGenerator40, false);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = blockContainer44.getMargin();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer44.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot47.getFixedLegendItems();
        double double50 = categoryPlot47.getAnchorValue();
        categoryPlot47.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = barRenderer3D2.initialise(graphics2D43, rectangle2D46, categoryPlot47, 11, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnitType18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.64E7d + "'", double19 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNull(legendItemCollection49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj9 = barRenderer3D8.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke15 = valueMarker14.getOutlineStroke();
        java.lang.String str16 = valueMarker14.getLabel();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        xYStepAreaRenderer1.setShapesVisible(false);
        xYStepAreaRenderer1.setShapesVisible(true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        java.lang.Object obj3 = numberAxis0.clone();
        org.jfree.data.Range range4 = numberAxis0.getDefaultAutoRange();
        java.lang.Object obj5 = numberAxis0.clone();
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint6, stroke8, rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder10.getInsets();
        boolean boolean12 = numberAxis0.equals((java.lang.Object) lineBorder10);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        combinedRangeXYPlot0.setRenderers(xYItemRendererArray3);
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 2147483647);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        double double22 = xYSeriesCollection13.getIntervalWidth();
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setLabelLinksVisible(false);
        piePlot0.setShadowYOffset((double) 12);
        double double7 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (-1L), (double) 11, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYStepAreaRenderer1.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(xYToolTipGenerator4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj11 = standardGradientPaintTransformer10.clone();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        xYAreaRenderer1.setOutline(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer16.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str20 = combinedRangeXYPlot19.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace21 = combinedRangeXYPlot19.getFixedDomainAxisSpace();
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal(paint22, paint23);
        combinedRangeXYPlot19.setDomainCrosshairPaint(paint23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer27.setSeriesPaint(4, paint34);
        boolean boolean36 = xYStepAreaRenderer27.getPlotArea();
        xYStepAreaRenderer27.removeAnnotations();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { periodAxis48, dateAxis53 };
        combinedRangeXYPlot40.setRangeAxes(valueAxisArray54);
        boolean boolean56 = combinedRangeXYPlot40.isRangeMinorGridlinesVisible();
        boolean boolean57 = combinedRangeXYPlot40.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = combinedRangeXYPlot40.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker59, layer60);
        int int62 = combinedRangeXYPlot40.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range64 = combinedRangeXYPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis63);
        org.jfree.data.xy.XYSeries xYSeries66 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
        xYSeries66.removeChangeListener(seriesChangeListener67);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection69 = new org.jfree.data.xy.XYSeriesCollection(xYSeries66);
        int int73 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection69, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection69);
        xYSeriesCollection69.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer27.initialise(graphics2D38, rectangle2D39, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot40, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState83 = xYAreaRenderer1.initialise(graphics2D15, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo82);
        boolean boolean87 = xYAreaRenderer1.isItemLabelVisible((int) ' ', (int) (byte) 0, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Combined Range XYPlot" + "'", str20.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNull(range75);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertEquals((double) number78, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(xYItemRendererState83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint14 = categoryPlot0.getRangeMinorGridlinePaint();
        categoryPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        xYStepAreaRenderer1.setRangeBase((double) (-1L));
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer1.setBaseItemLabelFont(font13);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYStepAreaRenderer1.setLegendItemToolTipGenerator(xYSeriesLabelGenerator15);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryAxis8.setAxisLinePaint((java.awt.Paint) color12);
        java.lang.String str14 = categoryAxis8.getLabelURL();
        java.awt.Paint paint16 = categoryAxis8.getTickLabelPaint((java.lang.Comparable) 900000L);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.lang.Object obj1 = xYBarRenderer0.clone();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer3.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer3.getBasePositiveItemLabelPosition();
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter8 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        xYBarRenderer0.setBarPainter(xYBarPainter8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.data.Range range11 = xYBarRenderer0.findDomainBounds(xYDataset10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(xYBarPainter8);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("12/31/69 4:00 PM", graphics2D1, (float) 3, 0.0f, 35.0d, (float) '4', (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace7, false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        try {
            double double20 = xYSeriesCollection11.getYValue((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        java.awt.Shape shape6 = xYAreaRenderer1.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType11 = dateTickUnit10.getUnitType();
        double double12 = dateTickUnit10.getSize();
        dateAxis9.setTickUnit(dateTickUnit10, false, false);
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot7.setRangeAxis(10, valueAxis19);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnitType11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.64E7d + "'", double12 == 8.64E7d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryAxis8.setAxisLinePaint((java.awt.Paint) color12);
        categoryAxis8.setCategoryMargin((double) 100);
        float float16 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        categoryAxis8.configure();
        boolean boolean12 = categoryAxis8.isVisible();
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        piePlot18.setNoDataMessage("hi!");
        java.awt.Paint paint21 = piePlot18.getBaseSectionOutlinePaint();
        piePlot18.clearSectionOutlineStrokes(true);
        boolean boolean24 = xYSeries14.equals((java.lang.Object) piePlot18);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType26 = dateTickUnit25.getUnitType();
        java.awt.Paint paint27 = piePlot18.getSectionOutlinePaint((java.lang.Comparable) dateTickUnit25);
        categoryAxis8.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit25);
        int int29 = categoryAxis8.getCategoryLabelPositionOffset();
        boolean boolean30 = categoryAxis8.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(dateTickUnitType26);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ERROR : Relative To String");
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        java.lang.Object obj7 = standardPieSectionLabelGenerator4.clone();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = null;
        xYStepAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator11);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 3, (-458));
        java.lang.Object obj4 = segmentedTimeline3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setPieIndex((int) (short) -1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(4);
        int int12 = year11.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo14 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray15 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo14 };
        periodAxis13.setLabelInfo(periodAxisLabelInfoArray15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { periodAxis13, dateAxis18 };
        combinedRangeXYPlot5.setRangeAxes(valueAxisArray19);
        boolean boolean21 = combinedRangeXYPlot5.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot5.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke25 = valueMarker24.getOutlineStroke();
        org.jfree.chart.util.Layer layer26 = null;
        combinedRangeXYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType32 = dateTickUnit31.getUnitType();
        double double33 = dateTickUnit31.getSize();
        dateAxis30.setTickUnit(dateTickUnit31, false, false);
        categoryPlot28.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot28.getColumnRenderingOrder();
        java.awt.Paint paint40 = categoryPlot28.getDomainCrosshairPaint();
        java.awt.Paint paint41 = categoryPlot28.getRangeZeroBaselinePaint();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(4);
        int int45 = year44.getYear();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(4);
        int int48 = year47.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year44, (org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo50 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray51 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo50 };
        periodAxis49.setLabelInfo(periodAxisLabelInfoArray51);
        java.awt.Stroke stroke53 = periodAxis49.getTickMarkStroke();
        periodAxis49.setMinorTickMarksVisible(true);
        org.jfree.data.Range range56 = categoryPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis49);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = valueMarker58.getLabelOffset();
        categoryPlot28.setAxisOffset(rectangleInsets59);
        combinedRangeXYPlot5.setAxisOffset(rectangleInsets59);
        piePlot0.setLabelPadding(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray15);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(dateTickUnitType32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.64E7d + "'", double33 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot10 = jFreeChart7.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.WaferMapPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        java.util.List list2 = null;
        axisState0.setTicks(list2);
        double double4 = axisState0.getCursor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        boolean boolean18 = combinedRangeXYPlot0.isRangePannable();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockContainer20.getMargin();
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer20.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getFixedLegendItems();
        double double26 = categoryPlot23.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot23.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker29, layer30);
        java.util.List list32 = categoryPlot23.getAnnotations();
        java.util.Collection collection33 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list32);
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D19, rectangle2D22, list32);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity35 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(4);
        int int40 = year39.getYear();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(4);
        int int43 = year42.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year42);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo45 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray46 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo45 };
        periodAxis44.setLabelInfo(periodAxisLabelInfoArray46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { periodAxis44, dateAxis49 };
        combinedRangeXYPlot36.setRangeAxes(valueAxisArray50);
        boolean boolean52 = combinedRangeXYPlot36.isRangeMinorGridlinesVisible();
        java.lang.String str53 = combinedRangeXYPlot36.getPlotType();
        java.awt.Paint paint54 = combinedRangeXYPlot36.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYSeries xYSeries56 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
        xYSeries56.removeChangeListener(seriesChangeListener57);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection59 = new org.jfree.data.xy.XYSeriesCollection(xYSeries56);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection59, valueAxis60, polarItemRenderer61);
        boolean boolean63 = polarPlot62.isAngleLabelsVisible();
        java.awt.Stroke stroke64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot62.setRadiusGridlineStroke(stroke64);
        combinedRangeXYPlot36.setDomainGridlineStroke(stroke64);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = combinedRangeXYPlot36.getDomainAxisEdge();
        double double68 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D22, rectangleEdge67);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray46);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Combined Range XYPlot" + "'", str53.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(4);
        int int10 = year9.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(4);
        int int13 = year12.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year12);
        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(4);
        int int22 = year21.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year21);
        int int24 = year18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        timeSeries3.add(regularTimePeriod25, 1.0E-5d, false);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(6, 4);
        int int32 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
        try {
            timeSeries3.setMaximumItemAge((-62025408000001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo11 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray12 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo11 };
        periodAxis10.setLabelInfo(periodAxisLabelInfoArray12);
        java.awt.Stroke stroke14 = periodAxis10.getTickMarkStroke();
        periodAxis10.setMinorTickMarksVisible(true);
        java.util.Locale locale17 = periodAxis10.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale17);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", locale17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale17);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(tickUnitSource20);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        int int8 = year2.getYear();
        int int9 = year2.getYear();
        long long10 = year2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62041132800000L) + "'", long10 == (-62041132800000L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str8 = combinedRangeXYPlot7.getPlotType();
        java.awt.Paint paint9 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker13.getLabelAnchor();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = combinedRangeXYPlot7.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker13, layer15, true);
        combinedRangeXYPlot7.zoom((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font21 = numberAxis20.getLabelFont();
        boolean boolean22 = combinedRangeXYPlot7.equals((java.lang.Object) numberAxis20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockContainer24.getMargin();
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer24.getBounds();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(4);
        int int30 = year29.getYear();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(4);
        int int33 = year32.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo35 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray36 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo35 };
        periodAxis34.setLabelInfo(periodAxisLabelInfoArray36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = new org.jfree.chart.axis.AxisState();
        double double40 = axisState39.getMax();
        axisState39.cursorLeft(100.0d);
        axisState39.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle46.getPosition();
        java.util.List list48 = periodAxis34.refreshTicks(graphics2D38, axisState39, rectangle2D45, rectangleEdge47);
        combinedRangeXYPlot7.drawDomainTickBands(graphics2D23, rectangle2D26, list48);
        try {
            categoryPlot0.mapDatasetToDomainAxes(4, list48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined Range XYPlot" + "'", str8.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range3 = timeSeriesCollection1.getDomainBounds(false);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(4);
        int int12 = year11.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo14 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray15 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo14 };
        periodAxis13.setLabelInfo(periodAxisLabelInfoArray15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { periodAxis13, dateAxis18 };
        combinedRangeXYPlot5.setRangeAxes(valueAxisArray19);
        boolean boolean21 = combinedRangeXYPlot5.isRangeMinorGridlinesVisible();
        boolean boolean22 = combinedRangeXYPlot5.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        boolean boolean24 = timeSeriesCollection1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray15);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.util.List list9 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        boolean boolean4 = xYPlot0.isDomainZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str8 = combinedRangeXYPlot7.getPlotType();
        java.awt.Paint paint9 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker13.getLabelAnchor();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = combinedRangeXYPlot7.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker13, layer15, true);
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke20 = piePlot19.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder(paint18, stroke20, rectangleInsets21);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer24.setBaseSeriesVisible(false);
        xYStepAreaRenderer24.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint29 = xYStepAreaRenderer24.getBasePaint();
        boolean boolean30 = rectangleInsets21.equals((java.lang.Object) xYStepAreaRenderer24);
        valueMarker13.setLabelOffset(rectangleInsets21);
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13, layer32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined Range XYPlot" + "'", str8.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        xYSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        int int9 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection5, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double10 = xYSeriesCollection5.getIntervalPositionFactor();
        org.jfree.data.DomainOrder domainOrder11 = xYSeriesCollection5.getDomainOrder();
        java.lang.Object obj12 = xYSeriesCollection5.clone();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(4);
        int int16 = year15.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year18);
        double double21 = periodAxis20.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline24 = dateAxis23.getTimeline();
        int int25 = dateAxis23.getMinorTickCount();
        double double26 = dateAxis23.getUpperBound();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint29 = null;
        xYStepAreaRenderer28.setBasePaint(paint29);
        java.awt.Stroke stroke32 = null;
        xYStepAreaRenderer28.setSeriesOutlineStroke((int) ' ', stroke32);
        org.jfree.data.xy.XYSeries xYSeries35 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        xYSeries35.removeChangeListener(seriesChangeListener36);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection38 = new org.jfree.data.xy.XYSeriesCollection(xYSeries35);
        int int42 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection38, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range43 = xYStepAreaRenderer28.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection38);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator44 = xYStepAreaRenderer28.getBaseToolTipGenerator();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, (org.jfree.chart.axis.ValueAxis) periodAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer28);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(4);
        int int49 = year48.getYear();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(4);
        int int52 = year51.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo54 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray55 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo54 };
        periodAxis53.setLabelInfo(periodAxisLabelInfoArray55);
        java.awt.Stroke stroke57 = periodAxis53.getTickMarkStroke();
        java.lang.Class class58 = periodAxis53.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(4);
        int int62 = year61.getYear();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(4);
        int int65 = year64.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis66 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year61, (org.jfree.data.time.RegularTimePeriod) year64);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo67 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray68 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo67 };
        periodAxis66.setLabelInfo(periodAxisLabelInfoArray68);
        java.awt.Stroke stroke70 = periodAxis66.getTickMarkStroke();
        java.lang.Class class71 = periodAxis66.getAutoRangeTimePeriodClass();
        periodAxis53.setMinorTickTimePeriodClass(class71);
        java.lang.Class class73 = periodAxis53.getMinorTickTimePeriodClass();
        periodAxis20.setMinorTickTimePeriodClass(class73);
        java.io.InputStream inputStream75 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class73);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(timeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNull(xYToolTipGenerator44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 4 + "'", int65 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(class71);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertNull(inputStream75);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        java.awt.Stroke stroke12 = periodAxis8.getTickMarkStroke();
        java.lang.Class class13 = periodAxis8.getAutoRangeTimePeriodClass();
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", class13);
        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNotNull(classLoader15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        java.lang.String str2 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setLimit((-458.0d));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        periodAxis7.setMinorTickMarksVisible(false);
        boolean boolean15 = periodAxis7.isMinorTickMarksVisible();
        org.jfree.data.Range range16 = periodAxis7.getRange();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) categoryDataset7, (java.lang.Comparable) numberTickUnit10);
        java.lang.String str12 = legendItemBlockContainer11.getToolTipText();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint3 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Font font4 = standardChartTheme1.getRegularFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = standardChartTheme1.getAxisOffset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape14 = xYStepAreaRenderer8.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape14, (org.jfree.chart.axis.Axis) categoryAxis15, "");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Font font19 = categoryAxis15.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font19);
        java.awt.Font font21 = textFragment20.getFont();
        standardChartTheme1.setRegularFont(font21);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeZeroBaselineStroke(stroke7);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = xYAreaRenderer1.getDrawingSupplier();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font19 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) waferMapPlot20, false);
        int int23 = jFreeChart22.getSubtitleCount();
        java.awt.Paint paint24 = jFreeChart22.getBorderPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape15, (java.awt.Paint) color16, stroke17, paint24);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = legendItem25.getFillPaintTransformer();
        xYAreaRenderer1.setGradientTransformer(gradientPaintTransformer26);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline29 = dateAxis28.getTimeline();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) dateAxis28, "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int33 = dateTickUnit32.getMinorTickCount();
        java.lang.String str35 = dateTickUnit32.valueToString((double) (short) 100);
        dateAxis28.setTickUnit(dateTickUnit32);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(timeline29);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "12/31/69 4:00 PM" + "'", str35.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String str17 = combinedRangeXYPlot0.getPlotType();
        combinedRangeXYPlot0.setWeight(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined Range XYPlot" + "'", str17.equals("Combined Range XYPlot"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart4.createBufferedImage(5, 4, (double) (byte) 10, (double) 0L, chartRenderingInfo9);
        jFreeChart4.setTitle("Category Plot");
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart4.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        org.jfree.data.DomainOrder domainOrder10 = xYSeriesCollection4.getDomainOrder();
        java.lang.Object obj11 = xYSeriesCollection4.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(4);
        int int15 = year14.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year17);
        double double20 = periodAxis19.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline23 = dateAxis22.getTimeline();
        int int24 = dateAxis22.getMinorTickCount();
        double double25 = dateAxis22.getUpperBound();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        org.jfree.data.xy.XYSeries xYSeries34 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        xYSeries34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection(xYSeries34);
        int int41 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection37, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range42 = xYStepAreaRenderer27.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection37);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator43 = xYStepAreaRenderer27.getBaseToolTipGenerator();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer27);
        xYStepAreaRenderer27.setRangeBase((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(timeline23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(xYToolTipGenerator43);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) categoryDataset7, (java.lang.Comparable) numberTickUnit10);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset7, 9);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) (-458.0d));
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range3 = timeSeriesCollection1.getDomainBounds(false);
        try {
            java.lang.Number number6 = timeSeriesCollection1.getX(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        double double66 = categoryPlot51.getAnchorValue();
        categoryPlot51.clearRangeMarkers();
        try {
            org.jfree.chart.axis.CategoryAxis categoryAxis69 = categoryPlot51.getDomainAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer2.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer2.setBaseItemLabelsVisible(false, false);
        boolean boolean12 = blockBorder0.equals((java.lang.Object) xYStepAreaRenderer2);
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, valueAxis18, polarItemRenderer19);
        boolean boolean21 = polarPlot20.isAngleLabelsVisible();
        boolean boolean22 = polarPlot20.isDomainZoomable();
        java.awt.Stroke stroke23 = polarPlot20.getAngleGridlineStroke();
        boolean boolean24 = blockBorder0.equals((java.lang.Object) stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        valueMarker11.notifyListeners(markerChangeEvent12);
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = categoryPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker11, layer14);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setDatasetIndex((-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYCrosshairState0.updateCrosshairPoint((double) 64, (double) 9, (-1), 2958465, (double) (-2208960000000L), 33.0d, plotOrientation9);
        xYCrosshairState0.updateCrosshairX((double) 12, 4);
        xYCrosshairState0.setCrosshairY((double) 0.0f);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedRangeXYPlot0.getInsets();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        float float1 = combinedRangeXYPlot0.getBackgroundAlpha();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.Paint paint8 = periodAxis7.getMinorTickMarkPaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Shape shape11 = periodAxis7.getLeftArrow();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(4);
        int int16 = year15.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo21 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray22 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo21 };
        periodAxis20.setLabelInfo(periodAxisLabelInfoArray22);
        java.awt.Stroke stroke24 = periodAxis20.getTickMarkStroke();
        java.lang.Class class25 = periodAxis20.getAutoRangeTimePeriodClass();
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", class25);
        periodAxis7.setMajorTickTimePeriodClass(class25);
        org.jfree.chart.StandardChartTheme standardChartTheme29 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = standardChartTheme29.getDrawingSupplier();
        java.awt.Paint paint31 = standardChartTheme29.getLabelLinkPaint();
        java.awt.Font font32 = standardChartTheme29.getRegularFont();
        periodAxis7.setLabelFont(font32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNull(inputStream26);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        xYSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis6, polarItemRenderer7);
        boolean boolean9 = polarPlot8.isAngleLabelsVisible();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot8.setRadiusGridlineStroke(stroke10);
        boolean boolean12 = standardGradientPaintTransformer0.equals((java.lang.Object) polarPlot8);
        java.lang.Object obj13 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis15.setInverted(false);
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis15.setMinimumDate(date18);
        boolean boolean20 = standardGradientPaintTransformer0.equals((java.lang.Object) dateAxis15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str2 = standardXYToolTipGenerator1.getFormatString();
        java.text.NumberFormat numberFormat3 = standardXYToolTipGenerator1.getXFormat();
        numberFormat3.setParseIntegerOnly(true);
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE2", numberFormat3, numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'yFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean8 = org.jfree.chart.util.PaintUtilities.equal(paint6, paint7);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        int int5 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke8 = valueMarker7.getOutlineStroke();
        java.lang.String str9 = valueMarker7.getLabel();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer10);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray15, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot21.getFixedLegendItems();
        double double24 = categoryPlot21.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot21.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker27, layer28);
        java.util.List list30 = categoryPlot21.getAnnotations();
        java.util.Collection collection31 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18, list30, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot0.getRendererForDataset(categoryDataset18);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setPlotArea(true);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setNoDataMessage("hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint14 = null;
        xYStepAreaRenderer13.setBasePaint(paint14);
        java.awt.Stroke stroke17 = null;
        xYStepAreaRenderer13.setSeriesOutlineStroke((int) ' ', stroke17);
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer13.setSeriesPaint(4, paint20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke23 = piePlot22.getOutlineStroke();
        xYStepAreaRenderer13.setBaseOutlineStroke(stroke23, false);
        piePlot9.setLabelLinkStroke(stroke23);
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepAreaRenderer1.getBaseItemLabelGenerator();
        xYStepAreaRenderer1.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme13.setLegendBackgroundPaint(paint14);
        xYStepAreaRenderer1.setBasePaint(paint14, false);
        org.jfree.data.xy.XYSeries xYSeries19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        xYSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection22 = new org.jfree.data.xy.XYSeriesCollection(xYSeries19);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        piePlot23.setNoDataMessage("hi!");
        java.awt.Paint paint26 = piePlot23.getBaseSectionOutlinePaint();
        piePlot23.clearSectionOutlineStrokes(true);
        boolean boolean29 = xYSeries19.equals((java.lang.Object) piePlot23);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator30 = piePlot23.getLegendLabelGenerator();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot23.setBaseSectionOutlineStroke(stroke31);
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getMinorTickCount();
        java.lang.String str3 = dateTickUnit0.valueToString((double) (short) 100);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit0.getUnitType();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "12/31/69 4:00 PM" + "'", str3.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(dateTickUnitType4);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate51 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(4);
        int int56 = year55.getYear();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(4);
        int int59 = year58.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis60 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year55, (org.jfree.data.time.RegularTimePeriod) year58);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo61 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray62 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo61 };
        periodAxis60.setLabelInfo(periodAxisLabelInfoArray62);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { periodAxis60, dateAxis65 };
        combinedRangeXYPlot52.setRangeAxes(valueAxisArray66);
        boolean boolean68 = combinedRangeXYPlot52.isRangeMinorGridlinesVisible();
        boolean boolean69 = combinedRangeXYPlot52.canSelectByRegion();
        boolean boolean70 = combinedRangeXYPlot52.isRangePannable();
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.block.BlockContainer blockContainer72 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = blockContainer72.getMargin();
        java.awt.geom.Rectangle2D rectangle2D74 = blockContainer72.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot75.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection77 = categoryPlot75.getFixedLegendItems();
        double double78 = categoryPlot75.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer82 = null;
        boolean boolean83 = categoryPlot75.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker81, layer82);
        java.util.List list84 = categoryPlot75.getAnnotations();
        java.util.Collection collection85 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list84);
        combinedRangeXYPlot52.drawRangeTickBands(graphics2D71, rectangle2D74, list84);
        org.jfree.data.time.DateRange dateRange87 = new org.jfree.data.time.DateRange();
        java.util.Date date88 = dateRange87.getUpperDate();
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, list84, (org.jfree.data.Range) dateRange87, false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray62);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNull(legendItemCollection77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNotNull(collection85);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNull(range90);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.clearSectionOutlineStrokes(true);
        boolean boolean11 = xYSeries1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot5.getLegendLabelGenerator();
        piePlot5.setLabelLinkMargin((double) 'a');
        boolean boolean15 = piePlot5.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelAngle(1.0E-5d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity10 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart8, "Category Plot");
        java.lang.String str11 = jFreeChartEntity10.toString();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYStepAreaRenderer13.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape19 = xYStepAreaRenderer13.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone(shape19);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer22.setSeriesOutlinePaint((int) (byte) 100, paint24, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYAreaRenderer22.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        xYAreaRenderer22.setBaseShape(shape33);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.equal(shape19, shape33);
        boolean boolean36 = jFreeChartEntity10.equals((java.lang.Object) shape19);
        jFreeChartEntity10.setToolTipText("{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChartEntity: tooltip = Category Plot" + "'", str11.equals("JFreeChartEntity: tooltip = Category Plot"));
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        long long4 = timeSeries3.getMaximumItemAge();
        double double5 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(4);
        int int12 = year11.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.08d);
        double double16 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight(2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setNoDataMessage("hi!");
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint7);
        piePlot0.clearSectionPaints(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedRangeXYPlot0.setFixedLegendItems(legendItemCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(35.0d, plotRenderingInfo22, point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Paint paint10 = standardChartTheme1.getItemLabelPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Color color13 = java.awt.Color.BLUE;
        standardChartTheme12.setWallPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = standardChartTheme12.getSubtitlePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = standardChartTheme12.getLabelLinkStyle();
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle16);
        java.awt.Paint paint18 = standardChartTheme1.getGridBandPaint();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        int int5 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke8 = valueMarker7.getOutlineStroke();
        java.lang.String str9 = valueMarker7.getLabel();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer10);
        java.lang.String str12 = valueMarker7.getLabel();
        java.lang.String str13 = valueMarker7.getLabel();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setNoDataMessage("hi!");
        java.awt.Paint paint6 = piePlot3.getBaseSectionOutlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        piePlot0.setLabelShadowPaint((java.awt.Paint) color8);
        piePlot0.setStartAngle(45.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        xYSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis6, polarItemRenderer7);
        boolean boolean9 = polarPlot8.isAngleLabelsVisible();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot8.setRadiusGridlineStroke(stroke10);
        boolean boolean12 = standardGradientPaintTransformer0.equals((java.lang.Object) polarPlot8);
        try {
            polarPlot8.zoom((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 1);
        double double7 = range6.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint2.toRangeWidth(range6);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation5);
        float float7 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Shape shape5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(4);
        int int11 = year10.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(4);
        int int14 = year13.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo16 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray17 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo16 };
        periodAxis15.setLabelInfo(periodAxisLabelInfoArray17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { periodAxis15, dateAxis20 };
        combinedRangeXYPlot7.setRangeAxes(valueAxisArray21);
        boolean boolean23 = combinedRangeXYPlot7.isRangeMinorGridlinesVisible();
        boolean boolean24 = combinedRangeXYPlot7.canSelectByRegion();
        java.awt.Paint paint25 = combinedRangeXYPlot7.getRangeCrosshairPaint();
        java.awt.Paint paint27 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint30 = null;
        xYStepAreaRenderer29.setBasePaint(paint30);
        java.awt.Stroke stroke33 = null;
        xYStepAreaRenderer29.setSeriesOutlineStroke((int) ' ', stroke33);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke36 = piePlot35.getOutlineStroke();
        xYStepAreaRenderer29.setBaseOutlineStroke(stroke36);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-452));
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D44 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj45 = barRenderer3D44.clone();
        boolean boolean46 = barRenderer3D44.getAutoPopulateSeriesPaint();
        barRenderer3D44.setDrawBarOutline(true);
        java.awt.Paint paint50 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D44.setSeriesFillPaint(9, paint50);
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("LengthConstraintType.NONE", "", "LengthConstraintType.NONE", "First", true, shape5, true, paint25, true, paint27, stroke36, true, shape40, stroke41, paint50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray17);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj11 = standardGradientPaintTransformer10.clone();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        xYAreaRenderer1.setOutline(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer16.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str20 = combinedRangeXYPlot19.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace21 = combinedRangeXYPlot19.getFixedDomainAxisSpace();
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal(paint22, paint23);
        combinedRangeXYPlot19.setDomainCrosshairPaint(paint23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer27.setSeriesPaint(4, paint34);
        boolean boolean36 = xYStepAreaRenderer27.getPlotArea();
        xYStepAreaRenderer27.removeAnnotations();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { periodAxis48, dateAxis53 };
        combinedRangeXYPlot40.setRangeAxes(valueAxisArray54);
        boolean boolean56 = combinedRangeXYPlot40.isRangeMinorGridlinesVisible();
        boolean boolean57 = combinedRangeXYPlot40.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = combinedRangeXYPlot40.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker59, layer60);
        int int62 = combinedRangeXYPlot40.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range64 = combinedRangeXYPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis63);
        org.jfree.data.xy.XYSeries xYSeries66 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
        xYSeries66.removeChangeListener(seriesChangeListener67);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection69 = new org.jfree.data.xy.XYSeriesCollection(xYSeries66);
        int int73 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection69, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection69);
        xYSeriesCollection69.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer27.initialise(graphics2D38, rectangle2D39, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot40, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState83 = xYAreaRenderer1.initialise(graphics2D15, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo82);
        org.jfree.data.xy.XYSeries xYSeries85 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener86 = null;
        xYSeries85.removeChangeListener(seriesChangeListener86);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection88 = new org.jfree.data.xy.XYSeriesCollection(xYSeries85);
        org.jfree.data.Range range89 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection88);
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection88);
        org.jfree.chart.entity.XYItemEntity xYItemEntity95 = new org.jfree.chart.entity.XYItemEntity((java.awt.Shape) rectangle2D18, (org.jfree.data.xy.XYDataset) xYSeriesCollection88, (int) (short) -1, 12, "series", "Category Plot");
        org.jfree.chart.plot.RingPlot ringPlot96 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color97 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        ringPlot96.setSeparatorPaint((java.awt.Paint) color97);
        boolean boolean99 = xYItemEntity95.equals((java.lang.Object) color97);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Combined Range XYPlot" + "'", str20.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNull(range75);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertEquals((double) number78, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(xYItemRendererState83);
        org.junit.Assert.assertNull(range89);
        org.junit.Assert.assertNull(range90);
        org.junit.Assert.assertNotNull(color97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer3.setBaseSeriesVisible(false);
        boolean boolean6 = textLine1.equals((java.lang.Object) xYStepAreaRenderer3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(6, 4);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month7, (double) (-62025408000001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint3 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Font font4 = standardChartTheme1.getRegularFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = standardChartTheme1.getAxisOffset();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter6 = standardChartTheme1.getXYBarPainter();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(xYBarPainter6);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D3);
        size2D4.setWidth((double) 64);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.awt.Font font2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) waferMapPlot3, false);
        jFreeChart5.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart5.getLegend((int) (byte) 0);
        java.awt.Paint paint9 = jFreeChart5.getBorderPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) verticalAlignment0, jFreeChart5);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = polarPlot0.getOrientation();
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "SerialDate.weekInMonthToString(): invalid code.", textAnchor2, textAnchor3, (-1.0d));
        java.lang.String str6 = numberTick5.getText();
        java.lang.String str7 = numberTick5.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str6.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str7.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        polarPlot7.setAngleLabelsVisible(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        java.awt.Paint paint13 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        java.text.AttributedString attributedString27 = legendItem14.getAttributedLabel();
        legendItem14.setDatasetIndex((int) (byte) 0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(attributedString27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        int int5 = jFreeChart4.getSubtitleCount();
        java.awt.Paint paint6 = jFreeChart4.getBorderPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        float float8 = jFreeChart4.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo11 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray12 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo11 };
        periodAxis10.setLabelInfo(periodAxisLabelInfoArray12);
        java.awt.Stroke stroke14 = periodAxis10.getTickMarkStroke();
        java.lang.Class class15 = periodAxis10.getAutoRangeTimePeriodClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", class15);
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TimePeriodAnchor.MIDDLE", class15);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("UnitType.RELATIVE", class15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(inputStream16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(uRL18);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot1.getFixedLegendItems();
        categoryPlot1.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot1.setDomainAxisLocation(axisLocation6);
        boolean boolean8 = polarPlot0.equals((java.lang.Object) axisLocation6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot0.zoomRangeAxes(4.0d, plotRenderingInfo10, point2D11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        boolean boolean7 = dateAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        java.awt.Shape shape6 = xYAreaRenderer1.getLegendArea();
        org.jfree.chart.StandardChartTheme standardChartTheme9 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = standardChartTheme9.getDrawingSupplier();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) waferMapPlot13, false);
        jFreeChart15.removeLegend();
        standardChartTheme9.apply(jFreeChart15);
        java.awt.Font font19 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) waferMapPlot20, false);
        jFreeChart22.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart22.getLegend((int) (byte) 0);
        java.awt.Paint paint26 = jFreeChart22.getBorderPaint();
        standardChartTheme9.setDomainGridlinePaint(paint26);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle28 = standardChartTheme9.getLabelLinkStyle();
        java.awt.Paint paint29 = standardChartTheme9.getDomainGridlinePaint();
        try {
            xYAreaRenderer1.setSeriesItemLabelPaint((-459), paint29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNull(legendTitle25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.5d, "VerticalAlignment.TOP", textAnchor2, textAnchor6, (double) 100.0f);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis4, false);
        java.awt.Font font9 = numberAxis4.getTickLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        double double12 = axisState11.getMax();
        java.util.List list13 = null;
        axisState11.setTicks(list13);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape16 = numberAxis15.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity18 = new org.jfree.chart.entity.TitleEntity(shape16, (org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle17.setTextAlignment(horizontalAlignment19);
        java.lang.Object obj21 = textTitle17.clone();
        textTitle17.setMargin(0.05d, (double) 10.0f, (double) 100, (double) 100L);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockContainer28.getMargin();
        java.awt.geom.Rectangle2D rectangle2D30 = blockContainer28.getBounds();
        textTitle17.draw(graphics2D27, rectangle2D30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(4);
        int int35 = year34.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(4);
        int int38 = year37.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) year37);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo40 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray41 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo40 };
        periodAxis39.setLabelInfo(periodAxisLabelInfoArray41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = new org.jfree.chart.axis.AxisState();
        double double45 = axisState44.getMax();
        axisState44.cursorLeft(100.0d);
        axisState44.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = textTitle51.getPosition();
        java.util.List list53 = periodAxis39.refreshTicks(graphics2D43, axisState44, rectangle2D50, rectangleEdge52);
        try {
            java.util.List list54 = numberAxis4.refreshTicks(graphics2D10, axisState11, rectangle2D30, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(list53);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        xYStepAreaRenderer1.setShapesVisible(false);
        java.lang.Boolean boolean7 = xYStepAreaRenderer1.getSeriesVisibleInLegend(10);
        xYStepAreaRenderer1.setBaseCreateEntities(true, false);
        xYStepAreaRenderer1.setItemLabelAnchorOffset((double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer1.setSeriesPositiveItemLabelPosition(1, itemLabelPosition14);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition14.getRotationAnchor();
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        xYSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        boolean boolean10 = combinedRangeXYPlot0.isRangePannable();
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) (byte) -1);
        ringPlot0.setSeparatorsVisible(true);
        int int5 = ringPlot0.getPieIndex();
        ringPlot0.setOuterSeparatorExtension((double) (-13120));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        try {
            timeSeries3.update(3, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        double double5 = piePlot0.getMinimumArcAngleToDraw();
        double double6 = piePlot0.getShadowYOffset();
        java.awt.Paint paint7 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", graphics2D1, (float) (short) -1, (float) '#', (double) 100, (float) (byte) 100, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d, false);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        combinedRangeXYPlot0.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 255);
        boolean boolean32 = axisLocation29.equals((java.lang.Object) 255);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer8.setBaseSeriesVisible(false);
        boolean boolean11 = textBlockAnchor6.equals((java.lang.Object) xYStepAreaRenderer8);
        org.jfree.data.xy.XYSeries xYSeries14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        xYSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection(xYSeries14);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, valueAxis18, polarItemRenderer19);
        boolean boolean21 = polarPlot20.isAngleLabelsVisible();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot20.setRadiusGridlineStroke(stroke22);
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        piePlot24.setNoDataMessage("hi!");
        java.awt.Paint paint27 = piePlot24.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke28 = piePlot24.getBaseSectionOutlineStroke();
        polarPlot20.setRadiusGridlineStroke(stroke28);
        xYStepAreaRenderer8.setSeriesStroke((int) (byte) 10, stroke28);
        boolean boolean31 = xYStepAreaRenderer8.isOutline();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator34 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean36 = standardXYURLGenerator34.equals((java.lang.Object) rectangleAnchor35);
        xYStepAreaRenderer8.setSeriesURLGenerator(6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator34);
        xYStepAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator34);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        org.jfree.data.Range range7 = null;
        try {
            dateAxis1.setRange(range7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        int int18 = combinedRangeXYPlot0.getSeriesCount();
        boolean boolean19 = combinedRangeXYPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYStepAreaRenderer1.setLegendItemToolTipGenerator(xYSeriesLabelGenerator10);
        java.awt.Paint paint15 = xYStepAreaRenderer1.getItemPaint(3, 31, true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo11 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray12 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo11 };
        periodAxis10.setLabelInfo(periodAxisLabelInfoArray12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        double double16 = axisState15.getMax();
        axisState15.cursorLeft(100.0d);
        axisState15.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle22.getPosition();
        java.util.List list24 = periodAxis10.refreshTicks(graphics2D14, axisState15, rectangle2D21, rectangleEdge23);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(4);
        int int28 = year27.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo33 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray34 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo33 };
        periodAxis32.setLabelInfo(periodAxisLabelInfoArray34);
        java.awt.Stroke stroke36 = periodAxis32.getTickMarkStroke();
        java.lang.Class class37 = periodAxis32.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(4);
        int int41 = year40.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis45 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) year43);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo46 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray47 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo46 };
        periodAxis45.setLabelInfo(periodAxisLabelInfoArray47);
        java.awt.Stroke stroke49 = periodAxis45.getTickMarkStroke();
        java.lang.Class class50 = periodAxis45.getAutoRangeTimePeriodClass();
        periodAxis32.setMinorTickTimePeriodClass(class50);
        periodAxis10.setMajorTickTimePeriodClass(class50);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent54 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) class50, false);
        waferMapPlot0.rendererChanged(rendererChangeEvent54);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(class50);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
        int int2 = year1.getYear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis12, "");
        int int15 = categoryAxis12.getCategoryLabelPositionOffset();
        java.awt.Font font16 = categoryAxis12.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font16);
        int int18 = year1.compareTo((java.lang.Object) "{0}: ({1}, {2})");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (-16777216));
        java.util.Date date21 = year1.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate51 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        double double53 = intervalXYDelegate51.getDomainUpperBound(false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        java.lang.String str2 = multiplePiePlot0.getPlotType();
        java.lang.Object obj3 = multiplePiePlot0.clone();
        multiplePiePlot0.setLimit((double) 5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        boolean boolean18 = combinedRangeXYPlot0.isRangePannable();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockContainer20.getMargin();
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer20.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getFixedLegendItems();
        double double26 = categoryPlot23.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot23.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker29, layer30);
        java.util.List list32 = categoryPlot23.getAnnotations();
        java.util.Collection collection33 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list32);
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D19, rectangle2D22, list32);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity35 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D22);
        java.lang.String str36 = legendItemEntity35.getShapeType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "rect" + "'", str36.equals("rect"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation10, false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        int int36 = combinedRangeXYPlot14.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range38 = combinedRangeXYPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        int int47 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection43, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYStepAreaRenderer1.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo54);
        boolean boolean59 = xYStepAreaRenderer1.isItemLabelVisible(2958465, (int) (short) -1, true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity10 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart8, "Category Plot");
        java.lang.Object obj11 = jFreeChartEntity10.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.lang.String str9 = categoryPlot0.getPlotType();
        categoryPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.image.BufferedImage bufferedImage6 = jFreeChart3.createBufferedImage(2, 3);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(bufferedImage6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Comparable comparable1 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Paint paint2 = categoryPlot0.getDomainCrosshairPaint();
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.lang.Object obj7 = null;
        boolean boolean8 = valueMarker6.equals(obj7);
        org.jfree.chart.util.Layer layer9 = null;
        categoryPlot0.addRangeMarker((-459), (org.jfree.chart.plot.Marker) valueMarker6, layer9);
        java.lang.String str11 = valueMarker6.getLabel();
        org.junit.Assert.assertNull(comparable1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection8, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isAngleLabelsVisible();
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot11.setRadiusGridlineStroke(stroke13);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint15, stroke17, rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = lineBorder19.getInsets();
        double double22 = rectangleInsets20.calculateTopOutset((double) 12);
        polarPlot11.setInsets(rectangleInsets20);
        valueMarker1.setLabelOffset(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        java.util.List list2 = axisState0.getTicks();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setPieIndex((int) (short) -1);
        piePlot0.setSimpleLabels(true);
        piePlot0.setShadowYOffset((double) (-62041132800000L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek(4);
        java.lang.String str4 = serialDate1.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-1900" + "'", str4.equals("2-January-1900"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        double double3 = barRenderer3D2.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = barRenderer3D2.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj11 = standardGradientPaintTransformer10.clone();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        xYAreaRenderer1.setOutline(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer16.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str20 = combinedRangeXYPlot19.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace21 = combinedRangeXYPlot19.getFixedDomainAxisSpace();
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal(paint22, paint23);
        combinedRangeXYPlot19.setDomainCrosshairPaint(paint23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer27.setSeriesPaint(4, paint34);
        boolean boolean36 = xYStepAreaRenderer27.getPlotArea();
        xYStepAreaRenderer27.removeAnnotations();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { periodAxis48, dateAxis53 };
        combinedRangeXYPlot40.setRangeAxes(valueAxisArray54);
        boolean boolean56 = combinedRangeXYPlot40.isRangeMinorGridlinesVisible();
        boolean boolean57 = combinedRangeXYPlot40.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = combinedRangeXYPlot40.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker59, layer60);
        int int62 = combinedRangeXYPlot40.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range64 = combinedRangeXYPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis63);
        org.jfree.data.xy.XYSeries xYSeries66 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
        xYSeries66.removeChangeListener(seriesChangeListener67);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection69 = new org.jfree.data.xy.XYSeriesCollection(xYSeries66);
        int int73 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection69, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection69, false);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection69);
        xYSeriesCollection69.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer27.initialise(graphics2D38, rectangle2D39, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot40, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState83 = xYAreaRenderer1.initialise(graphics2D15, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19, (org.jfree.data.xy.XYDataset) xYSeriesCollection69, plotRenderingInfo82);
        org.jfree.data.xy.XYSeries xYSeries85 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener86 = null;
        xYSeries85.removeChangeListener(seriesChangeListener86);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection88 = new org.jfree.data.xy.XYSeriesCollection(xYSeries85);
        org.jfree.data.Range range89 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection88);
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection88);
        org.jfree.chart.entity.XYItemEntity xYItemEntity95 = new org.jfree.chart.entity.XYItemEntity((java.awt.Shape) rectangle2D18, (org.jfree.data.xy.XYDataset) xYSeriesCollection88, (int) (short) -1, 12, "series", "Category Plot");
        java.lang.String str96 = xYItemEntity95.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Combined Range XYPlot" + "'", str20.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNull(range75);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertEquals((double) number78, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(xYItemRendererState83);
        org.junit.Assert.assertNull(range89);
        org.junit.Assert.assertNull(range90);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator5);
        int int7 = barRenderer3D2.getColumnCount();
        java.lang.Boolean boolean9 = barRenderer3D2.getSeriesVisible((int) (short) 100);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(4);
        int int10 = year9.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(4);
        int int13 = year12.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year12);
        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(4);
        int int22 = year21.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) year21);
        int int24 = year18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.next();
        timeSeries3.add(regularTimePeriod25, 1.0E-5d, false);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(6, 4);
        int int32 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
        long long33 = month31.getFirstMillisecond();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62028000000000L) + "'", long33 == (-62028000000000L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String str17 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint18 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        xYSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection(xYSeries20);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection23, valueAxis24, polarItemRenderer25);
        boolean boolean27 = polarPlot26.isAngleLabelsVisible();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot26.setRadiusGridlineStroke(stroke28);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        combinedRangeXYPlot0.panRangeAxes((double) (-2208927600001L), plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        try {
            combinedRangeXYPlot0.setRangeAxisLocation(0, axisLocation37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined Range XYPlot" + "'", str17.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        java.lang.String str3 = rangeType1.toString();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RangeType.POSITIVE" + "'", str3.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        int int18 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range19 = xYStepAreaRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        xYStepAreaRenderer4.setBaseLegendShape(shape27);
        boolean boolean32 = multiplePiePlot0.equals((java.lang.Object) xYStepAreaRenderer4);
        org.jfree.chart.util.TableOrder tableOrder33 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj11 = standardGradientPaintTransformer10.clone();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        xYAreaRenderer1.setSeriesVisible(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.clearSectionOutlineStrokes(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        org.jfree.chart.util.Rotation rotation5 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot1.setDirection(rotation5);
        java.awt.Paint paint7 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        boolean boolean10 = xYAreaRenderer1.getPlotShapes();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color1);
        ringPlot0.setInnerSeparatorExtension((double) 644288400000L);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String str17 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint18 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        xYSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection(xYSeries20);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection23, valueAxis24, polarItemRenderer25);
        boolean boolean27 = polarPlot26.isAngleLabelsVisible();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot26.setRadiusGridlineStroke(stroke28);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        combinedRangeXYPlot0.panRangeAxes((double) (-2208927600001L), plotRenderingInfo33, point2D34);
        java.awt.Stroke stroke36 = combinedRangeXYPlot0.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined Range XYPlot" + "'", str17.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        double double3 = range2.getUpperBound();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 900000L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range2, (double) (byte) 1, true);
        org.jfree.data.Range range12 = org.jfree.data.Range.scale(range10, 0.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(4);
        int int17 = year16.getYear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(4);
        int int20 = year19.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo22 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray23 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo22 };
        periodAxis21.setLabelInfo(periodAxisLabelInfoArray23);
        java.awt.Stroke stroke25 = periodAxis21.getTickMarkStroke();
        periodAxis21.setMinorTickMarksVisible(true);
        org.jfree.data.Range range28 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis21);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker30.getLabelOffset();
        categoryPlot0.setAxisOffset(rectangleInsets31);
        java.lang.Comparable comparable33 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(comparable33);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Comparable comparable1 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Paint paint2 = categoryPlot0.getDomainCrosshairPaint();
        double double3 = categoryPlot0.getAnchorValue();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(comparable1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        org.jfree.data.DomainOrder domainOrder10 = xYSeriesCollection4.getDomainOrder();
        java.lang.Object obj11 = xYSeriesCollection4.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(4);
        int int15 = year14.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year17);
        double double20 = periodAxis19.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline23 = dateAxis22.getTimeline();
        int int24 = dateAxis22.getMinorTickCount();
        double double25 = dateAxis22.getUpperBound();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint28 = null;
        xYStepAreaRenderer27.setBasePaint(paint28);
        java.awt.Stroke stroke31 = null;
        xYStepAreaRenderer27.setSeriesOutlineStroke((int) ' ', stroke31);
        org.jfree.data.xy.XYSeries xYSeries34 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        xYSeries34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection(xYSeries34);
        int int41 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection37, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range42 = xYStepAreaRenderer27.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection37);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator43 = xYStepAreaRenderer27.getBaseToolTipGenerator();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer27);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState45 = xYSeriesCollection4.getSelectionState();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(timeline23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(xYToolTipGenerator43);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState45);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
        numberFormat1.setMaximumFractionDigits((int) (byte) -1);
        int int6 = numberFormat1.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(4);
        java.lang.Number number5 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year4, number5);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        int int1 = numberFormat0.getMaximumFractionDigits();
        numberFormat0.setMaximumIntegerDigits((int) (short) 100);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape8 = xYStepAreaRenderer2.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity11 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) categoryAxis9, "");
        int int12 = categoryAxis9.getCategoryLabelPositionOffset();
        java.awt.Font font13 = categoryAxis9.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        int int21 = timeSeriesCollection16.indexOf(timeSeries20);
        int int22 = timeSeriesCollection16.getSeriesCount();
        boolean boolean23 = textFragment14.equals((java.lang.Object) timeSeriesCollection16);
        try {
            java.lang.Number number26 = timeSeriesCollection16.getStartX((-13120), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        int int5 = jFreeChart4.getSubtitleCount();
        jFreeChart4.setTextAntiAlias(true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer10.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer10.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator15 = new org.jfree.chart.urls.StandardXYURLGenerator("ERROR : Relative To String");
        xYStepAreaRenderer10.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str19 = combinedRangeXYPlot18.getPlotType();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(4);
        int int23 = year22.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(4);
        int int26 = year25.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo28 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray29 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo28 };
        periodAxis27.setLabelInfo(periodAxisLabelInfoArray29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState();
        double double33 = axisState32.getMax();
        axisState32.cursorLeft(100.0d);
        axisState32.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = textTitle39.getPosition();
        java.util.List list41 = periodAxis27.refreshTicks(graphics2D31, axisState32, rectangle2D38, rectangleEdge40);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(4);
        int int46 = year45.getYear();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(4);
        int int49 = year48.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year45, (org.jfree.data.time.RegularTimePeriod) year48);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo51 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray52 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo51 };
        periodAxis50.setLabelInfo(periodAxisLabelInfoArray52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] { periodAxis50, dateAxis55 };
        combinedRangeXYPlot42.setRangeAxes(valueAxisArray56);
        boolean boolean58 = combinedRangeXYPlot42.isRangeMinorGridlinesVisible();
        boolean boolean59 = combinedRangeXYPlot42.canSelectByRegion();
        boolean boolean60 = combinedRangeXYPlot42.isRangePannable();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = blockContainer62.getMargin();
        java.awt.geom.Rectangle2D rectangle2D64 = blockContainer62.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot65.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot65.getFixedLegendItems();
        double double68 = categoryPlot65.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer72 = null;
        boolean boolean73 = categoryPlot65.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker71, layer72);
        java.util.List list74 = categoryPlot65.getAnnotations();
        java.util.Collection collection75 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list74);
        combinedRangeXYPlot42.drawRangeTickBands(graphics2D61, rectangle2D64, list74);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity77 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D64);
        xYStepAreaRenderer10.fillRangeGridBand(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.chart.axis.ValueAxis) periodAxis27, rectangle2D64, 0.0d, 8.0d);
        java.awt.geom.Point2D point2D81 = null;
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape83 = numberAxis82.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle84 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity85 = new org.jfree.chart.entity.TitleEntity(shape83, (org.jfree.chart.title.Title) textTitle84);
        org.jfree.chart.title.Title title86 = titleEntity85.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo87 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean88 = titleEntity85.equals((java.lang.Object) chartRenderingInfo87);
        try {
            jFreeChart4.draw(graphics2D8, rectangle2D64, point2D81, chartRenderingInfo87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Combined Range XYPlot" + "'", str19.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray52);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNull(legendItemCollection67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(title86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYSeriesCollection13.getGroup();
        try {
            java.lang.Number number24 = xYSeriesCollection13.getY((int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(datasetGroup21);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke4 = valueMarker3.getOutlineStroke();
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot0.removeRangeMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker3, layer5);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) (byte) -1);
        ringPlot0.setInnerSeparatorExtension((double) 100);
        java.awt.Paint paint5 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        int int6 = timeSeriesCollection1.indexOf(timeSeries5);
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone8);
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(4);
        int int15 = year14.getYear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo20 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray21 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo20 };
        periodAxis19.setLabelInfo(periodAxisLabelInfoArray21);
        java.awt.Stroke stroke23 = periodAxis19.getTickMarkStroke();
        periodAxis19.setMinorTickMarksVisible(true);
        java.util.Locale locale26 = periodAxis19.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale26);
        java.text.NumberFormat numberFormat28 = java.text.NumberFormat.getPercentInstance(locale26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date7, timeZone8, locale26);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(numberFormat28);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        double double3 = barRenderer3D2.getBase();
        boolean boolean4 = barRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("series");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke4 = valueMarker3.getOutlineStroke();
        java.lang.String str5 = valueMarker3.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        valueMarker3.setLabelAnchor(rectangleAnchor8);
        labelBlock1.setTextAnchor(rectangleAnchor8);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer2.setSeriesOutlinePaint((int) (byte) 100, paint4, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer2.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj12 = standardGradientPaintTransformer11.clone();
        xYAreaRenderer2.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        xYAreaRenderer2.setOutline(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockContainer17.getMargin();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer17.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str21 = combinedRangeXYPlot20.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace22 = combinedRangeXYPlot20.getFixedDomainAxisSpace();
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal(paint23, paint24);
        combinedRangeXYPlot20.setDomainCrosshairPaint(paint24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint29 = null;
        xYStepAreaRenderer28.setBasePaint(paint29);
        java.awt.Stroke stroke32 = null;
        xYStepAreaRenderer28.setSeriesOutlineStroke((int) ' ', stroke32);
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer28.setSeriesPaint(4, paint35);
        boolean boolean37 = xYStepAreaRenderer28.getPlotArea();
        xYStepAreaRenderer28.removeAnnotations();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(4);
        int int45 = year44.getYear();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(4);
        int int48 = year47.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year44, (org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo50 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray51 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo50 };
        periodAxis49.setLabelInfo(periodAxisLabelInfoArray51);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray55 = new org.jfree.chart.axis.ValueAxis[] { periodAxis49, dateAxis54 };
        combinedRangeXYPlot41.setRangeAxes(valueAxisArray55);
        boolean boolean57 = combinedRangeXYPlot41.isRangeMinorGridlinesVisible();
        boolean boolean58 = combinedRangeXYPlot41.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer61 = null;
        boolean boolean62 = combinedRangeXYPlot41.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker60, layer61);
        int int63 = combinedRangeXYPlot41.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range65 = combinedRangeXYPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis64);
        org.jfree.data.xy.XYSeries xYSeries67 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        xYSeries67.removeChangeListener(seriesChangeListener68);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection70 = new org.jfree.data.xy.XYSeriesCollection(xYSeries67);
        int int74 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection70, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection70, false);
        org.jfree.data.Range range78 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection70, false);
        java.lang.Number number79 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection70);
        xYSeriesCollection70.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState82 = xYStepAreaRenderer28.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot41, (org.jfree.data.xy.XYDataset) xYSeriesCollection70, plotRenderingInfo81);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState84 = xYAreaRenderer2.initialise(graphics2D16, rectangle2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.data.xy.XYDataset) xYSeriesCollection70, plotRenderingInfo83);
        try {
            boolean boolean85 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Combined Range XYPlot" + "'", str21.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray51);
        org.junit.Assert.assertNotNull(valueAxisArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNull(range65);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNull(range76);
        org.junit.Assert.assertNull(range78);
        org.junit.Assert.assertEquals((double) number79, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState82);
        org.junit.Assert.assertNotNull(xYItemRendererState84);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        org.jfree.chart.util.SortOrder sortOrder66 = categoryPlot51.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(sortOrder66);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setTextAlignment(horizontalAlignment4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        piePlot7.setNoDataMessage("hi!");
        piePlot7.setPieIndex((int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot7.getSimpleLabelOffset();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape17 = numberAxis16.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape17, (org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle18.setTextAlignment(horizontalAlignment20);
        java.lang.Object obj22 = textTitle18.clone();
        textTitle18.setMargin(0.05d, (double) 10.0f, (double) 100, (double) 100L);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockContainer29.getMargin();
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer29.getBounds();
        textTitle18.draw(graphics2D28, rectangle2D31);
        piePlot14.drawBackgroundImage(graphics2D15, rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets12.createInsetRectangle(rectangle2D31);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke36 = null;
        piePlot35.setOutlineStroke(stroke36);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        piePlot38.setNoDataMessage("hi!");
        java.awt.Paint paint41 = piePlot38.getBaseSectionOutlinePaint();
        piePlot35.setBaseSectionOutlinePaint(paint41);
        java.lang.Object obj43 = textTitle2.draw(graphics2D6, rectangle2D34, (java.lang.Object) piePlot35);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setNoDataMessage("hi!");
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) piePlot0, true);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = standardChartTheme12.getDrawingSupplier();
        java.awt.Font font15 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) waferMapPlot16, false);
        jFreeChart18.removeLegend();
        standardChartTheme12.apply(jFreeChart18);
        java.awt.Paint paint21 = standardChartTheme12.getItemLabelPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Color color24 = java.awt.Color.BLUE;
        standardChartTheme23.setWallPaint((java.awt.Paint) color24);
        java.awt.Paint paint26 = standardChartTheme23.getSubtitlePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = standardChartTheme23.getLabelLinkStyle();
        standardChartTheme12.setLabelLinkStyle(pieLabelLinkStyle27);
        piePlot0.setLabelLinkStyle(pieLabelLinkStyle27);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        double double4 = barRenderer3D2.getMinimumBarLength();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color9 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color9.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        java.awt.color.ColorSpace colorSpace16 = color9.getColorSpace();
        barRenderer3D8.setBaseItemLabelPaint((java.awt.Paint) color9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = barRenderer3D8.getLegendItemLabelGenerator();
        barRenderer3D2.setLegendItemLabelGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = barRenderer3D2.getItemLabelGenerator((-458), (int) ' ', true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer3D2.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
        org.junit.Assert.assertNull(itemLabelPosition25);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint11 = xYStepAreaRenderer1.getItemPaint(1, (int) '4', true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYStepAreaRenderer1.getDrawingSupplier();
        boolean boolean13 = xYStepAreaRenderer1.isShapesFilled();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        boolean boolean9 = polarPlot7.isDomainZoomable();
        java.awt.Stroke stroke10 = polarPlot7.getAngleGridlineStroke();
        polarPlot7.setAngleGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        int int36 = combinedRangeXYPlot14.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range38 = combinedRangeXYPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        int int47 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection43, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYStepAreaRenderer1.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo54);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = xYStepAreaRenderer1.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState55);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator56);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str19 = datasetRenderingOrder18.toString();
        combinedRangeXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str19.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        xYSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.color.ColorSpace colorSpace19 = color12.getColorSpace();
        barRenderer3D11.setBaseItemLabelPaint((java.awt.Paint) color12, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer3D11.getLegendItemLabelGenerator();
        java.awt.Paint paint24 = barRenderer3D11.lookupSeriesOutlinePaint((-452));
        combinedRangeXYPlot0.setDomainGridlinePaint(paint24);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        double double4 = dateTickUnit2.getSize();
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        java.util.Date date8 = dateAxis1.getMinimumDate();
        dateAxis1.setAutoRangeMinimumSize(12.0d, false);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.64E7d + "'", double4 == 8.64E7d);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        boolean boolean4 = piePlot0.isCircular();
        java.text.NumberFormat numberFormat6 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat6, numberFormat7);
        java.lang.Object obj9 = standardPieSectionLabelGenerator8.clone();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator8.getPercentFormat();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        long long4 = timeSeries3.getMaximumItemAge();
        double double5 = timeSeries3.getMaxY();
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) (byte) 10);
        double double9 = rectangleConstraint8.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint8.toFixedHeight((double) 'a');
        double double12 = rectangleConstraint11.getWidth();
        boolean boolean13 = timeSeries3.equals((java.lang.Object) rectangleConstraint11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(6, 4);
        long long17 = month16.getLastMillisecond();
        long long18 = month16.getSerialIndex();
        java.lang.Number number19 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month16, number19);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62025408000001L) + "'", long17 == (-62025408000001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 54L + "'", long18 == 54L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        java.lang.Class class12 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(4);
        int int16 = year15.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(4);
        int int19 = year18.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo21 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray22 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo21 };
        periodAxis20.setLabelInfo(periodAxisLabelInfoArray22);
        java.awt.Stroke stroke24 = periodAxis20.getTickMarkStroke();
        java.lang.Class class25 = periodAxis20.getAutoRangeTimePeriodClass();
        periodAxis7.setMinorTickTimePeriodClass(class25);
        java.lang.Class class27 = periodAxis7.getMinorTickTimePeriodClass();
        java.awt.Shape shape28 = periodAxis7.getUpArrow();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries4.removeAgedItems(false);
        java.lang.Object obj7 = timeSeries4.clone();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(4);
        int int11 = year10.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(4);
        int int14 = year13.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year13);
        int int16 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(4);
        int int20 = year19.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(4);
        int int23 = year22.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) year22);
        long long25 = year19.getSerialIndex();
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone26);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(4);
        int int34 = year33.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo36 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray37 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo36 };
        periodAxis35.setLabelInfo(periodAxisLabelInfoArray37);
        java.awt.Shape shape39 = periodAxis35.getLeftArrow();
        java.util.Locale locale40 = periodAxis35.getLocale();
        java.util.Locale locale41 = periodAxis35.getLocale();
        org.jfree.chart.axis.PeriodAxis periodAxis42 = new org.jfree.chart.axis.PeriodAxis("12/31/69 4:00 PM", (org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year19, timeZone26, locale41);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 4L + "'", long25 == 4L);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(locale41);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape8 = xYStepAreaRenderer2.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity11 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) categoryAxis9, "");
        int int12 = categoryAxis9.getCategoryLabelPositionOffset();
        java.awt.Font font13 = categoryAxis9.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        int int21 = timeSeriesCollection16.indexOf(timeSeries20);
        int int22 = timeSeriesCollection16.getSeriesCount();
        boolean boolean23 = textFragment14.equals((java.lang.Object) timeSeriesCollection16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textFragment14.draw(graphics2D24, (float) '#', (float) 9223372036854775807L, textAnchor27, (float) (-62041132800000L), (float) 9223372036854775807L, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setDrawBarOutline(false);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(4);
        int int9 = year8.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo11 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray12 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo11 };
        periodAxis10.setLabelInfo(periodAxisLabelInfoArray12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        double double16 = axisState15.getMax();
        axisState15.cursorLeft(100.0d);
        axisState15.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = textTitle22.getPosition();
        java.util.List list24 = periodAxis10.refreshTicks(graphics2D14, axisState15, rectangle2D21, rectangleEdge23);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(4);
        int int28 = year27.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo33 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray34 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo33 };
        periodAxis32.setLabelInfo(periodAxisLabelInfoArray34);
        java.awt.Stroke stroke36 = periodAxis32.getTickMarkStroke();
        java.lang.Class class37 = periodAxis32.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(4);
        int int41 = year40.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis45 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) year43);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo46 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray47 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo46 };
        periodAxis45.setLabelInfo(periodAxisLabelInfoArray47);
        java.awt.Stroke stroke49 = periodAxis45.getTickMarkStroke();
        java.lang.Class class50 = periodAxis45.getAutoRangeTimePeriodClass();
        periodAxis32.setMinorTickTimePeriodClass(class50);
        periodAxis10.setMajorTickTimePeriodClass(class50);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent54 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) class50, false);
        barRenderer0.notifyListeners(rendererChangeEvent54);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(class50);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        int int18 = combinedRangeXYPlot0.getSeriesCount();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke22 = piePlot21.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder(paint20, stroke22, rectangleInsets23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer26.setBaseSeriesVisible(false);
        xYStepAreaRenderer26.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint31 = xYStepAreaRenderer26.getBasePaint();
        boolean boolean32 = rectangleInsets23.equals((java.lang.Object) xYStepAreaRenderer26);
        java.awt.Font font35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font35, (java.awt.Paint) color36);
        xYStepAreaRenderer26.setLegendTextFont(6, font35);
        java.awt.Paint paint40 = xYStepAreaRenderer26.getSeriesOutlinePaint(9);
        combinedRangeXYPlot0.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer26);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint44 = null;
        xYStepAreaRenderer43.setBasePaint(paint44);
        java.awt.Stroke stroke47 = null;
        xYStepAreaRenderer43.setSeriesOutlineStroke((int) ' ', stroke47);
        org.jfree.data.xy.XYSeries xYSeries50 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        xYSeries50.removeChangeListener(seriesChangeListener51);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection(xYSeries50);
        int int57 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection53, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range58 = xYStepAreaRenderer43.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        java.lang.Object obj59 = xYSeriesCollection53.clone();
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53, true);
        double double63 = xYSeriesCollection53.getDomainLowerBound(true);
        org.jfree.data.Range range64 = xYStepAreaRenderer26.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = textTitle0.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        int int18 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range19 = xYStepAreaRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        xYStepAreaRenderer4.setBaseLegendShape(shape27);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity32 = new org.jfree.chart.entity.LegendItemEntity(shape27);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint35 = null;
        xYStepAreaRenderer34.setBasePaint(paint35);
        java.awt.Stroke stroke38 = null;
        xYStepAreaRenderer34.setSeriesOutlineStroke((int) ' ', stroke38);
        xYStepAreaRenderer34.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries43 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        xYSeries43.removeChangeListener(seriesChangeListener44);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection46 = new org.jfree.data.xy.XYSeriesCollection(xYSeries43);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer48 = null;
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection46, valueAxis47, polarItemRenderer48);
        org.jfree.data.Range range50 = xYStepAreaRenderer34.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection46);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection46, true);
        legendItemEntity32.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection46);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate54 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection46);
        boolean boolean55 = blockBorder2.equals((java.lang.Object) intervalXYDelegate54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = blockBorder2.getInsets();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder2);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets56);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        int int16 = combinedRangeXYPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        int int2 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem14.getFillPaintTransformer();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        legendItem14.setOutlineStroke(stroke16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        try {
            legendItem14.setFillPaintTransformer(gradientPaintTransformer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        org.jfree.data.Range range11 = xYSeriesCollection4.getDomainBounds(true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Boolean boolean2 = barRenderer3D0.getSeriesVisibleInLegend(2958465);
        double double3 = barRenderer3D0.getMinimumBarLength();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        boolean boolean4 = barRenderer3D2.getAutoPopulateSeriesPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D2.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        piePlot0.setShadowPaint((java.awt.Paint) color2);
        int int4 = color2.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color7 = color6.brighter();
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Boolean boolean11 = barRenderer3D9.getSeriesVisibleInLegend(2958465);
        int int12 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        java.awt.Paint paint13 = barRenderer3D9.getWallPaint();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        boolean boolean51 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean10 = combinedRangeXYPlot0.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker6, layer8, true);
        combinedRangeXYPlot0.zoom((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font14 = numberAxis13.getLabelFont();
        boolean boolean15 = combinedRangeXYPlot0.equals((java.lang.Object) numberAxis13);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockContainer17.getMargin();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer17.getBounds();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(4);
        int int23 = year22.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(4);
        int int26 = year25.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo28 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray29 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo28 };
        periodAxis27.setLabelInfo(periodAxisLabelInfoArray29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState();
        double double33 = axisState32.getMax();
        axisState32.cursorLeft(100.0d);
        axisState32.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = textTitle39.getPosition();
        java.util.List list41 = periodAxis27.refreshTicks(graphics2D31, axisState32, rectangle2D38, rectangleEdge40);
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D16, rectangle2D19, list41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = combinedRangeXYPlot0.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(valueAxis44);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.lang.String str3 = valueMarker1.getLabel();
        java.lang.Object obj4 = valueMarker1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        int int10 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection6, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6, false);
        xYSeriesCollection6.removeAllSeries();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long16 = segmentedTimeline14.toMillisecond((long) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.util.Date date19 = dateAxis18.getMinimumDate();
        long long20 = segmentedTimeline14.toTimelineValue(date19);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection6, (java.lang.Comparable) date19);
        double double22 = legendItemBlockContainer21.getWidth();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208927600001L) + "'", long16 == (-2208927600001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 644288400000L + "'", long20 == 644288400000L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

