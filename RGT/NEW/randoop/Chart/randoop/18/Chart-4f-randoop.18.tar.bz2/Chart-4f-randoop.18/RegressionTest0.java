import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        java.awt.Stroke stroke6 = null;
        java.awt.Paint paint7 = null;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, paint5, stroke6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, (float) (byte) 1, (int) ' ', textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) ' ', numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            blockContainer0.setBounds(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            waferMapPlot2.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 0, (float) 1, (float) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        java.lang.Number number4 = null;
        java.lang.Number number5 = null;
        try {
            xYSeries1.add(number4, number5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 0;
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke2, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        try {
            polarPlot7.zoom((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        try {
            xYStepAreaRenderer1.setLegendItemLabelGenerator(xYSeriesLabelGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ERROR : Relative To String", graphics2D1, (float) '#', (float) '4', textAnchor4, (double) (short) 10, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = null;
        try {
            xYSeries1.add(xYDataItem4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart4.getLegend((int) (byte) 0);
        try {
            jFreeChart4.setTextAntiAlias((java.lang.Object) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 10.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendTitle7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        double double2 = xYSeries1.getMinY();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint11 = null;
        xYStepAreaRenderer10.setBasePaint(paint11);
        java.awt.Stroke stroke14 = null;
        xYStepAreaRenderer10.setSeriesOutlineStroke((int) ' ', stroke14);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        xYSeries17.removeChangeListener(seriesChangeListener18);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection(xYSeries17);
        int int24 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection20, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range25 = xYStepAreaRenderer10.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        java.lang.Object obj26 = xYSeriesCollection20.clone();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYStepAreaRenderer1, obj26);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        java.awt.Paint paint9 = polarPlot7.getRadiusGridlinePaint();
        try {
            polarPlot7.zoom(4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint14 = null;
        xYStepAreaRenderer13.setBasePaint(paint14);
        java.awt.Stroke stroke17 = null;
        xYStepAreaRenderer13.setSeriesOutlineStroke((int) ' ', stroke17);
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer13.setSeriesPaint(4, paint20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke23 = piePlot22.getOutlineStroke();
        xYStepAreaRenderer13.setBaseOutlineStroke(stroke23, false);
        try {
            xYStepAreaRenderer1.setSeriesStroke((-16777216), stroke23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.lang.Object obj3 = piePlot0.clone();
        piePlot0.setAutoPopulateSectionOutlineStroke(true);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        xYSeriesCollection4.removeAllSeries();
        try {
            double double14 = xYSeriesCollection4.getStartXValue(1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.chart.title.Title title9 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape8, title9, "ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart4.getLegend((int) (byte) 0);
        jFreeChart4.setTextAntiAlias(false);
        org.jfree.chart.title.Title title10 = null;
        try {
            jFreeChart4.addSubtitle(title10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendTitle7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection11.clearSelection();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        java.awt.Paint paint9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Font font13 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font13, (org.jfree.chart.plot.Plot) waferMapPlot14, false);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke18 = jFreeChart16.getBorderStroke();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.clone(shape27);
        org.jfree.data.xy.XYSeries xYSeries30 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        xYSeries30.removeChangeListener(seriesChangeListener31);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection33 = new org.jfree.data.xy.XYSeriesCollection(xYSeries30);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection33, valueAxis34, polarItemRenderer35);
        boolean boolean37 = polarPlot36.isAngleLabelsVisible();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot36.setRadiusGridlineStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.darkGray;
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "", "index.html", "ThreadContext", true, shape7, false, paint9, false, (java.awt.Paint) color11, stroke18, true, shape27, stroke38, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        try {
            double double19 = xYSeriesCollection11.getEndYValue(2958465, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        java.awt.Stroke stroke6 = jFreeChart4.getBorderStroke();
        jFreeChart4.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.setBorderVisible(false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle1 = null;
        try {
            piePlot0.setLabelLinkStyle(pieLabelLinkStyle1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setPlotArea(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYStepAreaRenderer1.addAnnotation(xYAnnotation9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = xYStepAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        try {
            xYStepAreaRenderer1.setSeriesShape((-16777216), shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(xYToolTipGenerator17);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        try {
            double double20 = xYSeriesCollection13.getYValue(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double11 = periodAxis7.java2DToValue((double) (short) 1, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) 0.0f, (java.lang.Number) 10);
        xYSeries1.setNotify(false);
        org.junit.Assert.assertNull(xYDataItem8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setNotify(false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYStepAreaRenderer1.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        double double5 = piePlot0.getMinimumArcAngleToDraw();
        java.lang.Comparable comparable6 = null;
        java.awt.Color color7 = java.awt.Color.BLUE;
        try {
            piePlot0.setSectionPaint(comparable6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("SerialDate.weekInMonthToString(): invalid code.", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) textTitle6);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYStepAreaRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape15 = xYStepAreaRenderer9.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape15);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape15);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        piePlot18.setNoDataMessage("hi!");
        java.awt.Paint paint21 = piePlot18.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke22 = piePlot18.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = null;
        piePlot23.setOutlineStroke(stroke24);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        piePlot26.setNoDataMessage("hi!");
        java.awt.Paint paint29 = piePlot26.getBaseSectionOutlinePaint();
        piePlot23.setBaseSectionOutlinePaint(paint29);
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "index.html", "", "hi!", shape5, stroke22, paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        xYStepAreaRenderer1.setShapesVisible(false);
        java.lang.Boolean boolean7 = xYStepAreaRenderer1.getSeriesVisibleInLegend(10);
        xYStepAreaRenderer1.setBaseCreateEntities(true, false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYStepAreaRenderer1.fillRangeGridBand(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis13, rectangle2D14, (double) (byte) 1, (double) (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        xYStepAreaRenderer1.setRangeBase((double) (-1L));
        java.awt.Paint paint14 = xYStepAreaRenderer1.getSeriesFillPaint(0);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) (-1), (double) 100, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double11 = periodAxis7.java2DToValue((double) (-1L), rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-452));
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, Double.NaN, (float) (byte) 1, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle2.getTextAlignment();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
        int int4 = numberFormat2.getMinimumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis8.getCategoryStart(0, 3, rectangle2D13, rectangleEdge14);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke8);
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer1.setBaseOutlinePaint(paint10);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ERROR : Relative To String", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = null;
        try {
            numberAxis0.setDownArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint3 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke4 = piePlot0.getBaseSectionOutlineStroke();
        piePlot0.setNotify(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.clearSectionOutlineStrokes(true);
        boolean boolean11 = xYSeries1.equals((java.lang.Object) piePlot5);
        try {
            java.lang.Number number13 = xYSeries1.getX((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        int int18 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range19 = xYStepAreaRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        xYStepAreaRenderer4.setBaseLegendShape(shape27);
        boolean boolean32 = multiplePiePlot0.equals((java.lang.Object) xYStepAreaRenderer4);
        java.awt.Shape shape33 = xYStepAreaRenderer4.getBaseLegendShape();
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        polarPlot7.addCornerTextItem("index.html");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.block.BlockFrame blockFrame4 = blockContainer0.getFrame();
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.Title title4 = titleEntity3.getTitle();
        titleEntity3.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(title4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setLabelLinksVisible(false);
        java.lang.Object obj5 = piePlot0.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        java.awt.Stroke stroke5 = xYStepAreaRenderer1.lookupSeriesOutlineStroke((-458));
        java.lang.Boolean boolean7 = xYStepAreaRenderer1.getSeriesVisibleInLegend((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.Title title4 = titleEntity3.getTitle();
        java.lang.Object obj5 = titleEntity3.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(title4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.addOrUpdate((java.lang.Number) 0.0f, (java.lang.Number) 10);
        try {
            xYSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        java.awt.Font font4 = null;
        try {
            valueMarker1.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment2.draw(graphics2D3, 0.0f, (float) (short) 10, textAnchor6, 100.0f, (float) 6, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(true);
        xYStepAreaRenderer1.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        java.lang.Object obj3 = numberAxis0.clone();
        org.jfree.data.Range range4 = numberAxis0.getDefaultAutoRange();
        int int5 = numberAxis0.getMinorTickCount();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) '4', 8.64E7d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        try {
            periodAxis7.setAutoRangeMinimumSize((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        double double4 = dateTickUnit2.getSize();
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone9 = null;
        try {
            java.util.Date date10 = dateTickUnit2.addToDate(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.64E7d + "'", double4 == 8.64E7d);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        try {
            java.lang.Number number9 = xYSeriesCollection4.getX((int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart4.getLegend((int) (byte) 0);
        java.awt.Image image8 = jFreeChart4.getBackgroundImage();
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        try {
            jFreeChart4.plotChanged(plotChangeEvent5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "DomainOrder.NONE", "series", shape6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            java.lang.Comparable comparable3 = timeSeriesCollection1.getSeriesKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        int int18 = xYStepAreaRenderer1.getDefaultEntityRadius();
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape15 = numberAxis14.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape15, (org.jfree.chart.title.Title) textTitle16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle18.getPosition();
        textTitle16.setPosition(rectangleEdge19);
        try {
            double double21 = periodAxis7.valueToJava2D(0.0d, rectangle2D13, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYStepAreaRenderer1.notifyListeners(rendererChangeEvent10);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = dateAxis1.draw(graphics2D4, 1.0E-5d, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        try {
            org.jfree.data.xy.XYSeries xYSeries6 = xYSeriesCollection4.getSeries(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        boolean boolean6 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D3);
        java.lang.Object obj5 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) (byte) 10);
        double double10 = rectangleConstraint9.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight((double) 'a');
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer0.arrange(graphics2D6, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        double double19 = xYSeriesCollection11.getRangeLowerBound(true);
        org.jfree.data.Range range21 = xYSeriesCollection11.getDomainBounds(false);
        xYSeriesCollection11.removeAllSeries();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        boolean boolean4 = blockContainer0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.block.Block block5 = null;
        blockContainer0.add(block5);
        double double7 = blockContainer0.getContentYOffset();
        java.lang.Object obj8 = blockContainer0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            timeSeriesCollection1.setSelected(2958465, 12, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2958465).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint3 = standardChartTheme1.getLabelLinkPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = null;
        try {
            standardChartTheme1.setDrawingSupplier(drawingSupplier4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'supplier' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.MIDDLE" + "'", str1.equals("TimePeriodAnchor.MIDDLE"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getXValue((-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("{0}: ({1}, {2})", "", "ThreadContext");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list2 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (short) 100, list2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint11 = xYStepAreaRenderer1.getItemPaint(1, (int) '4', true);
        java.awt.Shape shape12 = xYStepAreaRenderer1.getBaseLegendShape();
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis1.setRange(date2, date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis2 = combinedRangeXYPlot0.getDomainAxisForDataset(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 6 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        xYStepAreaRenderer1.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (-16777216), (double) 9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        boolean boolean4 = blockContainer0.equals((java.lang.Object) 10.0f);
        java.lang.Object obj5 = blockContainer0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState();
        double double6 = axisState5.getMax();
        double double7 = axisState5.getCursor();
        categoryAxis0.drawTickMarks(graphics2D1, (double) (byte) 100, rectangle2D3, rectangleEdge4, axisState5);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        piePlot0.setAutoPopulateSectionOutlineStroke(false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, 9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate51 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        try {
            double double54 = intervalXYDelegate51.getEndXValue(9, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        periodAxis7.setMinorTickMarksVisible(true);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = periodAxis7.getLabelInfo();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot7.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem10 = legendItemCollection8.get(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year5.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        try {
            combinedRangeXYPlot0.zoomRangeAxes((double) 3, 0.4d, plotRenderingInfo20, point2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.31008E10) <= upper (-1.88928E10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape9 = xYStepAreaRenderer3.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) categoryAxis10, "");
        int int13 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Font font14 = categoryAxis10.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font14);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("DomainOrder.NONE", font14);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range18, (double) (byte) 10);
        double double21 = rectangleConstraint20.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint20.toFixedHeight((double) 'a');
        try {
            org.jfree.chart.util.Size2D size2D24 = labelBlock16.arrange(graphics2D17, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1L), (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        legendItemEntity29.setToolTipText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        int int2 = combinedRangeXYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        polarPlot7.setAngleLabelsVisible(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        polarPlot7.removeCornerTextItem("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        double double5 = piePlot0.getMinimumArcAngleToDraw();
        boolean boolean6 = piePlot0.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        piePlot0.setInsets(rectangleInsets7);
        double double10 = rectangleInsets7.calculateTopOutset((double) (-452));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getXValue((-452), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer11 = null;
        waferMapPlot7.setRenderer(waferMapRenderer11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getEndX((int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType8 = org.jfree.data.RangeType.POSITIVE;
        numberAxis7.setRangeType(rangeType8);
        java.lang.Object obj10 = numberAxis7.clone();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            barRenderer3D2.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis7, rectangle2D11, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint11 = xYStepAreaRenderer1.getBaseFillPaint();
        boolean boolean12 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange2((double) 1.0f, (double) (-452));
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle8.getPosition();
        try {
            double double10 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D7, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        xYStepAreaRenderer1.setItemLabelAnchorOffset((double) 4);
        xYStepAreaRenderer1.setSeriesItemLabelsVisible(4, (java.lang.Boolean) true, true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        boolean boolean11 = xYStepAreaRenderer1.getPlotArea();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(64, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint3 = null;
        xYStepAreaRenderer2.setBasePaint(paint3);
        java.awt.Stroke stroke6 = null;
        xYStepAreaRenderer2.setSeriesOutlineStroke((int) ' ', stroke6);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        xYSeries9.removeChangeListener(seriesChangeListener10);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries9);
        int int16 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection12, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range17 = xYStepAreaRenderer2.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYStepAreaRenderer19.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape25 = xYStepAreaRenderer19.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape25, (org.jfree.chart.axis.Axis) categoryAxis26, "");
        xYStepAreaRenderer2.setBaseLegendShape(shape25);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape25);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint33 = null;
        xYStepAreaRenderer32.setBasePaint(paint33);
        java.awt.Stroke stroke36 = null;
        xYStepAreaRenderer32.setSeriesOutlineStroke((int) ' ', stroke36);
        xYStepAreaRenderer32.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries41 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        xYSeries41.removeChangeListener(seriesChangeListener42);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection44 = new org.jfree.data.xy.XYSeriesCollection(xYSeries41);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection44, valueAxis45, polarItemRenderer46);
        org.jfree.data.Range range48 = xYStepAreaRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44, true);
        legendItemEntity30.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection44);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate52 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection44);
        boolean boolean53 = blockBorder0.equals((java.lang.Object) intervalXYDelegate52);
        double double54 = intervalXYDelegate52.getIntervalPositionFactor();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5d + "'", double54 == 0.5d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String str17 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint18 = null;
        try {
            combinedRangeXYPlot0.setRangeCrosshairPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined Range XYPlot" + "'", str17.equals("Combined Range XYPlot"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.setID("");
        boolean boolean5 = blockContainer1.equals((java.lang.Object) 10.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) (byte) 10);
        double double10 = rectangleConstraint9.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight((double) 'a');
        try {
            org.jfree.chart.util.Size2D size2D13 = columnArrangement0.arrange(blockContainer1, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        java.awt.Stroke stroke11 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        java.lang.Object obj6 = xYAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.category.BarPainter barPainter2 = standardChartTheme1.getBarPainter();
        org.junit.Assert.assertNotNull(barPainter2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis12, "");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer16.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator23 = xYStepAreaRenderer16.getBaseItemLabelGenerator();
        xYStepAreaRenderer16.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.StandardChartTheme standardChartTheme28 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint29 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme28.setLegendBackgroundPaint(paint29);
        xYStepAreaRenderer16.setBasePaint(paint29, false);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer35.setBaseSeriesVisible(false);
        boolean boolean38 = textBlockAnchor33.equals((java.lang.Object) xYStepAreaRenderer35);
        org.jfree.data.xy.XYSeries xYSeries41 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        xYSeries41.removeChangeListener(seriesChangeListener42);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection44 = new org.jfree.data.xy.XYSeriesCollection(xYSeries41);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection44, valueAxis45, polarItemRenderer46);
        boolean boolean48 = polarPlot47.isAngleLabelsVisible();
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot47.setRadiusGridlineStroke(stroke49);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        piePlot51.setNoDataMessage("hi!");
        java.awt.Paint paint54 = piePlot51.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke55 = piePlot51.getBaseSectionOutlineStroke();
        polarPlot47.setRadiusGridlineStroke(stroke55);
        xYStepAreaRenderer35.setSeriesStroke((int) (byte) 10, stroke55);
        java.awt.Paint paint58 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem(attributedString0, "index.html", "DomainOrder.NONE", "Combined Range XYPlot", shape11, paint29, stroke55, paint58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(xYItemLabelGenerator23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str14 = combinedRangeXYPlot13.getPlotType();
        java.awt.geom.GeneralPath generalPath15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        combinedRangeXYPlot13.select(generalPath15, rectangle2D16, renderingSource17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle20.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace23 = periodAxis7.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13, rectangle2D19, rectangleEdge21, axisSpace22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = xYStepAreaRenderer1.getItemLabelGenerator((int) (byte) 100, 5, true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(xYItemLabelGenerator16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toRangeWidth((org.jfree.data.Range) dateRange4);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateTickUnitType2, 5, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax((double) '4');
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) number13, Double.NaN, 0);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        int int22 = combinedRangeXYPlot0.getSeriesCount();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint25 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme24.setLegendBackgroundPaint(paint25);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYStepAreaRenderer28.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape34 = xYStepAreaRenderer28.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint38 = xYStepAreaRenderer28.getItemPaint(1, (int) '4', true);
        standardChartTheme24.setCrosshairPaint(paint38);
        combinedRangeXYPlot0.setRangeTickBandPaint(paint38);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.lang.String str1 = domainOrder0.toString();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer3.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer3.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint13 = xYStepAreaRenderer3.getBaseFillPaint();
        boolean boolean14 = domainOrder0.equals((java.lang.Object) xYStepAreaRenderer3);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.NONE" + "'", str1.equals("DomainOrder.NONE"));
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) '4', plotRenderingInfo23, point2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        double double3 = range2.getUpperBound();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 900000L);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range5);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1);
        double double10 = range9.getUpperBound();
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range9, (double) 900000L);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(range12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, range12);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 1, plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate51 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent52 = null;
        intervalXYDelegate51.datasetChanged(datasetChangeEvent52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer4.setSeriesPaint(4, paint11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke14 = piePlot13.getOutlineStroke();
        xYStepAreaRenderer4.setBaseOutlineStroke(stroke14, false);
        piePlot0.setLabelLinkStroke(stroke14);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor19 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
        piePlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor19);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint11 = null;
        xYStepAreaRenderer10.setBasePaint(paint11);
        java.awt.Stroke stroke14 = null;
        xYStepAreaRenderer10.setSeriesOutlineStroke((int) ' ', stroke14);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset17 = null;
        waferMapPlot16.setDataset(waferMapDataset17);
        xYStepAreaRenderer10.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot16);
        xYStepAreaRenderer10.setRangeBase((double) (-1L));
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer10.setBaseItemLabelFont(font22);
        polarPlot7.setAngleLabelFont(font22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        polarPlot7.zoomDomainAxes((double) (-458), plotRenderingInfo26, point2D27);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = null;
        polarPlot7.datasetChanged(datasetChangeEvent29);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ERROR : Relative To String");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) 100);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.color.ColorSpace colorSpace7 = color0.getColorSpace();
        java.awt.color.ColorSpace colorSpace8 = null;
        float[] floatArray13 = new float[] { 'a', (-452), (-452), 10L };
        try {
            float[] floatArray14 = color0.getComponents(colorSpace8, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        boolean boolean5 = piePlot0.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint6 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        boolean boolean9 = polarPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot7.zoomDomainAxes((double) 1L, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            polarPlot7.zoomRangeAxes((double) (-1.0f), (double) (byte) 10, plotRenderingInfo17, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        xYSeries1.setMaximumItemCount(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries1.addChangeListener(seriesChangeListener4);
        xYSeries1.add((java.lang.Number) 0.4d, (java.lang.Number) 3.0d, false);
        java.lang.Number number11 = null;
        try {
            xYSeries1.add(0.0d, number11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot7.getLegendItems();
        java.awt.Paint paint9 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYStepAreaRenderer6.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape12 = xYStepAreaRenderer6.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.StandardChartTheme standardChartTheme15 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme15.setLegendBackgroundPaint(paint16);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYStepAreaRenderer19.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape25 = xYStepAreaRenderer19.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint29 = xYStepAreaRenderer19.getItemPaint(1, (int) '4', true);
        standardChartTheme15.setCrosshairPaint(paint29);
        java.awt.Color color32 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.AffineTransform affineTransform36 = null;
        java.awt.RenderingHints renderingHints37 = null;
        java.awt.PaintContext paintContext38 = color32.createContext(colorModel33, rectangle34, rectangle2D35, affineTransform36, renderingHints37);
        java.awt.color.ColorSpace colorSpace39 = color32.getColorSpace();
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke41 = piePlot40.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint45 = null;
        xYStepAreaRenderer44.setBasePaint(paint45);
        java.awt.Stroke stroke48 = null;
        xYStepAreaRenderer44.setSeriesOutlineStroke((int) ' ', stroke48);
        org.jfree.data.xy.XYSeries xYSeries51 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        xYSeries51.removeChangeListener(seriesChangeListener52);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection54 = new org.jfree.data.xy.XYSeriesCollection(xYSeries51);
        int int58 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection54, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range59 = xYStepAreaRenderer44.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection54);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = xYStepAreaRenderer61.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape67 = xYStepAreaRenderer61.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape67, (org.jfree.chart.axis.Axis) categoryAxis68, "");
        xYStepAreaRenderer44.setBaseLegendShape(shape67);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity72 = new org.jfree.chart.entity.LegendItemEntity(shape67);
        org.jfree.chart.entity.ChartEntity chartEntity73 = new org.jfree.chart.entity.ChartEntity(shape67);
        java.awt.Stroke stroke74 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot75 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str76 = combinedRangeXYPlot75.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace77 = combinedRangeXYPlot75.getFixedDomainAxisSpace();
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint79 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean80 = org.jfree.chart.util.PaintUtilities.equal(paint78, paint79);
        combinedRangeXYPlot75.setDomainCrosshairPaint(paint79);
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "index.html", "{0}: ({1}, {2})", "DatasetRenderingOrder.FORWARD", false, shape12, false, paint29, false, (java.awt.Paint) color32, stroke41, true, shape67, stroke74, paint79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintContext38);
        org.junit.Assert.assertNotNull(colorSpace39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(itemLabelPosition63);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Combined Range XYPlot" + "'", str76.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint7 = null;
        xYStepAreaRenderer6.setBasePaint(paint7);
        java.awt.Stroke stroke10 = null;
        xYStepAreaRenderer6.setSeriesOutlineStroke((int) ' ', stroke10);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        waferMapPlot12.setDataset(waferMapDataset13);
        xYStepAreaRenderer6.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot12);
        xYStepAreaRenderer6.setRangeBase((double) (-1L));
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer6.setBaseItemLabelFont(font18);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (byte) 0, (double) (byte) -1, 4.0d, (double) (byte) 0, font18);
        java.awt.Graphics2D graphics2D21 = null;
        double double22 = markerAxisBand20.getHeight(graphics2D21);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
        numberFormat1.setMaximumFractionDigits((int) (byte) -1);
        try {
            java.lang.Object obj7 = numberFormat1.parseObject("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRange(true);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis1.setAxisLinePaint(paint4);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint8 = null;
        xYStepAreaRenderer7.setBasePaint(paint8);
        java.awt.Stroke stroke11 = null;
        xYStepAreaRenderer7.setSeriesOutlineStroke((int) ' ', stroke11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke14 = piePlot13.getOutlineStroke();
        xYStepAreaRenderer7.setBaseOutlineStroke(stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0, paint4, stroke14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries3.getDataItem((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        double double19 = xYSeriesCollection11.getRangeLowerBound(true);
        org.jfree.data.Range range21 = xYSeriesCollection11.getDomainBounds(false);
        try {
            boolean boolean24 = xYSeriesCollection11.isSelected((int) (byte) -1, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer6.setBaseSeriesVisible(false);
        xYStepAreaRenderer6.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint11 = xYStepAreaRenderer6.getBasePaint();
        boolean boolean12 = rectangleInsets3.equals((java.lang.Object) xYStepAreaRenderer6);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            rectangleInsets3.trim(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        try {
            float float7 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        int int22 = combinedRangeXYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = combinedRangeXYPlot0.getRenderer((-458));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        xYStepAreaRenderer1.setRangeBase((double) (-1L));
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer1.setBaseItemLabelFont(font13);
        java.awt.Shape shape16 = xYStepAreaRenderer1.getSeriesShape((int) (byte) 100);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(4);
        int int22 = year21.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(4);
        int int25 = year24.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo27 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray28 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo27 };
        periodAxis26.setLabelInfo(periodAxisLabelInfoArray28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { periodAxis26, dateAxis31 };
        combinedRangeXYPlot18.setRangeAxes(valueAxisArray32);
        boolean boolean34 = combinedRangeXYPlot18.isRangeMinorGridlinesVisible();
        boolean boolean35 = combinedRangeXYPlot18.canSelectByRegion();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme40 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke42 = null;
        piePlot41.setOutlineStroke(stroke42);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        piePlot44.setNoDataMessage("hi!");
        java.awt.Paint paint47 = piePlot44.getBaseSectionOutlinePaint();
        piePlot41.setBaseSectionOutlinePaint(paint47);
        standardChartTheme40.setRangeGridlinePaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint52 = null;
        xYStepAreaRenderer51.setBasePaint(paint52);
        java.awt.Stroke stroke55 = null;
        xYStepAreaRenderer51.setSeriesOutlineStroke((int) ' ', stroke55);
        xYStepAreaRenderer51.setAutoPopulateSeriesShape(false);
        java.awt.Stroke stroke60 = xYStepAreaRenderer51.lookupSeriesStroke(10);
        try {
            xYStepAreaRenderer1.drawRangeLine(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, valueAxis36, rectangle2D37, (double) (-2208960000000L), paint47, stroke60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray28);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot0.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ERROR : Relative To String");
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(4, attributedString3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot0.addDomainMarker(2, categoryMarker15, layer16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange2((double) 1.0f, (double) (-452));
        java.text.NumberFormat numberFormat6 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (-16777216), (double) (byte) 10, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        int int5 = jFreeChart4.getSubtitleCount();
        java.awt.Paint paint6 = jFreeChart4.getBorderPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) waferMapPlot13, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart15.createBufferedImage(5, 4, (double) (byte) 10, (double) 0L, chartRenderingInfo20);
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart4.createBufferedImage((int) (byte) -1, (int) '#', (int) ' ', chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(bufferedImage21);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setNoDataMessage("hi!");
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean3 = standardXYURLGenerator1.equals((java.lang.Object) rectangleAnchor2);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent4.getChart();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimHeight((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.0d + "'", double2 == 33.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3D2.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNull(itemLabelPosition13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke4 = piePlot0.getBaseSectionOutlineStroke();
        double double5 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = xYItemRendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("SerialDate.weekInMonthToString(): invalid code.", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 1L, plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        polarPlot7.setAngleLabelsVisible(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot7.setRenderer(polarItemRenderer11);
        boolean boolean13 = polarPlot7.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.setID("");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = blockContainer1.arrange(graphics2D4);
        size2D5.setHeight((double) 1.0f);
        boolean boolean8 = strokeMap0.equals((java.lang.Object) 1.0f);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        int int22 = combinedRangeXYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range24 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis23);
        boolean boolean25 = numberAxis23.isInverted();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("series", graphics2D1, (float) (byte) 100, (float) 3, 0.0d, (float) 0, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setMaximumLabelWidth((double) 4);
        int int6 = piePlot0.getPieIndex();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = piePlot7.getOutlineStroke();
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke8);
        java.awt.Stroke stroke13 = xYStepAreaRenderer1.getItemStroke((int) (short) 10, 6, false);
        xYStepAreaRenderer1.setSeriesItemLabelsVisible(2958465, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart4.createBufferedImage(5, 4, (double) (byte) 10, (double) 0L, chartRenderingInfo9);
        int int11 = jFreeChart4.getSubtitleCount();
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange2((double) 1.0f, (double) (-452));
        java.awt.Paint paint6 = null;
        try {
            numberAxis0.setTickMarkPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator3.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setID("");
        boolean boolean4 = blockContainer0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.block.Block block5 = null;
        blockContainer0.add(block5);
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke9 = piePlot8.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint7, stroke9, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        double double14 = rectangleInsets12.calculateTopOutset((double) 12);
        blockContainer0.setMargin(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, true);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint12 = numberAxis11.getLabelPaint();
        xYStepAreaRenderer1.setBasePaint(paint12);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection4.validateObject();
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer3D2.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot15.getFixedLegendItems();
        double double18 = categoryPlot15.getAnchorValue();
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) true);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke26 = null;
        piePlot25.setOutlineStroke(stroke26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        piePlot28.setNoDataMessage("hi!");
        java.awt.Paint paint31 = piePlot28.getBaseSectionOutlinePaint();
        piePlot25.setBaseSectionOutlinePaint(paint31);
        standardChartTheme24.setRangeGridlinePaint(paint31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        standardChartTheme24.setChartBackgroundPaint((java.awt.Paint) color34);
        java.awt.Stroke stroke36 = null;
        try {
            barRenderer3D2.drawDomainLine(graphics2D14, categoryPlot15, rectangle2D21, 100.0d, (java.awt.Paint) color34, stroke36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        java.awt.Stroke stroke18 = null;
        try {
            xYStepAreaRenderer1.setBaseOutlineStroke(stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        numberAxis0.resizeRange2((double) (short) 100, 100.0d);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DomainOrder.NONE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DomainOrder.NONE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getXOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = dateTickUnit0.getUnitType();
//        double double2 = dateTickUnit0.getSize();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//        dateAxis4.setInverted(false);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis4.setMinimumDate(date7);
//        java.lang.String str9 = dateTickUnit0.dateToString(date7);
//        org.junit.Assert.assertNotNull(dateTickUnit0);
//        org.junit.Assert.assertNotNull(dateTickUnitType1);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.64E7d + "'", double2 == 8.64E7d);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "6/13/19 1:07 PM" + "'", str9.equals("6/13/19 1:07 PM"));
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle4.getPosition();
        textTitle2.setPosition(rectangleEdge5);
        textTitle2.setHeight(0.0d);
        textTitle2.visible = false;
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getMultiple();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-458), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("series");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        piePlot4.setNoDataMessage("hi!");
        piePlot4.clearSectionOutlineStrokes(false);
        try {
            java.lang.Object obj9 = labelBlock1.draw(graphics2D2, rectangle2D3, (java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.setPieIndex((int) (short) -1);
        piePlot0.setSimpleLabels(true);
        boolean boolean7 = piePlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color2 = java.awt.Color.getColor("index.html", (-458));
        int int3 = color2.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0d), keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3, textAnchor4, (double) (short) 100);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, 2958465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator5);
        barRenderer3D2.setShadowYOffset((double) (-459));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke6 = piePlot5.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder(paint4, stroke6, rectangleInsets7);
        valueMarker1.setLabelOffset(rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets7.createOutsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 0, false, false);
        xYSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        boolean boolean11 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint20 = null;
        xYStepAreaRenderer19.setBasePaint(paint20);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYStepAreaRenderer19.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        xYStepAreaRenderer1.setRangeBase((double) (-1L));
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer1.setBaseItemLabelFont(font13);
        java.awt.Shape shape16 = xYStepAreaRenderer1.getSeriesShape((int) (byte) 100);
        xYStepAreaRenderer1.setItemLabelAnchorOffset((double) 31);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint4);
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke10 = null;
        piePlot9.setOutlineStroke(stroke10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setNoDataMessage("hi!");
        java.awt.Paint paint15 = piePlot12.getBaseSectionOutlinePaint();
        piePlot9.setBaseSectionOutlinePaint(paint15);
        standardChartTheme8.setRangeGridlinePaint(paint15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme8.setErrorIndicatorPaint((java.awt.Paint) color18);
        float[] floatArray26 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray27 = color18.getColorComponents(floatArray26);
        int int28 = color18.getGreen();
        combinedRangeXYPlot0.setDomainCrosshairPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.Marker marker30 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(marker30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 64 + "'", int28 == 64);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        waferMapPlot7.setDataset(waferMapDataset8);
        xYStepAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) waferMapPlot7);
        xYStepAreaRenderer1.setRangeBase((double) (-1L));
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepAreaRenderer1.setBaseItemLabelFont(font13);
        java.awt.Shape shape16 = xYStepAreaRenderer1.getSeriesShape((int) (byte) 100);
        xYStepAreaRenderer1.setShapesFilled(false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        java.lang.Object obj5 = jFreeChart4.getTextAntiAlias();
        jFreeChart4.fireChartChanged();
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(12.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer1.getNegativeItemLabelPosition((int) (byte) 10, (int) '4', false);
        xYAreaRenderer1.setSeriesVisible(64, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot26.getFixedLegendItems();
        categoryPlot26.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot26.setDomainAxisLocation(axisLocation31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot26.getDomainAxisLocation();
        try {
            combinedRangeXYPlot0.setDomainAxisLocation((-1), axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = lineBorder4.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder4.getInsets();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepAreaRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer2.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        xYStepAreaRenderer2.setBaseItemLabelsVisible(false, false);
        boolean boolean12 = blockBorder0.equals((java.lang.Object) xYStepAreaRenderer2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str15 = combinedRangeXYPlot14.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace16 = combinedRangeXYPlot14.getFixedDomainAxisSpace();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        combinedRangeXYPlot14.setDomainCrosshairPaint(paint18);
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = null;
        piePlot23.setOutlineStroke(stroke24);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        piePlot26.setNoDataMessage("hi!");
        java.awt.Paint paint29 = piePlot26.getBaseSectionOutlinePaint();
        piePlot23.setBaseSectionOutlinePaint(paint29);
        standardChartTheme22.setRangeGridlinePaint(paint29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme22.setErrorIndicatorPaint((java.awt.Paint) color32);
        float[] floatArray40 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray41 = color32.getColorComponents(floatArray40);
        int int42 = color32.getGreen();
        combinedRangeXYPlot14.setDomainCrosshairPaint((java.awt.Paint) color32);
        xYStepAreaRenderer2.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined Range XYPlot" + "'", str15.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 64 + "'", int42 == 64);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent17);
        boolean boolean19 = combinedRangeXYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRange(true);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape4 = numberAxis3.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity6 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) textTitle5);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape14 = xYStepAreaRenderer8.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape14);
        numberAxis0.setRightArrow(shape4);
        numberAxis0.setTickMarkOutsideLength((float) 9);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        double double4 = dateTickUnit2.getSize();
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        int int8 = dateTickUnit2.getMinorTickCount();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.64E7d + "'", double4 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getUpperDate();
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, 0.2d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        try {
            timeSeries1.delete((int) (byte) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        try {
            double double8 = xYSeriesCollection4.getEndYValue(255, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity7 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart5, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder(paint0, stroke2, rectangleInsets3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer6.setBaseSeriesVisible(false);
        xYStepAreaRenderer6.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint11 = xYStepAreaRenderer6.getBasePaint();
        boolean boolean12 = rectangleInsets3.equals((java.lang.Object) xYStepAreaRenderer6);
        java.awt.Paint paint13 = xYStepAreaRenderer6.getBaseLegendTextPaint();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        double double6 = timeSeriesCollection1.getDomainLowerBound(true);
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        double double4 = rectangleInsets3.getBottom();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            barRenderer3D2.drawBackground(graphics2D7, categoryPlot8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 100);
        titleEntity3.setArea(shape6);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) waferMapPlot9, false);
        int int12 = jFreeChart11.getSubtitleCount();
        java.awt.Paint paint13 = jFreeChart11.getBorderPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape4, (java.awt.Paint) color5, stroke6, paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape22 = xYStepAreaRenderer16.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis23, "");
        legendItem14.setLine(shape22);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline29 = dateAxis28.getTimeline();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) dateAxis28, "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator32 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator33 = null;
        try {
            java.lang.String str34 = axisEntity31.getImageMapAreaTag(toolTipTagFragmentGenerator32, uRLTagFragmentGenerator33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(timeline29);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.clearSectionOutlineStrokes(false);
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Paint paint6 = piePlot0.getSectionPaint(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(true);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState1.setCrosshairState(xYCrosshairState4);
        xYCrosshairState4.updateCrosshairX((double) 31, 31);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        categoryPlot0.clearRangeMarkers(2);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) textTitle10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle10.getVerticalAlignment();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj16 = barRenderer3D15.clone();
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle10, obj16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle18.getPosition();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle18, (java.lang.Object) stroke20);
        textTitle18.setVisible(false);
        java.awt.Font font24 = textTitle18.getFont();
        categoryPlot0.setNoDataMessageFont(font24);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(4);
        int int5 = year4.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year4, (org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo10 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray11 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo10 };
        periodAxis9.setLabelInfo(periodAxisLabelInfoArray11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { periodAxis9, dateAxis14 };
        combinedRangeXYPlot1.setRangeAxes(valueAxisArray15);
        boolean boolean17 = combinedRangeXYPlot1.isRangeMinorGridlinesVisible();
        boolean boolean18 = combinedRangeXYPlot1.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.awt.Paint paint20 = combinedRangeXYPlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray11);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        int int6 = timeSeriesCollection1.indexOf(timeSeries5);
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeriesCollection1.getSeries(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent17);
        java.awt.Stroke stroke19 = null;
        try {
            combinedRangeXYPlot0.setDomainCrosshairStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        xYAreaRenderer1.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        categoryPlot0.clearRangeMarkers(2);
        int int7 = categoryPlot0.getWeight();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getRangeMarkers(layer1);
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        org.jfree.data.Range range17 = xYStepAreaRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        double double21 = xYSeriesCollection13.getDomainUpperBound(true);
        boolean boolean22 = xYSeriesCollection13.isAutoWidth();
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        boolean boolean17 = polarPlot16.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) polarPlot16, "{0}: ({1}, {2})");
        org.jfree.data.general.DatasetGroup datasetGroup20 = polarPlot16.getDatasetGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        polarPlot16.datasetChanged(datasetChangeEvent21);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(datasetGroup20);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        jFreeChart4.removeLegend();
        java.awt.Stroke stroke6 = jFreeChart4.getBorderStroke();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        chartRenderingInfo10.clear();
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D8, point2D9, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot7.getLegendItems();
        int int9 = legendItemCollection8.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection8.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("DatasetRenderingOrder.FORWARD");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        xYSeriesCollection11.seriesChanged(seriesChangeEvent20);
        xYSeriesCollection11.removeAllSeries();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer4.setSeriesPaint(4, paint11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke14 = piePlot13.getOutlineStroke();
        xYStepAreaRenderer4.setBaseOutlineStroke(stroke14, false);
        piePlot0.setLabelLinkStroke(stroke14);
        piePlot0.setAutoPopulateSectionOutlineStroke(true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, (double) 12);
        double double3 = barRenderer3D2.getMaximumBarWidth();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = barRenderer3D2.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(drawingSupplier4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = color0.brighter();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = periodAxis7.draw(graphics2D8, (double) 10, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        numberAxis0.configure();
        double double4 = numberAxis0.getUpperMargin();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font13 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font13, (org.jfree.chart.plot.Plot) waferMapPlot14, false);
        int int17 = jFreeChart16.getSubtitleCount();
        java.awt.Paint paint18 = jFreeChart16.getBorderPaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.FORWARD", "series", "", "Category Plot", shape9, (java.awt.Paint) color10, stroke11, paint18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        legendItem19.setLine(shape27);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline34 = dateAxis33.getTimeline();
        org.jfree.chart.entity.AxisEntity axisEntity36 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) dateAxis33, "DatasetRenderingOrder.FORWARD");
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, 8.64E7d, 1.0d);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape39, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=10.0]", "");
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(timeline34);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint5 = null;
        xYStepAreaRenderer4.setBasePaint(paint5);
        java.awt.Stroke stroke8 = null;
        xYStepAreaRenderer4.setSeriesOutlineStroke((int) ' ', stroke8);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        xYSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        int int18 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range19 = xYStepAreaRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYStepAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape27 = xYStepAreaRenderer21.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape27, (org.jfree.chart.axis.Axis) categoryAxis28, "");
        xYStepAreaRenderer4.setBaseLegendShape(shape27);
        boolean boolean32 = multiplePiePlot0.equals((java.lang.Object) xYStepAreaRenderer4);
        org.jfree.chart.plot.XYPlot xYPlot33 = null;
        xYStepAreaRenderer4.setPlot(xYPlot33);
        xYStepAreaRenderer4.setShapesFilled(true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj5 = barRenderer3D4.clone();
        double double6 = barRenderer3D4.getMinimumBarLength();
        java.awt.geom.RectangularShape rectangularShape10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            gradientBarPainter0.paintBar(graphics2D1, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D4, 1, 3, false, rectangularShape10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = periodAxis7.getTickMarkStroke();
        periodAxis7.setMinorTickMarksVisible(true);
        java.util.Locale locale14 = periodAxis7.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale14);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator16 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            polarPlot7.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        java.util.Currency currency1 = null;
        try {
            numberFormat0.setCurrency(currency1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot0.getDomainAxisLocation((-458));
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(4);
        int int10 = year9.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year6, (org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo12 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray13 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo12 };
        periodAxis11.setLabelInfo(periodAxisLabelInfoArray13);
        java.awt.Stroke stroke15 = periodAxis11.getTickMarkStroke();
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke15);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint19 = null;
        xYStepAreaRenderer18.setBasePaint(paint19);
        java.awt.Stroke stroke22 = null;
        xYStepAreaRenderer18.setSeriesOutlineStroke((int) ' ', stroke22);
        org.jfree.data.xy.XYSeries xYSeries25 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        xYSeries25.removeChangeListener(seriesChangeListener26);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection(xYSeries25);
        int int32 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection28, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range33 = xYStepAreaRenderer18.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYStepAreaRenderer35.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape41 = xYStepAreaRenderer35.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity44 = new org.jfree.chart.entity.AxisEntity(shape41, (org.jfree.chart.axis.Axis) categoryAxis42, "");
        xYStepAreaRenderer18.setBaseLegendShape(shape41);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity46 = new org.jfree.chart.entity.LegendItemEntity(shape41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer48 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint49 = null;
        xYStepAreaRenderer48.setBasePaint(paint49);
        java.awt.Stroke stroke52 = null;
        xYStepAreaRenderer48.setSeriesOutlineStroke((int) ' ', stroke52);
        xYStepAreaRenderer48.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries57 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        xYSeries57.removeChangeListener(seriesChangeListener58);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection60 = new org.jfree.data.xy.XYSeriesCollection(xYSeries57);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection60, valueAxis61, polarItemRenderer62);
        org.jfree.data.Range range64 = xYStepAreaRenderer48.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection60);
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection60, true);
        legendItemEntity46.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection60);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit71 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType72 = dateTickUnit71.getUnitType();
        double double73 = dateTickUnit71.getSize();
        dateAxis70.setTickUnit(dateTickUnit71, false, false);
        categoryPlot68.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        categoryPlot68.setRangeAxis(10, valueAxis80);
        boolean boolean82 = xYSeriesCollection60.hasListener((java.util.EventListener) categoryPlot68);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection60);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertNotNull(dateTickUnit71);
        org.junit.Assert.assertNotNull(dateTickUnitType72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 8.64E7d + "'", double73 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(xYItemRenderer83);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = polarPlot7.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot7.zoomDomainAxes((double) 1L, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.Point point11 = polarPlot7.translateValueThetaRadiusToJava2D(1.0d, (double) 9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) 10, (double) (byte) 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries10.removeChangeListener(seriesChangeListener11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis14, polarItemRenderer15);
        boolean boolean17 = polarPlot16.isRangeZoomable();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) polarPlot16, "{0}: ({1}, {2})");
        org.jfree.chart.plot.Plot plot20 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape8, plot20, "Multiple Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("6/13/19 1:07 PM", dateFormat1, dateFormat2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        boolean boolean9 = polarPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot7.zoomDomainAxes((double) 1L, plotRenderingInfo11, point2D12, false);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.Point point18 = polarPlot7.translateValueThetaRadiusToJava2D((double) '4', 10.0d, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        barRenderer3D2.setBase((double) 3);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(true);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState1.setCrosshairState(xYCrosshairState4);
        double double6 = xYCrosshairState4.getAnchorX();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        boolean boolean5 = piePlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        chartRenderingInfo1.setEntityCollection(entityCollection2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        xYStepAreaRenderer1.setPlotArea(true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        int int2 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultKeyedValues0.getIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.color.ColorSpace colorSpace10 = color3.getColorSpace();
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer3D2.getLegendItemLabelGenerator();
        java.awt.Paint paint15 = barRenderer3D2.lookupSeriesOutlinePaint((-452));
        barRenderer3D2.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation2);
        java.lang.String str4 = axisLocation2.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str4.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "DatasetRenderingOrder.FORWARD", "Combined Range XYPlot");
        timeSeries3.removeAgedItems(false);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(4);
        int int10 = year9.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(4);
        int int13 = year12.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year9, regularTimePeriod15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker20.getLabelOffset();
        org.jfree.chart.util.Layer layer22 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker20, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setRangePannable(false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape13 = xYStepAreaRenderer7.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint17 = xYStepAreaRenderer7.getItemPaint(1, (int) '4', true);
        combinedRangeXYPlot3.setRangeTickBandPaint(paint17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis20.setInverted(false);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis20.setMinimumDate(date23);
        java.text.DateFormat dateFormat25 = dateAxis20.getDateFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            xYAreaRenderer1.fillRangeGridBand(graphics2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.chart.axis.ValueAxis) dateAxis20, rectangle2D26, (double) '#', (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(dateFormat25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        double double4 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        polarPlot7.setAngleGridlinesVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot7.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit11);
        java.awt.Paint paint13 = polarPlot7.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setTextAlignment(horizontalAlignment4);
        java.lang.Object obj6 = textTitle2.clone();
        textTitle2.setMargin(0.05d, (double) 10.0f, (double) 100, (double) 100L);
        boolean boolean12 = textTitle2.visible;
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType55 = dateTickUnit54.getUnitType();
        double double56 = dateTickUnit54.getSize();
        dateAxis53.setTickUnit(dateTickUnit54, false, false);
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        categoryPlot51.setRangeAxis(10, valueAxis63);
        boolean boolean65 = xYSeriesCollection43.hasListener((java.util.EventListener) categoryPlot51);
        double double66 = categoryPlot51.getAnchorValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        java.awt.geom.Point2D point2D70 = null;
        categoryPlot51.zoomRangeAxes((double) 9, 100.0d, plotRenderingInfo69, point2D70);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(dateTickUnitType55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.64E7d + "'", double56 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        boolean boolean8 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYStepAreaRenderer1.addAnnotation(xYAnnotation9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 100, paint3, false);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYAreaRenderer1.setBaseItemLabelFont(font6);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 33.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        xYSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        boolean boolean7 = textBlockAnchor0.equals((java.lang.Object) xYSeriesCollection5);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image3, "DomainOrder.NONE", "", "DomainOrder.NONE");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image11, "DomainOrder.NONE", "", "DomainOrder.NONE");
        java.lang.String str16 = projectInfo15.toString();
        java.util.List list17 = null;
        projectInfo15.setContributors(list17);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE" + "'", str16.equals("series version DomainOrder.NONE.\nDomainOrder.NONE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:series\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY series:None\nseries LICENCE TERMS:\nDomainOrder.NONE"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setNoDataMessage("hi!");
        piePlot0.clearSectionOutlineStrokes(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot0.getLabelDistributor();
        int int6 = abstractPieLabelDistributor5.getItemCount();
        abstractPieLabelDistributor5.clear();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.util.Date date4 = dateAxis3.getMinimumDate();
        try {
            combinedRangeXYPlot0.setRangeAxis((-452), (org.jfree.chart.axis.ValueAxis) dateAxis3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            categoryPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        double double3 = range2.getUpperBound();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 900000L);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range5);
        double double8 = dateRange6.constrain(0.0d);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange6, (double) (byte) 100);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
        polarPlot7.setAngleGridlinesVisible(false);
        java.awt.Font font12 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) waferMapPlot13, false);
        jFreeChart15.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart15.getLegend((int) (byte) 0);
        jFreeChart15.setTextAntiAlias(false);
        polarPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart15);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = polarPlot7.getRenderer();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.Point point26 = polarPlot7.translateValueThetaRadiusToJava2D((double) (short) 10, (double) 255, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(legendTitle18);
        org.junit.Assert.assertNull(polarItemRenderer22);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getMaximumCategoryLabelLines();
        java.lang.String str12 = categoryAxis8.getLabelURL();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) (-2208960000000L));
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        periodAxis7.setAxisLineStroke(stroke11);
        try {
            periodAxis7.zoomRange(8.64E7d, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.64E7) <= upper (9.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int3 = java.awt.Color.HSBtoRGB((float) (-2208960000000L), (float) ' ', (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-13120) + "'", int3 == (-13120));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 0, false, false);
        try {
            xYSeries3.delete(5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 11");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getMaximumCategoryLabelLines();
        categoryAxis8.setFixedDimension((double) (short) -1);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint15, stroke17, rectangleInsets18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer21.setBaseSeriesVisible(false);
        xYStepAreaRenderer21.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint26 = xYStepAreaRenderer21.getBasePaint();
        boolean boolean27 = rectangleInsets18.equals((java.lang.Object) xYStepAreaRenderer21);
        java.awt.Font font30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font30, (java.awt.Paint) color31);
        xYStepAreaRenderer21.setLegendTextFont(6, font30);
        categoryAxis8.setTickLabelFont((java.lang.Comparable) 4.0d, font30);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("series", "DomainOrder.NONE", "series", image3, "DomainOrder.NONE", "", "DomainOrder.NONE");
        projectInfo7.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Image image10 = projectInfo7.getLogo();
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("hi!");
        java.awt.Color color2 = java.awt.Color.BLUE;
        standardChartTheme1.setWallPaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        standardChartTheme1.setChartBackgroundPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = null;
        try {
            standardChartTheme1.setDomainGridlinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 0, (double) (short) 1, (double) '4');
        double double9 = xYSeriesCollection4.getIntervalPositionFactor();
        try {
            xYSeriesCollection4.setSelected(5, (int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str4 = combinedRangeXYPlot3.getPlotType();
        java.awt.Paint paint5 = combinedRangeXYPlot3.getDomainCrosshairPaint();
        combinedRangeXYPlot3.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker9.getLabelAnchor();
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean13 = combinedRangeXYPlot3.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker9, layer11, true);
        org.jfree.chart.util.Layer layer14 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker9, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Combined Range XYPlot" + "'", str4.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        numberAxis0.configure();
        double double4 = numberAxis0.getUpperMargin();
        java.awt.Font font5 = numberAxis0.getTickLabelFont();
        numberAxis0.setTickLabelsVisible(true);
        numberAxis0.setMinorTickCount((int) '4');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer11.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape17 = xYStepAreaRenderer11.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        numberAxis0.setUpArrow(shape18);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        double double3 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker6, layer7);
        java.lang.String str9 = categoryPlot0.getPlotType();
        categoryPlot0.setBackgroundAlpha(0.0f);
        int int12 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        double double12 = rectangleInsets10.calculateBottomInset((double) 10L);
        boolean boolean13 = textLine3.equals((java.lang.Object) rectangleInsets10);
        standardChartTheme1.setAxisOffset(rectangleInsets10);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint20 = null;
        xYStepAreaRenderer19.setBasePaint(paint20);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        java.awt.Paint paint23 = xYStepAreaRenderer19.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.Number number7 = timeSeriesCollection1.getY(6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        boolean boolean10 = jFreeChart7.getAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart7.addProgressListener(chartProgressListener11);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = combinedRangeXYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        int int36 = combinedRangeXYPlot14.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range38 = combinedRangeXYPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        int int47 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection43, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        xYSeriesCollection43.removeAllSeries();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState55 = xYStepAreaRenderer1.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo54);
        try {
            java.awt.Paint paint57 = combinedRangeXYPlot14.getQuadrantPaint(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYItemRendererState55);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange2((double) 1.0f, (double) (-452));
        numberAxis0.setFixedAutoRange(0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        standardChartTheme1.setLegendBackgroundPaint(paint2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        java.awt.Paint paint15 = xYStepAreaRenderer5.getItemPaint(1, (int) '4', true);
        standardChartTheme1.setCrosshairPaint(paint15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        piePlot17.setNoDataMessage("hi!");
        java.awt.Paint paint20 = null;
        piePlot17.setLabelShadowPaint(paint20);
        double double22 = piePlot17.getMinimumArcAngleToDraw();
        boolean boolean23 = piePlot17.getAutoPopulateSectionOutlineStroke();
        java.awt.Paint paint24 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        piePlot17.setShadowPaint(paint24);
        standardChartTheme1.setLegendBackgroundPaint(paint24);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-5d + "'", double22 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        double double9 = periodAxis8.getUpperMargin();
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend10 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) periodAxis8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(true);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState1.setCrosshairState(xYCrosshairState4);
        double double6 = xYCrosshairState4.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            legendTitle1.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = dateTickUnit0.getUnitType();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        int int4 = dateTickUnitType3.getCalendarField();
        java.text.DateFormat dateFormat6 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (byte) -1, dateTickUnitType3, (-459), dateFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYStepAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape24 = xYStepAreaRenderer18.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis25, "");
        xYStepAreaRenderer1.setBaseLegendShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint32 = null;
        xYStepAreaRenderer31.setBasePaint(paint32);
        java.awt.Stroke stroke35 = null;
        xYStepAreaRenderer31.setSeriesOutlineStroke((int) ' ', stroke35);
        xYStepAreaRenderer31.setAutoPopulateSeriesShape(false);
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        xYSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection(xYSeries40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection43, valueAxis44, polarItemRenderer45);
        org.jfree.data.Range range47 = xYStepAreaRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection43, true);
        legendItemEntity29.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection43);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate51 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        try {
            org.jfree.data.xy.XYSeries xYSeries53 = xYSeriesCollection43.getSeries((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("{0}: ({1}, {2})", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getLastItemIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = xYItemRendererState1.getCrosshairState();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(xYCrosshairState3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (-452));
        double double4 = rectangleInsets0.calculateLeftInset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-458.0d) + "'", double2 == (-458.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) waferMapPlot2, false);
        int int5 = jFreeChart4.getSubtitleCount();
        java.awt.Paint paint6 = jFreeChart4.getBorderPaint();
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setNoDataMessage("hi!");
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        java.awt.Paint paint15 = legendTitle14.getBackgroundPaint();
        jFreeChart12.addSubtitle((org.jfree.chart.title.Title) legendTitle14);
        java.awt.Paint paint17 = legendTitle14.getItemPaint();
        try {
            jFreeChart4.addSubtitle(1, (org.jfree.chart.title.Title) legendTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        java.awt.Stroke stroke5 = xYStepAreaRenderer1.lookupSeriesOutlineStroke((-458));
        java.awt.Shape shape6 = xYStepAreaRenderer1.getBaseLegendShape();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer1.setSeriesPaint((int) (byte) 1, paint8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        xYSeries1.add((java.lang.Number) 0.4d, (java.lang.Number) 10.0d);
        boolean boolean7 = xYSeries1.isEmpty();
        xYSeries1.add((double) (byte) -1, (java.lang.Number) 0.2d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        double double4 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer5.setBaseSeriesVisible(false);
        xYStepAreaRenderer5.setItemLabelAnchorOffset((double) 4);
        java.awt.Paint paint10 = xYStepAreaRenderer5.getBasePaint();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (-1L), (double) 0L, 0.5d, (double) (byte) 0, paint10);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Combined Range XYPlot");
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        xYSeries1.setNotify(false);
        boolean boolean6 = xYSeries1.getAllowDuplicateXValues();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        boolean boolean17 = combinedRangeXYPlot0.canSelectByRegion();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint20 = null;
        xYStepAreaRenderer19.setBasePaint(paint20);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        boolean boolean23 = combinedRangeXYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        try {
            boolean boolean6 = timeSeriesCollection1.isSelected((int) (byte) 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries3);
    }
}

