import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        boolean boolean4 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke9 = piePlot5.getBaseSectionOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYStepAreaRenderer1.getBaseItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem11 = xYStepAreaRenderer1.getLegendItem(12, 100);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertNull(legendItem11);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isRangeZoomable();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot7.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(polarItemRenderer9);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = color0.brighter();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        xYSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, valueAxis7, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleLabelsVisible();
        boolean boolean11 = polarPlot9.isDomainZoomable();
        java.awt.Stroke stroke12 = polarPlot9.getAngleGridlineStroke();
        boolean boolean13 = color0.equals((java.lang.Object) polarPlot9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState1 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState1.setDatasetIndex((-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYCrosshairState1.updateCrosshairPoint((double) 64, (double) 9, (-1), 2958465, (double) (-2208960000000L), 33.0d, plotOrientation10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation10);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat2, numberFormat3);
        numberFormat3.setMaximumFractionDigits((int) (short) 0);
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray12, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.data.general.Dataset) categoryDataset15, (java.lang.Comparable) numberTickUnit18);
        numberAxis0.setTickUnit(numberTickUnit18);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) waferMapPlot5, false);
        jFreeChart7.removeLegend();
        standardChartTheme1.apply(jFreeChart7);
        java.awt.Font font11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) waferMapPlot12, false);
        jFreeChart14.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart14.getLegend((int) (byte) 0);
        java.awt.Paint paint18 = jFreeChart14.getBorderPaint();
        standardChartTheme1.setDomainGridlinePaint(paint18);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint21 = null;
        try {
            standardChartTheme1.setThermometerPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset6, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        ringPlot9.setInnerSeparatorExtension(1.0E-5d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        boolean boolean4 = xYPlot0.isDomainZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRenderer(1);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        xYSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) (byte) 0, (double) (short) 1, (double) '4');
        org.jfree.data.Range range16 = xYStepAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.Object obj17 = xYSeriesCollection11.clone();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        xYSeriesCollection11.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType23 = org.jfree.data.RangeType.POSITIVE;
        numberAxis22.setRangeType(rangeType23);
        numberAxis22.configure();
        double double26 = numberAxis22.getUpperMargin();
        java.awt.Font font27 = numberAxis22.getTickLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) numberAxis22, polarItemRenderer28);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rangeType23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(4);
        int int5 = year4.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year4, (org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo10 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray11 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo10 };
        periodAxis9.setLabelInfo(periodAxisLabelInfoArray11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { periodAxis9, dateAxis14 };
        combinedRangeXYPlot1.setRangeAxes(valueAxisArray15);
        boolean boolean17 = combinedRangeXYPlot1.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot1.clearDomainAxes();
        int int19 = combinedRangeXYPlot1.getSeriesCount();
        java.awt.geom.GeneralPath generalPath20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str22 = combinedRangeXYPlot21.getPlotType();
        java.awt.Paint paint23 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        combinedRangeXYPlot21.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = combinedRangeXYPlot21.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker27, layer29, true);
        combinedRangeXYPlot21.zoom((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font35 = numberAxis34.getLabelFont();
        boolean boolean36 = combinedRangeXYPlot21.equals((java.lang.Object) numberAxis34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.BlockContainer blockContainer38 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockContainer38.getMargin();
        java.awt.geom.Rectangle2D rectangle2D40 = blockContainer38.getBounds();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(4);
        int int44 = year43.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(4);
        int int47 = year46.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo49 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray50 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo49 };
        periodAxis48.setLabelInfo(periodAxisLabelInfoArray50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState();
        double double54 = axisState53.getMax();
        axisState53.cursorLeft(100.0d);
        axisState53.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle60.getPosition();
        java.util.List list62 = periodAxis48.refreshTicks(graphics2D52, axisState53, rectangle2D59, rectangleEdge61);
        combinedRangeXYPlot21.drawDomainTickBands(graphics2D37, rectangle2D40, list62);
        org.jfree.chart.RenderingSource renderingSource64 = null;
        combinedRangeXYPlot1.select(generalPath20, rectangle2D40, renderingSource64);
        try {
            boolean boolean66 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray11);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Combined Range XYPlot" + "'", str22.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) '4');
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            double double7 = timeSeriesCollection1.getXValue(12, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.clearSectionOutlineStrokes(true);
        boolean boolean11 = xYSeries1.equals((java.lang.Object) piePlot5);
        org.jfree.data.xy.XYDataItem xYDataItem14 = xYSeries1.addOrUpdate(12.0d, (double) 0L);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem16 = xYSeries1.remove((java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(xYDataItem14);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) (byte) -1);
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font2 = legendTitle1.getItemFont();
        legendTitle1.setNotify(false);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj9 = barRenderer3D8.clone();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj9);
        textTitle3.setMaximumLinesToDisplay(1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis8.drawTickMarks(graphics2D11, 0.0d, rectangle2D13, rectangleEdge14, axisState15);
        categoryAxis8.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        xYSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setNoDataMessage("hi!");
        java.awt.Paint paint8 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.clearSectionOutlineStrokes(true);
        boolean boolean11 = xYSeries1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!");
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getFirstTextFragment();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke17 = piePlot16.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint15, stroke17, rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = lineBorder19.getInsets();
        double double22 = rectangleInsets20.calculateBottomInset((double) 10L);
        boolean boolean23 = textLine13.equals((java.lang.Object) rectangleInsets20);
        piePlot5.setLabelPadding(rectangleInsets20);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D27 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, (double) 12);
        boolean boolean28 = barRenderer3D27.getAutoPopulateSeriesShape();
        boolean boolean29 = rectangleInsets20.equals((java.lang.Object) barRenderer3D27);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Shape shape11 = periodAxis7.getLeftArrow();
        java.util.Locale locale12 = periodAxis7.getLocale();
        java.util.Locale locale13 = periodAxis7.getLocale();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = periodAxis7.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 4, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", false);
        java.text.NumberFormat numberFormat4 = logFormat3.getExponentFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(4);
        int int7 = year6.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo9 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray10 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo9 };
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { periodAxis8, dateAxis13 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String str17 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint18 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        xYSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection(xYSeries20);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection23, valueAxis24, polarItemRenderer25);
        boolean boolean27 = polarPlot26.isAngleLabelsVisible();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot26.setRadiusGridlineStroke(stroke28);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        combinedRangeXYPlot0.panRangeAxes((double) (-2208927600001L), plotRenderingInfo33, point2D34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = combinedRangeXYPlot0.getRangeMarkers(layer36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined Range XYPlot" + "'", str17.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.POSITIVE;
        numberAxis0.setRangeType(rangeType1);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray7, doubleArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) (-452));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3, (org.jfree.data.general.Dataset) categoryDataset10, (java.lang.Comparable) numberTickUnit13);
        numberAxis0.setTickUnit(numberTickUnit13);
        boolean boolean17 = numberTickUnit13.equals((java.lang.Object) "{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        double double3 = blockParams0.getTranslateX();
        double double4 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Paint paint12 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint13 = categoryPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint14 = categoryPlot0.getRangeMinorGridlinePaint();
        double double15 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        dateAxis1.setInverted(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date4);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        dateAxis1.setLabelInsets(rectangleInsets7, true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer11.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape17 = xYStepAreaRenderer11.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape17, (org.jfree.chart.axis.Axis) categoryAxis18, "");
        categoryAxis18.configure();
        boolean boolean22 = categoryAxis18.isVisible();
        org.jfree.data.xy.XYSeries xYSeries24 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        xYSeries24.removeChangeListener(seriesChangeListener25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection(xYSeries24);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        piePlot28.setNoDataMessage("hi!");
        java.awt.Paint paint31 = piePlot28.getBaseSectionOutlinePaint();
        piePlot28.clearSectionOutlineStrokes(true);
        boolean boolean34 = xYSeries24.equals((java.lang.Object) piePlot28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType36 = dateTickUnit35.getUnitType();
        java.awt.Paint paint37 = piePlot28.getSectionOutlinePaint((java.lang.Comparable) dateTickUnit35);
        categoryAxis18.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit35);
        dateAxis1.setTickUnit(dateTickUnit35, true, true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(dateTickUnitType36);
        org.junit.Assert.assertNull(paint37);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 900000L, (double) 'a');
        java.lang.Object obj3 = barRenderer3D2.clone();
        java.awt.Paint paint4 = barRenderer3D2.getWallPaint();
        java.lang.Object obj5 = barRenderer3D2.clone();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray9, doubleArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Combined Range XYPlot", doubleArray11);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.data.Range range16 = barRenderer3D2.findRangeBounds(categoryDataset12, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        int int3 = year2.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(4);
        int int6 = year5.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo8 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray9 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo8 };
        periodAxis7.setLabelInfo(periodAxisLabelInfoArray9);
        java.awt.Shape shape11 = periodAxis7.getLeftArrow();
        java.lang.Class class12 = periodAxis7.getAutoRangeTimePeriodClass();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(4);
        int int18 = year17.getYear();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(4);
        int int21 = year20.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo23 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo23 };
        periodAxis22.setLabelInfo(periodAxisLabelInfoArray24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { periodAxis22, dateAxis27 };
        combinedRangeXYPlot14.setRangeAxes(valueAxisArray28);
        boolean boolean30 = combinedRangeXYPlot14.isRangeMinorGridlinesVisible();
        boolean boolean31 = combinedRangeXYPlot14.canSelectByRegion();
        boolean boolean32 = combinedRangeXYPlot14.isRangePannable();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockContainer34.getMargin();
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer34.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot37.getFixedLegendItems();
        double double40 = categoryPlot37.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot37.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker43, layer44);
        java.util.List list46 = categoryPlot37.getAnnotations();
        java.util.Collection collection47 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list46);
        combinedRangeXYPlot14.drawRangeTickBands(graphics2D33, rectangle2D36, list46);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity49 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D36);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(4);
        int int53 = year52.getYear();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(4);
        int int56 = year55.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year52, (org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo58 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray59 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo58 };
        periodAxis57.setLabelInfo(periodAxisLabelInfoArray59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.AxisState axisState62 = new org.jfree.chart.axis.AxisState();
        double double63 = axisState62.getMax();
        axisState62.cursorLeft(100.0d);
        axisState62.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = textTitle69.getPosition();
        java.util.List list71 = periodAxis57.refreshTicks(graphics2D61, axisState62, rectangle2D68, rectangleEdge70);
        double double72 = periodAxis7.valueToJava2D((double) (-1), rectangle2D36, rectangleEdge70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray59);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean10 = combinedRangeXYPlot0.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker6, layer8, true);
        combinedRangeXYPlot0.zoom((double) 10L);
        boolean boolean13 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            combinedRangeXYPlot0.handleClick((int) (short) 0, 11, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.calculateRightInset(0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        xYStepAreaRenderer1.setPlotArea(true);
        boolean boolean10 = xYStepAreaRenderer1.isSeriesVisibleInLegend((int) ' ');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer12.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer17.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYStepAreaRenderer12.setSeriesPositiveItemLabelPosition(0, itemLabelPosition19);
        xYStepAreaRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition19, false);
        xYStepAreaRenderer1.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType3 = org.jfree.data.RangeType.POSITIVE;
        numberAxis2.setRangeType(rangeType3);
        numberAxis2.configure();
        double double6 = numberAxis2.getUpperMargin();
        java.awt.Font font7 = numberAxis2.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Combined Range XYPlot", font7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", font12, (java.awt.Paint) color13);
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) 4, (java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        try {
            org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("JFreeChartEntity: tooltip = Category Plot", font7, (java.awt.Paint) color13, (float) 100, 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot1.getFixedLegendItems();
        categoryPlot1.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot1.setDomainAxisLocation(axisLocation6);
        boolean boolean8 = polarPlot0.equals((java.lang.Object) axisLocation6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot0.zoomDomainAxes((double) 5, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        int int3 = dateAxis1.getMinorTickCount();
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit3.getUnitType();
        double double5 = dateTickUnit3.getSize();
        dateAxis2.setTickUnit(dateTickUnit3, false, false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = valueMarker16.getLabelOffset();
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer18);
        java.awt.Paint paint20 = valueMarker16.getOutlinePaint();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.64E7d + "'", double5 == 8.64E7d);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(4);
        int int5 = year4.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year4, (org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo10 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray11 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo10 };
        periodAxis9.setLabelInfo(periodAxisLabelInfoArray11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { periodAxis9, dateAxis14 };
        combinedRangeXYPlot1.setRangeAxes(valueAxisArray15);
        boolean boolean17 = combinedRangeXYPlot1.isRangeMinorGridlinesVisible();
        boolean boolean18 = combinedRangeXYPlot1.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 10);
        boolean boolean24 = xYAreaRenderer23.isOutline();
        int int25 = combinedRangeXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer23);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray11);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.awt.Paint paint2 = null;
        xYStepAreaRenderer1.setBasePaint(paint2);
        java.awt.Stroke stroke5 = null;
        xYStepAreaRenderer1.setSeriesOutlineStroke((int) ' ', stroke5);
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYStepAreaRenderer1.setSeriesPaint(4, paint8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = standardChartTheme12.getDrawingSupplier();
        java.awt.Font font15 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) waferMapPlot16, false);
        jFreeChart18.removeLegend();
        standardChartTheme12.apply(jFreeChart18);
        java.awt.Paint paint21 = standardChartTheme12.getItemLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint23 = numberAxis22.getLabelPaint();
        standardChartTheme12.setPlotOutlinePaint(paint23);
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { paint8, paint10, paint23 };
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint27 = numberAxis26.getLabelPaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { paint27, paint28 };
        java.awt.Stroke[] strokeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray25, paintArray29, strokeArray30, strokeArray31, shapeArray32);
        java.awt.Stroke stroke34 = defaultDrawingSupplier33.getNextOutlineStroke();
        java.awt.Paint paint35 = defaultDrawingSupplier33.getNextPaint();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        java.util.List list4 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        valueMarker7.notifyListeners(markerChangeEvent8);
        org.jfree.chart.util.Layer layer10 = null;
        combinedRangeXYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker7, layer10, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 4, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", false);
        int int4 = logFormat3.getMaximumFractionDigits();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getLastItemIndex();
        org.jfree.chart.entity.EntityCollection entityCollection3 = xYItemRendererState1.getEntityCollection();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(4);
        int int4 = year3.getYear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape13 = xYStepAreaRenderer7.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity16 = new org.jfree.chart.entity.AxisEntity(shape13, (org.jfree.chart.axis.Axis) categoryAxis14, "");
        int int17 = categoryAxis14.getCategoryLabelPositionOffset();
        java.awt.Font font18 = categoryAxis14.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font18);
        int int20 = year3.compareTo((java.lang.Object) "{0}: ({1}, {2})");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (byte) -1);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone23);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(4);
        int int28 = year27.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(4);
        int int31 = year30.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo33 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray34 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo33 };
        periodAxis32.setLabelInfo(periodAxisLabelInfoArray34);
        java.awt.Stroke stroke36 = periodAxis32.getTickMarkStroke();
        periodAxis32.setMinorTickMarksVisible(true);
        java.util.Locale locale39 = periodAxis32.getLocale();
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("AxisLocation.BOTTOM_OR_RIGHT", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year22, timeZone23, locale39);
        try {
            org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(9999, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(locale39);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape7 = xYStepAreaRenderer1.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis8, "");
        int int11 = categoryAxis8.getMaximumCategoryLabelLines();
        categoryAxis8.setFixedDimension((double) (short) -1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str16 = combinedRangeXYPlot15.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace17 = combinedRangeXYPlot15.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedRangeXYPlot15.getAxisOffset();
        java.util.List list19 = combinedRangeXYPlot15.getAnnotations();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(4);
        int int24 = year23.getYear();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(4);
        int int27 = year26.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo29 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray30 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo29 };
        periodAxis28.setLabelInfo(periodAxisLabelInfoArray30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { periodAxis28, dateAxis33 };
        combinedRangeXYPlot20.setRangeAxes(valueAxisArray34);
        boolean boolean36 = combinedRangeXYPlot20.isRangeMinorGridlinesVisible();
        combinedRangeXYPlot20.clearDomainAxes();
        int int38 = combinedRangeXYPlot20.getSeriesCount();
        java.awt.geom.GeneralPath generalPath39 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str41 = combinedRangeXYPlot40.getPlotType();
        java.awt.Paint paint42 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        combinedRangeXYPlot40.clearDomainMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = valueMarker46.getLabelAnchor();
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean50 = combinedRangeXYPlot40.removeRangeMarker(2958465, (org.jfree.chart.plot.Marker) valueMarker46, layer48, true);
        combinedRangeXYPlot40.zoom((double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font54 = numberAxis53.getLabelFont();
        boolean boolean55 = combinedRangeXYPlot40.equals((java.lang.Object) numberAxis53);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.block.BlockContainer blockContainer57 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = blockContainer57.getMargin();
        java.awt.geom.Rectangle2D rectangle2D59 = blockContainer57.getBounds();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(4);
        int int63 = year62.getYear();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(4);
        int int66 = year65.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis67 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year62, (org.jfree.data.time.RegularTimePeriod) year65);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo68 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray69 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo68 };
        periodAxis67.setLabelInfo(periodAxisLabelInfoArray69);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.axis.AxisState axisState72 = new org.jfree.chart.axis.AxisState();
        double double73 = axisState72.getMax();
        axisState72.cursorLeft(100.0d);
        axisState72.setMax((double) (-452));
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = textTitle79.getPosition();
        java.util.List list81 = periodAxis67.refreshTicks(graphics2D71, axisState72, rectangle2D78, rectangleEdge80);
        combinedRangeXYPlot40.drawDomainTickBands(graphics2D56, rectangle2D59, list81);
        org.jfree.chart.RenderingSource renderingSource83 = null;
        combinedRangeXYPlot20.select(generalPath39, rectangle2D59, renderingSource83);
        org.jfree.chart.title.TextTitle textTitle85 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = textTitle85.getPosition();
        boolean boolean87 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge86);
        try {
            double double88 = categoryAxis8.getCategoryMiddle((java.lang.Comparable) 5, list19, rectangle2D59, rectangleEdge86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Combined Range XYPlot" + "'", str16.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray30);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Combined Range XYPlot" + "'", str41.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray69);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot11.getFixedLegendItems();
        double double14 = categoryPlot11.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot11.removeDomainMarker((-458), (org.jfree.chart.plot.Marker) valueMarker17, layer18);
        java.util.List list20 = categoryPlot11.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes(100, list20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
        int int2 = year1.getYear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer5.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Shape shape11 = xYStepAreaRenderer5.getItemShape((int) ' ', (int) (byte) 1, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis12, "");
        int int15 = categoryAxis12.getCategoryLabelPositionOffset();
        java.awt.Font font16 = categoryAxis12.getTickLabelFont();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font16);
        int int18 = year1.compareTo((java.lang.Object) "{0}: ({1}, {2})");
        long long19 = year1.getFirstMillisecond();
        java.lang.String str20 = year1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62041132800000L) + "'", long19 == (-62041132800000L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4" + "'", str20.equals("4"));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.lang.Object obj1 = xYBarRenderer0.clone();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        xYStepAreaRenderer3.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer3.getBasePositiveItemLabelPosition();
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = xYBarRenderer0.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        boolean boolean10 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str2 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot1.getDomainAxisLocation((-458));
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(4);
        int int8 = year7.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(4);
        int int11 = year10.getYear();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo13 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo13 };
        periodAxis12.setLabelInfo(periodAxisLabelInfoArray14);
        java.awt.Stroke stroke16 = periodAxis12.getTickMarkStroke();
        combinedRangeXYPlot1.setDomainGridlineStroke(stroke16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke16, rectangleInsets18);
        java.awt.Color color20 = java.awt.Color.BLACK;
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke24 = null;
        piePlot23.setOutlineStroke(stroke24);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        piePlot26.setNoDataMessage("hi!");
        java.awt.Paint paint29 = piePlot26.getBaseSectionOutlinePaint();
        piePlot23.setBaseSectionOutlinePaint(paint29);
        standardChartTheme22.setRangeGridlinePaint(paint29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme22.setErrorIndicatorPaint((java.awt.Paint) color32);
        float[] floatArray40 = new float[] { 900000L, 9, (byte) 1, '#', (-1), 0 };
        float[] floatArray41 = color32.getColorComponents(floatArray40);
        float[] floatArray42 = color20.getRGBColorComponents(floatArray40);
        float[] floatArray43 = color0.getRGBColorComponents(floatArray40);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined Range XYPlot" + "'", str2.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }
}

