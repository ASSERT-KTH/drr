import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setWeight(3);
        xYPlot4.setDomainGridlinesVisible(true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str3 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2-January-1900" + "'", str3.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        numberAxis3D0.setAutoRangeStickyZero(false);
        numberAxis3D0.setAutoRangeStickyZero(false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        java.awt.Color color2 = java.awt.Color.GREEN;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color2);
        java.awt.Color color4 = color2.brighter();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer1 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean3 = boxAndWhiskerRenderer1.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer1.setBaseItemLabelFont(font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color7 = java.awt.Color.lightGray;
        boolean boolean8 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color6, (java.awt.Paint) color7);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font4, (java.awt.Paint) color7);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine();
        boolean boolean11 = textFragment9.equals((java.lang.Object) textLine10);
        java.awt.Font font12 = textFragment9.getFont();
        java.awt.Font font13 = textFragment9.getFont();
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textFragment9.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        waterfallBarRenderer15.setNegativeBarPaint((java.awt.Paint) color16);
        lineAndShapeRenderer2.setSeriesPaint(2, (java.awt.Paint) color16);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color16.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext24);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Comparable comparable8 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) 5, comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font2 = waterfallBarRenderer1.getBaseItemLabelFont();
        double double3 = waterfallBarRenderer1.getUpperClip();
        java.awt.Paint paint4 = waterfallBarRenderer1.getLastBarPaint();
        java.awt.Stroke stroke5 = waterfallBarRenderer1.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        waterfallBarRenderer1.setLegendItemURLGenerator(categorySeriesLabelGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        waterfallBarRenderer1.setLastBarPaint(paint8);
        boolean boolean10 = chartChangeEventType0.equals((java.lang.Object) waterfallBarRenderer1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "Range[0.0,0.0]", "{0}");
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection5, jFreeChart6, chartChangeEventType7);
        boolean boolean9 = chartEntity4.equals((java.lang.Object) chartChangeEventType7);
        java.lang.String str10 = chartEntity4.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = Range[0.0,0.0]" + "'", str10.equals("ChartEntity: tooltip = Range[0.0,0.0]"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        java.util.List list4 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (int) (byte) 100);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat12);
        int int14 = dateTickUnit13.getRollCount();
        java.lang.String str16 = dateTickUnit13.valueToString(100.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.util.Date date18 = month17.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        java.lang.String str20 = dateTickUnit13.dateToString(date18);
        java.lang.Number number21 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((java.lang.Comparable) "CONTRACT", (java.lang.Comparable) str20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12/31/69" + "'", str16.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6/1/19" + "'", str20.equals("6/1/19"));
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.util.List list9 = blockContainer8.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, (java.lang.Number) (byte) 0, (java.lang.Number) 5, (java.lang.Number) (short) 1, (java.lang.Number) 5, (java.lang.Number) 11, (java.lang.Number) Double.NaN, (java.lang.Number) 8.0d, list9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = lineAndShapeRenderer13.getLegendItems();
        java.lang.Boolean boolean16 = lineAndShapeRenderer13.getSeriesLinesVisible(2);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer13.setSeriesOutlineStroke(10, stroke18, false);
        lineAndShapeRenderer13.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        lineAndShapeRenderer13.setBaseToolTipGenerator(categoryToolTipGenerator23, false);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        lineAndShapeRenderer13.setBaseShape(shape27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape30, (double) 620L, 0.0d);
        lineAndShapeRenderer13.setBaseShape(shape33);
        boolean boolean35 = boxAndWhiskerItem10.equals((java.lang.Object) shape33);
        java.lang.Number number36 = boxAndWhiskerItem10.getMinOutlier();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) number36, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        java.lang.Object obj57 = null;
        try {
            jFreeChart17.setTextAntiAlias(obj57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Oct");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) 1);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions3);
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) '4');
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        double double4 = intervalMarker2.getEndValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setPieIndex(0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getLegendLabelURLGenerator();
        java.lang.Object obj5 = piePlot1.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextBlockAnchor.BOTTOM_CENTER", (org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint4 = waterfallBarRenderer2.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock8.draw(graphics2D9, (float) 8, (float) 10, textBlockAnchor12, (float) 8, (float) 0L, (double) 0L);
        org.jfree.chart.text.TextLine textLine17 = textBlock8.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint25 = waterfallBarRenderer23.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer28 = new org.jfree.chart.text.G2TextMeasurer(graphics2D27);
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint25, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock29.draw(graphics2D30, (float) 8, (float) 10, textBlockAnchor33, (float) 8, (float) 0L, (double) 0L);
        textBlock8.draw(graphics2D18, (float) (short) 100, (float) (byte) 0, textBlockAnchor33);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.clearDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str46 = serialDate45.toString();
        java.awt.Paint paint47 = piePlot0.getSectionPaint((java.lang.Comparable) serialDate45);
        piePlot0.setShadowYOffset((double) (-1.0f));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertNull(paint47);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month9);
        java.lang.Number number11 = null;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        defaultKeyedValues2D1.setValue(number11, (java.lang.Comparable) 10.0f, (java.lang.Comparable) month13);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        try {
            java.lang.Comparable comparable5 = defaultBoxAndWhiskerCategoryDataset0.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getFixedLegendItems();
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer2.setBase((double) '4');
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        waterfallBarRenderer2.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        waterfallBarRenderer2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        java.awt.Font font15 = waterfallBarRenderer2.getItemLabelFont(2, (int) 'a');
        java.awt.Color color16 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("WMAP_Plot", font15, (java.awt.Paint) color16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("WMAP_Plot", font15, paint18);
        java.awt.Paint paint20 = null;
        try {
            labelBlock19.setPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        org.jfree.data.Range range3 = numberAxis3D0.getDefaultAutoRange();
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        boolean boolean4 = numberAxis3D0.isAxisLineVisible();
        numberAxis3D0.setRangeWithMargins(0.0d, (double) 86400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        piePlot0.setBackgroundImageAlpha((float) 1);
        double double45 = piePlot0.getLabelGap();
        piePlot0.setLabelGap((double) '#');
        java.awt.Paint paint48 = piePlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setRenderAsPercentages(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment5, (double) 7, (double) (-2208927599900L));
        columnArrangement8.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator13, false);
        boolean boolean18 = stackedAreaRenderer11.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        stackedAreaRenderer11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator20, false);
        stackedAreaRenderer11.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer11, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26, (java.lang.Comparable) false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(7, (int) (short) 0);
        java.lang.Number number35 = defaultBoxAndWhiskerCategoryDataset26.getMinRegularValue((java.lang.Comparable) (byte) 0, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range36 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        stackedBarRenderer0.setRenderAsPercentages(true);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(100.0d);
        axisState0.cursorUp((double) 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        try {
            boxAndWhiskerRenderer0.setSeriesVisibleInLegend((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator3 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj4 = standardCategoryToolTipGenerator3.clone();
        stackedBarRenderer3D1.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.25d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "hi!", "Range[0.0,0.0]", "ChartChangeEventType.GENERAL", shape4, paint5);
        java.awt.Paint paint7 = legendItem6.getFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        double double40 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset38);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Stroke stroke10 = xYPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot4.getOrientation();
        org.jfree.chart.plot.Plot plot12 = xYPlot4.getParent();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateTopInset(100.0d);
        double double8 = rectangleInsets5.getTop();
        numberAxis3D0.setLabelInsets(rectangleInsets5);
        double double10 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint16 = stackedAreaRenderer1.getItemPaint(12, (int) '#');
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (java.lang.Comparable) (-2208927599900L));
        double double22 = defaultBoxAndWhiskerCategoryDataset17.getRangeUpperBound(false);
        org.jfree.data.Range range23 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer();
        java.util.List list33 = blockContainer32.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem34 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, (java.lang.Number) (byte) 0, (java.lang.Number) 5, (java.lang.Number) (short) 1, (java.lang.Number) 5, (java.lang.Number) 11, (java.lang.Number) Double.NaN, (java.lang.Number) 8.0d, list33);
        java.lang.Number number35 = boxAndWhiskerItem34.getMaxOutlier();
        defaultBoxAndWhiskerCategoryDataset17.add(boxAndWhiskerItem34, (java.lang.Comparable) 5, (java.lang.Comparable) 12);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 8.0d + "'", number35.equals(8.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj3 = objectList1.get(12);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(3);
        objectList1.set((int) (byte) 10, (java.lang.Object) serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate6);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle0.setPaint(paint5);
        double double7 = textTitle0.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer67 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = null;
        stackedAreaRenderer67.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator69, false);
        boolean boolean74 = stackedAreaRenderer67.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator76 = null;
        stackedAreaRenderer67.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator76, false);
        stackedAreaRenderer67.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset82 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset82);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent84 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer67, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset82);
        java.util.List list85 = defaultBoxAndWhiskerCategoryDataset82.getRowKeys();
        jFreeChart17.setSubtitles(list85);
        java.awt.Graphics2D graphics2D87 = null;
        java.awt.geom.Rectangle2D rectangle2D88 = null;
        java.awt.geom.Point2D point2D89 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo90 = null;
        try {
            jFreeChart17.draw(graphics2D87, rectangle2D88, point2D89, chartRenderingInfo90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(range83);
        org.junit.Assert.assertNotNull(list85);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        jFreeChart17.setTitle("");
        java.awt.Stroke stroke59 = jFreeChart17.getBorderStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        waterfallBarRenderer15.setNegativeBarPaint((java.awt.Paint) color16);
        lineAndShapeRenderer2.setSeriesPaint(2, (java.awt.Paint) color16);
        boolean boolean19 = lineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, 0);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge5);
        textTitle0.setPosition(rectangleEdge5);
        java.lang.Object obj8 = null;
        boolean boolean9 = rectangleEdge5.equals(obj8);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D21.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list25 = defaultKeyedValues2D21.getRowKeys();
        boolean boolean26 = defaultBoxAndWhiskerCategoryDataset16.equals((java.lang.Object) list25);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer67 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = null;
        stackedAreaRenderer67.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator69, false);
        boolean boolean74 = stackedAreaRenderer67.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator76 = null;
        stackedAreaRenderer67.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator76, false);
        stackedAreaRenderer67.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset82 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset82);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent84 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer67, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset82);
        java.util.List list85 = defaultBoxAndWhiskerCategoryDataset82.getRowKeys();
        jFreeChart17.setSubtitles(list85);
        java.awt.RenderingHints renderingHints87 = jFreeChart17.getRenderingHints();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(range83);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertNotNull(renderingHints87);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelPositions0.equals(obj1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean12 = boxAndWhiskerRenderer10.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 86400000L, (double) 1, Double.NaN, (double) 2, font13);
        double double16 = numberAxis3D0.getFixedAutoRange();
        numberAxis3D0.setLowerMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        taskSeries1.addChangeListener(seriesChangeListener4);
        int int6 = taskSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        org.jfree.chart.text.TextLine textLine8 = null;
        textBlock5.addLine(textLine8);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth(0);
        org.jfree.chart.LegendItem legendItem5 = layeredBarRenderer0.getLegendItem((int) (byte) 10, (int) '4');
        double double7 = layeredBarRenderer0.getSeriesBarWidth(9999);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = layeredBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp((double) 620L);
        axisState0.cursorUp((double) 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        waterfallBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false);
        waterfallBarRenderer0.setItemLabelAnchorOffset(0.0d);
        waterfallBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer11.setItemMargin((double) 10L);
        java.awt.Stroke stroke15 = waterfallBarRenderer11.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer11.setAutoPopulateSeriesPaint(true);
        java.awt.Shape shape20 = waterfallBarRenderer11.getItemShape(1, 12);
        java.awt.Color color22 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer26 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean28 = boxAndWhiskerRenderer26.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer26.setBaseItemLabelFont(font29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color32 = java.awt.Color.lightGray;
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color31, (java.awt.Paint) color32);
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font29, (java.awt.Paint) color32);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer35 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer35.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer38 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer38.setItemMargin((double) 10L);
        java.awt.Stroke stroke42 = waterfallBarRenderer38.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer35.setBaseStroke(stroke42);
        java.awt.Color color44 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer45.setItemMargin((double) 10L);
        java.awt.Stroke stroke49 = waterfallBarRenderer45.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color32, stroke42, (java.awt.Paint) color44, stroke49, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke49);
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("{0}", "WMAP_Plot", "", "ChartChangeEventType.GENERAL", shape20, (java.awt.Paint) color22);
        boolean boolean54 = defaultKeyedValues2D1.equals((java.lang.Object) "WMAP_Plot");
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator13, false);
        boolean boolean18 = stackedAreaRenderer11.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        stackedAreaRenderer11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator20, false);
        stackedAreaRenderer11.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer11, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26);
        xYPlot4.datasetChanged(datasetChangeEvent28);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            boolean boolean31 = xYPlot4.removeAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Color color3 = java.awt.Color.lightGray;
        stackedAreaRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color3, true);
        java.lang.Class<?> wildcardClass6 = stackedAreaRenderer1.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = waterfallBarRenderer0.getURLGenerator(0, 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color1 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean7 = boxAndWhiskerRenderer5.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer5.setBaseItemLabelFont(font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color11 = java.awt.Color.lightGray;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color10, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font8, (java.awt.Paint) color11);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer14.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer17.setItemMargin((double) 10L);
        java.awt.Stroke stroke21 = waterfallBarRenderer17.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer14.setBaseStroke(stroke21);
        java.awt.Color color23 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer24.setItemMargin((double) 10L);
        java.awt.Stroke stroke28 = waterfallBarRenderer24.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color11, stroke21, (java.awt.Paint) color23, stroke28, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        valueMarker31.setPaint(paint32);
        org.jfree.chart.text.TextAnchor textAnchor34 = valueMarker31.getLabelTextAnchor();
        double double35 = valueMarker31.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.lang.Object obj2 = stackedAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj1 = standardCategoryToolTipGenerator0.clone();
        java.lang.String str2 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Color color3 = java.awt.Color.GREEN;
        boxAndWhiskerRenderer0.setArtifactPaint((java.awt.Paint) color3);
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, 0.2d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (java.lang.Comparable) (-2208927599900L));
        double double9 = defaultBoxAndWhiskerCategoryDataset4.getRangeUpperBound(false);
        java.util.List list12 = defaultBoxAndWhiskerCategoryDataset4.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap13 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, keyToGroupMap13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint2.toRangeWidth(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getSeriesIndex();
        boolean boolean17 = legendItem15.isLineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str46 = serialDate45.toString();
        java.awt.Paint paint47 = piePlot0.getSectionPaint((java.lang.Comparable) serialDate45);
        java.awt.Stroke stroke49 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "Default Group");
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(stroke49);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "ThreadContext", "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator5 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator6 = null;
        try {
            java.lang.String str7 = chartEntity4.getImageMapAreaTag(toolTipTagFragmentGenerator5, uRLTagFragmentGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer12 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean14 = boxAndWhiskerRenderer12.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer12.setBaseItemLabelFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color18 = java.awt.Color.lightGray;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color17, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font15, (java.awt.Paint) color18);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer21 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer21.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer24.setItemMargin((double) 10L);
        java.awt.Stroke stroke28 = waterfallBarRenderer24.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer21.setBaseStroke(stroke28);
        java.awt.Color color30 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer31 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer31.setItemMargin((double) 10L);
        java.awt.Stroke stroke35 = waterfallBarRenderer31.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color18, stroke28, (java.awt.Paint) color30, stroke35, (float) (byte) 1);
        java.awt.Stroke stroke38 = intervalMarker37.getStroke();
        xYPlot4.setDomainGridlineStroke(stroke38);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        try {
            java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset16.getMaxRegularValue((int) '#', (-620));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        java.awt.Paint paint43 = piePlot0.getLabelShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator44 = piePlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(pieSectionLabelGenerator44);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        double double29 = intervalMarker28.getStartValue();
        intervalMarker28.setLabel("AreaRendererEndType.TRUNCATE");
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getColumnKey(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextBlockAnchor.BOTTOM_CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextBlockAnchor.BOTTOM_CENTER, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        java.awt.Paint paint8 = xYPlot4.getRangeTickBandPaint();
        int int9 = xYPlot4.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot3.getOrientation();
        java.lang.Object obj8 = null;
        boolean boolean9 = plotOrientation7.equals(obj8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer21.getLegendItems();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer21.setBaseItemLabelPaint((java.awt.Paint) color23);
        stackedAreaRenderer1.setBaseFillPaint((java.awt.Paint) color23, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        stackedAreaRenderer29.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator31, false);
        boolean boolean36 = stackedAreaRenderer29.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = null;
        stackedAreaRenderer29.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator38, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = stackedAreaRenderer29.getLegendItemLabelGenerator();
        java.awt.Paint paint44 = stackedAreaRenderer29.getItemPaint(12, (int) '#');
        stackedAreaRenderer1.setSeriesOutlinePaint(3, paint44, true);
        boolean boolean47 = stackedAreaRenderer1.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator29 = piePlot0.getURLGenerator();
        java.lang.String str30 = piePlot0.getPlotType();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(pieURLGenerator29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Pie Plot" + "'", str30.equals("Pie Plot"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.Object obj1 = null;
        boolean boolean2 = dateTickMarkPosition0.equals(obj1);
        java.lang.String str3 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickMarkPosition.END" + "'", str3.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        float[] floatArray22 = new float[] { 5, '#', 1, 100.0f, 2019L, 0.0f };
        float[] floatArray23 = color14.getColorComponents(floatArray22);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boxAndWhiskerRenderer0.setBaseItemLabelsVisible(true, true);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.awt.Color color12 = java.awt.Color.pink;
        polarPlot11.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = polarPlot11.getAngleGridlineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color15);
        polarPlot11.removeCornerTextItem("Oct");
        boolean boolean19 = boxAndWhiskerRenderer0.equals((java.lang.Object) "Oct");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup21 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset20.setGroup(datasetGroup21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        polarPlot27.setNoDataMessage("");
        boolean boolean31 = polarPlot27.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = polarPlot27.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset20.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot27);
        boxAndWhiskerRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot27);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals((double) number23, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(Double.NaN, 1.0E-8d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getLegendItems();
        boolean boolean6 = xYPlot4.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle57.getPosition();
        java.awt.Paint paint62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle57.setPaint(paint62);
        jFreeChart17.removeSubtitle((org.jfree.chart.title.Title) textTitle57);
        org.jfree.chart.title.TextTitle textTitle65 = jFreeChart17.getTitle();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(textTitle65);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            waferMapPlot1.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11, false);
        boolean boolean16 = stackedAreaRenderer9.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer9.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        stackedAreaRenderer9.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer9, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = lineAndShapeRenderer29.getLegendItems();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer29.setBaseItemLabelPaint((java.awt.Paint) color31);
        stackedAreaRenderer9.setBaseFillPaint((java.awt.Paint) color31, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer37.getLegendItemLabelGenerator();
        java.awt.Paint paint52 = stackedAreaRenderer37.getItemPaint(12, (int) '#');
        stackedAreaRenderer9.setSeriesOutlinePaint(3, paint52, true);
        java.awt.Stroke stroke56 = stackedAreaRenderer9.lookupSeriesOutlineStroke((int) '#');
        xYPlot4.setRangeGridlineStroke(stroke56);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot4.getDomainAxisEdge(0);
        java.lang.Object obj60 = xYPlot4.clone();
        xYPlot4.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(obj60);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Paint paint7 = xYPlot4.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset(xYDataset8);
        xYPlot4.setRangeCrosshairValue(8.0d, true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj10 = categoryAxis3D9.clone();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setPositiveArrowVisible(false);
        double double14 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment17, (double) 7, (double) (-2208927599900L));
        columnArrangement20.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        stackedAreaRenderer23.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator25, false);
        boolean boolean30 = stackedAreaRenderer23.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
        stackedAreaRenderer23.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator32, false);
        stackedAreaRenderer23.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset38 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer23, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset38);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement20, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset38, (java.lang.Comparable) false);
        try {
            waterfallBarRenderer0.drawItem(graphics2D3, categoryItemRendererState5, rectangle2D6, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset38, (int) ' ', (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Stroke stroke10 = xYPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot4.getOrientation();
        int int12 = xYPlot4.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        polarPlot7.setNoDataMessage("");
        boolean boolean11 = polarPlot7.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot7.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int15 = defaultBoxAndWhiskerCategoryDataset0.getColumnCount();
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Stroke stroke10 = xYPlot4.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        xYPlot16.setDomainCrosshairValue(1.0d);
        boolean boolean19 = xYPlot16.isDomainCrosshairVisible();
        float float20 = xYPlot16.getBackgroundAlpha();
        boolean boolean21 = xYPlot16.isRangeCrosshairLockedOnData();
        java.lang.String str22 = xYPlot16.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot16.getDomainAxisLocation();
        try {
            xYPlot4.setRangeAxisLocation((-1), axisLocation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        columnArrangement5.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator10, false);
        boolean boolean15 = stackedAreaRenderer8.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedAreaRenderer8.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator17, false);
        stackedAreaRenderer8.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23, (java.lang.Comparable) false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        try {
            java.lang.Object obj31 = legendItemBlockContainer27.draw(graphics2D28, rectangle2D29, (java.lang.Object) categoryLabelPositions30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(categoryLabelPositions30);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = null;
        try {
            xYPlot4.setDomainAxes(valueAxisArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setWeight(3);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot4.getRangeAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("2-January-1900");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer3.getLegendItems();
        boolean boolean5 = categoryLabelWidthType0.equals((java.lang.Object) legendItemCollection4);
        java.lang.String str6 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str6.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getLegendItems();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot4.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        boolean boolean10 = xYPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 100.0f, (double) '#');
        java.lang.String str3 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=100.0, height=35.0]" + "'", str3.equals("Size2D[width=100.0, height=35.0]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.lang.Object obj17 = legendItemEntity16.clone();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator21, false);
        stackedAreaRenderer19.setBaseItemLabelsVisible(false, false);
        java.awt.Color color27 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean30 = blockBorder28.equals((java.lang.Object) shape29);
        stackedAreaRenderer19.setBaseShape(shape29);
        legendItemEntity16.setArea(shape29);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        double double29 = intervalMarker28.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType30, jFreeChart31);
        intervalMarker28.setLabelOffsetType(lengthAdjustmentType30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker28.notifyListeners(markerChangeEvent34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.LegendItemCollection legendItemCollection37 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection37, jFreeChart38, chartChangeEventType39);
        boolean boolean41 = lengthAdjustmentType36.equals((java.lang.Object) chartChangeEvent40);
        intervalMarker28.setLabelOffsetType(lengthAdjustmentType36);
        java.awt.Paint paint43 = intervalMarker28.getLabelPaint();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(chartChangeEventType39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.awt.Color color12 = java.awt.Color.pink;
        polarPlot11.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = polarPlot11.getRadiusGridlineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape6, (java.awt.Paint) color7, stroke14, (java.awt.Paint) color15);
        java.text.AttributedString attributedString17 = legendItem16.getAttributedLabel();
        boolean boolean18 = legendItem16.isShapeVisible();
        java.text.AttributedString attributedString19 = legendItem16.getAttributedLabel();
        java.awt.Paint paint20 = legendItem16.getFillPaint();
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint(paint20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(attributedString17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(attributedString19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        java.awt.Stroke stroke29 = piePlot0.getLabelLinkStroke();
        float float30 = piePlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock5.calculateDimensions(graphics2D8);
        size2D9.setHeight((double) (-620));
        size2D9.setWidth((double) 24234L);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator15 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
        boolean boolean16 = size2D9.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        piePlot0.setBackgroundImageAlpha((float) 1);
        double double45 = piePlot0.getLabelGap();
        piePlot0.setLabelGap((double) '#');
        java.awt.Paint paint48 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, range2);
        boolean boolean4 = paintList0.equals((java.lang.Object) rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (byte) -1);
        java.lang.Comparable comparable8 = null;
        try {
            java.lang.Number number9 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 12, comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat4);
        int int6 = dateTickUnit5.getRollUnit();
        int int7 = dateTickUnit5.getRollUnit();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = java.awt.Color.lightGray;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color1);
        java.lang.String str3 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        columnArrangement5.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator10, false);
        boolean boolean15 = stackedAreaRenderer8.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedAreaRenderer8.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator17, false);
        stackedAreaRenderer8.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23, (java.lang.Comparable) false);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, (int) (short) 0);
        java.lang.Number number32 = defaultBoxAndWhiskerCategoryDataset23.getMinRegularValue((java.lang.Comparable) (byte) 0, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23, true);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = boxAndWhiskerRenderer0.getLegendItemToolTipGenerator();
        boolean boolean4 = boxAndWhiskerRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = boxAndWhiskerRenderer0.getSeriesNegativeItemLabelPosition(9999);
        boolean boolean7 = boxAndWhiskerRenderer0.getFillBox();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = boxAndWhiskerRenderer0.getPositiveItemLabelPosition((int) (short) 0, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = boxAndWhiskerRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = boxAndWhiskerRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        boxAndWhiskerRenderer0.setSeriesItemLabelPaint(0, paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Color color8 = java.awt.Color.pink;
        polarPlot7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = polarPlot7.getAngleGridlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot7.setAngleLabelPaint((java.awt.Paint) color11);
        waterfallBarRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color11);
        waterfallBarRenderer0.setMaximumBarWidth((double) (byte) 10);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator16 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        waterfallBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator16);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor21, textAnchor22, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor18, textAnchor22, textAnchor25, (double) (short) 10);
        waterfallBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Oct", "hi!", "Range[0.0,0.0]", "Oct");
        java.lang.String str5 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[0.0,0.0]" + "'", str5.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5, false);
        boolean boolean10 = stackedAreaRenderer3.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedAreaRenderer3.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator12, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedAreaRenderer3.getLegendItemLabelGenerator();
        waterfallBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator15);
        java.awt.Paint paint19 = waterfallBarRenderer0.getItemOutlinePaint((int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        double double3 = waterfallBarRenderer0.getBase();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection11 = xYPlot8.getRangeMarkers((int) (short) 1, layer10);
        java.awt.Paint paint12 = xYPlot8.getRangeZeroBaselinePaint();
        boolean boolean13 = waterfallBarRenderer0.hasListener((java.util.EventListener) xYPlot8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        numberAxis3D0.setTickLabelInsets(rectangleInsets4);
        java.awt.Shape shape6 = numberAxis3D0.getUpArrow();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition1.getCategoryAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        boolean boolean9 = xYPlot4.isRangeCrosshairLockedOnData();
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot3.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.data.Range range10 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis3D6.lengthToJava2D((double) 620L, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D15.resizeRange(35.0d, (double) (short) 100);
        double double19 = numberAxis3D15.getAutoRangeMinimumSize();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20, (java.lang.Comparable) (-2208927599900L));
        double double25 = defaultBoxAndWhiskerCategoryDataset20.getRangeUpperBound(false);
        java.util.List list28 = defaultBoxAndWhiskerCategoryDataset20.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap29 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset20, keyToGroupMap29);
        numberAxis3D15.setDefaultAutoRange(range30);
        numberAxis3D6.setRangeWithMargins(range30);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-8d + "'", double19 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNull(list28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getSeriesIndex();
        java.lang.String str17 = legendItem15.getDescription();
        java.awt.Paint paint18 = legendItem15.getLinePaint();
        java.lang.String str19 = legendItem15.getURLText();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[0.0,0.0]" + "'", str17.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator27);
        boolean boolean29 = piePlot0.isCircular();
        java.awt.Paint paint30 = null;
        try {
            piePlot0.setBaseSectionPaint(paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint4 = waterfallBarRenderer2.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock8.draw(graphics2D9, (float) 8, (float) 10, textBlockAnchor12, (float) 8, (float) 0L, (double) 0L);
        org.jfree.chart.text.TextLine textLine17 = textBlock8.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textBlock8.getLineAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        int int9 = xYPlot4.getIndexOf(xYItemRenderer8);
        java.awt.Font font11 = null;
        java.awt.Paint paint12 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, paint12, (-1.0f), textMeasurer14);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font18 = waterfallBarRenderer17.getBaseItemLabelFont();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset26, valueAxis27, polarItemRenderer28);
        java.awt.Color color30 = java.awt.Color.pink;
        polarPlot29.setBackgroundPaint((java.awt.Paint) color30);
        java.awt.Stroke stroke32 = polarPlot29.getRadiusGridlineStroke();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape24, (java.awt.Paint) color25, stroke32, (java.awt.Paint) color33);
        textBlock15.addLine("{0}", font18, (java.awt.Paint) color33);
        java.awt.Color color36 = color33.brighter();
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color36);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        boolean boolean3 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        waterfallBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        minMaxCategoryRenderer0.setGroupStroke(stroke1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean7 = polarPlot3.equals((java.lang.Object) (byte) -1);
        java.awt.Color color8 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        int int10 = color8.getTransparency();
        polarPlot3.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getAngleGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot15.setAngleLabelPaint((java.awt.Paint) color19);
        int int21 = color19.getTransparency();
        boolean boolean22 = polarPlot3.equals((java.lang.Object) int21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Paint paint9 = waterfallBarRenderer0.getPositiveBarPaint();
        java.awt.Paint paint10 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color4);
        boolean boolean8 = lineAndShapeRenderer2.getItemShapeVisible(0, 0);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer9 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean10 = waterfallBarRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        stackedAreaRenderer12.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator14, false);
        boolean boolean19 = stackedAreaRenderer12.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        stackedAreaRenderer12.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator21, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = stackedAreaRenderer12.getLegendItemLabelGenerator();
        waterfallBarRenderer9.setLegendItemURLGenerator(categorySeriesLabelGenerator24);
        lineAndShapeRenderer2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Stroke stroke7 = xYPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.general.DatasetGroup datasetGroup8 = xYPlot4.getDatasetGroup();
        try {
            xYPlot4.setBackgroundImageAlpha((float) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(datasetGroup8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getBase();
        waterfallBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor2, textAnchor3, (double) 0.0f);
        java.lang.Object obj6 = numberTick5.clone();
        java.lang.String str7 = numberTick5.getText();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 52);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        float float3 = categoryAxis3D1.getTickMarkOutsideLength();
        categoryAxis3D1.setMaximumCategoryLabelLines(4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        java.awt.Stroke stroke44 = piePlot0.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        jFreeChart17.setTitle("Pie Plot");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        numberAxis3D0.setAxisLinePaint(paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(100.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer4.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator6, false);
        boolean boolean11 = stackedAreaRenderer4.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedAreaRenderer4.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator13, false);
        stackedAreaRenderer4.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset19 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset19);
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset19.getRowKeys();
        axisState0.setTicks(list22);
        double double24 = axisState0.getMax();
        java.util.List list25 = axisState0.getTicks();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot0.getLegendLabelURLGenerator();
        double double4 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Oct");
        java.lang.Object obj2 = categoryAxis1.clone();
        categoryAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat4);
        int int6 = dateTickUnit5.getRollCount();
        java.lang.String str8 = dateTickUnit5.valueToString(100.0d);
        double double9 = dateTickUnit5.getSize();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12/31/69" + "'", str8.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock5.calculateDimensions(graphics2D8);
        java.util.List list10 = textBlock5.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock5.getLineAlignment();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint2 = waterfallBarRenderer0.lookupSeriesPaint((int) (short) 1);
        int int3 = waterfallBarRenderer0.getPassCount();
        java.awt.Color color4 = java.awt.Color.cyan;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color4);
        waterfallBarRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("DateTickMarkPosition.END", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        int int19 = defaultBoxAndWhiskerCategoryDataset16.getRowCount();
        java.lang.Comparable comparable21 = null;
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset16.getMinRegularValue((java.lang.Comparable) 100L, comparable21);
        try {
            java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset16.getValue(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color1 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean7 = boxAndWhiskerRenderer5.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer5.setBaseItemLabelFont(font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color11 = java.awt.Color.lightGray;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color10, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font8, (java.awt.Paint) color11);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer14.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer17.setItemMargin((double) 10L);
        java.awt.Stroke stroke21 = waterfallBarRenderer17.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer14.setBaseStroke(stroke21);
        java.awt.Color color23 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer24.setItemMargin((double) 10L);
        java.awt.Stroke stroke28 = waterfallBarRenderer24.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color11, stroke21, (java.awt.Paint) color23, stroke28, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke28);
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot();
        piePlot32.setPieIndex(0);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.util.Date date36 = month35.getStart();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot(xYDataset44, valueAxis45, polarItemRenderer46);
        java.awt.Color color48 = java.awt.Color.pink;
        polarPlot47.setBackgroundPaint((java.awt.Paint) color48);
        java.awt.Stroke stroke50 = polarPlot47.getRadiusGridlineStroke();
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape42, (java.awt.Paint) color43, stroke50, (java.awt.Paint) color51);
        int int53 = legendItem52.getSeriesIndex();
        java.lang.String str54 = legendItem52.getDescription();
        java.awt.Paint paint55 = legendItem52.getLinePaint();
        boolean boolean56 = month35.equals((java.lang.Object) paint55);
        piePlot32.setExplodePercent((java.lang.Comparable) month35, (double) 10);
        piePlot32.setStartAngle((double) 0.0f);
        piePlot32.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset63 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number64 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset63);
        org.jfree.data.general.PieDataset pieDataset66 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset63, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset70 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset66, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot32.setDataset(pieDataset70);
        piePlot32.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator75 = piePlot32.getURLGenerator();
        piePlot32.setOutlineVisible(true);
        java.awt.Paint paint78 = piePlot32.getLabelShadowPaint();
        java.awt.Paint paint79 = piePlot32.getLabelBackgroundPaint();
        valueMarker31.setOutlinePaint(paint79);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Range[0.0,0.0]" + "'", str54.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 0.0d + "'", number64.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset66);
        org.junit.Assert.assertNotNull(pieDataset70);
        org.junit.Assert.assertNull(pieURLGenerator75);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint79);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font2 = labelBlock1.getFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = labelBlock1.getMargin();
        double double4 = rectangleInsets3.getTop();
        double double6 = rectangleInsets3.calculateTopOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setPieIndex(0);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Color color19 = java.awt.Color.pink;
        polarPlot18.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = polarPlot18.getRadiusGridlineStroke();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape13, (java.awt.Paint) color14, stroke21, (java.awt.Paint) color22);
        int int24 = legendItem23.getSeriesIndex();
        java.lang.String str25 = legendItem23.getDescription();
        java.awt.Paint paint26 = legendItem23.getLinePaint();
        boolean boolean27 = month6.equals((java.lang.Object) paint26);
        piePlot3.setExplodePercent((java.lang.Comparable) month6, (double) 10);
        piePlot3.setStartAngle((double) 0.0f);
        piePlot3.setLabelGap((double) 0.0f);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        piePlot3.setShadowPaint(paint34);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        stackedAreaRenderer37.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset52 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset52);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent54 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer37, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset52);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer57.getLegendItems();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer57.setBaseItemLabelPaint((java.awt.Paint) color59);
        stackedAreaRenderer37.setBaseFillPaint((java.awt.Paint) color59, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator67 = null;
        stackedAreaRenderer65.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator67, false);
        boolean boolean72 = stackedAreaRenderer65.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator74 = null;
        stackedAreaRenderer65.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator74, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator77 = stackedAreaRenderer65.getLegendItemLabelGenerator();
        java.awt.Paint paint80 = stackedAreaRenderer65.getItemPaint(12, (int) '#');
        stackedAreaRenderer37.setSeriesOutlinePaint(3, paint80, true);
        java.awt.Stroke stroke84 = stackedAreaRenderer37.lookupSeriesOutlineStroke((int) '#');
        piePlot3.setLabelLinkStroke(stroke84);
        piePlot0.setLabelOutlineStroke(stroke84);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Range[0.0,0.0]" + "'", str25.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator77);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        boolean boolean15 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        int int5 = lineAndShapeRenderer2.getRowCount();
        boolean boolean8 = lineAndShapeRenderer2.isItemLabelVisible(7, (int) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot14.setRangeAxes(valueAxisArray16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRendererForDataset(xYDataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot14.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        boolean boolean24 = defaultDrawingSupplier9.equals((java.lang.Object) xYPlot14);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot14);
        xYPlot14.clearDomainMarkers();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        boolean boolean3 = lineAndShapeRenderer2.getUseFillPaint();
        boolean boolean4 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesItemLabelsVisible(2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Color color3 = java.awt.Color.GREEN;
        boxAndWhiskerRenderer0.setArtifactPaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = boxAndWhiskerRenderer0.initialise(graphics2D5, rectangle2D6, categoryPlot7, 15, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        boolean boolean3 = lineAndShapeRenderer2.getUseFillPaint();
        boolean boolean4 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color6 = java.awt.Color.blue;
        float[] floatArray13 = new float[] { 1, 5, 'a', 2.0f, 2.0f, 0.95f };
        float[] floatArray14 = color6.getComponents(floatArray13);
        float[] floatArray15 = color5.getColorComponents(floatArray13);
        boolean boolean16 = lineAndShapeRenderer2.equals((java.lang.Object) floatArray15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        piePlot0.setShadowPaint(paint31);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = null;
        stackedAreaRenderer34.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator36, false);
        boolean boolean41 = stackedAreaRenderer34.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator43 = null;
        stackedAreaRenderer34.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator43, false);
        stackedAreaRenderer34.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset49 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset49);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent51 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer34, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset49);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = lineAndShapeRenderer54.getLegendItems();
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer54.setBaseItemLabelPaint((java.awt.Paint) color56);
        stackedAreaRenderer34.setBaseFillPaint((java.awt.Paint) color56, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer62 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = null;
        stackedAreaRenderer62.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator64, false);
        boolean boolean69 = stackedAreaRenderer62.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator71 = null;
        stackedAreaRenderer62.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator71, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator74 = stackedAreaRenderer62.getLegendItemLabelGenerator();
        java.awt.Paint paint77 = stackedAreaRenderer62.getItemPaint(12, (int) '#');
        stackedAreaRenderer34.setSeriesOutlinePaint(3, paint77, true);
        java.awt.Stroke stroke81 = stackedAreaRenderer34.lookupSeriesOutlineStroke((int) '#');
        piePlot0.setLabelLinkStroke(stroke81);
        piePlot0.setCircular(true, true);
        java.awt.Paint paint87 = piePlot0.getSectionPaint((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(legendItemCollection55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator74);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNull(paint87);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        piePlot0.setSectionOutlinesVisible(true);
        java.awt.Paint paint33 = piePlot0.getLabelShadowPaint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        boolean boolean39 = xYPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot38.setRangeAxes(valueAxisArray40);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = null;
        stackedAreaRenderer43.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator45, false);
        boolean boolean50 = stackedAreaRenderer43.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator52 = null;
        stackedAreaRenderer43.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator52, false);
        stackedAreaRenderer43.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset58 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset58);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent60 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer43, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset58);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection64 = lineAndShapeRenderer63.getLegendItems();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer63.setBaseItemLabelPaint((java.awt.Paint) color65);
        stackedAreaRenderer43.setBaseFillPaint((java.awt.Paint) color65, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer71 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator73 = null;
        stackedAreaRenderer71.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator73, false);
        boolean boolean78 = stackedAreaRenderer71.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator80 = null;
        stackedAreaRenderer71.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator80, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator83 = stackedAreaRenderer71.getLegendItemLabelGenerator();
        java.awt.Paint paint86 = stackedAreaRenderer71.getItemPaint(12, (int) '#');
        stackedAreaRenderer43.setSeriesOutlinePaint(3, paint86, true);
        java.awt.Stroke stroke90 = stackedAreaRenderer43.lookupSeriesOutlineStroke((int) '#');
        xYPlot38.setRangeGridlineStroke(stroke90);
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = xYPlot38.getDomainAxisEdge(0);
        boolean boolean94 = piePlot0.equals((java.lang.Object) rectangleEdge93);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(legendItemCollection64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator83);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(rectangleEdge93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit7);
        numberAxis3D0.resizeRange(90.0d);
        numberAxis3D0.setAutoRangeStickyZero(false);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        boolean boolean20 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        stackedAreaRenderer24.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator26, false);
        boolean boolean31 = stackedAreaRenderer24.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
        stackedAreaRenderer24.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator33, false);
        stackedAreaRenderer24.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset39 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer24, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = lineAndShapeRenderer44.getLegendItems();
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer44.setBaseItemLabelPaint((java.awt.Paint) color46);
        stackedAreaRenderer24.setBaseFillPaint((java.awt.Paint) color46, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        stackedAreaRenderer52.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator54, false);
        boolean boolean59 = stackedAreaRenderer52.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = null;
        stackedAreaRenderer52.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator61, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator64 = stackedAreaRenderer52.getLegendItemLabelGenerator();
        java.awt.Paint paint67 = stackedAreaRenderer52.getItemPaint(12, (int) '#');
        stackedAreaRenderer24.setSeriesOutlinePaint(3, paint67, true);
        java.awt.Stroke stroke71 = stackedAreaRenderer24.lookupSeriesOutlineStroke((int) '#');
        xYPlot19.setRangeGridlineStroke(stroke71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = xYPlot19.getDomainAxisEdge(0);
        try {
            double double75 = numberAxis3D0.java2DToValue(0.0d, rectangle2D14, rectangleEdge74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNotNull(legendItemCollection45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator64);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        boolean boolean9 = xYPlot8.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot8.getOrientation();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color12 = java.awt.Color.lightGray;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color11, (java.awt.Paint) color12);
        xYPlot8.setRangeCrosshairPaint((java.awt.Paint) color11);
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot8);
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot8.getDataset(4);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(xYDataset17);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.Range range22 = defaultBoxAndWhiskerCategoryDataset16.getRangeBounds(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setMaximumCategoryLabelLines((int) '4');
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double9 = categoryAxis3D1.getCategoryMiddle((int) (short) 100, (int) 'a', rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100.0f, true);
        java.awt.Paint paint4 = stackedBarRenderer3D3.getWallPaint();
        double double5 = stackedBarRenderer3D3.getXOffset();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer67 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = null;
        stackedAreaRenderer67.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator69, false);
        boolean boolean74 = stackedAreaRenderer67.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator76 = null;
        stackedAreaRenderer67.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator76, false);
        stackedAreaRenderer67.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset82 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset82);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent84 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer67, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset82);
        java.util.List list85 = defaultBoxAndWhiskerCategoryDataset82.getRowKeys();
        jFreeChart17.setSubtitles(list85);
        java.awt.Paint paint87 = jFreeChart17.getBorderPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(range83);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertNotNull(paint87);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone1;
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getID();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection0, jFreeChart1, chartChangeEventType2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        boolean boolean10 = xYPlot9.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot9.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot9.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot9.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot9.getFixedRangeAxisSpace();
        xYPlot9.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer23 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean25 = boxAndWhiskerRenderer23.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer23.setBaseItemLabelFont(font26);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer28 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font29 = waterfallBarRenderer28.getBaseItemLabelFont();
        double double30 = waterfallBarRenderer28.getUpperClip();
        double double31 = waterfallBarRenderer28.getUpperClip();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color33 = java.awt.Color.lightGray;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color32, (java.awt.Paint) color33);
        waterfallBarRenderer28.setLastBarPaint((java.awt.Paint) color33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font38 = null;
        java.awt.Paint paint39 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (-1.0f), textMeasurer41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock42.setLineAlignment(horizontalAlignment43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock42.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock42.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = textTitle49.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement53 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment48, verticalAlignment50, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets54, (java.awt.Paint) color55);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("{0}", font26, (java.awt.Paint) color33, rectangleEdge36, horizontalAlignment47, verticalAlignment50, rectangleInsets54);
        java.awt.Color color58 = java.awt.Color.WHITE;
        textTitle57.setPaint((java.awt.Paint) color58);
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle57);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener63 = null;
        textTitle61.removeChangeListener(titleChangeListener63);
        textTitle61.setID("CONTRACT");
        textTitle61.setText("Oct");
        jFreeChart21.setTitle(textTitle61);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer71 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator73 = null;
        stackedAreaRenderer71.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator73, false);
        boolean boolean78 = stackedAreaRenderer71.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator80 = null;
        stackedAreaRenderer71.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator80, false);
        stackedAreaRenderer71.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset86 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range87 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset86);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent88 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer71, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset86);
        java.util.List list89 = defaultBoxAndWhiskerCategoryDataset86.getRowKeys();
        jFreeChart21.setSubtitles(list89);
        chartChangeEvent3.setChart(jFreeChart21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo96 = null;
        java.awt.image.BufferedImage bufferedImage97 = jFreeChart21.createBufferedImage(11, 100, (double) (short) 10, (double) 0L, chartRenderingInfo96);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(textBlock42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment50);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(range87);
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(bufferedImage97);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot4.getDataset((int) '#');
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        axisState4.setCursor((double) ' ');
        java.util.List list7 = axisState4.getTicks();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list10 = dateAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        int int2 = year0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot4.setDataset((int) ' ', xYDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        polarPlot16.setNoDataMessage("");
        boolean boolean19 = polarPlot16.isRangeZoomable();
        java.awt.Paint paint20 = polarPlot16.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        polarPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Stroke stroke24 = defaultDrawingSupplier21.getNextStroke();
        xYPlot4.setDomainGridlineStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot4.setDomainAxisLocation(axisLocation26);
        xYPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        java.awt.Paint paint3 = waterfallBarRenderer0.getNegativeBarPaint();
        boolean boolean6 = waterfallBarRenderer0.getItemCreateEntity((int) '#', 0);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        java.awt.Color color18 = java.awt.Color.pink;
        polarPlot17.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = polarPlot17.getRadiusGridlineStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape12, (java.awt.Paint) color13, stroke20, (java.awt.Paint) color21);
        boolean boolean23 = waterfallBarRenderer0.equals((java.lang.Object) "Range[0.0,0.0]");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRangeWithMargins(0.0d, (double) '#');
        numberAxis0.setNegativeArrowVisible(true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100.0f, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getLowerMargin();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        java.awt.Color color17 = java.awt.Color.pink;
        polarPlot16.setBackgroundPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = polarPlot16.getRadiusGridlineStroke();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape11, (java.awt.Paint) color12, stroke19, (java.awt.Paint) color20);
        numberAxis3D4.setLeftArrow(shape11);
        stackedBarRenderer3D3.setBaseShape(shape11, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.lang.Object obj3 = categoryAxis3D1.clone();
        java.awt.Stroke stroke4 = categoryAxis3D1.getTickMarkStroke();
        categoryAxis3D1.setUpperMargin((double) (short) 1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat4);
        int int6 = dateTickUnit5.getCalendarField();
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat11);
        int int13 = dateTickUnit12.getRollCount();
        java.lang.String str15 = dateTickUnit12.valueToString(100.0d);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.util.Date date17 = month16.getStart();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        java.lang.String str19 = dateTickUnit12.dateToString(date17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.Date date21 = dateTickUnit5.addToDate(date17);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17);
        java.lang.String str23 = year22.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12/31/69" + "'", str15.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "6/1/19" + "'", str19.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) '4');
        java.awt.Stroke stroke8 = intervalMarker7.getStroke();
        boolean boolean9 = rectangleAnchor4.equals((java.lang.Object) intervalMarker7);
        boolean boolean10 = color3.equals((java.lang.Object) boolean9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        int int5 = lineAndShapeRenderer2.getRowCount();
        boolean boolean8 = lineAndShapeRenderer2.isItemLabelVisible(7, (int) (byte) 100);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        java.lang.Boolean boolean13 = lineAndShapeRenderer2.getSeriesVisible(2019);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            labelBlock1.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        textTitle0.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle0.getPadding();
        double double8 = rectangleInsets6.calculateRightOutset((double) 500);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 52, (-1.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot4.getAxisOffset();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("2019", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        double double2 = categoryAxis3D1.getLowerMargin();
        double double3 = categoryAxis3D1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot3.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot3.getRenderer();
        int int9 = polarPlot3.getBackgroundImageAlignment();
        polarPlot3.clearCornerTextItems();
        java.lang.Class<?> wildcardClass11 = polarPlot3.getClass();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        numberAxis3D0.setVisible(false);
        boolean boolean9 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("SortOrder.DESCENDING");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        double double3 = numberAxis3D0.getFixedAutoRange();
        java.lang.String str4 = numberAxis3D0.getLabel();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setPieIndex(0);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Color color21 = java.awt.Color.pink;
        polarPlot20.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = polarPlot20.getRadiusGridlineStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape15, (java.awt.Paint) color16, stroke23, (java.awt.Paint) color24);
        int int26 = legendItem25.getSeriesIndex();
        java.lang.String str27 = legendItem25.getDescription();
        java.awt.Paint paint28 = legendItem25.getLinePaint();
        boolean boolean29 = month8.equals((java.lang.Object) paint28);
        piePlot5.setExplodePercent((java.lang.Comparable) month8, (double) 10);
        piePlot5.setStartAngle((double) 0.0f);
        piePlot5.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset36 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset36);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset36, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset39, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot5.setDataset(pieDataset43);
        piePlot5.setPieIndex(100);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource48 = numberAxis3D0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Range[0.0,0.0]" + "'", str27.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0d + "'", number37.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(tickUnitSource48);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint16 = stackedAreaRenderer1.getItemPaint(12, (int) '#');
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (java.lang.Comparable) (-2208927599900L));
        double double22 = defaultBoxAndWhiskerCategoryDataset17.getRangeUpperBound(false);
        org.jfree.data.Range range23 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        stackedAreaRenderer25.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator27, false);
        boolean boolean32 = stackedAreaRenderer25.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = null;
        stackedAreaRenderer25.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator34, false);
        stackedAreaRenderer25.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset40 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset40);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer25, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset40);
        int int43 = defaultBoxAndWhiskerCategoryDataset40.getRowCount();
        org.jfree.data.Range range44 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset40);
        try {
            java.lang.Number number47 = defaultBoxAndWhiskerCategoryDataset40.getMaxRegularValue((int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge5);
        textTitle0.setPosition(rectangleEdge5);
        java.lang.String str8 = textTitle0.getText();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot1.setRenderer(waferMapRenderer3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        boolean boolean9 = xYPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("CONTRACT");
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat6);
        int int8 = dateTickUnit7.getRollCount();
        java.lang.String str10 = dateTickUnit7.valueToString(100.0d);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        java.lang.String str14 = dateTickUnit7.dateToString(date12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.util.Date date17 = month16.getStart();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        try {
            dateAxis1.setRange(date12, date17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12/31/69" + "'", str10.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "6/1/19" + "'", str14.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boxAndWhiskerRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color6);
        boxAndWhiskerRenderer0.setArtifactPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelPositions0.equals(obj1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setPositiveArrowVisible(false);
        double double8 = numberAxis3D5.getFixedAutoRange();
        java.lang.String str9 = numberAxis3D5.getLabel();
        boolean boolean10 = categoryLabelPosition3.equals((java.lang.Object) numberAxis3D5);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot4.getOrientation();
        xYPlot4.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = lineAndShapeRenderer2.getLegendItemURLGenerator();
        lineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot4.setDataset((int) ' ', xYDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        polarPlot16.setNoDataMessage("");
        boolean boolean19 = polarPlot16.isRangeZoomable();
        java.awt.Paint paint20 = polarPlot16.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        polarPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Stroke stroke24 = defaultDrawingSupplier21.getNextStroke();
        xYPlot4.setDomainGridlineStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot4.setDomainAxisLocation(axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        boolean boolean33 = xYPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot32.setRangeAxes(valueAxisArray34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot32.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation36);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        lineAndShapeRenderer2.setBaseItemLabelFont(font6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getToolTipGenerator(1900, (int) (short) 10);
        java.awt.Shape shape13 = lineAndShapeRenderer2.lookupSeriesShape(52);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setRenderAsPercentages(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment5, (double) 7, (double) (-2208927599900L));
        columnArrangement8.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator13, false);
        boolean boolean18 = stackedAreaRenderer11.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        stackedAreaRenderer11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator20, false);
        stackedAreaRenderer11.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer11, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26, (java.lang.Comparable) false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(7, (int) (short) 0);
        java.lang.Number number35 = defaultBoxAndWhiskerCategoryDataset26.getMinRegularValue((java.lang.Comparable) (byte) 0, (java.lang.Comparable) (short) 0);
        org.jfree.data.Range range36 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0d + "'", number37.equals(0.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        java.awt.Paint paint3 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Stroke stroke4 = waterfallBarRenderer0.getBaseOutlineStroke();
        boolean boolean7 = waterfallBarRenderer0.getItemCreateEntity((-1), 1);
        waterfallBarRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, (double) 620L, 0.0d);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset19, valueAxis20, polarItemRenderer21);
        java.awt.Color color23 = java.awt.Color.pink;
        polarPlot22.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke25 = polarPlot22.getRadiusGridlineStroke();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape17, (java.awt.Paint) color18, stroke25, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        java.lang.String str29 = legendItem27.getDescription();
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        boolean boolean31 = month10.equals((java.lang.Object) paint30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color34 = java.awt.Color.blue;
        float[] floatArray41 = new float[] { 1, 5, 'a', 2.0f, 2.0f, 0.95f };
        float[] floatArray42 = color34.getComponents(floatArray41);
        float[] floatArray43 = color33.getColorComponents(floatArray41);
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "AreaRendererEndType.TRUNCATE", "Range[35.0,45.0]", "Range[35.0,45.0]", shape9, paint30, stroke32, (java.awt.Paint) color33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Range[0.0,0.0]" + "'", str29.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean6 = polarPlot3.isRangeZoomable();
        java.awt.Stroke stroke7 = polarPlot3.getAngleGridlineStroke();
        boolean boolean8 = polarPlot3.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font2 = labelBlock1.getFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = labelBlock1.getMargin();
        java.awt.Color color4 = java.awt.Color.pink;
        labelBlock1.setPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color7);
        int int9 = polarPlot3.getSeriesCount();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, 3.0d, (double) 7);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color1);
        java.awt.Color color3 = java.awt.Color.blue;
        float[] floatArray10 = new float[] { 1, 5, 'a', 2.0f, 2.0f, 0.95f };
        float[] floatArray11 = color3.getComponents(floatArray10);
        float[] floatArray12 = color1.getComponents(floatArray10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        double double29 = intervalMarker28.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType30, jFreeChart31);
        intervalMarker28.setLabelOffsetType(lengthAdjustmentType30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker28.notifyListeners(markerChangeEvent34);
        float float36 = intervalMarker28.getAlpha();
        intervalMarker28.setLabel("");
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        boolean boolean7 = boxAndWhiskerRenderer0.isSeriesItemLabelsVisible(52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        lineAndShapeRenderer2.setBaseItemLabelFont(font6, false);
        org.jfree.chart.LegendItem legendItem11 = lineAndShapeRenderer2.getLegendItem(5, (int) (byte) 0);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(legendItem11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator12, false);
        boolean boolean17 = stackedAreaRenderer10.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        stackedAreaRenderer10.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator19, false);
        stackedAreaRenderer10.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset25 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset25);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer10, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset25);
        xYPlot4.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.plot.Plot plot29 = xYPlot4.getRootPlot();
        float float30 = plot29.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        java.text.AttributedString attributedString16 = legendItem15.getAttributedLabel();
        boolean boolean17 = legendItem15.isShapeVisible();
        java.lang.String str18 = legendItem15.getDescription();
        int int19 = legendItem15.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(attributedString16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Shape shape17 = legendItemEntity16.getArea();
        org.jfree.data.general.Dataset dataset18 = null;
        legendItemEntity16.setDataset(dataset18);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot4.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        org.jfree.chart.plot.Plot plot14 = xYPlot4.getParent();
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font17 = labelBlock16.getFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = labelBlock16.getMargin();
        try {
            plot14.setInsets(rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) "({0}, {1}) = {2}", (java.lang.Comparable) 9999);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer7 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font8 = waterfallBarRenderer7.getBaseItemLabelFont();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        java.awt.Color color20 = java.awt.Color.pink;
        polarPlot19.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke22 = polarPlot19.getRadiusGridlineStroke();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape14, (java.awt.Paint) color15, stroke22, (java.awt.Paint) color23);
        textBlock5.addLine("{0}", font8, (java.awt.Paint) color23);
        org.jfree.chart.text.TextLine textLine26 = textBlock5.getLastLine();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textLine26);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate3);
        java.lang.String str7 = serialDate3.getDescription();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-1900" + "'", str5.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font2 = labelBlock1.getFont();
        java.lang.Object obj3 = null;
        boolean boolean4 = labelBlock1.equals(obj3);
        labelBlock1.setURLText("");
        labelBlock1.setURLText("6/1/19");
        labelBlock1.setURLText("WMAP_Plot");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator4, false);
        boolean boolean9 = stackedAreaRenderer2.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        stackedAreaRenderer2.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator11, false);
        stackedAreaRenderer2.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer2, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset17);
        boolean boolean20 = shapeList0.equals((java.lang.Object) stackedAreaRenderer2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = minMaxCategoryRenderer0.getGroupPaint();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        piePlot2.setPieIndex(0);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        java.awt.Color color18 = java.awt.Color.pink;
        polarPlot17.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = polarPlot17.getRadiusGridlineStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape12, (java.awt.Paint) color13, stroke20, (java.awt.Paint) color21);
        int int23 = legendItem22.getSeriesIndex();
        java.lang.String str24 = legendItem22.getDescription();
        java.awt.Paint paint25 = legendItem22.getLinePaint();
        boolean boolean26 = month5.equals((java.lang.Object) paint25);
        piePlot2.setExplodePercent((java.lang.Comparable) month5, (double) 10);
        piePlot2.setStartAngle((double) 0.0f);
        piePlot2.setLabelGap((double) 0.0f);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        piePlot2.setShadowPaint(paint33);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = null;
        stackedAreaRenderer36.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator38, false);
        boolean boolean43 = stackedAreaRenderer36.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = null;
        stackedAreaRenderer36.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator45, false);
        stackedAreaRenderer36.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset51 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset51);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer36, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset51);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection57 = lineAndShapeRenderer56.getLegendItems();
        java.awt.Color color58 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer56.setBaseItemLabelPaint((java.awt.Paint) color58);
        stackedAreaRenderer36.setBaseFillPaint((java.awt.Paint) color58, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer64 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator66 = null;
        stackedAreaRenderer64.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator66, false);
        boolean boolean71 = stackedAreaRenderer64.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator73 = null;
        stackedAreaRenderer64.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator73, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator76 = stackedAreaRenderer64.getLegendItemLabelGenerator();
        java.awt.Paint paint79 = stackedAreaRenderer64.getItemPaint(12, (int) '#');
        stackedAreaRenderer36.setSeriesOutlinePaint(3, paint79, true);
        java.awt.Stroke stroke83 = stackedAreaRenderer36.lookupSeriesOutlineStroke((int) '#');
        piePlot2.setLabelLinkStroke(stroke83);
        minMaxCategoryRenderer0.setGroupStroke(stroke83);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Range[0.0,0.0]" + "'", str24.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator76);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint4 = waterfallBarRenderer2.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock8.draw(graphics2D9, (float) 8, (float) 10, textBlockAnchor12, (float) 8, (float) 0L, (double) 0L);
        org.jfree.chart.text.TextLine textLine17 = textBlock8.getLastLine();
        java.util.List list18 = textBlock8.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNull(textLine17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
        taskSeries1.setKey((java.lang.Comparable) (short) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str46 = serialDate45.toString();
        java.awt.Paint paint47 = piePlot0.getSectionPaint((java.lang.Comparable) serialDate45);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer51 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean53 = boxAndWhiskerRenderer51.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer51.setBaseItemLabelFont(font54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color57 = java.awt.Color.lightGray;
        boolean boolean58 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color56, (java.awt.Paint) color57);
        org.jfree.chart.text.TextFragment textFragment59 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font54, (java.awt.Paint) color57);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer60 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer60.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer63 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer63.setItemMargin((double) 10L);
        java.awt.Stroke stroke67 = waterfallBarRenderer63.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer60.setBaseStroke(stroke67);
        java.awt.Color color69 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer70 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer70.setItemMargin((double) 10L);
        java.awt.Stroke stroke74 = waterfallBarRenderer70.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker76 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color57, stroke67, (java.awt.Paint) color69, stroke74, (float) (byte) 1);
        double double77 = intervalMarker76.getStartValue();
        boolean boolean78 = piePlot0.equals((java.lang.Object) double77);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator79 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(boolean53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(pieURLGenerator79);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ChartEntity: tooltip = Range[0.0,0.0]");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        java.lang.Object obj43 = piePlot0.clone();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("{0}", "TextBlockAnchor.BOTTOM_CENTER", "{0}", image3, "2-January-1900", "12/31/69", "Default Group");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(100.0d);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset3.setGroup(datasetGroup4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset3);
        java.util.List list7 = defaultBoxAndWhiskerCategoryDataset3.getRowKeys();
        axisState0.setTicks(list7);
        try {
            java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list7);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        textTitle0.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        polarPlot10.setNoDataMessage("");
        boolean boolean13 = polarPlot10.isRangeZoomable();
        java.awt.Paint paint14 = polarPlot10.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextOutlinePaint();
        polarPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Stroke stroke18 = defaultDrawingSupplier15.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder(paint6, stroke18, rectangleInsets19);
        textTitle0.setMargin(rectangleInsets19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        numberAxis3D24.setTickLabelInsets(rectangleInsets28);
        double double30 = rectangleInsets28.getRight();
        textTitle0.setPadding(rectangleInsets28);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        boolean boolean10 = xYPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Oct");
        java.lang.Object obj2 = categoryAxis1.clone();
        categoryAxis1.setLabelURL("({0}, {1}) = {3} - {4}");
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.util.List list9 = blockContainer8.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, (java.lang.Number) (byte) 0, (java.lang.Number) 5, (java.lang.Number) (short) 1, (java.lang.Number) 5, (java.lang.Number) 11, (java.lang.Number) Double.NaN, (java.lang.Number) 8.0d, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxOutlier();
        java.util.List list12 = boxAndWhiskerItem10.getOutliers();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 8.0d + "'", number11.equals(8.0d));
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color3 = java.awt.Color.blue;
        float[] floatArray10 = new float[] { 1, 5, 'a', 2.0f, 2.0f, 0.95f };
        float[] floatArray11 = color3.getComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(10, 12, (int) (byte) 1, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Color color8 = java.awt.Color.pink;
        polarPlot7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = polarPlot7.getAngleGridlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot7.setAngleLabelPaint((java.awt.Paint) color11);
        waterfallBarRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color11);
        waterfallBarRenderer0.setMaximumBarWidth((double) (byte) 10);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator16 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        waterfallBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = waterfallBarRenderer0.getSeriesNegativeItemLabelPosition(15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        boolean boolean8 = xYPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean4 = boxAndWhiskerRenderer2.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer2.setBaseItemLabelFont(font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font5, (java.awt.Paint) color8);
        textLine0.addFragment(textFragment10);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        lineAndShapeRenderer2.setBaseShape(shape16);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, (double) 620L, 0.0d);
        lineAndShapeRenderer2.setBaseShape(shape22);
        java.awt.Font font26 = lineAndShapeRenderer2.getItemLabelFont(8, 8);
        java.awt.Stroke stroke29 = lineAndShapeRenderer2.getItemStroke((int) ' ', 11);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot4.getFixedRangeAxisSpace();
        xYPlot4.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace14);
        boolean boolean16 = xYPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        boolean boolean9 = xYPlot4.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot4.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.axis.AxisState axisState66 = new org.jfree.chart.axis.AxisState();
        axisState66.cursorUp(100.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer70 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator72 = null;
        stackedAreaRenderer70.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator72, false);
        boolean boolean77 = stackedAreaRenderer70.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator79 = null;
        stackedAreaRenderer70.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator79, false);
        stackedAreaRenderer70.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset85 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range86 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset85);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent87 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer70, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset85);
        java.util.List list88 = defaultBoxAndWhiskerCategoryDataset85.getRowKeys();
        axisState66.setTicks(list88);
        java.util.List list90 = axisState66.getTicks();
        jFreeChart17.setSubtitles(list90);
        org.jfree.chart.event.ChartChangeListener chartChangeListener92 = null;
        try {
            jFreeChart17.removeChangeListener(chartChangeListener92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(range86);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(list90);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = categoryLabelPosition0.getCategoryAnchor();
        float float2 = categoryLabelPosition0.getWidthRatio();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D4 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D4.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list8 = defaultKeyedValues2D4.getRowKeys();
        defaultKeyedValues2D4.clear();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        defaultKeyedValues2D4.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month12);
        boolean boolean14 = categoryLabelPosition0.equals((java.lang.Object) defaultKeyedValues2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.95f + "'", float2 == 0.95f);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat5);
        int int7 = dateTickUnit6.getCalendarField();
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat12);
        int int14 = dateTickUnit13.getRollCount();
        java.lang.String str16 = dateTickUnit13.valueToString(100.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.util.Date date18 = month17.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        java.lang.String str20 = dateTickUnit13.dateToString(date18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.Date date22 = dateTickUnit6.addToDate(date18);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year23);
        int int25 = task24.getSubtaskCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12/31/69" + "'", str16.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6/1/19" + "'", str20.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = waterfallBarRenderer0.getBaseNegativeItemLabelPosition();
        waterfallBarRenderer0.setItemMargin((double) 1.0f);
        boolean boolean14 = waterfallBarRenderer0.getItemCreateEntity(15, 500);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        categoryItemRendererState4.setBarWidth((double) 10);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj11 = categoryAxis3D10.clone();
        java.lang.Object obj12 = categoryAxis3D10.clone();
        java.awt.Stroke stroke13 = categoryAxis3D10.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.resizeRange(35.0d, (double) (short) 100);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup19 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset18.setGroup(datasetGroup19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18);
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset18.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18, (int) (byte) 100);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D2, categoryItemRendererState4, rectangle2D7, categoryPlot8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18, 8, (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertEquals((double) number21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(pieDataset24);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5, false);
        boolean boolean10 = stackedAreaRenderer3.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedAreaRenderer3.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator12, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedAreaRenderer3.getLegendItemLabelGenerator();
        waterfallBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Color color21 = java.awt.Color.pink;
        polarPlot20.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = polarPlot20.getAngleGridlineStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot20.setAngleLabelPaint((java.awt.Paint) color24);
        waterfallBarRenderer0.setLastBarPaint((java.awt.Paint) color24);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("", "hi!", "Range[0.0,0.0]", "ChartChangeEventType.GENERAL", shape31, paint32);
        java.awt.Paint paint34 = legendItem33.getLinePaint();
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color24, paint34 };
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray37 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray38 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj41 = categoryAxis3D40.clone();
        java.lang.Object obj42 = categoryAxis3D40.clone();
        java.awt.Stroke stroke43 = categoryAxis3D40.getTickMarkStroke();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer44 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean46 = waterfallBarRenderer44.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Stroke stroke48 = waterfallBarRenderer44.lookupSeriesStroke((int) (byte) -1);
        java.awt.Color color50 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer54 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean56 = boxAndWhiskerRenderer54.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font57 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer54.setBaseItemLabelFont(font57);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color60 = java.awt.Color.lightGray;
        boolean boolean61 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color59, (java.awt.Paint) color60);
        org.jfree.chart.text.TextFragment textFragment62 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font57, (java.awt.Paint) color60);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer63 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer63.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer66 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer66.setItemMargin((double) 10L);
        java.awt.Stroke stroke70 = waterfallBarRenderer66.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer63.setBaseStroke(stroke70);
        java.awt.Color color72 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer73 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer73.setItemMargin((double) 10L);
        java.awt.Stroke stroke77 = waterfallBarRenderer73.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color60, stroke70, (java.awt.Paint) color72, stroke77, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color50, stroke77);
        java.awt.Stroke[] strokeArray81 = new java.awt.Stroke[] { stroke43, stroke48, stroke77 };
        java.awt.Shape[] shapeArray82 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier83 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray35, paintArray36, paintArray37, strokeArray38, strokeArray81, shapeArray82);
        try {
            java.awt.Stroke stroke84 = defaultDrawingSupplier83.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(strokeArray81);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.setNoDataMessage("");
        boolean boolean7 = polarPlot4.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot4.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer9 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer9.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        java.awt.Stroke stroke16 = waterfallBarRenderer12.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer9.setBaseStroke(stroke16);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer18 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint20 = waterfallBarRenderer18.lookupSeriesPaint((int) (short) 1);
        int int21 = waterfallBarRenderer18.getPassCount();
        java.awt.Color color22 = java.awt.Color.cyan;
        waterfallBarRenderer18.setPositiveBarPaint((java.awt.Paint) color22);
        java.lang.String str24 = color22.toString();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer25 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font26 = waterfallBarRenderer25.getBaseItemLabelFont();
        double double27 = waterfallBarRenderer25.getUpperClip();
        java.awt.Paint paint28 = waterfallBarRenderer25.getLastBarPaint();
        java.awt.Stroke stroke29 = waterfallBarRenderer25.getBaseOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 7, paint8, stroke16, (java.awt.Paint) color22, stroke29, (float) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str24.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11, false);
        boolean boolean16 = stackedAreaRenderer9.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer9.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        stackedAreaRenderer9.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer9, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = lineAndShapeRenderer29.getLegendItems();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer29.setBaseItemLabelPaint((java.awt.Paint) color31);
        stackedAreaRenderer9.setBaseFillPaint((java.awt.Paint) color31, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer37.getLegendItemLabelGenerator();
        java.awt.Paint paint52 = stackedAreaRenderer37.getItemPaint(12, (int) '#');
        stackedAreaRenderer9.setSeriesOutlinePaint(3, paint52, true);
        java.awt.Stroke stroke56 = stackedAreaRenderer9.lookupSeriesOutlineStroke((int) '#');
        xYPlot4.setRangeGridlineStroke(stroke56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = xYPlot4.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 620L, 0.0d);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (byte) 100, shape5, "{0}", "({0}, {1}) = {3} - {4}");
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        categoryLabelEntity8.setArea(shape10);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        java.lang.String str5 = waferMapPlot4.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        waferMapPlot4.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) waferMapPlot4);
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat13);
        int int15 = dateTickUnit14.getCalendarField();
        java.text.DateFormat dateFormat20 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat20);
        int int22 = dateTickUnit21.getRollCount();
        java.lang.String str24 = dateTickUnit21.valueToString(100.0d);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        java.lang.String str28 = dateTickUnit21.dateToString(date26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.util.Date date30 = dateTickUnit14.addToDate(date26);
        java.util.List list32 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) date30, (java.lang.Comparable) "CONTRACT");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "12/31/69" + "'", str24.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "6/1/19" + "'", str28.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(list32);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean6 = boxAndWhiskerRenderer4.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer4.setBaseItemLabelFont(font7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color10 = java.awt.Color.lightGray;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color9, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font7, (java.awt.Paint) color10);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer13.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer16.setItemMargin((double) 10L);
        java.awt.Stroke stroke20 = waterfallBarRenderer16.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer13.setBaseStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer23.setItemMargin((double) 10L);
        java.awt.Stroke stroke27 = waterfallBarRenderer23.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color10, stroke20, (java.awt.Paint) color22, stroke27, (float) (byte) 1);
        double double30 = intervalMarker29.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType31, jFreeChart32);
        intervalMarker29.setLabelOffsetType(lengthAdjustmentType31);
        boolean boolean35 = categoryAnchor0.equals((java.lang.Object) intervalMarker29);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        stackedAreaRenderer37.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset52 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset52);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent54 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer37, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset52);
        java.awt.Stroke stroke56 = stackedAreaRenderer37.lookupSeriesOutlineStroke((-620));
        boolean boolean57 = categoryAnchor0.equals((java.lang.Object) (-620));
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boxAndWhiskerRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator3);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) (-2208927599900L));
        double double10 = defaultBoxAndWhiskerCategoryDataset5.getRangeUpperBound(false);
        java.util.List list13 = defaultBoxAndWhiskerCategoryDataset5.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        try {
            java.lang.String str15 = standardCategorySeriesLabelGenerator3.generateLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5, (-620));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(list13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        boolean boolean9 = xYPlot4.isRangeCrosshairLockedOnData();
        java.lang.String str10 = xYPlot4.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getDomainAxis();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font14 = waterfallBarRenderer13.getBaseItemLabelFont();
        double double15 = waterfallBarRenderer13.getUpperClip();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset23, valueAxis24, polarItemRenderer25);
        java.awt.Color color27 = java.awt.Color.pink;
        polarPlot26.setBackgroundPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = polarPlot26.getRadiusGridlineStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape21, (java.awt.Paint) color22, stroke29, (java.awt.Paint) color30);
        java.text.AttributedString attributedString32 = legendItem31.getAttributedLabel();
        boolean boolean33 = legendItem31.isShapeVisible();
        java.text.AttributedString attributedString34 = legendItem31.getAttributedLabel();
        java.awt.Paint paint35 = legendItem31.getFillPaint();
        waterfallBarRenderer13.setPositiveBarPaint(paint35);
        boolean boolean37 = xYPlot4.equals((java.lang.Object) paint35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(attributedString34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.awt.Color color12 = java.awt.Color.pink;
        polarPlot11.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = polarPlot11.getRadiusGridlineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape6, (java.awt.Paint) color7, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 520L, shape6, "hi!", "Range[0.0,0.0]");
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, 3.0d, (float) (byte) 0, 2.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor24, (double) (short) 1, (double) 0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer3 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint5 = waterfallBarRenderer3.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint5, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer13.setBase((double) '4');
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        waterfallBarRenderer13.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis18, marker19, rectangle2D20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        waterfallBarRenderer13.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        java.awt.Font font26 = waterfallBarRenderer13.getItemLabelFont(2, (int) 'a');
        java.awt.Color color27 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("WMAP_Plot", font26, (java.awt.Paint) color27);
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("WMAP_Plot", font26, paint29);
        java.awt.Paint paint31 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        textBlock9.addLine("blue", font26, paint31);
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("AreaRendererEndType.TRUNCATE", font26);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        java.lang.String str5 = waferMapPlot4.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        waferMapPlot4.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) waferMapPlot4);
        java.lang.String str9 = waferMapPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "WMAP_Plot" + "'", str9.equals("WMAP_Plot"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        java.awt.Paint paint43 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        polarPlot7.setNoDataMessage("");
        boolean boolean11 = polarPlot7.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot7.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup15 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset14.setGroup(datasetGroup15);
        java.lang.String str17 = datasetGroup15.getID();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean19 = datasetGroup15.equals((java.lang.Object) color18);
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup15);
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem21 = null;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getStart();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(boxAndWhiskerItem21, (java.lang.Comparable) month24, (java.lang.Comparable) "Size2D[width=100.0, height=35.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "NOID" + "'", str17.equals("NOID"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        numberAxis3D0.setLabelURL("ChartChangeEventType.GENERAL");
        numberAxis3D0.setLowerBound(90.0d);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.setAutoRange(true);
        org.jfree.data.Range range12 = numberAxis3D0.getRange();
        numberAxis3D0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        java.lang.Number number7 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((java.lang.Comparable) 0.0d, (java.lang.Comparable) 1);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        double double3 = numberAxis3D0.getFixedAutoRange();
        java.lang.String str4 = numberAxis3D0.getLabel();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setPieIndex(0);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Color color21 = java.awt.Color.pink;
        polarPlot20.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = polarPlot20.getRadiusGridlineStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape15, (java.awt.Paint) color16, stroke23, (java.awt.Paint) color24);
        int int26 = legendItem25.getSeriesIndex();
        java.lang.String str27 = legendItem25.getDescription();
        java.awt.Paint paint28 = legendItem25.getLinePaint();
        boolean boolean29 = month8.equals((java.lang.Object) paint28);
        piePlot5.setExplodePercent((java.lang.Comparable) month8, (double) 10);
        piePlot5.setStartAngle((double) 0.0f);
        piePlot5.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset36 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset36);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset36, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset39, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot5.setDataset(pieDataset43);
        piePlot5.setPieIndex(100);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        piePlot5.setMinimumArcAngleToDraw((double) 7);
        int int50 = piePlot5.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Range[0.0,0.0]" + "'", str27.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0d + "'", number37.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 15 + "'", int50 == 15);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 620L, 0.0d);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "CONTRACT", "XY Plot");
        chartEntity8.setURLText("12/31/69");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        boolean boolean7 = numberAxis3D0.getAutoRangeIncludesZero();
        double double8 = numberAxis3D0.getLabelAngle();
        numberAxis3D0.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        numberAxis3D0.setVisible(false);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset9 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset9, (java.lang.Comparable) (-2208927599900L));
        double double14 = defaultBoxAndWhiskerCategoryDataset9.getRangeUpperBound(false);
        java.util.List list17 = defaultBoxAndWhiskerCategoryDataset9.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap18 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset9, keyToGroupMap18);
        double double20 = range19.getLength();
        numberAxis3D0.setRangeWithMargins(range19);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setPieIndex(0);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Color color19 = java.awt.Color.pink;
        polarPlot18.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = polarPlot18.getRadiusGridlineStroke();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape13, (java.awt.Paint) color14, stroke21, (java.awt.Paint) color22);
        int int24 = legendItem23.getSeriesIndex();
        java.lang.String str25 = legendItem23.getDescription();
        java.awt.Paint paint26 = legendItem23.getLinePaint();
        boolean boolean27 = month6.equals((java.lang.Object) paint26);
        piePlot3.setExplodePercent((java.lang.Comparable) month6, (double) 10);
        piePlot3.setStartAngle((double) 0.0f);
        piePlot3.setLabelGap((double) 0.0f);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        piePlot3.setShadowPaint(paint34);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        stackedAreaRenderer37.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset52 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset52);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent54 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer37, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset52);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = lineAndShapeRenderer57.getLegendItems();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer57.setBaseItemLabelPaint((java.awt.Paint) color59);
        stackedAreaRenderer37.setBaseFillPaint((java.awt.Paint) color59, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer65 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator67 = null;
        stackedAreaRenderer65.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator67, false);
        boolean boolean72 = stackedAreaRenderer65.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator74 = null;
        stackedAreaRenderer65.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator74, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator77 = stackedAreaRenderer65.getLegendItemLabelGenerator();
        java.awt.Paint paint80 = stackedAreaRenderer65.getItemPaint(12, (int) '#');
        stackedAreaRenderer37.setSeriesOutlinePaint(3, paint80, true);
        java.awt.Stroke stroke84 = stackedAreaRenderer37.lookupSeriesOutlineStroke((int) '#');
        piePlot3.setLabelLinkStroke(stroke84);
        lineRenderer3D0.setSeriesStroke(6, stroke84, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Range[0.0,0.0]" + "'", str25.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator77);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setPositiveArrowVisible(false);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D4.setLeftArrow(shape7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getStart();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset18, valueAxis19, polarItemRenderer20);
        java.awt.Color color22 = java.awt.Color.pink;
        polarPlot21.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke24 = polarPlot21.getRadiusGridlineStroke();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape16, (java.awt.Paint) color17, stroke24, (java.awt.Paint) color25);
        int int27 = legendItem26.getSeriesIndex();
        java.lang.String str28 = legendItem26.getDescription();
        java.awt.Paint paint29 = legendItem26.getLinePaint();
        boolean boolean30 = month9.equals((java.lang.Object) paint29);
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "Default Group", "java.awt.Color[r=255,g=175,b=175]", "{0}", shape7, paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Range[0.0,0.0]" + "'", str28.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape(1900);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        columnArrangement5.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator10, false);
        boolean boolean15 = stackedAreaRenderer8.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedAreaRenderer8.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator17, false);
        stackedAreaRenderer8.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23, (java.lang.Comparable) false);
        java.lang.Number number30 = defaultBoxAndWhiskerCategoryDataset23.getMaxRegularValue((java.lang.Comparable) 5, (java.lang.Comparable) (byte) 1);
        try {
            java.lang.Number number33 = defaultBoxAndWhiskerCategoryDataset23.getMeanValue(0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        double double4 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Number number8 = defaultStatisticalCategoryDataset0.getValue((int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boxAndWhiskerRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        stackedAreaRenderer6.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator8, false);
        boolean boolean13 = stackedAreaRenderer6.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        stackedAreaRenderer6.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator15, false);
        stackedAreaRenderer6.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer6, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset21);
        int int24 = defaultBoxAndWhiskerCategoryDataset21.getRowCount();
        try {
            java.lang.String str26 = standardCategorySeriesLabelGenerator3.generateLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset21, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        java.lang.Object obj9 = categoryAxis3D7.clone();
        categoryAxis3D7.setLabelAngle((double) 86400000L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj13 = null;
        boolean boolean14 = categoryLabelPositions12.equals(obj13);
        categoryAxis3D7.setCategoryLabelPositions(categoryLabelPositions12);
        double double16 = categoryAxis3D7.getUpperMargin();
        categoryAxis3D7.setLowerMargin(35.0d);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        xYPlot23.setDomainCrosshairValue(1.0d);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot23.setDomainGridlinePaint((java.awt.Paint) color26);
        java.awt.Color color29 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer33 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean35 = boxAndWhiskerRenderer33.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer33.setBaseItemLabelFont(font36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color39 = java.awt.Color.lightGray;
        boolean boolean40 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color38, (java.awt.Paint) color39);
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font36, (java.awt.Paint) color39);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer42 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer42.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer45.setItemMargin((double) 10L);
        java.awt.Stroke stroke49 = waterfallBarRenderer45.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer42.setBaseStroke(stroke49);
        java.awt.Color color51 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer52 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer52.setItemMargin((double) 10L);
        java.awt.Stroke stroke56 = waterfallBarRenderer52.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color39, stroke49, (java.awt.Paint) color51, stroke56, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke56);
        java.awt.Paint paint60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        valueMarker59.setPaint(paint60);
        xYPlot23.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker59);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean65 = numberAxis64.isInverted();
        xYPlot23.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis64);
        double[] doubleArray70 = new double[] { 1.0E-8d };
        double[] doubleArray72 = new double[] { 1.0E-8d };
        double[] doubleArray74 = new double[] { 1.0E-8d };
        double[] doubleArray76 = new double[] { 1.0E-8d };
        double[] doubleArray78 = new double[] { 1.0E-8d };
        double[] doubleArray80 = new double[] { 1.0E-8d };
        double[][] doubleArray81 = new double[][] { doubleArray70, doubleArray72, doubleArray74, doubleArray76, doubleArray78, doubleArray80 };
        org.jfree.data.category.CategoryDataset categoryDataset82 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Oct", "2-January-1900", doubleArray81);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis64, categoryDataset82, 10, 1, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(categoryDataset82);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection0, jFreeChart1, chartChangeEventType2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        boolean boolean10 = xYPlot9.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot9.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot9.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot9.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot9.getFixedRangeAxisSpace();
        xYPlot9.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot9);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer23 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean25 = boxAndWhiskerRenderer23.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer23.setBaseItemLabelFont(font26);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer28 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font29 = waterfallBarRenderer28.getBaseItemLabelFont();
        double double30 = waterfallBarRenderer28.getUpperClip();
        double double31 = waterfallBarRenderer28.getUpperClip();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color33 = java.awt.Color.lightGray;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color32, (java.awt.Paint) color33);
        waterfallBarRenderer28.setLastBarPaint((java.awt.Paint) color33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font38 = null;
        java.awt.Paint paint39 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (-1.0f), textMeasurer41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock42.setLineAlignment(horizontalAlignment43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock42.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock42.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = textTitle49.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement53 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment48, verticalAlignment50, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets54, (java.awt.Paint) color55);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("{0}", font26, (java.awt.Paint) color33, rectangleEdge36, horizontalAlignment47, verticalAlignment50, rectangleInsets54);
        java.awt.Color color58 = java.awt.Color.WHITE;
        textTitle57.setPaint((java.awt.Paint) color58);
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle57);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener63 = null;
        textTitle61.removeChangeListener(titleChangeListener63);
        textTitle61.setID("CONTRACT");
        textTitle61.setText("Oct");
        jFreeChart21.setTitle(textTitle61);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer71 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator73 = null;
        stackedAreaRenderer71.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator73, false);
        boolean boolean78 = stackedAreaRenderer71.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator80 = null;
        stackedAreaRenderer71.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator80, false);
        stackedAreaRenderer71.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset86 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range87 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset86);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent88 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer71, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset86);
        java.util.List list89 = defaultBoxAndWhiskerCategoryDataset86.getRowKeys();
        jFreeChart21.setSubtitles(list89);
        chartChangeEvent3.setChart(jFreeChart21);
        java.awt.Paint paint92 = null;
        jFreeChart21.setBorderPaint(paint92);
        java.awt.Image image94 = jFreeChart21.getBackgroundImage();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(textBlock42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment50);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(range87);
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNull(image94);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot4.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        org.jfree.chart.plot.Plot plot14 = xYPlot4.getParent();
        xYPlot4.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue(1.0d);
        boolean boolean24 = xYPlot21.isDomainCrosshairVisible();
        float float25 = xYPlot21.getBackgroundAlpha();
        boolean boolean26 = xYPlot21.isRangeCrosshairLockedOnData();
        java.lang.String str27 = xYPlot21.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot21.getDomainAxisLocation();
        xYPlot4.setRangeAxisLocation((int) (byte) 0, axisLocation28, true);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection38 = xYPlot35.getRangeMarkers((int) (short) 1, layer37);
        java.lang.String str39 = layer37.toString();
        java.util.Collection collection40 = xYPlot4.getRangeMarkers(layer37);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection40);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup9 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset8.setGroup(datasetGroup9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset8);
        java.util.List list12 = defaultBoxAndWhiskerCategoryDataset8.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem13 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1, (java.lang.Number) 100.0d, (java.lang.Number) 90.0d, (java.lang.Number) 0.0d, (java.lang.Number) 620L, (java.lang.Number) 520L, (java.lang.Number) (short) 1, (java.lang.Number) 0, list12);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        boolean boolean16 = lineAndShapeRenderer2.getItemLineVisible((int) ' ', 0);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 100, 4 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] {};
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset22 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray20, numberArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        java.awt.Stroke stroke5 = boxAndWhiskerRenderer0.getItemOutlineStroke(1, 3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor10, textAnchor11, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor11, textAnchor14, (double) (short) 10);
        boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition(15, itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.awt.Stroke stroke20 = stackedAreaRenderer1.lookupSeriesOutlineStroke((-620));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent21);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10.0f, 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5, false);
        boolean boolean10 = stackedAreaRenderer3.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedAreaRenderer3.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator12, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedAreaRenderer3.getLegendItemLabelGenerator();
        waterfallBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator15);
        java.awt.Stroke stroke18 = waterfallBarRenderer0.lookupSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = waterfallBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        textTitle0.setID("CONTRACT");
        textTitle0.setWidth(0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle0.getTextAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        double double14 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        int int2 = keyToGroupMap0.getKeyCount((java.lang.Comparable) "2-January-1900");
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        boolean boolean5 = keyToGroupMap0.equals((java.lang.Object) boolean4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator27);
        java.awt.Paint paint29 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset1.setGroup(datasetGroup2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.setNoDataMessage("");
        boolean boolean12 = polarPlot8.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = polarPlot8.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.data.Range range16 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        try {
            java.lang.Number number19 = defaultBoxAndWhiskerCategoryDataset1.getMaxRegularValue(500, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        java.awt.Stroke stroke6 = polarPlot3.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        int int5 = lineAndShapeRenderer2.getRowCount();
        boolean boolean8 = lineAndShapeRenderer2.isItemLabelVisible(7, (int) (byte) 100);
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        try {
            lineAndShapeRenderer2.setSeriesPaint((int) (byte) -1, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue(0, 12, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = minMaxCategoryRenderer0.getGroupPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = lineAndShapeRenderer4.getLegendItems();
        java.lang.Boolean boolean7 = lineAndShapeRenderer4.getSeriesLinesVisible(2);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer4.setSeriesOutlineStroke(10, stroke9, false);
        lineAndShapeRenderer4.setBaseLinesVisible(true);
        lineAndShapeRenderer4.setBaseLinesVisible(true);
        lineAndShapeRenderer4.setBaseLinesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer4.getBaseNegativeItemLabelPosition();
        minMaxCategoryRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        int int2 = month0.compareTo((java.lang.Object) font1);
        java.util.Date date3 = month0.getStart();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat5);
        int int7 = dateTickUnit6.getCalendarField();
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat12);
        int int14 = dateTickUnit13.getRollCount();
        java.lang.String str16 = dateTickUnit13.valueToString(100.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.util.Date date18 = month17.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        java.lang.String str20 = dateTickUnit13.dateToString(date18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.Date date22 = dateTickUnit6.addToDate(date18);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) dateTickUnit6);
        java.text.DateFormat dateFormat28 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat28);
        int int30 = dateTickUnit29.getRollUnit();
        org.jfree.chart.axis.TickUnit tickUnit31 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit29);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12/31/69" + "'", str16.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6/1/19" + "'", str20.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(tickUnit31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getRadiusGridlineStroke();
        java.lang.String str7 = polarPlot3.getPlotType();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Polar Plot" + "'", str7.equals("Polar Plot"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.clearDomainAxes();
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle12.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment13, (double) 7, (double) (-2208927599900L));
        columnArrangement16.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator21, false);
        boolean boolean26 = stackedAreaRenderer19.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        stackedAreaRenderer19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator28, false);
        stackedAreaRenderer19.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34, (java.lang.Comparable) false);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot4, (org.jfree.chart.block.Arrangement) flowArrangement10, (org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = null;
        try {
            legendTitle39.setItemLabelPadding(rectangleInsets40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent67 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle66);
        jFreeChart17.titleChanged(titleChangeEvent67);
        org.jfree.chart.plot.Plot plot69 = jFreeChart17.getPlot();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(plot69);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge5);
        textTitle0.setPosition(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 0L, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 35.0d, false);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, 0.0d, 90.0d);
        java.lang.String str9 = range8.toString();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[35.0,945.0]" + "'", str9.equals("Range[35.0,945.0]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        polarPlot7.setNoDataMessage("");
        boolean boolean11 = polarPlot7.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot7.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        java.awt.Font font15 = null;
        java.awt.Paint paint16 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (-1.0f), textMeasurer18);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock19.setLineAlignment(horizontalAlignment20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D23 = textBlock19.calculateDimensions(graphics2D22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textBlock19.getLineAlignment();
        boolean boolean25 = polarPlot7.equals((java.lang.Object) horizontalAlignment24);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Paint paint7 = xYPlot4.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset(xYDataset8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        try {
            xYPlot4.setRenderer((-620), xYItemRenderer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Oct");
        java.lang.Object obj2 = categoryAxis1.clone();
        categoryAxis1.setLabelURL("({0}, {1}) = {3} - {4}");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.data.Range range15 = polarPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot8);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        numberAxis3D0.setLabelURL("ChartChangeEventType.GENERAL");
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        boolean boolean11 = xYPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot10.setRangeAxes(valueAxisArray12);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer15.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator17, false);
        boolean boolean22 = stackedAreaRenderer15.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        stackedAreaRenderer15.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator24, false);
        stackedAreaRenderer15.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer15, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = lineAndShapeRenderer35.getLegendItems();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer35.setBaseItemLabelPaint((java.awt.Paint) color37);
        stackedAreaRenderer15.setBaseFillPaint((java.awt.Paint) color37, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = null;
        stackedAreaRenderer43.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator45, false);
        boolean boolean50 = stackedAreaRenderer43.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator52 = null;
        stackedAreaRenderer43.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator52, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = stackedAreaRenderer43.getLegendItemLabelGenerator();
        java.awt.Paint paint58 = stackedAreaRenderer43.getItemPaint(12, (int) '#');
        stackedAreaRenderer15.setSeriesOutlinePaint(3, paint58, true);
        java.awt.Stroke stroke62 = stackedAreaRenderer15.lookupSeriesOutlineStroke((int) '#');
        xYPlot10.setRangeGridlineStroke(stroke62);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot10.getDomainAxisEdge(0);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        try {
            numberAxis3D0.zoomRange((double) (short) -1, (-100.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (47.5) <= upper (-3417.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (byte) 0);
        java.lang.String str4 = range3.toString();
        java.lang.String str5 = range3.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (byte) 0);
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.combine(range3, range8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup14 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset13.setGroup(datasetGroup14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset13);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        polarPlot20.setNoDataMessage("");
        boolean boolean24 = polarPlot20.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = polarPlot20.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset13.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot20);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(0.0d, range27);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str30 = lengthConstraintType29.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3, lengthConstraintType10, (double) 100L, range27, lengthConstraintType29);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[0.0,0.0]" + "'", str5.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertEquals((double) number16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraintType.RANGE" + "'", str30.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("Range[0.0,0.0]");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean2 = boxAndWhiskerRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.jfree.chart.LegendItem legendItem5 = boxAndWhiskerRenderer0.getLegendItem(11, 6);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot3.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot3.getOrientation();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        piePlot0.setOutlineVisible(true);
        java.awt.Paint paint46 = piePlot0.getLabelShadowPaint();
        java.awt.Paint paint47 = piePlot0.getLabelBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset48 = piePlot0.getDataset();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(pieDataset48);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        java.awt.Paint paint43 = piePlot0.getLabelShadowPaint();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer44 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean46 = boxAndWhiskerRenderer44.getSeriesVisibleInLegend((int) (short) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boxAndWhiskerRenderer44.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator47);
        java.awt.Paint paint51 = boxAndWhiskerRenderer44.getItemLabelPaint((-620), 0);
        piePlot0.setLabelLinkPaint(paint51);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(boolean46);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Paint paint7 = xYPlot4.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset(xYDataset8);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((java.lang.Comparable) numberTickUnit4, (java.lang.Comparable) 52);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, (double) (short) 0);
        double double3 = barRenderer3D2.getYOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Range[35.0,945.0]", "Layer.FOREGROUND", "", "CONTRACT", "CONTRACT");
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        java.awt.Font font5 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setAutoRangeMinimumSize((double) (byte) 10, false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean6 = boxAndWhiskerRenderer4.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer4.setBaseItemLabelFont(font7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color10 = java.awt.Color.lightGray;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color9, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font7, (java.awt.Paint) color10);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer13.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer16 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer16.setItemMargin((double) 10L);
        java.awt.Stroke stroke20 = waterfallBarRenderer16.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer13.setBaseStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer23.setItemMargin((double) 10L);
        java.awt.Stroke stroke27 = waterfallBarRenderer23.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color10, stroke20, (java.awt.Paint) color22, stroke27, (float) (byte) 1);
        double double30 = intervalMarker29.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType31, jFreeChart32);
        intervalMarker29.setLabelOffsetType(lengthAdjustmentType31);
        boolean boolean35 = categoryAnchor0.equals((java.lang.Object) intervalMarker29);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets();
        double double38 = rectangleInsets36.calculateTopInset(100.0d);
        intervalMarker29.setLabelOffset(rectangleInsets36);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Paint paint1 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        java.awt.Paint paint2 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.clearDomainAxes();
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle12.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment13, (double) 7, (double) (-2208927599900L));
        columnArrangement16.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator21, false);
        boolean boolean26 = stackedAreaRenderer19.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        stackedAreaRenderer19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator28, false);
        stackedAreaRenderer19.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34, (java.lang.Comparable) false);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot4, (org.jfree.chart.block.Arrangement) flowArrangement10, (org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle39.setItemLabelPadding(rectangleInsets40);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.clearDomainAxes();
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle12.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment13, (double) 7, (double) (-2208927599900L));
        columnArrangement16.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator21, false);
        boolean boolean26 = stackedAreaRenderer19.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        stackedAreaRenderer19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator28, false);
        stackedAreaRenderer19.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34, (java.lang.Comparable) false);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot4, (org.jfree.chart.block.Arrangement) flowArrangement10, (org.jfree.chart.block.Arrangement) columnArrangement16);
        columnArrangement16.clear();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        double double3 = waterfallBarRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11, false);
        boolean boolean16 = stackedAreaRenderer9.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer9.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        stackedAreaRenderer9.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer9, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = lineAndShapeRenderer29.getLegendItems();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer29.setBaseItemLabelPaint((java.awt.Paint) color31);
        stackedAreaRenderer9.setBaseFillPaint((java.awt.Paint) color31, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer37.getLegendItemLabelGenerator();
        java.awt.Paint paint52 = stackedAreaRenderer37.getItemPaint(12, (int) '#');
        stackedAreaRenderer9.setSeriesOutlinePaint(3, paint52, true);
        java.awt.Stroke stroke56 = stackedAreaRenderer9.lookupSeriesOutlineStroke((int) '#');
        xYPlot4.setRangeGridlineStroke(stroke56);
        org.jfree.chart.axis.AxisSpace axisSpace58 = xYPlot4.getFixedDomainAxisSpace();
        xYPlot4.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(axisSpace58);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Stroke stroke7 = xYPlot4.getRangeZeroBaselineStroke();
        xYPlot4.setRangeZeroBaselineVisible(false);
        xYPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getSeriesIndex();
        boolean boolean17 = legendItem15.isShapeOutlineVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = legendItem15.getFillPaintTransformer();
        legendItem15.setDatasetIndex(0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        int int3 = numberTickUnit1.compareTo((java.lang.Object) paint2);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor2, textAnchor3, (double) 0.0f);
        java.lang.Object obj6 = numberTick5.clone();
        java.lang.String str7 = numberTick5.getText();
        double double8 = numberTick5.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 620.0d + "'", double8 == 620.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month9);
        defaultKeyedValues2D1.addValue((java.lang.Number) 1.0E-8d, (java.lang.Comparable) '4', (java.lang.Comparable) 10.0f);
        java.lang.Object obj15 = null;
        boolean boolean16 = defaultKeyedValues2D1.equals(obj15);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot4.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        xYPlot4.axisChanged(axisChangeEvent14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        boolean boolean8 = verticalAlignment3.equals((java.lang.Object) blockContainer7);
        boolean boolean9 = blockContainer7.isEmpty();
        blockContainer7.setHeight(0.05d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (double) (byte) 0);
        java.lang.String str16 = range15.toString();
        java.lang.String str17 = range15.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range15, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint19.toUnconstrainedWidth();
        double double21 = rectangleConstraint20.getWidth();
        org.jfree.chart.util.Size2D size2D22 = flowArrangement0.arrange(blockContainer7, graphics2D12, rectangleConstraint20);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[0.0,0.0]" + "'", str16.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[0.0,0.0]" + "'", str17.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list5 = taskSeriesCollection4.getRowKeys();
        taskSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.setNoDataMessage("");
        boolean boolean7 = polarPlot4.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextOutlinePaint();
        polarPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Stroke stroke12 = defaultDrawingSupplier9.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint0, stroke12, rectangleInsets13);
        double double18 = rectangleInsets13.calculateRightInset((double) (-2208927599900L));
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.setNoDataMessage("");
        boolean boolean7 = polarPlot4.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextOutlinePaint();
        polarPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Stroke stroke12 = defaultDrawingSupplier9.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint0, stroke12, rectangleInsets13);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        int int19 = defaultBoxAndWhiskerCategoryDataset17.getRowCount();
        int int21 = defaultBoxAndWhiskerCategoryDataset17.getRowIndex((java.lang.Comparable) "hi!");
        boolean boolean22 = lineBorder16.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset17);
        java.text.DateFormat dateFormat27 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat27);
        int int29 = dateTickUnit28.getCalendarField();
        java.lang.Number number31 = defaultBoxAndWhiskerCategoryDataset17.getMedianValue((java.lang.Comparable) int29, (java.lang.Comparable) 100.0d);
        defaultBoxAndWhiskerCategoryDataset17.validateObject();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(number31);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        polarPlot7.setNoDataMessage("");
        boolean boolean11 = polarPlot7.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot7.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        java.awt.Stroke stroke14 = polarPlot7.getRadiusGridlineStroke();
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateTopInset(100.0d);
        intervalMarker2.setLabelOffset(rectangleInsets3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = intervalMarker2.getLabelAnchor();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.setDomainCrosshairValue(0.0d, true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) '4', (double) 10, 12);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) 100, 0.0d, 12);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) pieDataset3, jFreeChart12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double15 = piePlot14.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint11 = stackedAreaRenderer1.getItemLabelPaint(3, (int) 'a');
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font16 = waterfallBarRenderer15.getBaseItemLabelFont();
        double double17 = waterfallBarRenderer15.getUpperClip();
        java.awt.Paint paint18 = waterfallBarRenderer15.getLastBarPaint();
        java.awt.Stroke stroke19 = waterfallBarRenderer15.getBaseOutlineStroke();
        boolean boolean22 = waterfallBarRenderer15.getItemCreateEntity((-1), 1);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font24 = waterfallBarRenderer23.getBaseItemLabelFont();
        double double25 = waterfallBarRenderer23.getUpperClip();
        java.awt.Paint paint26 = waterfallBarRenderer23.getNegativeBarPaint();
        waterfallBarRenderer15.setPositiveBarPaint(paint26);
        boolean boolean28 = stackedAreaRenderer1.equals((java.lang.Object) waterfallBarRenderer15);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.util.List list9 = blockContainer8.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, (java.lang.Number) (byte) 0, (java.lang.Number) 5, (java.lang.Number) (short) 1, (java.lang.Number) 5, (java.lang.Number) 11, (java.lang.Number) Double.NaN, (java.lang.Number) 8.0d, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMinRegularValue();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 5 + "'", number11.equals(5));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = boxAndWhiskerRenderer0.getPositiveItemLabelPosition((int) (short) 0, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = boxAndWhiskerRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = boxAndWhiskerRenderer0.getSeriesToolTipGenerator(100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        boxAndWhiskerRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        boxAndWhiskerRenderer0.setSeriesItemLabelGenerator(11, categoryItemLabelGenerator16);
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean12 = boxAndWhiskerRenderer10.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 86400000L, (double) 1, Double.NaN, (double) 2, font13);
        double double16 = numberAxis3D0.getFixedAutoRange();
        double double17 = numberAxis3D0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-8d + "'", double17 == 1.0E-8d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer21.getLegendItems();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer21.setBaseItemLabelPaint((java.awt.Paint) color23);
        stackedAreaRenderer1.setBaseFillPaint((java.awt.Paint) color23, false);
        org.jfree.chart.LegendItem legendItem29 = stackedAreaRenderer1.getLegendItem(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(legendItem29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getValue((-620), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("12/31/69");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 12/31/69");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 0L, (double) 10.0f);
        double double4 = range2.constrain((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot4.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.data.Range range11 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D7);
        java.awt.Font font12 = polarPlot4.getAngleLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("Range[35.0,45.0]", font12, paint13);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D0.setLeftArrow(shape3);
        org.jfree.chart.axis.TickUnits tickUnits5 = new org.jfree.chart.axis.TickUnits();
        numberAxis3D0.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits5);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot3.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot3.getRenderer();
        java.lang.String str9 = polarPlot3.getPlotType();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor2, textAnchor3, (double) 0.0f);
        java.lang.Object obj6 = numberTick5.clone();
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick5.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) (byte) -1, (double) 12, 35.0d, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat5);
        int int7 = dateTickUnit6.getRollCount();
        java.lang.String str9 = dateTickUnit6.valueToString(100.0d);
        java.lang.String str11 = dateTickUnit6.valueToString(1.0d);
        try {
            org.jfree.chart.axis.TickUnit tickUnit12 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "12/31/69" + "'", str9.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "12/31/69" + "'", str11.equals("12/31/69"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        numberAxis3D0.setLabelURL("ChartChangeEventType.GENERAL");
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        boolean boolean11 = xYPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot10.setRangeAxes(valueAxisArray12);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        stackedAreaRenderer15.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator17, false);
        boolean boolean22 = stackedAreaRenderer15.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        stackedAreaRenderer15.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator24, false);
        stackedAreaRenderer15.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer15, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = lineAndShapeRenderer35.getLegendItems();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer35.setBaseItemLabelPaint((java.awt.Paint) color37);
        stackedAreaRenderer15.setBaseFillPaint((java.awt.Paint) color37, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = null;
        stackedAreaRenderer43.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator45, false);
        boolean boolean50 = stackedAreaRenderer43.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator52 = null;
        stackedAreaRenderer43.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator52, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = stackedAreaRenderer43.getLegendItemLabelGenerator();
        java.awt.Paint paint58 = stackedAreaRenderer43.getItemPaint(12, (int) '#');
        stackedAreaRenderer15.setSeriesOutlinePaint(3, paint58, true);
        java.awt.Stroke stroke62 = stackedAreaRenderer15.lookupSeriesOutlineStroke((int) '#');
        xYPlot10.setRangeGridlineStroke(stroke62);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot10.getDomainAxisEdge(0);
        numberAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer69 = null;
        org.jfree.chart.plot.PolarPlot polarPlot70 = new org.jfree.chart.plot.PolarPlot(xYDataset67, valueAxis68, polarItemRenderer69);
        polarPlot70.setNoDataMessage("");
        boolean boolean73 = polarPlot70.isRangeZoomable();
        java.awt.Paint paint74 = polarPlot70.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier75 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint76 = defaultDrawingSupplier75.getNextOutlinePaint();
        polarPlot70.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier75);
        java.awt.Stroke stroke78 = defaultDrawingSupplier75.getNextStroke();
        xYPlot10.setDomainGridlineStroke(stroke78);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        categoryAxis3D1.setMaximumCategoryLabelLines((int) '4');
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.Object obj1 = null;
        boolean boolean2 = sortOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE2" + "'", str1.equals("ItemLabelAnchor.OUTSIDE2"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        taskSeries1.removeAll();
        org.jfree.data.gantt.Task task5 = null;
        try {
            taskSeries1.add(task5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'task' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer2.setBaseCreateEntities(true);
        boxAndWhiskerRenderer2.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = boxAndWhiskerRenderer2.getPositiveItemLabelPosition((int) (short) 0, 0);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean12 = itemLabelPosition10.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.Number number14 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) year11, (java.lang.Comparable) year13);
        long long15 = year11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.lang.String str3 = labelBlock1.getToolTipText();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font8 = numberAxis3D4.getTickLabelFont();
        java.awt.Font font9 = numberAxis3D4.getTickLabelFont();
        labelBlock1.setFont(font9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.awt.Stroke stroke20 = stackedAreaRenderer1.lookupSeriesOutlineStroke((-620));
        boolean boolean21 = stackedAreaRenderer1.getRenderAsPercentages();
        boolean boolean22 = stackedAreaRenderer1.getRenderAsPercentages();
        stackedAreaRenderer1.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', (int) (byte) 1, 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean7 = polarPlot3.equals((java.lang.Object) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot12.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot12.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot12.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot12.getFixedRangeAxisSpace();
        xYPlot12.setRangeCrosshairValue((double) 1);
        polarPlot3.setParent((org.jfree.chart.plot.Plot) xYPlot12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        java.lang.String str2 = datasetGroup0.getID();
        java.lang.Object obj3 = datasetGroup0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        java.awt.Paint paint3 = waterfallBarRenderer0.getNegativeBarPaint();
        java.awt.Paint paint4 = waterfallBarRenderer0.getPositiveBarPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle57.getPosition();
        java.awt.Paint paint62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle57.setPaint(paint62);
        jFreeChart17.removeSubtitle((org.jfree.chart.title.Title) textTitle57);
        org.jfree.chart.plot.XYPlot xYPlot65 = jFreeChart17.getXYPlot();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(xYPlot65);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font2 = labelBlock1.getFont();
        java.lang.Object obj3 = null;
        boolean boolean4 = labelBlock1.equals(obj3);
        labelBlock1.setURLText("");
        labelBlock1.setURLText("6/1/19");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator12, false);
        boolean boolean17 = stackedAreaRenderer10.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        stackedAreaRenderer10.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator19, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = stackedAreaRenderer10.getLegendItemLabelGenerator();
        java.awt.Paint paint25 = stackedAreaRenderer10.getItemPaint(12, (int) '#');
        stackedAreaRenderer10.setRenderAsPercentages(true);
        java.awt.Color color28 = java.awt.Color.WHITE;
        stackedAreaRenderer10.setBaseFillPaint((java.awt.Paint) color28);
        labelBlock1.setPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        dateAxis0.setMinimumDate(date6);
        java.awt.Color color9 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean12 = blockBorder10.equals((java.lang.Object) shape11);
        dateAxis0.setDownArrow(shape11);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelPositions0.equals(obj1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj7 = null;
        boolean boolean8 = categoryLabelPositions6.equals(obj7);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions6, categoryLabelPosition9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions5, categoryLabelPosition9);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition13.getCategoryAnchor();
        float float15 = categoryLabelPosition13.getWidthRatio();
        double double16 = categoryLabelPosition13.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition12, categoryLabelPosition13);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.95f + "'", float15 == 0.95f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str46 = serialDate45.toString();
        java.awt.Paint paint47 = piePlot0.getSectionPaint((java.lang.Comparable) serialDate45);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean50 = waterfallBarRenderer48.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot(xYDataset52, valueAxis53, polarItemRenderer54);
        java.awt.Color color56 = java.awt.Color.pink;
        polarPlot55.setBackgroundPaint((java.awt.Paint) color56);
        java.awt.Stroke stroke58 = polarPlot55.getAngleGridlineStroke();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot55.setAngleLabelPaint((java.awt.Paint) color59);
        waterfallBarRenderer48.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color59);
        piePlot0.setLabelPaint((java.awt.Paint) color59);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle57.getPosition();
        java.awt.Paint paint62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle57.setPaint(paint62);
        jFreeChart17.removeSubtitle((org.jfree.chart.title.Title) textTitle57);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot65 = jFreeChart17.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Stroke stroke4 = waterfallBarRenderer0.lookupSeriesStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font6 = waterfallBarRenderer5.getBaseItemLabelFont();
        boolean boolean8 = waterfallBarRenderer5.isSeriesItemLabelsVisible((int) (short) -1);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer14.setItemMargin((double) 10L);
        java.awt.Stroke stroke18 = waterfallBarRenderer14.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer14.setAutoPopulateSeriesPaint(true);
        java.awt.Shape shape23 = waterfallBarRenderer14.getItemShape(1, 12);
        java.awt.Color color25 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer29 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean31 = boxAndWhiskerRenderer29.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer29.setBaseItemLabelFont(font32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color35 = java.awt.Color.lightGray;
        boolean boolean36 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color34, (java.awt.Paint) color35);
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font32, (java.awt.Paint) color35);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer38 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer38.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer41 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer41.setItemMargin((double) 10L);
        java.awt.Stroke stroke45 = waterfallBarRenderer41.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer38.setBaseStroke(stroke45);
        java.awt.Color color47 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer48.setItemMargin((double) 10L);
        java.awt.Stroke stroke52 = waterfallBarRenderer48.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color35, stroke45, (java.awt.Paint) color47, stroke52, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke52);
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("{0}", "WMAP_Plot", "", "ChartChangeEventType.GENERAL", shape23, (java.awt.Paint) color25);
        waterfallBarRenderer5.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color25, false);
        waterfallBarRenderer0.setLastBarPaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        polarPlot19.setNoDataMessage("");
        boolean boolean22 = polarPlot19.isRangeZoomable();
        java.awt.Paint paint23 = polarPlot19.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        polarPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        java.awt.Stroke stroke27 = defaultDrawingSupplier24.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double30 = rectangleInsets28.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder(paint15, stroke27, rectangleInsets28);
        lineAndShapeRenderer2.setBaseStroke(stroke27, true);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator35 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        lineAndShapeRenderer2.setSeriesToolTipGenerator(4, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator35, true);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        xYPlot4.mapDatasetToDomainAxis((int) '#', 10);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        xYPlot4.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        java.lang.Object obj63 = textTitle57.clone();
        textTitle57.setExpandToFitSpace(true);
        jFreeChart17.setTitle(textTitle57);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setHeight(0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis((int) 'a');
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot4.getFixedRangeAxisSpace();
        xYPlot4.setDomainCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer2.setBaseOutlineStroke(stroke3, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        polarPlot10.setNoDataMessage("");
        boolean boolean13 = polarPlot10.isRangeZoomable();
        java.awt.Paint paint14 = polarPlot10.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextOutlinePaint();
        polarPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Stroke stroke18 = defaultDrawingSupplier15.getNextStroke();
        stackedAreaRenderer2.setSeriesStroke(0, stroke18);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke18);
        ringPlot0.setSeparatorStroke(stroke18);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot3.getOrientation();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer11 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean13 = boxAndWhiskerRenderer11.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer11.setBaseItemLabelFont(font14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color17 = java.awt.Color.lightGray;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font14, (java.awt.Paint) color17);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer20.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer23.setItemMargin((double) 10L);
        java.awt.Stroke stroke27 = waterfallBarRenderer23.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer20.setBaseStroke(stroke27);
        java.awt.Color color29 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer30 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer30.setItemMargin((double) 10L);
        java.awt.Stroke stroke34 = waterfallBarRenderer30.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color17, stroke27, (java.awt.Paint) color29, stroke34, (float) (byte) 1);
        double double37 = intervalMarker36.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType38, jFreeChart39);
        intervalMarker36.setLabelOffsetType(lengthAdjustmentType38);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        intervalMarker36.notifyListeners(markerChangeEvent42);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.LegendItemCollection legendItemCollection45 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType47 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection45, jFreeChart46, chartChangeEventType47);
        boolean boolean49 = lengthAdjustmentType44.equals((java.lang.Object) chartChangeEvent48);
        intervalMarker36.setLabelOffsetType(lengthAdjustmentType44);
        boolean boolean51 = polarPlot3.equals((java.lang.Object) lengthAdjustmentType44);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType38);
        org.junit.Assert.assertNotNull(lengthAdjustmentType44);
        org.junit.Assert.assertNotNull(chartChangeEventType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit7);
        float float9 = numberAxis3D0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer21.getLegendItems();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer21.setBaseItemLabelPaint((java.awt.Paint) color23);
        stackedAreaRenderer1.setBaseFillPaint((java.awt.Paint) color23, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        stackedAreaRenderer29.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator31, false);
        boolean boolean36 = stackedAreaRenderer29.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = null;
        stackedAreaRenderer29.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator38, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = stackedAreaRenderer29.getLegendItemLabelGenerator();
        java.awt.Paint paint44 = stackedAreaRenderer29.getItemPaint(12, (int) '#');
        stackedAreaRenderer1.setSeriesOutlinePaint(3, paint44, true);
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset54, valueAxis55, polarItemRenderer56);
        java.awt.Color color58 = java.awt.Color.pink;
        polarPlot57.setBackgroundPaint((java.awt.Paint) color58);
        java.awt.Stroke stroke60 = polarPlot57.getRadiusGridlineStroke();
        java.awt.Color color61 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape52, (java.awt.Paint) color53, stroke60, (java.awt.Paint) color61);
        int int63 = legendItem62.getSeriesIndex();
        boolean boolean64 = legendItem62.isShapeOutlineVisible();
        boolean boolean65 = stackedAreaRenderer1.equals((java.lang.Object) legendItem62);
        legendItem62.setSeriesIndex((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint11 = stackedAreaRenderer1.getItemLabelPaint(3, (int) 'a');
        stackedAreaRenderer1.setRenderAsPercentages(true);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer16 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean18 = boxAndWhiskerRenderer16.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer16.setBaseItemLabelFont(font19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color22 = java.awt.Color.lightGray;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color21, (java.awt.Paint) color22);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font19, (java.awt.Paint) color22);
        textLine14.removeFragment(textFragment24);
        java.awt.Font font26 = textFragment24.getFont();
        stackedAreaRenderer1.setBaseItemLabelFont(font26, false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        double double5 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        java.awt.Stroke stroke8 = xYPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        textTitle0.setHeight((double) (byte) 0);
        java.lang.String str5 = textTitle0.getURLText();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle0.getFrame();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month9);
        defaultKeyedValues2D1.addValue((java.lang.Number) 1.0E-8d, (java.lang.Comparable) '4', (java.lang.Comparable) 10.0f);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer18 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean20 = boxAndWhiskerRenderer18.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer18.setBaseItemLabelFont(font21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color24 = java.awt.Color.lightGray;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color23, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font21, (java.awt.Paint) color24);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer27.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer30 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer30.setItemMargin((double) 10L);
        java.awt.Stroke stroke34 = waterfallBarRenderer30.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer27.setBaseStroke(stroke34);
        java.awt.Color color36 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer37 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer37.setItemMargin((double) 10L);
        java.awt.Stroke stroke41 = waterfallBarRenderer37.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color24, stroke34, (java.awt.Paint) color36, stroke41, (float) (byte) 1);
        boolean boolean44 = defaultKeyedValues2D1.equals((java.lang.Object) intervalMarker43);
        org.jfree.chart.util.ObjectList objectList47 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj49 = objectList47.get(12);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(3);
        objectList47.set((int) (byte) 10, (java.lang.Object) serialDate52);
        defaultKeyedValues2D1.addValue((java.lang.Number) 2019, (java.lang.Comparable) "Layer.FOREGROUND", (java.lang.Comparable) serialDate52);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double8 = numberAxis3D0.java2DToValue((double) 100L, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getColumnKeys();
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) '#');
        int int6 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5, (java.lang.Comparable) (-2208927599900L));
        double double10 = defaultBoxAndWhiskerCategoryDataset5.getRangeUpperBound(false);
        java.util.List list13 = defaultBoxAndWhiskerCategoryDataset5.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap14 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset5, keyToGroupMap14);
        numberAxis3D0.setDefaultAutoRange(range15);
        double double17 = numberAxis3D0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot4.getOrientation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        xYPlot17.setDomainCrosshairValue(1.0d);
        boolean boolean20 = xYPlot17.isDomainCrosshairVisible();
        float float21 = xYPlot17.getBackgroundAlpha();
        boolean boolean22 = xYPlot17.isRangeCrosshairLockedOnData();
        java.lang.String str23 = xYPlot17.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot17.getDomainAxisLocation();
        xYPlot4.setRangeAxisLocation(axisLocation24, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "XY Plot" + "'", str23.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Paint paint1 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        java.lang.Object obj2 = null;
        boolean boolean3 = statisticalLineAndShapeRenderer0.equals(obj2);
        boolean boolean5 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        double double3 = numberAxis3D0.getFixedAutoRange();
        numberAxis3D0.resizeRange((double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.lang.String str3 = labelBlock1.getToolTipText();
        labelBlock1.setURLText("Layer.FOREGROUND");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj5 = categoryAxis3D4.clone();
        java.lang.Object obj6 = categoryAxis3D4.clone();
        categoryAxis3D4.setLabelAngle((double) 86400000L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj10 = null;
        boolean boolean11 = categoryLabelPositions9.equals(obj10);
        categoryAxis3D4.setCategoryLabelPositions(categoryLabelPositions9);
        double double13 = categoryAxis3D4.getUpperMargin();
        categoryAxis3D4.setLowerMargin(35.0d);
        categoryAxis3D4.setMaximumCategoryLabelLines((int) '4');
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setPositiveArrowVisible(false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        numberAxis3D18.setTickMarkStroke(stroke21);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean24 = waterfallBarRenderer23.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        stackedAreaRenderer26.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator28, false);
        boolean boolean33 = stackedAreaRenderer26.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = null;
        stackedAreaRenderer26.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator35, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedAreaRenderer26.getLegendItemLabelGenerator();
        waterfallBarRenderer23.setLegendItemURLGenerator(categorySeriesLabelGenerator38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.renderer.category.CategoryItemRenderer) waterfallBarRenderer23);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot(xYDataset41, valueAxis42, polarItemRenderer43);
        java.awt.Color color45 = java.awt.Color.pink;
        polarPlot44.setBackgroundPaint((java.awt.Paint) color45);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = polarPlot44.getLegendItems();
        categoryPlot40.setFixedLegendItems(legendItemCollection47);
        categoryPlot40.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(legendItemCollection47);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.awt.Paint paint0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "WMAP_Plot" + "'", str7.equals("WMAP_Plot"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 620L, (java.lang.Comparable) Double.NaN);
        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener59 = null;
        textTitle57.removeChangeListener(titleChangeListener59);
        textTitle57.setID("CONTRACT");
        textTitle57.setText("Oct");
        jFreeChart17.setTitle(textTitle57);
        org.jfree.chart.axis.AxisState axisState66 = new org.jfree.chart.axis.AxisState();
        axisState66.cursorUp(100.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer70 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator72 = null;
        stackedAreaRenderer70.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator72, false);
        boolean boolean77 = stackedAreaRenderer70.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator79 = null;
        stackedAreaRenderer70.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator79, false);
        stackedAreaRenderer70.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset85 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range86 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset85);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent87 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer70, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset85);
        java.util.List list88 = defaultBoxAndWhiskerCategoryDataset85.getRowKeys();
        axisState66.setTicks(list88);
        java.util.List list90 = axisState66.getTicks();
        jFreeChart17.setSubtitles(list90);
        java.awt.Graphics2D graphics2D92 = null;
        java.awt.geom.Rectangle2D rectangle2D93 = null;
        java.awt.geom.Point2D point2D94 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo95 = null;
        try {
            jFreeChart17.draw(graphics2D92, rectangle2D93, point2D94, chartRenderingInfo95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(range86);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(list90);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        taskSeries1.setDescription("XY Plot");
        taskSeries1.setKey((java.lang.Comparable) 3.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("hi!");
        boolean boolean3 = stackedBarRenderer0.equals((java.lang.Object) textLine2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        boolean boolean9 = xYPlot8.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot8.getRangeAxis((int) 'a');
        stackedBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot8);
        stackedBarRenderer0.setRenderAsPercentages(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        stackedAreaRenderer1.setRenderAsPercentages(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = stackedAreaRenderer1.getBaseURLGenerator();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean24 = boxAndWhiskerRenderer22.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer22.setBaseItemLabelFont(font25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color28 = java.awt.Color.lightGray;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color27, (java.awt.Paint) color28);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font25, (java.awt.Paint) color28);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer31 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer31.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer34 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer34.setItemMargin((double) 10L);
        java.awt.Stroke stroke38 = waterfallBarRenderer34.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer31.setBaseStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer41 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer41.setItemMargin((double) 10L);
        java.awt.Stroke stroke45 = waterfallBarRenderer41.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color28, stroke38, (java.awt.Paint) color40, stroke45, (float) (byte) 1);
        stackedAreaRenderer1.setBaseOutlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month3.previous();
        long long28 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month9);
        defaultKeyedValues2D1.addValue((java.lang.Number) 1.0E-8d, (java.lang.Comparable) '4', (java.lang.Comparable) 10.0f);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer18 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean20 = boxAndWhiskerRenderer18.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer18.setBaseItemLabelFont(font21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color24 = java.awt.Color.lightGray;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color23, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font21, (java.awt.Paint) color24);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer27.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer30 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer30.setItemMargin((double) 10L);
        java.awt.Stroke stroke34 = waterfallBarRenderer30.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer27.setBaseStroke(stroke34);
        java.awt.Color color36 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer37 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer37.setItemMargin((double) 10L);
        java.awt.Stroke stroke41 = waterfallBarRenderer37.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color24, stroke34, (java.awt.Paint) color36, stroke41, (float) (byte) 1);
        boolean boolean44 = defaultKeyedValues2D1.equals((java.lang.Object) intervalMarker43);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        piePlot45.setPieIndex(0);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.util.Date date49 = month48.getStart();
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer59 = null;
        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot(xYDataset57, valueAxis58, polarItemRenderer59);
        java.awt.Color color61 = java.awt.Color.pink;
        polarPlot60.setBackgroundPaint((java.awt.Paint) color61);
        java.awt.Stroke stroke63 = polarPlot60.getRadiusGridlineStroke();
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape55, (java.awt.Paint) color56, stroke63, (java.awt.Paint) color64);
        int int66 = legendItem65.getSeriesIndex();
        java.lang.String str67 = legendItem65.getDescription();
        java.awt.Paint paint68 = legendItem65.getLinePaint();
        boolean boolean69 = month48.equals((java.lang.Object) paint68);
        piePlot45.setExplodePercent((java.lang.Comparable) month48, (double) 10);
        piePlot45.setStartAngle((double) 0.0f);
        piePlot45.setLabelGap((double) 0.0f);
        java.awt.Paint paint76 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        piePlot45.setShadowPaint(paint76);
        java.awt.Paint paint78 = null;
        piePlot45.setLabelShadowPaint(paint78);
        intervalMarker43.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot45);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Range[0.0,0.0]" + "'", str67.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(paint76);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setPieIndex(0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        java.awt.Color color17 = java.awt.Color.pink;
        polarPlot16.setBackgroundPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = polarPlot16.getRadiusGridlineStroke();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape11, (java.awt.Paint) color12, stroke19, (java.awt.Paint) color20);
        int int22 = legendItem21.getSeriesIndex();
        java.lang.String str23 = legendItem21.getDescription();
        java.awt.Paint paint24 = legendItem21.getLinePaint();
        boolean boolean25 = month4.equals((java.lang.Object) paint24);
        piePlot1.setExplodePercent((java.lang.Comparable) month4, (double) 10);
        piePlot1.setStartAngle((double) 0.0f);
        piePlot1.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset35, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot1.setDataset(pieDataset39);
        piePlot1.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator44 = piePlot1.getURLGenerator();
        piePlot1.setOutlineVisible(true);
        java.awt.Paint paint47 = piePlot1.getLabelShadowPaint();
        java.awt.Paint paint48 = piePlot1.getLabelBackgroundPaint();
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart("TextBlockAnchor.BOTTOM_CENTER", (org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Range[0.0,0.0]" + "'", str23.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.0d + "'", number33.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertNull(pieURLGenerator44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        lineAndShapeRenderer2.setSeriesShapesFilled(7, false);
        boolean boolean8 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(3.0d, 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.setAngleLabelsVisible(true);
        java.awt.Image image11 = polarPlot8.getBackgroundImage();
        boolean boolean12 = numberAxis3D0.hasListener((java.util.EventListener) polarPlot8);
        numberAxis3D0.setRangeAboutValue((double) 500, (double) 100L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range2, range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range8);
        boolean boolean11 = dateRange9.contains(0.0d);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) 0, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 4, (java.lang.Number) 620L, (java.lang.Number) 1.0E-5d, (java.lang.Number) 2, (java.lang.Number) 1.0E-5d, (java.lang.Number) 15, (java.lang.Number) (byte) 0, (java.lang.Number) (-1), list9);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.setNoDataMessage("");
        boolean boolean7 = polarPlot4.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextOutlinePaint();
        polarPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Stroke stroke12 = defaultDrawingSupplier9.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint0, stroke12, rectangleInsets13);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) '4');
        java.awt.Stroke stroke20 = intervalMarker19.getStroke();
        java.lang.String str21 = intervalMarker19.getLabel();
        boolean boolean22 = lineBorder16.equals((java.lang.Object) intervalMarker19);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            lineBorder16.draw(graphics2D23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        numberAxis3D0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        boolean boolean9 = numberAxis3D0.equals((java.lang.Object) categoryLabelPositions8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = piePlot0.getURLGenerator();
        piePlot0.setOutlineVisible(true);
        java.awt.Paint paint46 = piePlot0.getLabelShadowPaint();
        java.awt.Paint paint47 = piePlot0.getLabelBackgroundPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator48 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator48);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNull(pieURLGenerator43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Oct");
        labelBlock1.setPadding((double) (short) 1, 0.2d, (double) (short) 1, (-100.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = labelBlock1.getPadding();
        double double9 = rectangleInsets7.trimWidth((double) 900000L);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 900099.8d + "'", double9 == 900099.8d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryLabelPositions1.equals(obj2);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition4.getLabelAnchor();
        java.awt.Color color9 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer13 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean15 = boxAndWhiskerRenderer13.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer13.setBaseItemLabelFont(font16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color19 = java.awt.Color.lightGray;
        boolean boolean20 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color18, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font16, (java.awt.Paint) color19);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer25 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer25.setItemMargin((double) 10L);
        java.awt.Stroke stroke29 = waterfallBarRenderer25.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer22.setBaseStroke(stroke29);
        java.awt.Color color31 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer32 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer32.setItemMargin((double) 10L);
        java.awt.Stroke stroke36 = waterfallBarRenderer32.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color19, stroke29, (java.awt.Paint) color31, stroke36, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke36);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        valueMarker39.setPaint(paint40);
        boolean boolean42 = categoryLabelPosition4.equals((java.lang.Object) paint40);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }
}

