import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor2, textAnchor3, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (short) 10, 0, 10, (int) (byte) 100, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 10, (int) '4', (int) (byte) 10);
        java.util.Date date4 = null;
        try {
            segmentedTimeline3.addBaseTimelineException(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0L, jFreeChart1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(10.0d, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            boxAndWhiskerRenderer0.drawOutline(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        java.awt.Shape shape3 = null;
        try {
            boxAndWhiskerRenderer0.setBaseShape(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.Point point8 = polarPlot3.translateValueThetaRadiusToJava2D((double) 10.0f, 0.0d, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 10, (int) '4', (int) (byte) 10);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (-1.0f));
        long long7 = segmentedTimeline3.toTimelineValue(0L);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        java.util.Date date10 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline3.getSegment(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (byte) 0);
        java.lang.String str4 = range3.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) (byte) 0);
        java.lang.String str10 = range9.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3, lengthConstraintType5, (double) ' ', range9, lengthConstraintType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = java.awt.Color.lightGray;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color1);
        java.awt.color.ColorSpace colorSpace3 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1, 100.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.String[] strArray5 = new java.lang.String[] { "Range[0.0,0.0]", "hi!", "", "hi!", "" };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 100.0f, 100.0d, (byte) -1, 2, 86400000L, 10.0f };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 100.0f, 100.0d, (byte) -1, 2, 86400000L, 10.0f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 100.0f, 100.0d, (byte) -1, 2, 86400000L, 10.0f };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 100.0f, 100.0d, (byte) -1, 2, 86400000L, 10.0f };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray12, numberArray19, numberArray26, numberArray33 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 0, 0.05d, 100.0f, (short) -1, (-2208927599900L), 86400000L };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray41 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset43 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray5, numberArray34, numberArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        java.lang.Object obj9 = stackedAreaRenderer1.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int3 = java.awt.Color.HSBtoRGB((float) 'a', (float) (short) 0, (float) 620L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-620) + "'", int3 == (-620));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.data.Range range7 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toRangeHeight(range7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer1.setBaseOutlineStroke(stroke2, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedAreaRenderer1.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 1L, (float) (byte) 0, (float) 2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer7 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer7.setBaseCreateEntities(true);
        boxAndWhiskerRenderer7.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer13 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer13.setBaseCreateEntities(true);
        boxAndWhiskerRenderer13.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = boxAndWhiskerRenderer13.getPositiveItemLabelPosition((int) (short) 0, 0);
        boxAndWhiskerRenderer7.setBaseNegativeItemLabelPosition(itemLabelPosition21, true);
        try {
            boxAndWhiskerRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        int int7 = color5.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "Oct", "", "", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("CONTRACT", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 'a');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getValue((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 12);
        java.awt.Color color3 = java.awt.Color.pink;
        java.awt.Paint paint4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer6 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color2, (java.awt.Paint) color3, paint4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'negativeBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, 100.0f, 0.0f, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setURLText("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) (byte) 0);
        java.lang.String str8 = range7.toString();
        java.lang.String str9 = range7.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range7, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D13 = labelBlock1.arrange(graphics2D4, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Range[0.0,0.0]" + "'", str8.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[0.0,0.0]" + "'", str9.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        waterfallBarRenderer0.setSeriesVisible(7, (java.lang.Boolean) false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color2 = java.awt.Color.getColor("Range[0.0,0.0]", (int) (short) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer6 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer6.setBaseCreateEntities(true);
        boxAndWhiskerRenderer6.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = boxAndWhiskerRenderer6.getPositiveItemLabelPosition((int) (short) 0, 0);
        boxAndWhiskerRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition14, true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23);
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D17, categoryItemRendererState18, rectangle2D19, categoryPlot20, categoryAxis21, valueAxis22, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23, (int) (byte) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) 10, (int) (short) 10, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Range[0.0,0.0]", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toMillisecond(100L);
        java.util.Date date3 = null;
        java.util.Date date4 = null;
        try {
            boolean boolean5 = segmentedTimeline0.containsDomainRange(date3, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927599900L) + "'", long2 == (-2208927599900L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, (double) 620L, 0.0d);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        java.awt.Color color20 = java.awt.Color.pink;
        polarPlot19.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke22 = polarPlot19.getRadiusGridlineStroke();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape14, (java.awt.Paint) color15, stroke22, (java.awt.Paint) color23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "Range[0.0,0.0]", "{0}", shape8, stroke22, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        taskSeries1.removeChangeListener(seriesChangeListener4);
        taskSeries1.removeAll();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) (byte) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (-1.0f), textMeasurer12);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font16 = waterfallBarRenderer15.getBaseItemLabelFont();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        java.awt.Color color28 = java.awt.Color.pink;
        polarPlot27.setBackgroundPaint((java.awt.Paint) color28);
        java.awt.Stroke stroke30 = polarPlot27.getRadiusGridlineStroke();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape22, (java.awt.Paint) color23, stroke30, (java.awt.Paint) color31);
        textBlock13.addLine("{0}", font16, (java.awt.Paint) color31);
        boolean boolean34 = horizontalAlignment6.equals((java.lang.Object) color31);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) (byte) 100, (float) 1, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = polarPlot3.getLegendItems();
        polarPlot3.setRadiusGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        float float5 = polarPlot3.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (byte) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 0);
        java.lang.String str9 = range8.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1, lengthConstraintType4, (double) (-1L), range8, lengthConstraintType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[0.0,0.0]" + "'", str9.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Oct", graphics2D1, (float) 10, (float) 'a', 0.0d, (float) (-1), (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.pink;
        polarPlot3.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        try {
            double double7 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        try {
            lineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        lineAndShapeRenderer2.setBaseItemLabelFont(font6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator10, true);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        java.awt.Color color6 = java.awt.Color.pink;
        polarPlot5.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = polarPlot5.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Color color12 = java.awt.Color.lightGray;
        stackedAreaRenderer10.setSeriesFillPaint(2, (java.awt.Paint) color12, true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Color color19 = java.awt.Color.pink;
        polarPlot18.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = polarPlot18.getRadiusGridlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, paint1, stroke8, (java.awt.Paint) color12, stroke21, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.awt.Font font3 = labelBlock1.getFont();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color1 = java.awt.Color.getColor("Oct");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = boxAndWhiskerRenderer0.getPositiveItemLabelPosition((int) (short) 0, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = boxAndWhiskerRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = boxAndWhiskerRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        stackedAreaRenderer19.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator21, false);
        boolean boolean26 = stackedAreaRenderer19.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        stackedAreaRenderer19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator28, false);
        stackedAreaRenderer19.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer19, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset34);
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D12, categoryItemRendererState13, rectangle2D14, categoryPlot15, categoryAxis16, valueAxis17, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset34, 0, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "hi!", (org.jfree.data.KeyedValues) pieDataset4);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(categoryDataset5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color4);
        try {
            lineAndShapeRenderer2.setSeriesCreateEntities((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Color color2 = java.awt.Color.getColor("2-January-1900", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint11 = stackedAreaRenderer1.getItemLabelPaint(3, (int) 'a');
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            stackedAreaRenderer1.drawBackground(graphics2D12, categoryPlot13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("{0}", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer1.setBase((double) '4');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        waterfallBarRenderer1.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        waterfallBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        boolean boolean12 = blockBorder0.equals((java.lang.Object) itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getRowKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean4 = waterfallBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        java.awt.Color color10 = java.awt.Color.pink;
        polarPlot9.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke12 = polarPlot9.getAngleGridlineStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot9.setAngleLabelPaint((java.awt.Paint) color13);
        waterfallBarRenderer2.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color13);
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint22 = waterfallBarRenderer20.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer25 = new org.jfree.chart.text.G2TextMeasurer(graphics2D24);
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font19, paint22, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer25);
        try {
            org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("CONTRACT", font1, (java.awt.Paint) color13, (float) 86400000L, 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock26);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = waterfallBarRenderer0.getBaseNegativeItemLabelPosition();
        boolean boolean12 = waterfallBarRenderer0.isItemLabelVisible((int) (byte) 100, 12);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        int int1 = keyToGroupMap0.getGroupCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        taskSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        boolean boolean11 = xYPlot10.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot10.getOrientation();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color14 = java.awt.Color.lightGray;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color13, (java.awt.Paint) color14);
        xYPlot10.setRangeCrosshairPaint((java.awt.Paint) color13);
        boolean boolean17 = taskSeries3.equals((java.lang.Object) color13);
        boolean boolean18 = keyToGroupMap0.equals((java.lang.Object) boolean17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        try {
            java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset16.getMeanValue((int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        try {
            lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        org.jfree.chart.text.TextLine textLine8 = textBlock5.getLastLine();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNull(textLine8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.util.Iterator iterator4 = legendItemCollection3.iterator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock5.calculateDimensions(graphics2D8);
        double double10 = size2D9.getWidth();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        polarPlot5.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = defaultDrawingSupplier0.equals((java.lang.Object) datasetChangeEvent6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopInset(100.0d);
        double double3 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean6 = polarPlot3.isRangeZoomable();
        java.awt.Paint paint7 = polarPlot3.getAngleGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double[] doubleArray3 = new double[] { (-1.0f), 86400000L, 12 };
        double[] doubleArray7 = new double[] { (-1.0f), 86400000L, 12 };
        double[] doubleArray11 = new double[] { (-1.0f), 86400000L, 12 };
        double[] doubleArray15 = new double[] { (-1.0f), 86400000L, 12 };
        double[] doubleArray19 = new double[] { (-1.0f), 86400000L, 12 };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        double[] doubleArray23 = new double[] { (byte) 0, 0L };
        double[] doubleArray26 = new double[] { (byte) 0, 0L };
        double[] doubleArray29 = new double[] { (byte) 0, 0L };
        double[] doubleArray32 = new double[] { (byte) 0, 0L };
        double[][] doubleArray33 = new double[][] { doubleArray23, doubleArray26, doubleArray29, doubleArray32 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset34 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        double double3 = waterfallBarRenderer0.getUpperClip();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10, (java.lang.Comparable) (-2208927599900L));
        double double15 = defaultBoxAndWhiskerCategoryDataset10.getRangeUpperBound(false);
        java.util.List list18 = defaultBoxAndWhiskerCategoryDataset10.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        try {
            waterfallBarRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis8, valueAxis9, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10, (-1), 7, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNull(list18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            polarPlot3.drawOutline(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, 1, (-620));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer3 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer3.setItemMargin((double) 10L);
        java.awt.Stroke stroke7 = waterfallBarRenderer3.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer0.setBaseStroke(stroke7);
        boolean boolean9 = waterfallBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator19, false);
        boolean boolean24 = stackedAreaRenderer17.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        stackedAreaRenderer17.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator26, false);
        stackedAreaRenderer17.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer17, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset32);
        try {
            waterfallBarRenderer0.drawItem(graphics2D10, categoryItemRendererState11, rectangle2D12, categoryPlot13, categoryAxis14, valueAxis15, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32, 0, 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        java.util.Iterator iterator1 = outlierListCollection0.iterator();
        boolean boolean2 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertNotNull(iterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        java.awt.Paint paint3 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Stroke stroke4 = waterfallBarRenderer0.getBaseOutlineStroke();
        java.awt.Shape shape7 = waterfallBarRenderer0.getItemShape(0, 3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        try {
            defaultKeyedValues2D1.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        java.util.Iterator iterator1 = outlierListCollection0.iterator();
        boolean boolean2 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertNotNull(iterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 10, 0.0f, (double) 900000L, (float) (byte) 0, (float) 1L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 100.0f, (double) '#');
        double double3 = size2D2.height;
        double double4 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Stroke stroke10 = waterfallBarRenderer0.lookupSeriesStroke(100);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getFixedLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            xYPlot4.setOrientation(plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5, false);
        boolean boolean10 = stackedAreaRenderer3.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedAreaRenderer3.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator12, false);
        stackedAreaRenderer3.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer3, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = lineAndShapeRenderer23.getLegendItems();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer23.setBaseItemLabelPaint((java.awt.Paint) color25);
        stackedAreaRenderer3.setBaseFillPaint((java.awt.Paint) color25, false);
        try {
            org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[0.0,0.0]", font1, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        boolean boolean4 = taskSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color1 = java.awt.Color.blue;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean7 = boxAndWhiskerRenderer5.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer5.setBaseItemLabelFont(font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color11 = java.awt.Color.lightGray;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color10, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font8, (java.awt.Paint) color11);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer14.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer17 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer17.setItemMargin((double) 10L);
        java.awt.Stroke stroke21 = waterfallBarRenderer17.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer14.setBaseStroke(stroke21);
        java.awt.Color color23 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer24.setItemMargin((double) 10L);
        java.awt.Stroke stroke28 = waterfallBarRenderer24.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color11, stroke21, (java.awt.Paint) color23, stroke28, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke28);
        java.lang.String str32 = org.jfree.chart.util.PaintUtilities.colorToString(color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "blue" + "'", str32.equals("blue"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean6 = polarPlot3.isRangeZoomable();
        java.awt.Paint paint7 = polarPlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextOutlinePaint();
        polarPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier8);
        boolean boolean12 = defaultDrawingSupplier8.equals((java.lang.Object) 1L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem21 = defaultBoxAndWhiskerCategoryDataset16.getItem((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        intervalMarker28.setStartValue((double) ' ');
        java.lang.Class class31 = null;
        try {
            java.util.EventListener[] eventListenerArray32 = intervalMarker28.getListeners(class31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        boolean boolean8 = lineAndShapeRenderer2.getItemShapeFilled((int) (short) 1, 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot4.getOrientation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        xYPlot4.setDomainZeroBaselineVisible(false);
        java.awt.Stroke stroke13 = null;
        try {
            xYPlot4.setDomainCrosshairStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean7 = xYPlot4.removeAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.String[] strArray5 = new java.lang.String[] { "Oct", "CONTRACT", "Oct", "ThreadContext", "blue" };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.25d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0.25d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.25d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.25d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.25d };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.25d };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray9, numberArray11, numberArray13, numberArray15, numberArray17 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[] numberArray23 = new java.lang.Number[] {};
        java.lang.Number[] numberArray24 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray19, numberArray20, numberArray21, numberArray22, numberArray23, numberArray24 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset26 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray5, numberArray18, numberArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", graphics2D1, (double) (short) -1, (float) (-620), (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 100, (int) (short) 1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean7 = polarPlot3.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        polarPlot3.rendererChanged(rendererChangeEvent8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.Point point13 = polarPlot3.translateValueThetaRadiusToJava2D((double) (-1), (double) (byte) 100, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.25d, (double) 0.0f, (double) 3, (double) (byte) 0);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Stroke stroke1 = null;
        try {
            numberAxis3D0.setTickMarkStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 620L, 0.0d);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape5, (double) 10.0f, 0.0f, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot4.handleClick((int) (byte) 1, (int) ' ', plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Range[0.0,0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color4);
        lineAndShapeRenderer2.setSeriesCreateEntities(2, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        intervalMarker28.setStartValue((double) ' ');
        java.lang.Object obj31 = intervalMarker28.clone();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = boxAndWhiskerRenderer0.initialise(graphics2D5, rectangle2D6, categoryPlot7, (int) (short) 1, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("2-January-1900", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.LegendItem legendItem4 = waterfallBarRenderer0.getLegendItem(2, (int) (byte) 10);
        boolean boolean5 = waterfallBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Color color9 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean12 = blockBorder10.equals((java.lang.Object) shape11);
        stackedAreaRenderer1.setBaseShape(shape11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        try {
            java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape11, rectangleAnchor14, (double) 1.0f, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot4.getOrientation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        boolean boolean18 = xYPlot17.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot17.setRangeAxes(valueAxisArray19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getRangeMarkers(layer21);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        stackedAreaRenderer24.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator26, false);
        boolean boolean31 = stackedAreaRenderer24.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
        stackedAreaRenderer24.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator33, false);
        stackedAreaRenderer24.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset39 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer24, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset39);
        xYPlot17.datasetChanged(datasetChangeEvent41);
        xYPlot4.datasetChanged(datasetChangeEvent41);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot();
        piePlot42.setPieIndex(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState47 = piePlot0.initialise(graphics2D40, rectangle2D41, piePlot42, (java.lang.Integer) 10, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot4.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        try {
            boolean boolean15 = xYPlot4.removeAnnotation(xYAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis3D0.draw(graphics2D5, (double) (-2208927599900L), rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean6 = polarPlot3.isRangeZoomable();
        org.jfree.chart.plot.Plot plot7 = polarPlot3.getParent();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer6 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer6.setBaseCreateEntities(true);
        boxAndWhiskerRenderer6.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = boxAndWhiskerRenderer6.getPositiveItemLabelPosition((int) (short) 0, 0);
        boxAndWhiskerRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition14, true);
        boolean boolean17 = boxAndWhiskerRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        org.jfree.chart.LegendItemCollection legendItemCollection6 = polarPlot3.getLegendItems();
        float float7 = polarPlot3.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11, false);
        boolean boolean16 = stackedAreaRenderer9.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer9.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        stackedAreaRenderer9.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer9, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = lineAndShapeRenderer29.getLegendItems();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer29.setBaseItemLabelPaint((java.awt.Paint) color31);
        stackedAreaRenderer9.setBaseFillPaint((java.awt.Paint) color31, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer37.getLegendItemLabelGenerator();
        java.awt.Paint paint52 = stackedAreaRenderer37.getItemPaint(12, (int) '#');
        stackedAreaRenderer9.setSeriesOutlinePaint(3, paint52, true);
        java.awt.Stroke stroke56 = stackedAreaRenderer9.lookupSeriesOutlineStroke((int) '#');
        xYPlot4.setRangeGridlineStroke(stroke56);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer61 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean63 = boxAndWhiskerRenderer61.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer61.setBaseItemLabelFont(font64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color67 = java.awt.Color.lightGray;
        boolean boolean68 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color66, (java.awt.Paint) color67);
        org.jfree.chart.text.TextFragment textFragment69 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font64, (java.awt.Paint) color67);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer70 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer70.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer73 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer73.setItemMargin((double) 10L);
        java.awt.Stroke stroke77 = waterfallBarRenderer73.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer70.setBaseStroke(stroke77);
        java.awt.Color color79 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer80 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer80.setItemMargin((double) 10L);
        java.awt.Stroke stroke84 = waterfallBarRenderer80.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker86 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color67, stroke77, (java.awt.Paint) color79, stroke84, (float) (byte) 1);
        xYPlot4.setRangeCrosshairStroke(stroke84);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(boolean63);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        boolean boolean7 = lineAndShapeRenderer2.getItemLineVisible((int) (short) 1, 0);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Range[0.0,0.0]", "ChartChangeEventType.GENERAL", "{0}", "");
        basicProjectInfo4.setCopyright("ThreadContext");
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        java.lang.Comparable comparable2 = keyToGroupMap0.getGroup((java.lang.Comparable) "{0}");
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Default Group" + "'", comparable2.equals("Default Group"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        waterfallBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer11 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer11.setBase((double) '4');
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        waterfallBarRenderer11.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        waterfallBarRenderer11.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        java.awt.Font font24 = waterfallBarRenderer11.getItemLabelFont(2, (int) 'a');
        boolean boolean25 = waterfallBarRenderer0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setRenderAsPercentages(true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(100.0d);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer4.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator6, false);
        boolean boolean11 = stackedAreaRenderer4.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedAreaRenderer4.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator13, false);
        stackedAreaRenderer4.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset19 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer4, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset19);
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset19.getRowKeys();
        axisState0.setTicks(list22);
        double double24 = axisState0.getCursor();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-100.0d) + "'", double24 == (-100.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj7 = categoryAxis3D6.clone();
        float float8 = categoryAxis3D6.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.resizeRange(35.0d, (double) (short) 100);
        double double13 = numberAxis3D9.getAutoRangeMinimumSize();
        java.lang.String str14 = numberAxis3D9.getLabelURL();
        float float15 = numberAxis3D9.getTickMarkInsideLength();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        stackedAreaRenderer17.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator19, false);
        boolean boolean24 = stackedAreaRenderer17.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        stackedAreaRenderer17.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator26, false);
        stackedAreaRenderer17.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer17, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset32);
        java.util.List list35 = defaultBoxAndWhiskerCategoryDataset32.getRowKeys();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32);
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32, 10, 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Color color8 = java.awt.Color.pink;
        polarPlot7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = polarPlot7.getAngleGridlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot7.setAngleLabelPaint((java.awt.Paint) color11);
        waterfallBarRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color11);
        waterfallBarRenderer0.setMaximumBarWidth((double) (byte) 10);
        double double16 = waterfallBarRenderer0.getUpperClip();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis3D1.draw(graphics2D2, 0.25d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str1.equals("TextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot4.drawAnnotations(graphics2D10, rectangle2D11, plotRenderingInfo12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot4.getDomainAxisLocation();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle15.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener17 = null;
        textTitle15.removeChangeListener(titleChangeListener17);
        textTitle15.setID("CONTRACT");
        textTitle15.setWidth(0.0d);
        boolean boolean23 = axisLocation14.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        java.text.AttributedString attributedString16 = legendItem15.getAttributedLabel();
        java.lang.String str17 = legendItem15.getURLText();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(attributedString16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = boxAndWhiskerRenderer0.getPositiveItemLabelPosition((int) (short) 0, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = boxAndWhiskerRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = boxAndWhiskerRenderer0.getSeriesToolTipGenerator(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        try {
            boxAndWhiskerRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 620L, 0.0d);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (byte) 100, shape5, "{0}", "({0}, {1}) = {3} - {4}");
        java.lang.String str9 = categoryLabelEntity8.getURLText();
        java.lang.String str10 = categoryLabelEntity8.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str9.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, 0.05d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        defaultBoxAndWhiskerCategoryDataset16.validateObject();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        stackedAreaRenderer3.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5, false);
        boolean boolean10 = stackedAreaRenderer3.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        stackedAreaRenderer3.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator12, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedAreaRenderer3.getLegendItemLabelGenerator();
        waterfallBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Color color21 = java.awt.Color.pink;
        polarPlot20.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = polarPlot20.getAngleGridlineStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot20.setAngleLabelPaint((java.awt.Paint) color24);
        waterfallBarRenderer0.setLastBarPaint((java.awt.Paint) color24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean12 = boxAndWhiskerRenderer10.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 86400000L, (double) 1, Double.NaN, (double) 2, font13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        markerAxisBand15.draw(graphics2D16, rectangle2D17, rectangle2D18, (double) (short) 0, (double) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        boolean boolean7 = verticalAlignment2.equals((java.lang.Object) blockContainer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            blockContainer6.draw(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setBase((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        waterfallBarRenderer0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = waterfallBarRenderer0.getBaseNegativeItemLabelPosition();
        waterfallBarRenderer0.setItemMargin((double) 1.0f);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            waterfallBarRenderer0.drawDomainGridline(graphics2D12, categoryPlot13, rectangle2D14, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = xYPlot5.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) '4');
        intervalMarker2.setStartValue(0.2d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, (int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boxAndWhiskerRenderer0.setItemMargin((double) (-1.0f));
        try {
            boxAndWhiskerRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray3 = new double[] { 0 };
        double[] doubleArray5 = new double[] { 0 };
        double[] doubleArray7 = new double[] { 0 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.GENERAL", "NOID", doubleArray8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset9);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.lang.Object obj3 = categoryAxis3D1.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle8.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener10 = null;
        textTitle8.removeChangeListener(titleChangeListener10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle8.getPosition();
        try {
            double double13 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D7, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("{0}", "TextBlockAnchor.BOTTOM_CENTER", "{0}", image3, "2-January-1900", "12/31/69", "Default Group");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.awt.Image image10 = projectInfo7.getLogo();
        java.awt.Image image11 = null;
        projectInfo7.setLogo(image11);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        java.awt.Color color2 = java.awt.Color.GREEN;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color2);
        double double4 = waterfallBarRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Font font16 = stackedAreaRenderer1.getItemLabelFont((int) (byte) -1, 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Paint paint3 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        stackedAreaRenderer5.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7, false);
        boolean boolean12 = stackedAreaRenderer5.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        stackedAreaRenderer5.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator14, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = stackedAreaRenderer5.getLegendItemLabelGenerator();
        java.awt.Paint paint20 = stackedAreaRenderer5.getItemPaint(12, (int) '#');
        textTitle1.setBackgroundPaint(paint20);
        boolean boolean22 = rectangleAnchor0.equals((java.lang.Object) textTitle1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection7 = xYPlot4.getRangeMarkers((int) (short) 1, layer6);
        java.awt.Paint paint8 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            xYPlot4.setDomainAxisLocation(0, axisLocation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.lang.String str3 = labelBlock1.getToolTipText();
        java.awt.Font font4 = labelBlock1.getFont();
        double double5 = labelBlock1.getWidth();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        stackedAreaRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator4, false);
        boolean boolean9 = stackedAreaRenderer2.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        stackedAreaRenderer2.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator11, false);
        stackedAreaRenderer2.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer2, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset17);
        java.util.List list20 = defaultBoxAndWhiskerCategoryDataset17.getRowKeys();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        try {
            java.lang.String str24 = standardCategoryURLGenerator0.generateURL((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (int) (short) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset3.setGroup(datasetGroup4);
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup4);
        java.lang.Object obj7 = defaultBoxAndWhiskerCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer1.setBase((double) '4');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        waterfallBarRenderer1.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        waterfallBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font14 = waterfallBarRenderer1.getItemLabelFont(2, (int) 'a');
        java.awt.Color color15 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("WMAP_Plot", font14, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle17.getVerticalAlignment();
        boolean boolean19 = color15.equals((java.lang.Object) verticalAlignment18);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        waterfallBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        waterfallBarRenderer0.setBaseItemLabelFont(font5, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth(90.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot3.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.data.Range range10 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) (byte) 0);
        try {
            numberAxis3D6.setRange(range11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        java.awt.Font font5 = numberAxis3D0.getTickLabelFont();
        org.jfree.data.RangeType rangeType6 = null;
        try {
            numberAxis3D0.setRangeType(rangeType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = polarPlot3.getDrawingSupplier();
        boolean boolean7 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot4.setRenderer(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.awt.Stroke stroke20 = stackedAreaRenderer1.lookupSeriesOutlineStroke((-620));
        boolean boolean21 = stackedAreaRenderer1.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleLabelPaint();
        java.awt.Font font5 = null;
        try {
            polarPlot3.setAngleLabelFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        double double8 = rectangleConstraint7.getHeight();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        int int5 = lineAndShapeRenderer2.getRowCount();
        boolean boolean8 = lineAndShapeRenderer2.isItemLabelVisible(7, (int) (byte) 100);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        java.lang.Boolean boolean11 = lineAndShapeRenderer2.getSeriesShapesFilled((int) ' ');
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range2, range7);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range8, (double) 5, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        boolean boolean7 = polarPlot3.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = polarPlot3.getDrawingSupplier();
        boolean boolean9 = polarPlot3.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Color color7 = java.awt.Color.pink;
        polarPlot6.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Stroke stroke9 = polarPlot6.getAngleGridlineStroke();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot6.setAngleLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = categoryAxis3D1.hasListener((java.util.EventListener) polarPlot6);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        taskSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor8, textAnchor9, (double) 0.0f);
        java.lang.Object obj12 = numberTick11.clone();
        boolean boolean13 = taskSeries1.equals(obj12);
        org.jfree.data.gantt.Task task14 = null;
        try {
            taskSeries1.add(task14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'task' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        float float6 = numberAxis3D0.getTickMarkInsideLength();
        float float7 = numberAxis3D0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        lineAndShapeRenderer2.setSeriesShapesFilled(7, false);
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getSeriesOutlineStroke(0);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color4);
        boolean boolean8 = lineAndShapeRenderer2.getItemShapeVisible(0, 0);
        java.awt.Paint paint9 = null;
        try {
            lineAndShapeRenderer2.setBaseItemLabelPaint(paint9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Font font2 = null;
        java.awt.Paint paint3 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (-1.0f), textMeasurer5);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font9 = waterfallBarRenderer8.getBaseItemLabelFont();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Color color21 = java.awt.Color.pink;
        polarPlot20.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = polarPlot20.getRadiusGridlineStroke();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape15, (java.awt.Paint) color16, stroke23, (java.awt.Paint) color24);
        textBlock6.addLine("{0}", font9, (java.awt.Paint) color24);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = null;
        org.jfree.chart.text.TextAnchor textAnchor28 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick30 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "blue", textBlock6, textBlockAnchor27, textAnchor28, 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke8 = lineAndShapeRenderer2.getItemOutlineStroke((int) (short) 100, 3);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        int int5 = lineAndShapeRenderer2.getRowCount();
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot3.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setRangeWithMargins((double) 1.0f, (double) (short) 10);
        org.jfree.data.Range range10 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        numberAxis3D6.setTickLabelsVisible(true);
        double double13 = numberAxis3D6.getAutoRangeMinimumSize();
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-8d + "'", double13 == 1.0E-8d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list10 = numberAxis3D0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint4 = waterfallBarRenderer2.lookupSeriesPaint((int) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, (float) 86400000L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock8.draw(graphics2D9, (float) 8, (float) 10, textBlockAnchor12, (float) 8, (float) 0L, (double) 0L);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        polarPlot20.setNoDataMessage("");
        org.jfree.chart.LegendItemCollection legendItemCollection23 = polarPlot20.getLegendItems();
        boolean boolean24 = textBlock8.equals((java.lang.Object) legendItemCollection23);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        double double3 = waterfallBarRenderer0.getUpperClip();
        waterfallBarRenderer0.setMinimumBarLength((double) ' ');
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        textTitle0.setText("6/1/19");
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot4.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "{0}", "Oct");
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot4.setDataset((int) ' ', xYDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedAreaRenderer14.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator16, false);
        boolean boolean21 = stackedAreaRenderer14.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        stackedAreaRenderer14.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator23, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedAreaRenderer14.getLegendItemLabelGenerator();
        java.awt.Paint paint29 = stackedAreaRenderer14.getItemPaint(12, (int) '#');
        stackedAreaRenderer14.setRenderAsPercentages(true);
        java.awt.Color color32 = java.awt.Color.WHITE;
        stackedAreaRenderer14.setBaseFillPaint((java.awt.Paint) color32);
        xYPlot4.setBackgroundPaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = xYPlot4.getOrientation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot4.getDataset((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("12/31/69", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        numberAxis3D0.setLabelURL("ChartChangeEventType.GENERAL");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState();
        axisState7.cursorUp(100.0d);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot15.getDomainAxisEdge(100);
        try {
            java.util.List list18 = numberAxis3D0.refreshTicks(graphics2D6, axisState7, rectangle2D10, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        xYPlot4.setDomainZeroBaselineVisible(false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean6 = stackedAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        textTitle0.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        polarPlot10.setNoDataMessage("");
        boolean boolean13 = polarPlot10.isRangeZoomable();
        java.awt.Paint paint14 = polarPlot10.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextOutlinePaint();
        polarPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Stroke stroke18 = defaultDrawingSupplier15.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder(paint6, stroke18, rectangleInsets19);
        textTitle0.setMargin(rectangleInsets19);
        double double25 = rectangleInsets19.calculateBottomInset((double) 8);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot4.getFixedRangeAxisSpace();
        xYPlot4.setRangeCrosshairValue((double) 1);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot4.getRendererForDataset(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "hi!", "Range[0.0,0.0]", "ChartChangeEventType.GENERAL", shape4, paint5);
        java.awt.Paint paint7 = legendItem6.getLinePaint();
        java.awt.Stroke stroke8 = legendItem6.getLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        java.lang.String str3 = labelBlock1.getToolTipText();
        java.awt.Font font4 = labelBlock1.getFont();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            labelBlock1.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        int int19 = defaultBoxAndWhiskerCategoryDataset16.getRowCount();
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset16.getMaxRegularValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        java.awt.Paint paint16 = stackedAreaRenderer1.getItemPaint(12, (int) '#');
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, (double) 620L, 0.0d);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity26 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (byte) 100, shape23, "{0}", "({0}, {1}) = {3} - {4}");
        stackedAreaRenderer1.setSeriesShape(10, shape23, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Range[0.0,0.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color1);
        org.jfree.chart.LegendItem legendItem5 = waterfallBarRenderer0.getLegendItem(0, 7);
        try {
            waterfallBarRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis((int) ' ');
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot4.getRangeMarkers((int) (short) 100, layer9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.awt.Color color12 = java.awt.Color.pink;
        polarPlot11.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = polarPlot11.getRadiusGridlineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape6, (java.awt.Paint) color7, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 520L, shape6, "hi!", "Range[0.0,0.0]");
        categoryLabelEntity19.setToolTipText("{0}");
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Color color2 = java.awt.Color.getColor("ThreadContext", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Default Group", "12/31/69", "({0}, {1}) = {3} - {4}", "2-January-1900");
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.LegendItem legendItem6 = lineAndShapeRenderer2.getLegendItem(2, 3);
        lineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.LegendItem legendItem12 = lineAndShapeRenderer2.getLegendItem(12, 0);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        axisState2.setCursor((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        try {
            java.util.List list8 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.TRUNCATE" + "'", str1.equals("AreaRendererEndType.TRUNCATE"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(12);
        int int3 = objectList0.size();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-620), (byte) 0, 0.0d, 10L, (-1), (-1L) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-620), (byte) 0, 0.0d, 10L, (-1), (-1L) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-620), (byte) 0, 0.0d, 10L, (-1), (-1L) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (-620), (byte) 0, 0.0d, 10L, (-1), (-1L) };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray6, numberArray13, numberArray20, numberArray27 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] {};
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray28, numberArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "TextBlockAnchor.BOTTOM_CENTER", "CONTRACT", "({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryLabelPositions1.equals(obj2);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType7 = categoryLabelPosition4.getWidthType();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(categoryLabelWidthType7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer1.setBase((double) '4');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        waterfallBarRenderer1.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        waterfallBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font14 = waterfallBarRenderer1.getItemLabelFont(2, (int) 'a');
        java.awt.Color color15 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("WMAP_Plot", font14, (java.awt.Paint) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor22, textAnchor23, (double) 0.0f);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer28 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean30 = boxAndWhiskerRenderer28.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer28.setBaseItemLabelFont(font31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color34 = java.awt.Color.lightGray;
        boolean boolean35 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color33, (java.awt.Paint) color34);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font31, (java.awt.Paint) color34);
        textLine26.removeFragment(textFragment36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        textLine26.draw(graphics2D38, (-1.0f), (float) 10L, textAnchor41, (float) 12, (float) 0L, (double) 'a');
        boolean boolean46 = textAnchor22.equals((java.lang.Object) 10L);
        try {
            textLine16.draw(graphics2D17, (float) 100, 100.0f, textAnchor22, (float) '4', (float) 3, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 12, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        stackedAreaRenderer1.setRenderAsPercentages(true);
        java.awt.Paint paint19 = stackedAreaRenderer1.getSeriesFillPaint((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "({0}, {1}) = {3} - {4}");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        columnArrangement5.clear();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        stackedAreaRenderer8.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator10, false);
        boolean boolean15 = stackedAreaRenderer8.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedAreaRenderer8.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator17, false);
        stackedAreaRenderer8.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer8, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset23, (java.lang.Comparable) false);
        java.lang.Number number30 = defaultBoxAndWhiskerCategoryDataset23.getMaxRegularValue((java.lang.Comparable) 5, (java.lang.Comparable) (byte) 1);
        int int31 = defaultBoxAndWhiskerCategoryDataset23.getColumnCount();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        textTitle0.setID("CONTRACT");
        textTitle0.setText("Oct");
        double double8 = textTitle0.getContentYOffset();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        java.awt.Paint paint2 = null;
        try {
            lineRenderer3D0.setWallPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) 'a', (java.lang.Boolean) false);
        lineAndShapeRenderer2.setDrawOutlines(true);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        java.awt.Stroke stroke3 = piePlot0.getLabelOutlineStroke();
        java.lang.Object obj4 = piePlot0.clone();
        piePlot0.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        java.awt.Color color2 = java.awt.Color.GREEN;
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color2);
        java.awt.Shape shape5 = waterfallBarRenderer0.lookupSeriesShape(4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = boxAndWhiskerRenderer0.getLegendItemToolTipGenerator();
        boolean boolean4 = boxAndWhiskerRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = boxAndWhiskerRenderer0.initialise(graphics2D5, rectangle2D6, categoryPlot7, (int) (short) 10, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset1.setGroup(datasetGroup2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.setNoDataMessage("");
        boolean boolean12 = polarPlot8.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = polarPlot8.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(0.0d, range15);
        double double17 = range15.getCentralValue();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean2 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Color color8 = java.awt.Color.pink;
        polarPlot7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = polarPlot7.getAngleGridlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot7.setAngleLabelPaint((java.awt.Paint) color11);
        waterfallBarRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color11);
        waterfallBarRenderer0.setMaximumBarWidth((double) (byte) 10);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator16 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        waterfallBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = null;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle19.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment20, (double) 7, (double) (-2208927599900L));
        columnArrangement23.clear();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle25.setFont(font26);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer29 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean31 = boxAndWhiskerRenderer29.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer29.setBaseItemLabelFont(font32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle34.setFont(font35);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer38 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = null;
        stackedAreaRenderer38.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator40, false);
        boolean boolean45 = stackedAreaRenderer38.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = null;
        stackedAreaRenderer38.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator47, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator50 = stackedAreaRenderer38.getLegendItemLabelGenerator();
        java.awt.Paint paint53 = stackedAreaRenderer38.getItemPaint(12, (int) '#');
        textTitle34.setBackgroundPaint(paint53);
        org.jfree.chart.text.TextLine textLine55 = new org.jfree.chart.text.TextLine("Oct", font32, paint53);
        columnArrangement23.add((org.jfree.chart.block.Block) textTitle25, (java.lang.Object) textLine55);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer58 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator60 = null;
        stackedAreaRenderer58.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator60, false);
        boolean boolean65 = stackedAreaRenderer58.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator67 = null;
        stackedAreaRenderer58.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator67, false);
        stackedAreaRenderer58.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset73 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset73);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent75 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer58, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset73);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(3);
        java.lang.String str78 = serialDate77.toString();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer79 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement23, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset73, (java.lang.Comparable) str78);
        try {
            java.lang.String str82 = standardCategoryURLGenerator16.generateURL((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset73, 4, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator50);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(range74);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "2-January-1900" + "'", str78.equals("2-January-1900"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        polarPlot7.setNoDataMessage("");
        boolean boolean11 = polarPlot7.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = polarPlot7.getDrawingSupplier();
        defaultBoxAndWhiskerCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        java.lang.Number number16 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((java.lang.Comparable) 2, (java.lang.Comparable) (-2208927599900L));
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        java.awt.Stroke stroke7 = xYPlot4.getRangeZeroBaselineStroke();
        java.awt.Paint paint8 = xYPlot4.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.setNoDataMessage("");
        boolean boolean7 = polarPlot4.isRangeZoomable();
        java.awt.Paint paint8 = polarPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextOutlinePaint();
        polarPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Stroke stroke12 = defaultDrawingSupplier9.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint0, stroke12, rectangleInsets13);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17);
        int int19 = defaultBoxAndWhiskerCategoryDataset17.getRowCount();
        int int21 = defaultBoxAndWhiskerCategoryDataset17.getRowIndex((java.lang.Comparable) "hi!");
        boolean boolean22 = lineBorder16.equals((java.lang.Object) defaultBoxAndWhiskerCategoryDataset17);
        try {
            java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset17.getMinOutlier((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection4 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.util.List list19 = defaultBoxAndWhiskerCategoryDataset16.getRowKeys();
        java.util.List list20 = defaultBoxAndWhiskerCategoryDataset16.getColumnKeys();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        boolean boolean9 = xYPlot8.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot8.getOrientation();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color12 = java.awt.Color.lightGray;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color11, (java.awt.Paint) color12);
        xYPlot8.setRangeCrosshairPaint((java.awt.Paint) color11);
        boolean boolean15 = taskSeries1.equals((java.lang.Object) color11);
        taskSeries1.removeAll();
        org.jfree.data.gantt.Task task18 = taskSeries1.get("({0}, {1}) = {3} - {4}");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        taskSeries1.addChangeListener(seriesChangeListener19);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(task18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("12/31/69", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 0L, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 35.0d, false);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, 0.0d, 90.0d);
        java.lang.String str9 = range5.toString();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[35.0,45.0]" + "'", str9.equals("Range[35.0,45.0]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        numberAxis3D0.setTickMarkStroke(stroke3);
        numberAxis3D0.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesLinesVisible(2);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer2.setSeriesOutlineStroke(10, stroke7, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        polarPlot19.setNoDataMessage("");
        boolean boolean22 = polarPlot19.isRangeZoomable();
        java.awt.Paint paint23 = polarPlot19.getNoDataMessagePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        polarPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        java.awt.Stroke stroke27 = defaultDrawingSupplier24.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double30 = rectangleInsets28.calculateTopInset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder(paint15, stroke27, rectangleInsets28);
        lineAndShapeRenderer2.setBaseStroke(stroke27, true);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator35 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator35);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        boolean boolean7 = verticalAlignment2.equals((java.lang.Object) blockContainer6);
        java.util.List list8 = blockContainer6.getBlocks();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 620L, "{0}", textAnchor3, textAnchor4, (double) 0.0f);
        java.lang.Object obj7 = numberTick6.clone();
        java.lang.String str8 = numberTick6.getText();
        boolean boolean9 = rectangleAnchor0.equals((java.lang.Object) numberTick6);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Range[0.0,0.0]", "ChartChangeEventType.GENERAL", "{0}", "");
        basicProjectInfo4.setCopyright("12/31/69");
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        textTitle0.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle0.getPadding();
        double double8 = rectangleInsets6.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        java.awt.Font font4 = numberAxis3D0.getTickLabelFont();
        numberAxis3D0.setVerticalTickLabels(false);
        numberAxis3D0.configure();
        boolean boolean8 = numberAxis3D0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedHeight(1.0E-5d);
        double double9 = rectangleConstraint8.getHeight();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Range[0.0,0.0]", "ChartChangeEventType.GENERAL", "{0}", "");
        basicProjectInfo4.setVersion("ThreadContext");
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value(11, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.lang.Comparable comparable3 = null;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean6 = waterfallBarRenderer4.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.awt.Color color12 = java.awt.Color.pink;
        polarPlot11.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = polarPlot11.getAngleGridlineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color15);
        waterfallBarRenderer4.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color15);
        try {
            categoryAxis3D1.setTickLabelPaint(comparable3, (java.awt.Paint) color15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle0.getPosition();
        java.lang.String str5 = textTitle0.getText();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        java.awt.Paint paint43 = piePlot0.getLabelShadowPaint();
        piePlot0.setLabelLinkMargin((double) (-1.0f));
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer46 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint48 = waterfallBarRenderer46.lookupSeriesPaint((int) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset49, valueAxis50, valueAxis51, xYItemRenderer52);
        boolean boolean54 = xYPlot53.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = xYPlot53.getOrientation();
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color57 = java.awt.Color.lightGray;
        boolean boolean58 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color56, (java.awt.Paint) color57);
        xYPlot53.setRangeCrosshairPaint((java.awt.Paint) color56);
        waterfallBarRenderer46.setNegativeBarPaint((java.awt.Paint) color56);
        piePlot0.setLabelPaint((java.awt.Paint) color56);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(plotOrientation55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedAreaRenderer1.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean1 = waterfallBarRenderer0.getAutoPopulateSeriesStroke();
        waterfallBarRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = intervalMarker28.getGradientPaintTransformer();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        intervalMarker28.notifyListeners(markerChangeEvent30);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(gradientPaintTransformer29);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
        double double3 = rectangleInsets0.getTop();
        double double5 = rectangleInsets0.calculateLeftInset((double) 8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = polarPlot3.getRenderer();
        boolean boolean5 = polarPlot3.isAngleGridlinesVisible();
        org.junit.Assert.assertNull(polarItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(1900, 5, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot4.getFixedRangeAxisSpace();
        java.awt.Stroke stroke12 = xYPlot4.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        dateAxis0.setRange(0.0d, (double) '4');
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getLegendItems();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot4.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Font font10 = xYPlot4.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Range[0.0,0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.Color color2 = java.awt.Color.getColor("12/31/69", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("Range[35.0,45.0]");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getFixedLegendItems();
        int int6 = xYPlot4.getRangeAxisCount();
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 620L, 0.0d);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (byte) 100, shape5, "{0}", "({0}, {1}) = {3} - {4}");
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (byte) 0);
        java.lang.String str12 = range11.toString();
        java.lang.String str13 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range11, (double) (byte) 0);
        boolean boolean16 = categoryLabelEntity8.equals((java.lang.Object) rectangleConstraint15);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Range[0.0,0.0]" + "'", str12.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,0.0]" + "'", str13.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11, false);
        boolean boolean16 = stackedAreaRenderer9.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer9.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        stackedAreaRenderer9.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer9, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = lineAndShapeRenderer29.getLegendItems();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        lineAndShapeRenderer29.setBaseItemLabelPaint((java.awt.Paint) color31);
        stackedAreaRenderer9.setBaseFillPaint((java.awt.Paint) color31, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        stackedAreaRenderer37.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator39, false);
        boolean boolean44 = stackedAreaRenderer37.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        stackedAreaRenderer37.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = stackedAreaRenderer37.getLegendItemLabelGenerator();
        java.awt.Paint paint52 = stackedAreaRenderer37.getItemPaint(12, (int) '#');
        stackedAreaRenderer9.setSeriesOutlinePaint(3, paint52, true);
        java.awt.Stroke stroke56 = stackedAreaRenderer9.lookupSeriesOutlineStroke((int) '#');
        xYPlot4.setRangeGridlineStroke(stroke56);
        org.jfree.chart.axis.AxisSpace axisSpace58 = xYPlot4.getFixedDomainAxisSpace();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot4.getDomainAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(axisSpace58);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue(1.0d);
        boolean boolean7 = xYPlot4.isDomainCrosshairVisible();
        float float8 = xYPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedAreaRenderer10.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator12, false);
        boolean boolean17 = stackedAreaRenderer10.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        stackedAreaRenderer10.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator19, false);
        stackedAreaRenderer10.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset25 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset25);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer10, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset25);
        xYPlot4.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.plot.Plot plot29 = xYPlot4.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("NOID");
        categoryAxis3D1.setAxisLineVisible(false);
        java.lang.Object obj4 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100.0f, true);
        double double4 = stackedBarRenderer3D3.getYOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (-1.0f), textMeasurer4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock5.setLineAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock5.calculateDimensions(graphics2D8);
        size2D9.width = 0.0d;
        size2D9.height = (short) 1;
        size2D9.setHeight((double) (byte) 1);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(size2D9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int3 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) 900000L);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font3 = labelBlock2.getFont();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("2-January-1900", font3);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        float float2 = waferMapPlot1.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer2.setBase((double) '4');
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        waterfallBarRenderer2.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        waterfallBarRenderer2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        java.awt.Font font15 = waterfallBarRenderer2.getItemLabelFont(2, (int) 'a');
        java.awt.Color color16 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("WMAP_Plot", font15, (java.awt.Paint) color16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("WMAP_Plot", font15, paint18);
        labelBlock19.setToolTipText("blue");
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        boolean boolean4 = numberAxis3D0.isAxisLineVisible();
        numberAxis3D0.setLowerMargin((double) 500);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        piePlot0.setBackgroundImageAlpha((float) 1);
        double double45 = piePlot0.getLabelGap();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor46 = piePlot0.getLabelDistributor();
        double double47 = piePlot0.getLabelGap();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        piePlot0.setCircular(true, true);
        org.jfree.chart.util.Rotation rotation43 = piePlot0.getDirection();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(rotation43);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        java.awt.Stroke stroke20 = stackedAreaRenderer1.getSeriesOutlineStroke(10);
        stackedAreaRenderer1.setBaseCreateEntities(false);
        stackedAreaRenderer1.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(stroke20);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Oct", "hi!", "Range[0.0,0.0]", "Oct");
        java.lang.String str5 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oct" + "'", str5.equals("Oct"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        double double5 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        java.util.List list8 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) 620L, (java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyToGroupMap keyToGroupMap9 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, keyToGroupMap9);
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) (-100.0d));
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardCategoryToolTipGenerator0.getDateFormat();
        java.lang.String str2 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        double double3 = waterfallBarRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setPositiveArrowVisible(false);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D0.setLeftArrow(shape3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat5);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        java.awt.Color color16 = java.awt.Color.pink;
        polarPlot15.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = polarPlot15.getRadiusGridlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape10, (java.awt.Paint) color11, stroke18, (java.awt.Paint) color19);
        int int21 = legendItem20.getSeriesIndex();
        java.lang.String str22 = legendItem20.getDescription();
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        boolean boolean24 = month3.equals((java.lang.Object) paint23);
        piePlot0.setExplodePercent((java.lang.Comparable) month3, (double) 10);
        piePlot0.setStartAngle((double) 0.0f);
        piePlot0.setLabelGap((double) 0.0f);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset31, (java.lang.Comparable) (-2208927599900L));
        org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset34, (java.lang.Comparable) '4', (double) 10, 12);
        piePlot0.setDataset(pieDataset38);
        java.lang.Comparable comparable40 = null;
        org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset38, comparable40, (double) (short) 100);
        boolean boolean43 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset42);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(pieDataset38);
        org.junit.Assert.assertNotNull(pieDataset42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (-2208927599900L));
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((java.lang.Comparable) 8.0d, (java.lang.Comparable) (-620));
        try {
            java.util.List list9 = defaultBoxAndWhiskerCategoryDataset0.getOutliers(12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat7);
        int int9 = dateTickUnit8.getCalendarField();
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) 0, (int) '4', 100, dateFormat14);
        int int16 = dateTickUnit15.getRollCount();
        java.lang.String str18 = dateTickUnit15.valueToString(100.0d);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.util.Date date20 = month19.getStart();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        java.lang.String str22 = dateTickUnit15.dateToString(date20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.Date date24 = dateTickUnit8.addToDate(date20);
        try {
            dateAxis0.setRange(date2, date20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12/31/69" + "'", str18.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "6/1/19" + "'", str22.equals("6/1/19"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Stroke stroke4 = null;
        polarPlot3.setOutlineStroke(stroke4);
        boolean boolean6 = polarPlot3.isAngleGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        polarPlot3.setAxis(valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot3.zoomDomainAxes(0.25d, (double) 2, plotRenderingInfo11, point2D12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, false);
        java.awt.Color color9 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean12 = blockBorder10.equals((java.lang.Object) shape11);
        stackedAreaRenderer1.setBaseShape(shape11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            stackedAreaRenderer1.drawBackground(graphics2D14, categoryPlot15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        java.awt.Color color4 = java.awt.Color.lightGray;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        java.lang.Class<?> wildcardClass7 = stackedAreaRenderer2.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "Range[0.0,0.0]", "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape1, "ChartChangeEventType.GENERAL", "blue");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean4 = boxAndWhiskerRenderer2.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer2.setBaseItemLabelFont(font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font5, (java.awt.Paint) color8);
        textLine0.removeFragment(textFragment10);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer13 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean15 = boxAndWhiskerRenderer13.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer13.setBaseItemLabelFont(font16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color19 = java.awt.Color.lightGray;
        boolean boolean20 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color18, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font16, (java.awt.Paint) color19);
        textLine0.removeFragment(textFragment21);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean12 = boxAndWhiskerRenderer10.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 86400000L, (double) 1, Double.NaN, (double) 2, font13);
        numberAxis3D0.configure();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        axisState8.cursorUp(100.0d);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        try {
            java.util.List list14 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.util.List list9 = blockContainer8.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, (java.lang.Number) (byte) 0, (java.lang.Number) 5, (java.lang.Number) (short) 1, (java.lang.Number) 5, (java.lang.Number) 11, (java.lang.Number) Double.NaN, (java.lang.Number) 8.0d, list9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = lineAndShapeRenderer13.getLegendItems();
        java.lang.Boolean boolean16 = lineAndShapeRenderer13.getSeriesLinesVisible(2);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer13.setSeriesOutlineStroke(10, stroke18, false);
        lineAndShapeRenderer13.setBaseLinesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        lineAndShapeRenderer13.setBaseToolTipGenerator(categoryToolTipGenerator23, false);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        lineAndShapeRenderer13.setBaseShape(shape27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '#');
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape30, (double) 620L, 0.0d);
        lineAndShapeRenderer13.setBaseShape(shape33);
        boolean boolean35 = boxAndWhiskerItem10.equals((java.lang.Object) shape33);
        java.lang.Number number36 = boxAndWhiskerItem10.getMaxOutlier();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 8.0d + "'", number36.equals(8.0d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-620), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        stackedAreaRenderer1.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator3, false);
        boolean boolean8 = stackedAreaRenderer1.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        stackedAreaRenderer1.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer1, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset16);
        int int19 = defaultBoxAndWhiskerCategoryDataset16.getRowCount();
        java.lang.Comparable comparable20 = null;
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset16.getOutliers(comparable20, (java.lang.Comparable) 0.95f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(list22);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getTextAlignment();
        java.lang.Object obj3 = textTitle0.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer3 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean5 = boxAndWhiskerRenderer3.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer3.setBaseItemLabelFont(font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.lightGray;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color8, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]", font6, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer12.setItemMargin((double) 10L);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer15.setItemMargin((double) 10L);
        java.awt.Stroke stroke19 = waterfallBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 100);
        waterfallBarRenderer12.setBaseStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer22.setItemMargin((double) 10L);
        java.awt.Stroke stroke26 = waterfallBarRenderer22.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 100.0f, (java.awt.Paint) color9, stroke19, (java.awt.Paint) color21, stroke26, (float) (byte) 1);
        double double29 = intervalMarker28.getStartValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lengthAdjustmentType30, jFreeChart31);
        intervalMarker28.setLabelOffsetType(lengthAdjustmentType30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker28.notifyListeners(markerChangeEvent34);
        float float36 = intervalMarker28.getAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        intervalMarker28.notifyListeners(markerChangeEvent37);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge(100);
        xYPlot4.clearRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 100.0f, (double) '#');
        double double3 = size2D2.height;
        size2D2.setHeight((double) (short) 0);
        double double6 = size2D2.width;
        double double7 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font1 = waterfallBarRenderer0.getBaseItemLabelFont();
        double double2 = waterfallBarRenderer0.getUpperClip();
        double double3 = waterfallBarRenderer0.getUpperClip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color5 = java.awt.Color.lightGray;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color4, (java.awt.Paint) color5);
        waterfallBarRenderer0.setLastBarPaint((java.awt.Paint) color5);
        java.awt.Color color8 = color5.darker();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineRenderer3D0.drawBackground(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle0.removeChangeListener(titleChangeListener2);
        textTitle0.setText("WMAP_Plot");
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        textTitle0.addChangeListener(titleChangeListener6);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot4.getLegendItems();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot4.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot4.setWeight(7);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.resizeRange(35.0d, (double) (short) 100);
        double double4 = numberAxis3D0.getAutoRangeMinimumSize();
        java.lang.String str5 = numberAxis3D0.getLabelURL();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean12 = boxAndWhiskerRenderer10.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 86400000L, (double) 1, Double.NaN, (double) 2, font13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        markerAxisBand15.draw(graphics2D16, rectangle2D17, rectangle2D18, (double) (-1), (double) (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100.0f, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.resizeRange(35.0d, (double) (short) 100);
        double double8 = numberAxis3D4.getAutoRangeMinimumSize();
        java.lang.String str9 = numberAxis3D4.getLabelURL();
        float float10 = numberAxis3D4.getTickMarkInsideLength();
        boolean boolean11 = stackedBarRenderer3D3.equals((java.lang.Object) float10);
        java.lang.Boolean boolean13 = stackedBarRenderer3D3.getSeriesVisibleInLegend(2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-8d + "'", double8 == 1.0E-8d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Stroke stroke4 = null;
        polarPlot3.setOutlineStroke(stroke4);
        boolean boolean6 = polarPlot3.isAngleGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        polarPlot3.setAxis(valueAxis7);
        boolean boolean9 = polarPlot3.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1L);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Color color11 = java.awt.Color.pink;
        polarPlot10.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot10.getRadiusGridlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "Range[0.0,0.0]", "", "hi!", shape5, (java.awt.Paint) color6, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getSeriesIndex();
        java.lang.String str17 = legendItem15.getDescription();
        java.lang.String str18 = legendItem15.getLabel();
        legendItem15.setDatasetIndex((int) (byte) 1);
        java.lang.String str21 = legendItem15.getLabel();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[0.0,0.0]" + "'", str17.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        java.awt.Stroke stroke3 = piePlot0.getLabelOutlineStroke();
        double double4 = piePlot0.getStartAngle();
        java.awt.Stroke stroke5 = piePlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setPieIndex(0);
        java.awt.Stroke stroke3 = piePlot0.getLabelOutlineStroke();
        piePlot0.setExplodePercent((java.lang.Comparable) "Default Group", (double) 0);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) -1);
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) month9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer4.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer7 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font8 = waterfallBarRenderer7.getBaseItemLabelFont();
        double double9 = waterfallBarRenderer7.getUpperClip();
        java.awt.Paint paint10 = waterfallBarRenderer7.getNegativeBarPaint();
        boxAndWhiskerRenderer4.setArtifactPaint(paint10);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer15 = new org.jfree.chart.text.G2TextMeasurer(graphics2D14);
        try {
            org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[35.0,45.0]", font2, paint10, 0.0f, (int) (short) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color7);
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = polarPlot3.getRenderer();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(polarItemRenderer10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getDomainAxisEdge(100);
        try {
            double double16 = dateAxis0.java2DToValue((double) 0.95f, rectangle2D8, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        java.lang.Object obj7 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot4.getRangeMarkers(4, layer11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (short) 0, 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setRangeAxes(valueAxisArray6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot4.getRangeMarkers(layer8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        stackedAreaRenderer11.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator13, false);
        boolean boolean18 = stackedAreaRenderer11.isItemLabelVisible((int) ' ', (int) (short) 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        stackedAreaRenderer11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator20, false);
        stackedAreaRenderer11.setBaseCreateEntities(false, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stackedAreaRenderer11, (org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset26);
        xYPlot4.datasetChanged(datasetChangeEvent28);
        java.lang.String str30 = datasetChangeEvent28.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        boolean boolean6 = xYPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot5.getRangeAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace12 = xYPlot5.getFixedRangeAxisSpace();
        xYPlot5.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", (org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer19 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Boolean boolean21 = boxAndWhiskerRenderer19.getSeriesVisibleInLegend((int) (short) 1);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boxAndWhiskerRenderer19.setBaseItemLabelFont(font22);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Font font25 = waterfallBarRenderer24.getBaseItemLabelFont();
        double double26 = waterfallBarRenderer24.getUpperClip();
        double double27 = waterfallBarRenderer24.getUpperClip();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color29 = java.awt.Color.lightGray;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, (java.awt.Paint) color29);
        waterfallBarRenderer24.setLastBarPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font34 = null;
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (-1.0f), textMeasurer37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock38.setLineAlignment(horizontalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock38.calculateDimensions(graphics2D41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textBlock38.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment46, (double) 7, (double) (-2208927599900L));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("{0}", font22, (java.awt.Paint) color29, rectangleEdge32, horizontalAlignment43, verticalAlignment46, rectangleInsets50);
        java.awt.Color color54 = java.awt.Color.WHITE;
        textTitle53.setPaint((java.awt.Paint) color54);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        try {
            org.jfree.chart.title.Title title58 = jFreeChart17.getSubtitle(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        try {
            org.jfree.data.gantt.Task task3 = taskSeries1.get((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.addChangeListener(seriesChangeListener2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        try {
            java.lang.Comparable comparable3 = defaultBoxAndWhiskerCategoryDataset0.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }
}

