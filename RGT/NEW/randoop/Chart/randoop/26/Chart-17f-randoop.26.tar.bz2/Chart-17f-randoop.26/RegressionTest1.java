import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.Date date5 = day4.getEnd();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class5);
        timeSeries6.setDescription("");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (-457));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        int int13 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long16 = fixedMillisecond15.getFirstMillisecond();
        long long17 = fixedMillisecond15.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries2.setKey((java.lang.Comparable) (short) 0);
        timeSeries2.removeAgedItems(true);
        timeSeries2.setDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
        int int2 = timeSeries1.getItemCount();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long6 = fixedMillisecond5.getFirstMillisecond();
        long long7 = fixedMillisecond5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond5.peg(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond5.next();
        try {
            timeSeries1.add(regularTimePeriod12, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long13 = fixedMillisecond12.getFirstMillisecond();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
        try {
            timeSeries10.add(timeSeriesDataItem15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNull(number14);
    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        int int3 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate8);
//        java.lang.String str10 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate8);
//        boolean boolean13 = spreadsheetDate2.isBefore(serialDate8);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(10, serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate16.getYYYY();
//        java.lang.String str19 = spreadsheetDate16.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2958465 + "'", int3 == 2958465);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9999 + "'", int18 == 9999);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-9999" + "'", str19.equals("31-December-9999"));
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date4 = fixedMillisecond3.getTime();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        boolean boolean9 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 4);
        timeSeries7.setDescription("ThreadContext");
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond3, (java.lang.Object) timeSeries7);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long25 = fixedMillisecond24.getFirstMillisecond();
        long long26 = fixedMillisecond24.getFirstMillisecond();
        int int27 = day20.compareTo((java.lang.Object) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 10.0f);
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        java.lang.Object obj31 = timeSeriesDataItem29.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        boolean boolean36 = timeSeriesDataItem29.equals((java.lang.Object) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        long long38 = month35.getLastMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0d + "'", number30.equals(10.0d));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28799999L + "'", long38 == 28799999L);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate4);
        boolean boolean11 = timeSeries10.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        int int3 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate8);
//        java.lang.String str10 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate8);
//        boolean boolean13 = spreadsheetDate2.isBefore(serialDate8);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(10, serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate16.getYYYY();
//        java.util.Date date19 = spreadsheetDate16.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long22 = fixedMillisecond21.getFirstMillisecond();
//        java.lang.String str23 = fixedMillisecond21.toString();
//        java.util.Date date24 = fixedMillisecond21.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24, timeZone28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date24, timeZone34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date19, timeZone34);
//        java.util.Date date38 = day37.getStart();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2958465 + "'", int3 == 2958465);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9999 + "'", int18 == 9999);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str23.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        boolean boolean8 = timeSeries6.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 4);
        java.lang.Number number15 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int16 = timeSeries2.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date20 = fixedMillisecond19.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries2.createCopy(regularTimePeriod17, (org.jfree.data.time.RegularTimePeriod) day23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long9 = fixedMillisecond8.getFirstMillisecond();
        java.lang.String str10 = fixedMillisecond8.toString();
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date14 = fixedMillisecond13.getTime();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date11, timeZone15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date11, timeZone18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long22 = fixedMillisecond21.getFirstMillisecond();
        java.lang.String str23 = fixedMillisecond21.toString();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date27 = fixedMillisecond26.getTime();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date11, timeZone28);
        java.lang.Class<?> wildcardClass32 = day31.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass32);
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("23-June-2020", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "13-June-2020", "January", (java.lang.Class) wildcardClass32);
        timeSeries35.removeAgedItems(false);
        timeSeries35.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str23.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNull(inputStream34);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        int int5 = spreadsheetDate4.toSerial();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate10);
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(0, serialDate10);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate10);
//        boolean boolean15 = spreadsheetDate4.isBefore(serialDate10);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(10, serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int20 = spreadsheetDate18.getYYYY();
//        int int21 = spreadsheetDate18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = serialDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2958465 + "'", int5 == 2958465);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9999 + "'", int20 == 9999);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) ' ', serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test14");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        boolean boolean8 = timeSeries6.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 4);
//        timeSeries6.setDescription("ThreadContext");
//        timeSeries6.removeAgedItems(true);
//        boolean boolean19 = day0.equals((java.lang.Object) timeSeries6);
//        long long20 = day0.getLastMillisecond();
//        java.util.Calendar calendar21 = null;
//        try {
//            day0.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate23);
//        boolean boolean25 = spreadsheetDate14.isOnOrAfter(serialDate23);
//        int int26 = spreadsheetDate1.compare(serialDate23);
//        spreadsheetDate1.setDescription("January");
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2914836 + "'", int26 == 2914836);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long3 = fixedMillisecond2.getFirstMillisecond();
        java.lang.String str4 = fixedMillisecond2.toString();
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5, timeZone9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long16 = fixedMillisecond15.getFirstMillisecond();
        java.lang.String str17 = fixedMillisecond15.toString();
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date21 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date18, timeZone22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date5, timeZone22);
        java.lang.Class<?> wildcardClass26 = day25.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long30 = fixedMillisecond29.getFirstMillisecond();
        java.lang.String str31 = fixedMillisecond29.toString();
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date35 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date32, timeZone36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date32, timeZone39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long43 = fixedMillisecond42.getFirstMillisecond();
        java.lang.String str44 = fixedMillisecond42.toString();
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date48 = fixedMillisecond47.getTime();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date45, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date32, timeZone49);
        java.lang.Class<?> wildcardClass53 = day52.getClass();
        java.net.URL uRL54 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass53);
        java.lang.Object obj55 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", (java.lang.Class) wildcardClass26, (java.lang.Class) wildcardClass53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str4.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str17.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str31.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str44.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(uRL54);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertNotNull(class56);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate23);
//        boolean boolean25 = spreadsheetDate14.isOnOrAfter(serialDate23);
//        int int26 = spreadsheetDate1.compare(serialDate23);
//        int int27 = spreadsheetDate1.getDayOfWeek();
//        spreadsheetDate1.setDescription("Following");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long40 = fixedMillisecond39.getFirstMillisecond();
//        java.lang.String str41 = fixedMillisecond39.toString();
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date45 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45, timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date42, timeZone46);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date42, timeZone49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long53 = fixedMillisecond52.getFirstMillisecond();
//        java.lang.String str54 = fixedMillisecond52.toString();
//        java.util.Date date55 = fixedMillisecond52.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date58 = fixedMillisecond57.getTime();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58, timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date55, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date42, timeZone59);
//        java.lang.Class<?> wildcardClass63 = day62.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long67 = fixedMillisecond66.getFirstMillisecond();
//        java.lang.String str68 = fixedMillisecond66.toString();
//        java.util.Date date69 = fixedMillisecond66.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date72 = fixedMillisecond71.getTime();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date72, timeZone73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date69, timeZone73);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date69, timeZone76);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long80 = fixedMillisecond79.getFirstMillisecond();
//        java.lang.String str81 = fixedMillisecond79.toString();
//        java.util.Date date82 = fixedMillisecond79.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Date date85 = fixedMillisecond84.getTime();
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date85, timeZone86);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date82, timeZone86);
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date69, timeZone86);
//        java.lang.Class<?> wildcardClass90 = day89.getClass();
//        java.net.URL uRL91 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass90);
//        java.lang.Object obj92 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", (java.lang.Class) wildcardClass63, (java.lang.Class) wildcardClass90);
//        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass63);
//        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long35, (java.lang.Class) wildcardClass63);
//        try {
//            int int95 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries94);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2914836 + "'", int26 == 2914836);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str41.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-1L) + "'", long53 == (-1L));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str54.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-1L) + "'", long67 == (-1L));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str68.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-1L) + "'", long80 == (-1L));
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str81.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNotNull(wildcardClass90);
//        org.junit.Assert.assertNull(uRL91);
//        org.junit.Assert.assertNull(obj92);
//        org.junit.Assert.assertNull(uRL93);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.String str6 = year4.toString();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4, "May", "", class9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year4.previous();
        java.lang.String str12 = year4.toString();
        long long13 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1969L + "'", long13 == 1969L);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long3 = fixedMillisecond2.getFirstMillisecond();
        java.lang.String str4 = fixedMillisecond2.toString();
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5, timeZone9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date5, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, year13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month15.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str4.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate10);
        int int13 = spreadsheetDate1.getMonth();
        boolean boolean15 = spreadsheetDate1.equals((java.lang.Object) "Value");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long3 = fixedMillisecond2.getFirstMillisecond();
        java.lang.String str4 = fixedMillisecond2.toString();
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5, timeZone9);
        java.lang.Class<?> wildcardClass12 = timeZone9.getClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str4.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (-457));
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long16 = fixedMillisecond15.getFirstMillisecond();
        java.lang.Number number17 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        boolean boolean18 = month2.equals((java.lang.Object) number17);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "Following", "January -457", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long7 = fixedMillisecond6.getFirstMillisecond();
        long long8 = fixedMillisecond6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond6.getFirstMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        boolean boolean12 = fixedMillisecond6.equals((java.lang.Object) 1L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond6);
        java.lang.String str14 = seriesChangeEvent13.toString();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        boolean boolean8 = timeSeries6.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 4);
        java.lang.Number number15 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int16 = timeSeries2.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long19 = fixedMillisecond18.getFirstMillisecond();
        java.lang.String str20 = fixedMillisecond18.toString();
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date24 = fixedMillisecond23.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date21, timeZone25);
        long long28 = day27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        timeSeries2.setMaximumItemAge((long) 2932897);
        int int32 = timeSeries2.getMaximumItemCount();
        timeSeries2.setNotify(true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str20.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 25568L + "'", long28 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Jan");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long5 = fixedMillisecond4.getFirstMillisecond();
        long long6 = fixedMillisecond4.getFirstMillisecond();
        int int7 = day0.compareTo((java.lang.Object) fixedMillisecond4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 10.0f);
        java.lang.String str10 = fixedMillisecond4.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date15 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (-47711260800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(comparable12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.removeAgedItems(true);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4, class16);
        long long18 = timeSeries17.getMaximumItemAge();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long24 = fixedMillisecond23.getFirstMillisecond();
        long long25 = fixedMillisecond23.getFirstMillisecond();
        int int26 = day19.compareTo((java.lang.Object) fixedMillisecond23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 10.0f);
        java.lang.Number number29 = timeSeriesDataItem28.getValue();
        java.lang.Object obj30 = timeSeriesDataItem28.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        boolean boolean35 = timeSeriesDataItem28.equals((java.lang.Object) month34);
        int int36 = month34.getYearValue();
        java.lang.Number number37 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month34);
        int int38 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month34);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10.0d + "'", number29.equals(10.0d));
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.removeAgedItems(true);
        java.util.Collection collection15 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getEndOfCurrentMonth(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date7 = fixedMillisecond6.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date4, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long13 = fixedMillisecond12.getFirstMillisecond();
        java.lang.String str14 = fixedMillisecond12.toString();
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date18 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date15, timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date15, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date4, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long27 = fixedMillisecond26.getFirstMillisecond();
        java.lang.String str28 = fixedMillisecond26.toString();
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date32 = fixedMillisecond31.getTime();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date29, timeZone33);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date4, timeZone33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date39 = fixedMillisecond38.getTime();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class41);
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        boolean boolean44 = timeSeries42.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 4);
        timeSeries42.setDescription("ThreadContext");
        boolean boolean53 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond38, (java.lang.Object) timeSeries42);
        boolean boolean54 = month36.equals((java.lang.Object) fixedMillisecond38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str14.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str28.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(class43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1L) + "'", long48 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long8 = fixedMillisecond7.getFirstMillisecond();
        java.lang.String str9 = fixedMillisecond7.toString();
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date13 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date10, timeZone14);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date10, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.lang.String str22 = fixedMillisecond20.toString();
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date26 = fixedMillisecond25.getTime();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date23, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date10, timeZone27);
        java.lang.Class<?> wildcardClass31 = day30.getClass();
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass31);
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass31);
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass31);
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass31);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long41 = fixedMillisecond40.getFirstMillisecond();
        java.lang.String str42 = fixedMillisecond40.toString();
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date46 = fixedMillisecond45.getTime();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date43, timeZone47);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date43, timeZone50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long54 = fixedMillisecond53.getFirstMillisecond();
        java.lang.String str55 = fixedMillisecond53.toString();
        java.util.Date date56 = fixedMillisecond53.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59, timeZone60);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date56, timeZone60);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date43, timeZone60);
        java.lang.Class<?> wildcardClass64 = day63.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long68 = fixedMillisecond67.getFirstMillisecond();
        java.lang.String str69 = fixedMillisecond67.toString();
        java.util.Date date70 = fixedMillisecond67.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date73 = fixedMillisecond72.getTime();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date73, timeZone74);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date70, timeZone74);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date70, timeZone77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long81 = fixedMillisecond80.getFirstMillisecond();
        java.lang.String str82 = fixedMillisecond80.toString();
        java.util.Date date83 = fixedMillisecond80.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date86 = fixedMillisecond85.getTime();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date86, timeZone87);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date83, timeZone87);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date70, timeZone87);
        java.lang.Class<?> wildcardClass91 = day90.getClass();
        java.net.URL uRL92 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass91);
        java.lang.Object obj93 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", (java.lang.Class) wildcardClass64, (java.lang.Class) wildcardClass91);
        java.lang.Object obj94 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass91);
        java.lang.Object obj95 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("23-June-2020", (java.lang.Class) wildcardClass31, (java.lang.Class) wildcardClass91);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str9.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str22.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(uRL32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNotNull(uRL34);
        org.junit.Assert.assertNull(inputStream35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str42.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str55.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-1L) + "'", long68 == (-1L));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str69.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-1L) + "'", long81 == (-1L));
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str82.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(uRL92);
        org.junit.Assert.assertNull(obj93);
        org.junit.Assert.assertNull(obj94);
        org.junit.Assert.assertNull(obj95);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long5 = fixedMillisecond4.getFirstMillisecond();
        java.lang.String str6 = fixedMillisecond4.toString();
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date7, timeZone11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date7, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long18 = fixedMillisecond17.getFirstMillisecond();
        java.lang.String str19 = fixedMillisecond17.toString();
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date23 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date20, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date7, timeZone24);
        java.lang.Class<?> wildcardClass28 = day27.getClass();
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass28);
        java.net.URL uRL30 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass28);
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass28);
        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str6.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str19.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(uRL29);
        org.junit.Assert.assertNull(uRL30);
        org.junit.Assert.assertNotNull(uRL31);
        org.junit.Assert.assertNotNull(classLoader32);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test40");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
//        timeSeries2.setDescription("");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day5);
//        long long7 = day5.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long10 = fixedMillisecond9.getFirstMillisecond();
//        java.lang.String str11 = fixedMillisecond9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond9.previous();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getFirstMillisecond(calendar14);
//        boolean boolean16 = day5.equals((java.lang.Object) fixedMillisecond9);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str11.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date7 = fixedMillisecond6.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date4, timeZone8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date4, timeZone11);
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1969L + "'", long13 == 1969L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDomainDescription("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        boolean boolean15 = timeSeries2.equals((java.lang.Object) "ClassContext");
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("May");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int2 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long3 = fixedMillisecond2.getFirstMillisecond();
        java.lang.String str4 = fixedMillisecond2.toString();
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5, timeZone9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date5, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, year13);
        int int16 = year13.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str4.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getLastMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 4);
        timeSeries26.setDescription("ThreadContext");
        timeSeries26.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        long long45 = fixedMillisecond43.getFirstMillisecond();
        int int46 = day39.compareTo((java.lang.Object) fixedMillisecond43);
        timeSeries26.setKey((java.lang.Comparable) day39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) 1969);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class51);
        java.lang.Class class53 = timeSeries52.getTimePeriodClass();
        boolean boolean54 = timeSeries52.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) 4);
        long long61 = fixedMillisecond56.getSerialIndex();
        int int62 = timeSeriesDataItem49.compareTo((java.lang.Object) fixedMillisecond56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.lang.Comparable comparable64 = timeSeries2.getKey();
        boolean boolean65 = timeSeries2.isEmpty();
        boolean boolean66 = timeSeries2.isEmpty();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(class53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1L) + "'", long58 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1L) + "'", long61 == (-1L));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(comparable64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange(serialDate17, serialDate22, 0);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        int int35 = spreadsheetDate34.toSerial();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate40);
//        java.lang.String str42 = serialDate40.toString();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate40);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate40);
//        boolean boolean45 = spreadsheetDate34.isBefore(serialDate40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
//        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = serialDate52.getEndOfCurrentMonth(serialDate56);
//        boolean boolean58 = spreadsheetDate47.isOnOrAfter(serialDate56);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day62.previous();
//        org.jfree.data.time.SerialDate serialDate64 = day62.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
//        org.jfree.data.time.SerialDate serialDate68 = day66.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate70 = serialDate65.getEndOfCurrentMonth(serialDate69);
//        boolean boolean71 = spreadsheetDate60.isOnOrAfter(serialDate69);
//        int int72 = spreadsheetDate47.compare(serialDate69);
//        int int73 = spreadsheetDate47.getDayOfWeek();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.previous();
//        org.jfree.data.time.SerialDate serialDate77 = day75.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate77);
//        boolean boolean79 = spreadsheetDate47.isAfter(serialDate77);
//        boolean boolean80 = spreadsheetDate34.isBefore(serialDate77);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addYears(2019, serialDate77);
//        boolean boolean82 = spreadsheetDate1.isBefore(serialDate81);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2958465 + "'", int35 == 2958465);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2914836 + "'", int72 == 2914836);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond2.getMiddleMillisecond(calendar5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        java.lang.String str12 = fixedMillisecond10.toString();
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date16 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13, timeZone17);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date13, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long24 = fixedMillisecond23.getFirstMillisecond();
        java.lang.String str25 = fixedMillisecond23.toString();
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date26, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date13, timeZone30);
        java.lang.Class<?> wildcardClass34 = day33.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long38 = fixedMillisecond37.getFirstMillisecond();
        java.lang.String str39 = fixedMillisecond37.toString();
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date43 = fixedMillisecond42.getTime();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date43, timeZone44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date40, timeZone44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date40, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long51 = fixedMillisecond50.getFirstMillisecond();
        java.lang.String str52 = fixedMillisecond50.toString();
        java.util.Date date53 = fixedMillisecond50.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date56 = fixedMillisecond55.getTime();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date53, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date40, timeZone57);
        java.lang.Class<?> wildcardClass61 = day60.getClass();
        java.net.URL uRL62 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass61);
        java.lang.Object obj63 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", (java.lang.Class) wildcardClass34, (java.lang.Class) wildcardClass61);
        java.net.URL uRL64 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, (java.lang.Class) wildcardClass34);
        java.net.URL uRL66 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December 1969", (java.lang.Class) wildcardClass34);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str12.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str25.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str39.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str52.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(uRL62);
        org.junit.Assert.assertNull(obj63);
        org.junit.Assert.assertNull(uRL64);
        org.junit.Assert.assertNull(uRL66);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate4);
//        java.lang.String str6 = serialDate4.toString();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, serialDate4);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate4);
//        java.lang.Object obj9 = seriesChangeEvent8.getSource();
//        java.lang.String str10 = seriesChangeEvent8.toString();
//        java.lang.Object obj11 = seriesChangeEvent8.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertNotNull(obj11);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getLastMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "Following", "January -457", class3);
        boolean boolean5 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        boolean boolean24 = timeSeries2.isEmpty();
        java.util.List list25 = timeSeries2.getItems();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        boolean boolean28 = timeSeries26.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 4);
        timeSeries26.setDescription("ThreadContext");
        timeSeries26.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        long long45 = fixedMillisecond43.getFirstMillisecond();
        int int46 = day39.compareTo((java.lang.Object) fixedMillisecond43);
        timeSeries26.setKey((java.lang.Comparable) day39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) 1969);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class51);
        java.lang.Class class53 = timeSeries52.getTimePeriodClass();
        boolean boolean54 = timeSeries52.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) 4);
        long long61 = fixedMillisecond56.getSerialIndex();
        int int62 = timeSeriesDataItem49.compareTo((java.lang.Object) fixedMillisecond56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class65);
        java.lang.Class class67 = timeSeries66.getTimePeriodClass();
        boolean boolean68 = timeSeries66.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) 4);
        timeSeries66.setDescription("ThreadContext");
        timeSeries66.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
        org.jfree.data.time.SerialDate serialDate81 = day79.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long84 = fixedMillisecond83.getFirstMillisecond();
        long long85 = fixedMillisecond83.getFirstMillisecond();
        int int86 = day79.compareTo((java.lang.Object) fixedMillisecond83);
        timeSeries66.setKey((java.lang.Comparable) day79);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener88 = null;
        timeSeries66.removeChangeListener(seriesChangeListener88);
        timeSeries66.fireSeriesChanged();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = timeSeries66.getDataItem(0);
        try {
            timeSeries2.add(timeSeriesDataItem92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(class53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1L) + "'", long58 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1L) + "'", long61 == (-1L));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertNull(class67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-1L) + "'", long84 == (-1L));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-1L) + "'", long85 == (-1L));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem92);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        boolean boolean8 = timeSeries6.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 4);
        java.lang.Number number15 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener16);
        java.util.Collection collection18 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.String str4 = timeSeries2.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
        int int7 = timeSeries6.getItemCount();
        java.lang.String str8 = timeSeries6.getDomainDescription();
        java.util.Collection collection9 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        java.lang.String str10 = timeSeries2.getDescription();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDomainDescription("");
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long17 = fixedMillisecond16.getFirstMillisecond();
        java.lang.String str18 = fixedMillisecond16.toString();
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date22 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date19, timeZone23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date19, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long30 = fixedMillisecond29.getFirstMillisecond();
        java.lang.String str31 = fixedMillisecond29.toString();
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date35 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date32, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date19, timeZone36);
        java.lang.Class<?> wildcardClass40 = day39.getClass();
        java.net.URL uRL41 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        java.lang.String str45 = fixedMillisecond43.toString();
        java.util.Date date46 = fixedMillisecond43.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long51 = fixedMillisecond50.getFirstMillisecond();
        java.lang.String str52 = fixedMillisecond50.toString();
        java.util.Date date53 = fixedMillisecond50.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date56 = fixedMillisecond55.getTime();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date53, timeZone57);
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date53, timeZone60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long64 = fixedMillisecond63.getFirstMillisecond();
        java.lang.String str65 = fixedMillisecond63.toString();
        java.util.Date date66 = fixedMillisecond63.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date69 = fixedMillisecond68.getTime();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date66, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date53, timeZone70);
        java.lang.Class<?> wildcardClass74 = day73.getClass();
        java.net.URL uRL75 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass74);
        java.net.URL uRL76 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass74);
        java.util.Date date77 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long80 = fixedMillisecond79.getFirstMillisecond();
        java.lang.String str81 = fixedMillisecond79.toString();
        java.util.Date date82 = fixedMillisecond79.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date85 = fixedMillisecond84.getTime();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date85, timeZone86);
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date82, timeZone86);
        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date91 = fixedMillisecond90.getTime();
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date91, timeZone92);
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date82, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date77, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone92);
        try {
            timeSeries2.add(regularTimePeriod96, (java.lang.Number) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str18.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str31.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(uRL41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str45.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str52.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str65.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(uRL75);
        org.junit.Assert.assertNull(uRL76);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-1L) + "'", long80 == (-1L));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str81.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod95);
        org.junit.Assert.assertNotNull(regularTimePeriod96);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2958465 + "'", int2 == 2958465);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-457), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class25);
        java.lang.String str27 = timeSeries26.getRangeDescription();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class29);
        timeSeries30.setDescription("");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, (-457));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        int int37 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long40 = fixedMillisecond39.getFirstMillisecond();
        long long41 = fixedMillisecond39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (-435));
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date47 = fixedMillisecond46.getTime();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (org.jfree.data.time.RegularTimePeriod) month48);
        java.lang.String str50 = fixedMillisecond44.toString();
        java.lang.Number number51 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number51);
        timeSeries2.clear();
        timeSeries2.setDescription("May");
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str50.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem52);
    }

//    @Test
//    public void test63() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test63");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2958465);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate23);
//        boolean boolean25 = spreadsheetDate14.isOnOrAfter(serialDate23);
//        int int26 = spreadsheetDate1.compare(serialDate23);
//        int int27 = spreadsheetDate1.getDayOfWeek();
//        spreadsheetDate1.setDescription("Following");
//        int int30 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2914836 + "'", int26 == 2914836);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9999 + "'", int30 == 9999);
//    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long9 = fixedMillisecond8.getFirstMillisecond();
        long long10 = fixedMillisecond8.getFirstMillisecond();
        int int11 = day4.compareTo((java.lang.Object) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 10.0f);
        java.lang.Number number14 = timeSeriesDataItem13.getValue();
        java.lang.Object obj15 = timeSeriesDataItem13.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        boolean boolean20 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        int int22 = timeSeriesDataItem13.compareTo((java.lang.Object) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem13.getPeriod();
        int int24 = month3.compareTo((java.lang.Object) regularTimePeriod23);
        long long25 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 10.0d + "'", number14.equals(10.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2649600000L) + "'", long25 == (-2649600000L));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 1969);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        boolean boolean30 = timeSeries28.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 4);
        long long37 = fixedMillisecond32.getSerialIndex();
        int int38 = timeSeriesDataItem25.compareTo((java.lang.Object) fixedMillisecond32);
        java.util.Date date39 = fixedMillisecond32.getEnd();
        long long40 = fixedMillisecond32.getFirstMillisecond();
        long long41 = fixedMillisecond32.getLastMillisecond();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 4);
        timeSeries2.setDescription("ThreadContext");
        timeSeries2.setDomainDescription("13-June-2019");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        int int22 = day15.compareTo((java.lang.Object) fixedMillisecond19);
        timeSeries2.setKey((java.lang.Comparable) day15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 1969);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        boolean boolean30 = timeSeries28.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 4);
        long long37 = fixedMillisecond32.getSerialIndex();
        int int38 = timeSeriesDataItem25.compareTo((java.lang.Object) fixedMillisecond32);
        long long39 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond32);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class1);
        timeSeries2.setDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, (-457));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        int int10 = month7.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month7.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.lang.String str6 = serialDate5.toString();
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate5.getNearestDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-1969" + "'", str6.equals("31-December-1969"));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("May");
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) "May");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test70() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test70");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long5 = fixedMillisecond4.getFirstMillisecond();
//        long long6 = fixedMillisecond4.getFirstMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) fixedMillisecond4);
//        long long8 = day0.getLastMillisecond();
//        long long9 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        java.util.Calendar calendar12 = null;
//        try {
//            day0.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-435), 13, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date7 = fixedMillisecond6.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date4, timeZone8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date4, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long15 = fixedMillisecond14.getFirstMillisecond();
        java.lang.String str16 = fixedMillisecond14.toString();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date20 = fixedMillisecond19.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date17, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        java.util.Date date26 = day24.getStart();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.String str6 = year4.toString();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4, "May", "", class9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year4.previous();
        java.lang.String str12 = year4.toString();
        long long13 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year4.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long17 = fixedMillisecond16.getFirstMillisecond();
        java.lang.String str18 = fixedMillisecond16.toString();
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long24 = fixedMillisecond23.getFirstMillisecond();
        java.lang.String str25 = fixedMillisecond23.toString();
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date26, timeZone30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long35 = fixedMillisecond34.getFirstMillisecond();
        java.lang.String str36 = fixedMillisecond34.toString();
        java.util.Date date37 = fixedMillisecond34.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date40 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date37, timeZone41);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date37, timeZone44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date26, timeZone44);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date19, timeZone44);
        int int48 = year4.compareTo((java.lang.Object) month47);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str18.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str25.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str36.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long4 = fixedMillisecond3.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 8);
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedMillisecond3.equals(obj9);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long9 = fixedMillisecond8.getFirstMillisecond();
        java.lang.String str10 = fixedMillisecond8.toString();
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date14 = fixedMillisecond13.getTime();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date11, timeZone15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date11, timeZone18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long22 = fixedMillisecond21.getFirstMillisecond();
        java.lang.String str23 = fixedMillisecond21.toString();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date27 = fixedMillisecond26.getTime();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date11, timeZone28);
        java.lang.Class<?> wildcardClass32 = day31.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", (java.lang.Class) wildcardClass32);
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("23-June-2020", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "13-June-2020", "January", (java.lang.Class) wildcardClass32);
        timeSeries35.removeAgedItems(false);
        try {
            java.lang.Number number39 = timeSeries35.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str23.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNull(inputStream34);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4, class1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long12 = fixedMillisecond11.getFirstMillisecond();
        long long13 = fixedMillisecond11.getFirstMillisecond();
        int int14 = day7.compareTo((java.lang.Object) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 10.0f);
        java.lang.Number number17 = timeSeriesDataItem16.getValue();
        java.lang.Object obj18 = timeSeriesDataItem16.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) month22);
        int int25 = timeSeriesDataItem16.compareTo((java.lang.Object) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem16.getPeriod();
        int int27 = month6.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries2.createCopy(regularTimePeriod26, regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10.0d + "'", number17.equals(10.0d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (-457));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getLastMillisecond();
        int int5 = month2.getMonth();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-47711260800001L) + "'", long4 == (-47711260800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-47711260800001L) + "'", long6 == (-47711260800001L));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.String str6 = year4.toString();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4, "May", "", class9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod11, (double) (byte) 0);
        java.util.Date date14 = regularTimePeriod11.getStart();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date4 = fixedMillisecond3.getTime();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        boolean boolean9 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 4);
        timeSeries7.setDescription("ThreadContext");
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond3, (java.lang.Object) timeSeries7);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long25 = fixedMillisecond24.getFirstMillisecond();
        long long26 = fixedMillisecond24.getFirstMillisecond();
        int int27 = day20.compareTo((java.lang.Object) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 10.0f);
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        java.lang.Object obj31 = timeSeriesDataItem29.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        boolean boolean36 = timeSeriesDataItem29.equals((java.lang.Object) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int38 = month35.getMonth();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0d + "'", number30.equals(10.0d));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test82() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test82");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long13 = fixedMillisecond12.getFirstMillisecond();
//        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class16);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        boolean boolean19 = timeSeries17.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 4);
//        timeSeries17.setDescription("ThreadContext");
//        timeSeries17.setDomainDescription("13-June-2019");
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        long long35 = fixedMillisecond34.getFirstMillisecond();
//        long long36 = fixedMillisecond34.getFirstMillisecond();
//        int int37 = day30.compareTo((java.lang.Object) fixedMillisecond34);
//        timeSeries17.setKey((java.lang.Comparable) day30);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        long long40 = day30.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test83");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class2);
        java.lang.String str4 = timeSeries3.getRangeDescription();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        boolean boolean9 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 4);
        java.lang.Number number16 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        java.lang.String str21 = fixedMillisecond19.toString();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date22, timeZone26);
        long long29 = day28.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Date date33 = fixedMillisecond32.getTime();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
        java.lang.String str37 = year35.toString();
        int int38 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        long long39 = year35.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 100, year35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str21.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 25568L + "'", long29 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969" + "'", str37.equals("1969"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-31507200000L) + "'", long39 == (-31507200000L));
    }

//    @Test
//    public void test84() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test84");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 1, "Value", "January -457", class3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate9.getEndOfCurrentMonth(serialDate13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate9);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.String str18 = day16.toString();
//        int int19 = day16.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2020" + "'", str18.equals("13-June-2020"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//    }
//}

