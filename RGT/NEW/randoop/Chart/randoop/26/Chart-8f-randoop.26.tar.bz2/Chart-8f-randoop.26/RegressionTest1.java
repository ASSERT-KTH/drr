import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        int int7 = week2.compareTo((java.lang.Object) week5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', year12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 1, year12);
        org.jfree.data.time.Year year15 = week14.getYear();
        long long16 = week14.getLastMillisecond();
        boolean boolean17 = week2.equals((java.lang.Object) long16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week2.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2757L + "'", long4 == 2757L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1967) + "'", int7 == (-1967));
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546761599999L + "'", long16 == 1546761599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        java.util.Date date4 = week3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 36, 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61765516800001L) + "'", long6 == (-61765516800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61765819200001L) + "'", long7 == (-61765819200001L));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean4 = week2.equals((java.lang.Object) (byte) 10);
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400000L) + "'", long5 == (-60526886400000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61766121600000L) + "'", long4 == (-61766121600000L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 0);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62161963200001L) + "'", long3 == (-62161963200001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException8.getSuppressed();
        java.lang.String str13 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 97" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 97"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        java.util.Date date14 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date19 = week18.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        int int22 = week20.compareTo((java.lang.Object) week21);
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str27 = week26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date14, timeZone30);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date36 = week35.getStart();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int40 = week39.getWeek();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        java.util.Date date42 = null;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass46 = week45.getClass();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date50 = week49.getStart();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date50, timeZone51);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date56 = week55.getStart();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date56, timeZone57);
        java.lang.Class class59 = null;
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date63 = week62.getEnd();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date63, timeZone64);
        java.util.TimeZone timeZone66 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date63, timeZone66);
        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass72 = week71.getClass();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date76 = week75.getStart();
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date76, timeZone77);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone79);
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date36, timeZone79);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date14, timeZone79);
        java.util.Locale locale84 = null;
        try {
            org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date5, timeZone79, locale84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2009) + "'", int22 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 10" + "'", str27.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date3 = week2.getStart();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 39, 12" + "'", str4.equals("Week 39, 12"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getFirstMillisecond();
        long long7 = week2.getMiddleMillisecond();
        boolean boolean9 = week2.equals((java.lang.Object) (-59100465600001L));
        int int10 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831440000000L) + "'", long6 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getFirstMillisecond();
        java.util.Date date5 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61831440000000L) + "'", long4 == (-61831440000000L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 35);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        int int10 = week8.compareTo((java.lang.Object) week9);
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str15 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass23 = week22.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.next();
        java.lang.Class<?> wildcardClass25 = week22.getClass();
        java.util.Date date26 = week22.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date26, timeZone27);
        java.util.Locale locale29 = null;
        try {
            org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date3, timeZone27, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-2009) + "'", int10 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 10" + "'", str15.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163777600001L) + "'", long4 == (-62163777600001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62164080000000L) + "'", long6 == (-62164080000000L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date4 = week3.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date12 = week11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date18 = week17.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date18, timeZone19);
        java.lang.Class class21 = null;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date25 = week24.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date25, timeZone28);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date34 = week33.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.Date date36 = week35.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date4, timeZone37);
        java.util.Locale locale40 = null;
        try {
            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date0, timeZone37, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62107531200001L) + "'", long4 == (-62107531200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39 + "'", int6 == 39);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getEnd();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 0" + "'", str6.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 10" + "'", str4.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 35);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str11 = week10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone14);
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 7, 0" + "'", str7.equals("Week 7, 0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        int int7 = week2.getYearValue();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getLastMillisecond();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        java.util.Date date16 = week12.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week12.previous();
        boolean boolean18 = week2.equals((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61830835200001L) + "'", long9 == (-61830835200001L));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(39, year5);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException1.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.lang.Object obj7 = null;
        int int8 = week2.compareTo(obj7);
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830835200001L) + "'", long5 == (-61830835200001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date4 = week3.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, year9);
        long long11 = week10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
        org.jfree.data.time.Year year13 = week10.getYear();
        java.util.Date date14 = week10.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date18 = week17.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        int int21 = week19.compareTo((java.lang.Object) week20);
        java.lang.Class<?> wildcardClass22 = week20.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str26 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week25.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass34 = week33.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week33.next();
        java.lang.Class<?> wildcardClass36 = week33.getClass();
        java.util.Date date37 = week33.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date14, timeZone38);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date4, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4);
        int int43 = week42.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week42.next();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1606636799999L + "'", long11 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-2009) + "'", int21 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 10" + "'", str26.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.util.Calendar calendar7 = null;
        try {
            week4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        boolean boolean6 = week2.equals((java.lang.Object) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831137600001L) + "'", long8 == (-61831137600001L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 52");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 52" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 52"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getMiddleMillisecond();
        long long6 = week4.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61831137600001L) + "'", long5 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 565L + "'", long6 == 565L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, year5);
        long long7 = week6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.Year year9 = week6.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) 'a', year9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '4', year9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(9, year9);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1606636799999L + "'", long7 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        java.util.Date date50 = week49.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass54 = week53.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
        java.util.Date date61 = week59.getEnd();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass65 = week64.getClass();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date69 = week68.getStart();
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone70);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date75 = week74.getStart();
        java.util.TimeZone timeZone76 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date75, timeZone76);
        java.lang.Class class78 = null;
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date82 = week81.getEnd();
        java.util.TimeZone timeZone83 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date82, timeZone83);
        java.util.TimeZone timeZone85 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date82, timeZone85);
        java.lang.Class class87 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date91 = week90.getStart();
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date91);
        java.util.Date date93 = week92.getEnd();
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class87, date93, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date61, timeZone94);
        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date50, timeZone94);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(class87);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod95);
        org.junit.Assert.assertNull(regularTimePeriod96);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, (-1967));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        int int7 = week5.getYearValue();
        java.lang.String str8 = week5.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 10, 97" + "'", str8.equals("Week 10, 97"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 52");
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getWeek();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 10" + "'", str4.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date15 = week14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone22);
        java.lang.Class class24 = null;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date28, timeZone31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass37 = week36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date41 = week40.getStart();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date41, timeZone44);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date49 = week48.getStart();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int53 = week52.getWeek();
        java.lang.Class<?> wildcardClass54 = week52.getClass();
        java.util.Date date55 = null;
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass59 = week58.getClass();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date63 = week62.getStart();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date69 = week68.getStart();
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date69, timeZone70);
        java.lang.Class class72 = null;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date76 = week75.getEnd();
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date76, timeZone77);
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date76, timeZone79);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass85 = week84.getClass();
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date89 = week88.getStart();
        java.util.TimeZone timeZone90 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date89, timeZone90);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date89, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date55, timeZone92);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date49, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date41, timeZone92);
        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date41);
        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date41);
        long long99 = week98.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(regularTimePeriod96);
        org.junit.Assert.assertTrue("'" + long99 + "' != '" + (-62107228800001L) + "'", long99 == (-62107228800001L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((-2009), year3);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getMiddleMillisecond();
        int int8 = week5.getYearValue();
        java.util.Date date9 = week5.getEnd();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1569740399999L + "'", long6 == 1569740399999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1569437999999L + "'", long7 == 1569437999999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        int int7 = week5.getYearValue();
        java.util.Date date8 = week5.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            week5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 11);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2);
        int int3 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', year2);
        java.lang.Class<?> wildcardClass4 = week3.getClass();
        org.jfree.data.time.Year year5 = week3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        int int7 = week2.getYearValue();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass15 = week14.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date19 = week18.getStart();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date25 = week24.getStart();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date25, timeZone26);
        java.lang.Class class28 = null;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date32 = week31.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date32, timeZone33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date32, timeZone35);
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass41 = week40.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date45 = week44.getStart();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date45, timeZone46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date45, timeZone48);
        int int50 = week10.compareTo((java.lang.Object) timeZone48);
        int int51 = week2.compareTo((java.lang.Object) int50);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831440000000L) + "'", long6 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int7 = week6.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        long long9 = week6.getSerialIndex();
        java.lang.String str10 = week6.toString();
        java.util.Date date11 = week6.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date15 = week14.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date19 = week18.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int23 = week22.getWeek();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        java.util.Date date25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date33 = week32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone34);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date39 = week38.getStart();
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date39, timeZone40);
        java.lang.Class class42 = null;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date46 = week45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date46, timeZone47);
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date46, timeZone49);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass55 = week54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date59 = week58.getStart();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date59, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone62);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date19, timeZone62);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date15, timeZone62);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date11, timeZone62);
        int int68 = week2.compareTo((java.lang.Object) timeZone62);
        java.util.Calendar calendar69 = null;
        try {
            long long70 = week2.getMiddleMillisecond(calendar69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 7, 0" + "'", str10.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass4 = week3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date8 = week7.getStart();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date14 = week13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone15);
        java.util.Date date17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass21 = week20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date25 = week24.getStart();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date31 = week30.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date31, timeZone32);
        java.lang.Class class34 = null;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date38 = week37.getEnd();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date38, timeZone39);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date38, timeZone41);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass47 = week46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date51 = week50.getStart();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date51, timeZone52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date17, timeZone54);
        java.util.Locale locale57 = null;
        try {
            org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date0, timeZone54, locale57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        int int3 = week2.getYearValue();
        int int4 = week2.getWeek();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str27 = timePeriodFormatException6.toString();
        java.lang.String str28 = timePeriodFormatException6.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str14 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        int int7 = week2.getYearValue();
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.util.Date date10 = week2.getEnd();
        java.util.Date date11 = week2.getEnd();
        java.lang.String str12 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 10" + "'", str12.equals("Week 35, 10"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date4 = week3.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, year9);
        long long11 = week10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
        org.jfree.data.time.Year year13 = week10.getYear();
        java.util.Date date14 = week10.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date18 = week17.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        int int21 = week19.compareTo((java.lang.Object) week20);
        java.lang.Class<?> wildcardClass22 = week20.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str26 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week25.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass34 = week33.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week33.next();
        java.lang.Class<?> wildcardClass36 = week33.getClass();
        java.util.Date date37 = week33.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date14, timeZone38);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date4, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4);
        int int43 = week42.getYearValue();
        try {
            org.jfree.data.time.Year year44 = week42.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1606636799999L + "'", long11 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-2009) + "'", int21 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 10" + "'", str26.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.String str10 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', (-2009));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        boolean boolean8 = week2.equals((java.lang.Object) (-2009));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830835200001L) + "'", long5 == (-61830835200001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        long long4 = week3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        long long6 = week3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1606636799999L + "'", long4 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1606032000000L + "'", long6 == 1606032000000L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.String str30 = timePeriodFormatException27.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        int int4 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getSerialIndex();
        int int9 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date20 = week19.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date20, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date29 = week28.getStart();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
        java.util.Date date31 = week30.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date31, timeZone32);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int37 = week36.getWeek();
        long long38 = week36.getFirstMillisecond();
        java.util.Date date39 = week36.getStart();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass43 = week42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date47 = week46.getStart();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date53 = week52.getStart();
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date53, timeZone54);
        java.lang.Class class56 = null;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date60 = week59.getEnd();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date60, timeZone61);
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date60, timeZone63);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date69 = week68.getStart();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
        java.util.Date date71 = week70.getEnd();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date71, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date39, timeZone72);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-59100768000000L) + "'", long38 == (-59100768000000L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) '#', year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year3);
        java.lang.String str6 = week5.toString();
        long long7 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 1, 2019" + "'", str6.equals("Week 1, 2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546761599999L + "'", long7 == 1546761599999L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean4 = week2.equals((java.lang.Object) (byte) 10);
        long long5 = week2.getFirstMillisecond();
        int int6 = week2.getYearValue();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str10 = week9.toString();
        long long11 = week9.getSerialIndex();
        long long12 = week9.getLastMillisecond();
        boolean boolean13 = week2.equals((java.lang.Object) long12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400000L) + "'", long5 == (-60526886400000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 10" + "'", str10.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 565L + "'", long11 == 565L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61830835200001L) + "'", long12 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.util.Date date9 = week8.getStart();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 52");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.lang.String str11 = week8.toString();
        long long12 = week8.getFirstMillisecond();
        boolean boolean13 = week2.equals((java.lang.Object) long12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 10" + "'", str9.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61831440000000L) + "'", long12 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException7.getSuppressed();
        int int16 = week4.compareTo((java.lang.Object) timePeriodFormatException7);
        java.util.Date date17 = week4.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        int int23 = week22.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException25.getSuppressed();
        int int34 = week22.compareTo((java.lang.Object) timePeriodFormatException25);
        boolean boolean35 = week4.equals((java.lang.Object) int34);
        int int36 = week4.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 48 + "'", int36 == 48);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 565L + "'", long4 == 565L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.String str11 = timePeriodFormatException9.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str22 = timePeriodFormatException9.toString();
        java.lang.String str23 = timePeriodFormatException9.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 52);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException7.getSuppressed();
        int int16 = week4.compareTo((java.lang.Object) timePeriodFormatException7);
        java.util.Date date17 = week4.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        int int23 = week22.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException25.getSuppressed();
        int int34 = week22.compareTo((java.lang.Object) timePeriodFormatException25);
        boolean boolean35 = week4.equals((java.lang.Object) int34);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = week4.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getFirstMillisecond();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.lang.Class<?> wildcardClass9 = week2.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59100768000000L) + "'", long4 == (-59100768000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59100768000000L) + "'", long5 == (-59100768000000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 10, 97" + "'", str6.equals("Week 10, 97"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) '#', year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        long long7 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107007L + "'", long7 == 107007L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getLastMillisecond();
        long long7 = week5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59100163200001L) + "'", long6 == (-59100163200001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100768000000L) + "'", long7 == (-59100768000000L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        org.jfree.data.time.Year year4 = week3.getYear();
        long long5 = week3.getSerialIndex();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107107L + "'", long5 == 107107L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        long long12 = week11.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61830835200001L) + "'", long8 == (-61830835200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 566L + "'", long12 == 566L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year4);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        boolean boolean7 = week2.equals((java.lang.Object) (-62164080000000L));
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        boolean boolean12 = week2.equals((java.lang.Object) regularTimePeriod11);
        java.lang.Class class13 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date17 = week16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
        int int19 = week16.getYearValue();
        int int20 = week16.getYearValue();
        int int21 = week16.getYearValue();
        java.util.Date date22 = week16.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year25 = week24.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(100, year25);
        long long27 = week26.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
        org.jfree.data.time.Year year29 = week26.getYear();
        java.util.Date date30 = week26.getEnd();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date34 = week33.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
        int int37 = week35.compareTo((java.lang.Object) week36);
        java.lang.Class<?> wildcardClass38 = week36.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str42 = week41.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.next();
        java.util.Date date44 = regularTimePeriod43.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass50 = week49.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week49.next();
        java.lang.Class<?> wildcardClass52 = week49.getClass();
        java.util.Date date53 = week49.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date53, timeZone54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date30, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date22, timeZone54);
        int int58 = week2.compareTo((java.lang.Object) timeZone54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1606636799999L + "'", long27 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-2009) + "'", int37 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 10" + "'", str42.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', year2);
        int int4 = week3.getYearValue();
        java.util.Date date5 = week3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int9 = week8.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        long long11 = week8.getSerialIndex();
        java.lang.String str12 = week8.toString();
        java.util.Date date13 = week8.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date17 = week16.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int25 = week24.getWeek();
        java.lang.Class<?> wildcardClass26 = week24.getClass();
        java.util.Date date27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass31 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date35 = week34.getStart();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date41 = week40.getStart();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date41, timeZone42);
        java.lang.Class class44 = null;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date48 = week47.getEnd();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone49);
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date48, timeZone51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass57 = week56.getClass();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date61 = week60.getStart();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone64);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date21, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date17, timeZone64);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date13, timeZone64);
        java.util.Locale locale70 = null;
        try {
            org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date5, timeZone64, locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 7L + "'", long11 == 7L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 7, 0" + "'", str12.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod66);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.lang.String str8 = week6.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61830230400001L) + "'", long7 == (-61830230400001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 36, 10" + "'", str8.equals("Week 36, 10"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date11 = week10.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        int int14 = week12.compareTo((java.lang.Object) week13);
        java.lang.Class<?> wildcardClass15 = week13.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str19 = week18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week18.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date6, timeZone22);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = week24.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2009) + "'", int14 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 10" + "'", str19.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        java.util.Date date50 = week49.getEnd();
        long long51 = week49.getFirstMillisecond();
        java.util.Calendar calendar52 = null;
        try {
            long long53 = week49.getFirstMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-62107833600000L) + "'", long51 == (-62107833600000L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date11 = week10.getStart();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        int int13 = week12.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        int int24 = week12.compareTo((java.lang.Object) timePeriodFormatException15);
        java.util.Date date25 = week12.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date29 = week28.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.next();
        long long31 = week28.getLastMillisecond();
        java.util.Date date32 = week28.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass36 = week35.getClass();
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getEnd();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass47 = week46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date51 = week50.getStart();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date51, timeZone52);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date57 = week56.getStart();
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date57, timeZone58);
        java.lang.Class class60 = null;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date64 = week63.getEnd();
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date64, timeZone65);
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date64, timeZone67);
        java.lang.Class class69 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date73 = week72.getStart();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
        java.util.Date date75 = week74.getEnd();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone76);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date32, timeZone76);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date25, timeZone76);
        java.util.Locale locale81 = null;
        try {
            org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date7, timeZone76, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61830835200001L) + "'", long31 == (-61830835200001L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(class69);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        int int7 = week2.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(35, (int) 'a');
        boolean boolean11 = week2.equals((java.lang.Object) week10);
        java.util.Date date12 = week10.getStart();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2757L + "'", long4 == 2757L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1967) + "'", int7 == (-1967));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.lang.String str11 = week8.toString();
        long long12 = week8.getFirstMillisecond();
        boolean boolean13 = week2.equals((java.lang.Object) long12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 10" + "'", str9.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61831440000000L) + "'", long12 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = week2.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 565L + "'", long4 == 565L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 39, 2019");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year4);
        long long8 = week7.getFirstMillisecond();
        long long9 = week7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1545552000000L + "'", long8 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1545854399999L + "'", long9 == 1545854399999L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, (int) 'a');
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59085648000000L) + "'", long3 == (-59085648000000L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException6.getSuppressed();
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        int int6 = week2.getYearValue();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        java.lang.Class<?> wildcardClass12 = week9.getClass();
        java.util.Date date13 = week9.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date18 = week17.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        int int21 = week19.compareTo((java.lang.Object) week20);
        java.lang.Class<?> wildcardClass22 = week20.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str26 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week25.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date13, timeZone29);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int39 = week38.getWeek();
        java.lang.Class<?> wildcardClass40 = week38.getClass();
        java.util.Date date41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = week44.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date49 = week48.getStart();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date55 = week54.getStart();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date55, timeZone56);
        java.lang.Class class58 = null;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date62 = week61.getEnd();
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date62, timeZone63);
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date62, timeZone65);
        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass71 = week70.getClass();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date75 = week74.getStart();
        java.util.TimeZone timeZone76 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date75, timeZone76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date75, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone78);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date35, timeZone78);
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date13, timeZone78);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date13);
        int int84 = week2.compareTo((java.lang.Object) date13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 565L + "'", long4 == 565L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-2009) + "'", int21 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 10" + "'", str26.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date15 = week14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone22);
        java.lang.Class class24 = null;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date28, timeZone31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass37 = week36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date41 = week40.getStart();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date41, timeZone44);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date49 = week48.getStart();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int53 = week52.getWeek();
        java.lang.Class<?> wildcardClass54 = week52.getClass();
        java.util.Date date55 = null;
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass59 = week58.getClass();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date63 = week62.getStart();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date69 = week68.getStart();
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date69, timeZone70);
        java.lang.Class class72 = null;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date76 = week75.getEnd();
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date76, timeZone77);
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date76, timeZone79);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass85 = week84.getClass();
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date89 = week88.getStart();
        java.util.TimeZone timeZone90 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date89, timeZone90);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date89, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date55, timeZone92);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date49, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date41, timeZone92);
        java.util.Date date97 = regularTimePeriod96.getStart();
        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date97);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(regularTimePeriod96);
        org.junit.Assert.assertNotNull(date97);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.lang.String str11 = week8.toString();
        long long12 = week8.getFirstMillisecond();
        boolean boolean13 = week2.equals((java.lang.Object) long12);
        int int14 = week2.getWeek();
        java.util.Date date15 = week2.getEnd();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week2.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 10" + "'", str9.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61831440000000L) + "'", long12 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date20 = week19.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date20, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date33 = week32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date33);
        java.lang.Class<?> wildcardClass39 = date33.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str9 = timePeriodFormatException6.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException6.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date14 = week13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date14, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week19.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526281600001L) + "'", long4 == (-60526281600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526584000001L) + "'", long5 == (-60526584000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) -1);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62139283200000L) + "'", long3 == (-62139283200000L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean4 = week2.equals((java.lang.Object) (byte) 10);
        long long5 = week2.getFirstMillisecond();
        int int6 = week2.getYearValue();
        java.lang.String str7 = week2.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400000L) + "'", long5 == (-60526886400000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 52" + "'", str7.equals("Week 1, 52"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        int int11 = week9.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.next();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year13 = week12.getYear();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, year13);
        java.util.Date date15 = week14.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int19 = week18.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week18.next();
        long long21 = week18.getSerialIndex();
        java.lang.String str22 = week18.toString();
        java.util.Date date23 = week18.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date27 = week26.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int35 = week34.getWeek();
        java.lang.Class<?> wildcardClass36 = week34.getClass();
        java.util.Date date37 = null;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass41 = week40.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date45 = week44.getStart();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date45, timeZone46);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date51 = week50.getStart();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone52);
        java.lang.Class class54 = null;
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date58 = week57.getEnd();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date58, timeZone59);
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date58, timeZone61);
        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass67 = week66.getClass();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date71 = week70.getStart();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date71, timeZone72);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date71, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone74);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date31, timeZone74);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date27, timeZone74);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date23, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone74);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7L + "'", long21 == 7L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 7, 0" + "'", str22.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 100");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        boolean boolean11 = week2.equals((java.lang.Object) str10);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831440000000L) + "'", long6 == (-61831440000000L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 100" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 100"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) '4');
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        int int7 = week2.compareTo((java.lang.Object) week5);
        java.util.Date date8 = week5.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        java.util.Date date16 = week12.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        int int24 = week22.compareTo((java.lang.Object) week23);
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str29 = week28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.next();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date16, timeZone32);
        java.util.Locale locale35 = null;
        try {
            org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date8, timeZone32, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2757L + "'", long4 == 2757L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1967) + "'", int7 == (-1967));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-2009) + "'", int24 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 10" + "'", str29.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        long long50 = week49.getLastMillisecond();
        long long51 = week49.getMiddleMillisecond();
        long long52 = week49.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62107228800001L) + "'", long50 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-62107531200001L) + "'", long51 == (-62107531200001L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-62107228800001L) + "'", long52 == (-62107228800001L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        java.util.Date date4 = week3.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, 5);
        boolean boolean8 = week3.equals((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        java.util.Date date4 = week3.getEnd();
        java.lang.String str5 = week3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 2019" + "'", str5.equals("Week 100, 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
        long long9 = week8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        org.jfree.data.time.Year year11 = week8.getYear();
        boolean boolean12 = week2.equals((java.lang.Object) year11);
        java.lang.Class<?> wildcardClass13 = week2.getClass();
        java.util.Date date14 = week2.getStart();
        long long15 = week2.getMiddleMillisecond();
        long long16 = week2.getFirstMillisecond();
        long long17 = week2.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week2.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 39, 12" + "'", str4.equals("Week 39, 12"));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1606636799999L + "'", long9 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61765819200001L) + "'", long15 == (-61765819200001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61766121600000L) + "'", long16 == (-61766121600000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61765819200001L) + "'", long17 == (-61765819200001L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        int int10 = week2.getYearValue();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, year14);
        long long16 = week15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week15.next();
        org.jfree.data.time.Year year18 = week15.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) 'a', year18);
        int int20 = week2.compareTo((java.lang.Object) year18);
        long long21 = year18.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831440000000L) + "'", long7 == (-61831440000000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1606636799999L + "'", long16 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        int int5 = week3.compareTo((java.lang.Object) false);
        long long6 = week3.getLastMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1606636799999L + "'", long6 == 1606636799999L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        long long7 = week5.getMiddleMillisecond();
        java.lang.String str8 = week5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.String str10 = week5.toString();
        int int12 = week5.compareTo((java.lang.Object) 566L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100465600001L) + "'", long7 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 10, 97" + "'", str8.equals("Week 10, 97"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 97" + "'", str10.equals("Week 10, 97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.String str9 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 0" + "'", str5.equals("Week 100, 0"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date11 = week10.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        int int14 = week12.compareTo((java.lang.Object) week13);
        java.lang.Class<?> wildcardClass15 = week13.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str19 = week18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week18.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date6, timeZone22);
        int int25 = week24.getYearValue();
        int int26 = week24.getWeek();
        long long27 = week24.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2009) + "'", int14 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 10" + "'", str19.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 35 + "'", int26 == 35);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61831137600001L) + "'", long27 == (-61831137600001L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-2009), 12);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        boolean boolean11 = week2.equals((java.lang.Object) week8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59100465600001L) + "'", long5 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 39, 12" + "'", str9.equals("Week 39, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', year8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year8);
        java.util.Date date11 = week10.getEnd();
        long long12 = week10.getFirstMillisecond();
        boolean boolean13 = week4.equals((java.lang.Object) week10);
        long long14 = week10.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1545552000000L + "'", long12 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107007L + "'", long14 == 107007L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date14 = week13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date14, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date14);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date11 = week10.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date11, timeZone12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date17, timeZone18);
        java.lang.Class class20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date24 = week23.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone25);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date24, timeZone27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date33 = week32.getStart();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.Date date35 = week34.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date35, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date3, timeZone36);
        long long39 = week38.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62107833600000L) + "'", long39 == (-62107833600000L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException13.getClass();
        java.lang.String str18 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str29 = timePeriodFormatException28.toString();
        java.lang.String str30 = timePeriodFormatException28.toString();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException28.getSuppressed();
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        long long17 = week16.getSerialIndex();
        int int18 = week16.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.String str25 = timePeriodFormatException20.toString();
        boolean boolean26 = week16.equals((java.lang.Object) timePeriodFormatException20);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 101L + "'", long17 == 101L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 48 + "'", int18 == 48);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        long long5 = week4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.jfree.data.time.Year year7 = week4.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-1967), year7);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1606636799999L + "'", long5 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 10" + "'", str6.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = regularTimePeriod4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830532800001L) + "'", long5 == (-61830532800001L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        boolean boolean7 = week2.equals((java.lang.Object) (-62164080000000L));
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        boolean boolean12 = week2.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        java.util.Date date14 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException7.getSuppressed();
        int int16 = week4.compareTo((java.lang.Object) timePeriodFormatException7);
        long long17 = week4.getLastMillisecond();
        java.lang.String str18 = week4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62107228800001L) + "'", long17 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 48, 1" + "'", str18.equals("Week 48, 1"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        long long50 = week49.getLastMillisecond();
        boolean boolean52 = week49.equals((java.lang.Object) 1.0d);
        int int53 = week49.getYearValue();
        java.lang.String str54 = week49.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62107228800001L) + "'", long50 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 48, 1" + "'", str54.equals("Week 48, 1"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.String str5 = week2.toString();
        int int6 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 6);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '4');
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException7.getSuppressed();
        int int16 = week4.compareTo((java.lang.Object) timePeriodFormatException7);
        long long17 = week4.getLastMillisecond();
        int int18 = week4.getYearValue();
        java.util.Date date19 = week4.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62107228800001L) + "'", long17 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        int int6 = week3.getYearValue();
        int int7 = week3.getYearValue();
        int int8 = week3.getYearValue();
        java.util.Date date9 = week3.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, year12);
        long long14 = week13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        org.jfree.data.time.Year year16 = week13.getYear();
        java.util.Date date17 = week13.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        int int24 = week22.compareTo((java.lang.Object) week23);
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str29 = week28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.next();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass37 = week36.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
        java.lang.Class<?> wildcardClass39 = week36.getClass();
        java.util.Date date40 = week36.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date17, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone41);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass48 = week47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class49);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class49);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass55 = week54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date59 = week58.getStart();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date59, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date9, timeZone62);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1606636799999L + "'", long14 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-2009) + "'", int24 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 10" + "'", str29.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int11 = week10.getWeek();
        java.lang.Class<?> wildcardClass12 = week10.getClass();
        java.util.Date date13 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = week16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date27 = week26.getStart();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date27, timeZone28);
        java.lang.Class class30 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date34 = week33.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date34, timeZone35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date34, timeZone37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass43 = week42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date47 = week46.getStart();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date47, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone50);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date7, timeZone50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date3, timeZone50);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar56 = null;
        try {
            week55.peg(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod52);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((-2009), year3);
        int int6 = week5.getWeek();
        java.util.Date date7 = week5.getEnd();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39 + "'", int6 == 39);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        int int7 = week2.compareTo((java.lang.Object) 9);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((-2009), 12);
        java.lang.String str11 = week10.toString();
        try {
            int int12 = week2.compareTo((java.lang.Object) week10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526281600001L) + "'", long4 == (-60526281600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 1, 52" + "'", str5.equals("Week 1, 52"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 39, 12" + "'", str11.equals("Week 39, 12"));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830835200001L) + "'", long5 == (-61830835200001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 100, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        long long7 = week5.getMiddleMillisecond();
        java.lang.String str8 = week5.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week5.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100465600001L) + "'", long7 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 10, 97" + "'", str8.equals("Week 10, 97"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526281600001L) + "'", long4 == (-60526281600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526584000001L) + "'", long5 == (-60526584000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        int int12 = week11.getYearValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61830835200001L) + "'", long8 == (-61830835200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        int int7 = week2.compareTo((java.lang.Object) week5);
        java.util.Date date8 = week5.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date12 = week11.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date16 = week15.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int20 = week19.getWeek();
        java.lang.Class<?> wildcardClass21 = week19.getClass();
        java.util.Date date22 = null;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = week25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date30 = week29.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date36 = week35.getStart();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date36, timeZone37);
        java.lang.Class class39 = null;
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date43 = week42.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone44);
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date43, timeZone46);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass52 = week51.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date56 = week55.getStart();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date56, timeZone57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date56, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone59);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date16, timeZone59);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date12, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date8, timeZone59);
        java.lang.Class<?> wildcardClass65 = timeZone59.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2757L + "'", long4 == 2757L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1967) + "'", int7 == (-1967));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int7 = week6.getWeek();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date17 = week16.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
        java.lang.Class class26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date30 = week29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date30, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date3, timeZone46);
        long long50 = week49.getLastMillisecond();
        boolean boolean52 = week49.equals((java.lang.Object) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week49.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62107228800001L) + "'", long50 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        int int6 = week2.getYearValue();
        long long7 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62164080000000L) + "'", long7 == (-62164080000000L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean4 = week2.equals((java.lang.Object) (byte) 10);
        long long5 = week2.getFirstMillisecond();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400000L) + "'", long5 == (-60526886400000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = week2.getEnd();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61830835200001L) + "'", long9 == (-61830835200001L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getMiddleMillisecond();
        java.util.Date date6 = week4.getStart();
        int int7 = week4.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61831137600001L) + "'", long5 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.String str30 = timePeriodFormatException27.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str37 = timePeriodFormatException16.toString();
        java.lang.String str38 = timePeriodFormatException16.toString();
        java.lang.String str39 = timePeriodFormatException16.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getFirstMillisecond();
        long long7 = week2.getLastMillisecond();
        long long8 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831440000000L) + "'", long6 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61830835200001L) + "'", long7 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        long long17 = week16.getSerialIndex();
        long long18 = week16.getSerialIndex();
        java.util.Date date19 = week16.getEnd();
        java.util.Date date20 = week16.getStart();
        java.lang.String str21 = week16.toString();
        java.util.Calendar calendar22 = null;
        try {
            week16.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 101L + "'", long17 == 101L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 101L + "'", long18 == 101L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 48, 1" + "'", str21.equals("Week 48, 1"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException6.getSuppressed();
        java.lang.Throwable throwable11 = null;
        try {
            timePeriodFormatException6.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        int int7 = week2.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(35, (int) 'a');
        boolean boolean11 = week2.equals((java.lang.Object) week10);
        try {
            org.jfree.data.time.Year year12 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2757L + "'", long4 == 2757L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1967) + "'", int7 == (-1967));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        long long4 = week3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        long long6 = week3.getSerialIndex();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1606636799999L + "'", long4 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107107L + "'", long6 == 107107L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) '#', year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 1, year3);
        org.jfree.data.time.Year year6 = week5.getYear();
        java.util.Date date7 = week5.getStart();
        long long8 = week5.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107008L + "'", long8 == 107008L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        long long7 = week5.getMiddleMillisecond();
        java.lang.String str8 = week5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = week5.getClass();
        long long11 = week5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100465600001L) + "'", long7 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 10, 97" + "'", str8.equals("Week 10, 97"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59100768000000L) + "'", long11 == (-59100768000000L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        int int6 = week2.getYearValue();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        long long5 = week4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.jfree.data.time.Year year7 = week4.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1606636799999L + "'", long5 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        boolean boolean7 = week2.equals((java.lang.Object) (-62164080000000L));
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        boolean boolean12 = week2.equals((java.lang.Object) regularTimePeriod11);
        java.util.Date date13 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str24 = timePeriodFormatException23.toString();
        java.lang.String str25 = timePeriodFormatException23.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.String str36 = timePeriodFormatException23.toString();
        int int37 = week2.compareTo((java.lang.Object) str36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.util.Date date7 = week4.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date12 = week11.getStart();
        java.util.Date date13 = week11.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year16 = week15.getYear();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, year16);
        long long18 = week17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week17.next();
        org.jfree.data.time.Year year20 = week17.getYear();
        java.util.Date date21 = week17.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date25 = week24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        int int28 = week26.compareTo((java.lang.Object) week27);
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str33 = week32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass41 = week40.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week40.next();
        java.lang.Class<?> wildcardClass43 = week40.getClass();
        java.util.Date date44 = week40.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date21, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date13, timeZone45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date7, timeZone45);
        java.util.Date date50 = week49.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1606636799999L + "'", long18 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2009) + "'", int28 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2757L + "'", long3 == 2757L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526281600001L) + "'", long4 == (-60526281600001L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        int int6 = week3.getYearValue();
        int int7 = week3.getYearValue();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str11 = week10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
        java.lang.String str13 = week10.toString();
        long long14 = week10.getFirstMillisecond();
        int int15 = week10.getYearValue();
        boolean boolean16 = week3.equals((java.lang.Object) week10);
        java.util.Date date17 = week3.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass21 = week20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        int int28 = week27.getWeek();
        int int30 = week27.compareTo((java.lang.Object) 1560063600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date37 = week36.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
        int int39 = week36.getYearValue();
        int int40 = week36.getYearValue();
        int int41 = week36.getYearValue();
        java.util.Date date42 = week36.getEnd();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year45 = week44.getYear();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(100, year45);
        long long47 = week46.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week46.next();
        org.jfree.data.time.Year year49 = week46.getYear();
        java.util.Date date50 = week46.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date54 = week53.getEnd();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
        int int57 = week55.compareTo((java.lang.Object) week56);
        java.lang.Class<?> wildcardClass58 = week56.getClass();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str62 = week61.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week61.next();
        java.util.Date date64 = regularTimePeriod63.getEnd();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date64, timeZone65);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass70 = week69.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week69.next();
        java.lang.Class<?> wildcardClass72 = week69.getClass();
        java.util.Date date73 = week69.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date73, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date50, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date42, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date32, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date17, timeZone74);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 10" + "'", str13.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61831440000000L) + "'", long14 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1606636799999L + "'", long47 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-2009) + "'", int57 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 35, 10" + "'", str62.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
        long long9 = week8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        org.jfree.data.time.Year year11 = week8.getYear();
        boolean boolean12 = week2.equals((java.lang.Object) year11);
        java.lang.Class<?> wildcardClass13 = week2.getClass();
        java.util.Date date14 = week2.getStart();
        long long15 = week2.getMiddleMillisecond();
        long long16 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 39, 12" + "'", str4.equals("Week 39, 12"));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1606636799999L + "'", long9 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61765819200001L) + "'", long15 == (-61765819200001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61766121600000L) + "'", long16 == (-61766121600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        int int7 = week5.getYearValue();
        java.util.Date date8 = week5.getEnd();
        java.lang.Object obj9 = null;
        int int10 = week5.compareTo(obj9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) '#', year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        int int3 = week2.getWeek();
        int int5 = week2.compareTo((java.lang.Object) 1560063600000L);
        java.lang.Object obj6 = null;
        int int7 = week2.compareTo(obj6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str14 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        int int16 = week2.compareTo((java.lang.Object) throwableArray15);
        long long17 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164080000000L) + "'", long4 == (-62164080000000L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 10" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 10"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62163475200001L) + "'", long17 == (-62163475200001L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str10 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        java.lang.String str12 = week9.toString();
        long long13 = week9.getFirstMillisecond();
        int int14 = week9.getYearValue();
        boolean boolean15 = week2.equals((java.lang.Object) week9);
        java.lang.Object obj16 = null;
        int int17 = week2.compareTo(obj16);
        java.lang.String str18 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 10" + "'", str10.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 10" + "'", str12.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61831440000000L) + "'", long13 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 10" + "'", str18.equals("Week 35, 10"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 10" + "'", str5.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831440000000L) + "'", long6 == (-61831440000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        int int6 = week2.getYearValue();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str10 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        java.lang.String str12 = week9.toString();
        long long13 = week9.getFirstMillisecond();
        int int14 = week9.getYearValue();
        boolean boolean15 = week2.equals((java.lang.Object) week9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException17.getSuppressed();
        int int20 = week2.compareTo((java.lang.Object) timePeriodFormatException17);
        long long21 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date25 = week24.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.next();
        long long27 = week24.getLastMillisecond();
        int int28 = week24.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week24.previous();
        int int30 = week24.getWeek();
        try {
            int int31 = week2.compareTo((java.lang.Object) week24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 10" + "'", str10.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 10" + "'", str12.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61831440000000L) + "'", long13 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61831440000000L) + "'", long21 == (-61831440000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61830835200001L) + "'", long27 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61765819200001L) + "'", long4 == (-61765819200001L));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) week5);
//        long long7 = week5.getFirstMillisecond();
//        long long8 = week5.getSerialIndex();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59100465600001L) + "'", long5 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getMiddleMillisecond();
        java.util.Date date6 = week4.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int10 = week9.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
        boolean boolean13 = week4.equals((java.lang.Object) week9);
        java.lang.Object obj14 = null;
        boolean boolean15 = week9.equals(obj14);
        java.util.Date date16 = week9.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61831137600001L) + "'", long5 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '4', year4);
        java.lang.String str8 = week7.toString();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 52, 2019" + "'", str8.equals("Week 52, 2019"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 52");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(39, year4);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.util.Date date7 = week4.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date12 = week11.getStart();
        java.util.Date date13 = week11.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year16 = week15.getYear();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, year16);
        long long18 = week17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week17.next();
        org.jfree.data.time.Year year20 = week17.getYear();
        java.util.Date date21 = week17.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date25 = week24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        int int28 = week26.compareTo((java.lang.Object) week27);
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str33 = week32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass41 = week40.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week40.next();
        java.lang.Class<?> wildcardClass43 = week40.getClass();
        java.util.Date date44 = week40.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date21, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date13, timeZone45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date7, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1606636799999L + "'", long18 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2009) + "'", int28 == (-2009));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        long long4 = week2.getFirstMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59100768000000L) + "'", long4 == (-59100768000000L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        int int6 = week2.getYearValue();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62164080000000L) + "'", long7 == (-62164080000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        long long3 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = week2.equals((java.lang.Object) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59100465600001L) + "'", long3 == (-59100465600001L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104507200001L) + "'", long4 == (-62104507200001L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int6 = week2.compareTo((java.lang.Object) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.lang.String str11 = week8.toString();
        long long12 = week8.getFirstMillisecond();
        boolean boolean13 = week2.equals((java.lang.Object) long12);
        int int14 = week2.getWeek();
        java.util.Date date15 = week2.getEnd();
        long long16 = week2.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week2.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 10" + "'", str9.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 10" + "'", str11.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61831440000000L) + "'", long12 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61830835200001L) + "'", long16 == (-61830835200001L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 0");
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date11 = week10.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date15 = week14.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int19 = week18.getWeek();
        java.lang.Class<?> wildcardClass20 = week18.getClass();
        java.util.Date date21 = null;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = week24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date29 = week28.getStart();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date35 = week34.getStart();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date35, timeZone36);
        java.lang.Class class38 = null;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date42 = week41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date42, timeZone43);
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date42, timeZone45);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass51 = week50.getClass();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date55 = week54.getStart();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date55, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone58);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date15, timeZone58);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date11, timeZone58);
        java.util.Locale locale63 = null;
        try {
            org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date5, timeZone58, locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNull(regularTimePeriod60);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        long long7 = week5.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100465600001L) + "'", long7 == (-59100465600001L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        long long17 = week16.getSerialIndex();
        long long18 = week16.getSerialIndex();
        long long19 = week16.getMiddleMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date23 = week22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.next();
        java.util.Date date25 = regularTimePeriod24.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25);
        java.lang.Class<?> wildcardClass28 = date25.getClass();
        boolean boolean29 = week16.equals((java.lang.Object) date25);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 101L + "'", long17 == 101L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 101L + "'", long18 == 101L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62107531200001L) + "'", long19 == (-62107531200001L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        long long7 = week5.getMiddleMillisecond();
        java.lang.String str8 = week5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = week5.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59100465600001L) + "'", long7 == (-59100465600001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 10, 97" + "'", str8.equals("Week 10, 97"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        int int3 = week2.getWeek();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 10" + "'", str6.equals("Week 35, 10"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException7.getSuppressed();
        int int16 = week4.compareTo((java.lang.Object) timePeriodFormatException7);
        long long17 = week4.getLastMillisecond();
        int int18 = week4.getYearValue();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        int int22 = week21.getWeek();
        java.lang.String str23 = week21.toString();
        boolean boolean24 = week4.equals((java.lang.Object) week21);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62107228800001L) + "'", long17 == (-62107228800001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 10" + "'", str23.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 97" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 97"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.String str11 = timePeriodFormatException9.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 97" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 97"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, year3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date10 = week9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        int int13 = week11.compareTo((java.lang.Object) week12);
        java.util.Date date14 = week11.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date19 = week18.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        int int21 = week20.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException23.getSuppressed();
        int int32 = week20.compareTo((java.lang.Object) timePeriodFormatException23);
        java.util.Date date33 = week20.getStart();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date37 = week36.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
        long long39 = week36.getLastMillisecond();
        java.util.Date date40 = week36.getStart();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass44 = week43.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        java.util.Date date51 = week49.getEnd();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass55 = week54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date59 = week58.getStart();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date65 = week64.getStart();
        java.util.TimeZone timeZone66 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date65, timeZone66);
        java.lang.Class class68 = null;
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date72 = week71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date72, timeZone73);
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date72, timeZone75);
        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date81 = week80.getStart();
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date81);
        java.util.Date date83 = week82.getEnd();
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date83, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date51, timeZone84);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date40, timeZone84);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date33, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone84);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2009) + "'", int13 == (-2009));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61830835200001L) + "'", long39 == (-61830835200001L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(class77);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', year5);
        boolean boolean7 = week2.equals((java.lang.Object) week6);
        long long8 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year9 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831440000000L) + "'", long8 == (-61831440000000L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 11);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61799385600001L) + "'", long3 == (-61799385600001L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean4 = week2.equals((java.lang.Object) (byte) 10);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526584000001L) + "'", long5 == (-60526584000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60526584000001L) + "'", long6 == (-60526584000001L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        long long17 = week16.getSerialIndex();
        long long18 = week16.getSerialIndex();
        java.util.Date date19 = week16.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date23 = week22.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int27 = week26.getWeek();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        java.util.Date date29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass33 = week32.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date37 = week36.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date43 = week42.getStart();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date43, timeZone44);
        java.lang.Class class46 = null;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date50 = week49.getEnd();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date50, timeZone51);
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date50, timeZone53);
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass59 = week58.getClass();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date63 = week62.getStart();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date63, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone66);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date23, timeZone66);
        java.util.Locale locale70 = null;
        try {
            org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date19, timeZone66, locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 101L + "'", long17 == 101L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 101L + "'", long18 == 101L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62107531200001L) + "'", long4 == (-62107531200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.previous();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        int int6 = week2.getYearValue();
        int int7 = week2.getWeek();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week4.compareTo((java.lang.Object) week5);
        java.util.Date date7 = week4.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        boolean boolean13 = week9.equals((java.lang.Object) throwableArray12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2009) + "'", int6 == (-2009));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 565L + "'", long4 == 565L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830835200001L) + "'", long5 == (-61830835200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int3 = week2.getWeek();
        int int4 = week2.getWeek();
        int int5 = week2.getWeek();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62164080000000L) + "'", long7 == (-62164080000000L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException5.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, year17);
        java.util.Date date19 = week18.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        int int23 = week22.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.next();
        long long25 = week22.getSerialIndex();
        java.lang.String str26 = week22.toString();
        java.util.Date date27 = week22.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date31 = week30.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int39 = week38.getWeek();
        java.lang.Class<?> wildcardClass40 = week38.getClass();
        java.util.Date date41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = week44.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date49 = week48.getStart();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date55 = week54.getStart();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date55, timeZone56);
        java.lang.Class class58 = null;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date62 = week61.getEnd();
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date62, timeZone63);
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date62, timeZone65);
        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass71 = week70.getClass();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date75 = week74.getStart();
        java.util.TimeZone timeZone76 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date75, timeZone76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date75, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone78);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date35, timeZone78);
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date31, timeZone78);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date27, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone78);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date3, timeZone78);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 7L + "'", long25 == 7L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 7, 0" + "'", str26.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod84);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        int int11 = week3.compareTo((java.lang.Object) class8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week3.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        int int12 = week9.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.previous();
        java.util.Date date14 = week9.getStart();
        boolean boolean15 = week5.equals((java.lang.Object) week9);
        java.util.Date date16 = week9.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 2);
        java.util.Date date3 = week2.getEnd();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62105414400000L) + "'", long4 == (-62105414400000L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date13, timeZone14);
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date20 = week19.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date20, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date33 = week32.getStart();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date33);
        java.util.Date date39 = week38.getEnd();
        long long40 = week38.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 101L + "'", long40 == 101L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass4 = week3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date8 = week7.getStart();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date14 = week13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone15);
        java.lang.Class class17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date21 = week20.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date21, timeZone24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = week29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date34 = week33.getStart();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date34, timeZone37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date34, timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61830835200001L) + "'", long5 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, year2);
        long long4 = week3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
        java.lang.String str13 = timePeriodFormatException7.toString();
        int int14 = week3.compareTo((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str25 = timePeriodFormatException24.toString();
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1606636799999L + "'", long4 == 1606636799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date7 = week6.getStart();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(1, (int) '4');
        boolean boolean14 = week12.equals((java.lang.Object) (byte) 10);
        long long15 = week12.getFirstMillisecond();
        java.util.Date date16 = week12.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date20 = week19.getStart();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int24 = week23.getWeek();
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        java.util.Date date26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = week29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date34 = week33.getStart();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date40 = week39.getStart();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date40, timeZone41);
        java.lang.Class class43 = null;
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date47 = week46.getEnd();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone48);
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone50);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass56 = week55.getClass();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date60 = week59.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date60, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone63);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date20, timeZone63);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date16, timeZone63);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date7, timeZone63);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60526886400000L) + "'", long15 == (-60526886400000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod65);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((-2009), year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year4.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str10 = timePeriodFormatException5.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getFirstMillisecond();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59100768000000L) + "'", long4 == (-59100768000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-59100768000000L) + "'", long5 == (-59100768000000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 10, 97" + "'", str6.equals("Week 10, 97"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', year9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(0, year9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(3, year9);
        int int13 = week2.compareTo((java.lang.Object) year9);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 1, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', year4);
        java.lang.String str8 = week7.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week7.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 2019" + "'", str8.equals("Week 35, 2019"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 97");
        java.lang.String str7 = timePeriodFormatException6.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2019");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 97" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 97"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        int int10 = week2.getYearValue();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date14 = week13.getStart();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year19 = week18.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', year19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(0, year19);
        java.util.Date date22 = week21.getEnd();
        long long23 = week21.getFirstMillisecond();
        boolean boolean24 = week15.equals((java.lang.Object) week21);
        boolean boolean25 = week2.equals((java.lang.Object) week21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week21.previous();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831440000000L) + "'", long7 == (-61831440000000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1545552000000L + "'", long23 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        int int7 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2009), 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date8 = week7.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        int int11 = week9.compareTo((java.lang.Object) "Week 1, 52");
        int int12 = week9.getWeek();
        int int13 = week9.getWeek();
        long long14 = week9.getLastMillisecond();
        int int15 = week4.compareTo((java.lang.Object) long14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61830835200001L) + "'", long14 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.String str15 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (byte) 10, (int) 'a');
        int int25 = week24.getWeek();
        java.lang.Class<?> wildcardClass26 = week24.getClass();
        java.util.Date date27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass31 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date35 = week34.getStart();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date41 = week40.getStart();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date41, timeZone42);
        java.lang.Class class44 = null;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.util.Date date48 = week47.getEnd();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone49);
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date48, timeZone51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
        java.lang.Class<?> wildcardClass57 = week56.getClass();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) (short) 100, (int) (byte) 0);
        java.util.Date date61 = week60.getStart();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone64);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date21, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date17, timeZone64);
        int int69 = week6.compareTo((java.lang.Object) date17);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 10" + "'", str15.equals("Week 35, 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }
}

