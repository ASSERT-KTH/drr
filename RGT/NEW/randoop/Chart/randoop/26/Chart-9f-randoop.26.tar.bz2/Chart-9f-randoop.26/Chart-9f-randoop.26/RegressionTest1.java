import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = null;
        timeSeriesDataItem5.setValue(number7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries10.setDomainDescription("");
        java.lang.Object obj13 = timeSeries10.clone();
        long long14 = timeSeries10.getMaximumItemAge();
        timeSeries10.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int19 = month18.getYearValue();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long23 = month22.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar27 = null;
        fixedMillisecond26.peg(calendar27);
        long long29 = fixedMillisecond26.getFirstMillisecond();
        long long30 = fixedMillisecond26.getMiddleMillisecond();
        java.lang.String str31 = fixedMillisecond26.toString();
        boolean boolean32 = month18.equals((java.lang.Object) fixedMillisecond26);
        java.util.Calendar calendar33 = null;
        fixedMillisecond26.peg(calendar33);
        int int35 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond26);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.0d + "'", number6.equals(7.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-58982659200001L) + "'", long23 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str31.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        java.lang.Object obj19 = timeSeries16.clone();
        java.lang.Class class20 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class20);
        int int26 = timeSeries25.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 9223372036854775807L);
        int int6 = month2.getMonth();
        long long7 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58983955200001L) + "'", long7 == (-58983955200001L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int15 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int28 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate20.getNearestDayOfWeek(1);
        java.lang.String str31 = spreadsheetDate20.toString();
        boolean boolean32 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries37.setDomainDescription("");
        java.lang.Object obj40 = timeSeries37.clone();
        java.lang.Class class41 = timeSeries37.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean53 = spreadsheetDate50.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean58 = spreadsheetDate55.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean59 = spreadsheetDate52.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean60 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.util.Date date61 = spreadsheetDate52.toDate();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date61, timeZone62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date61);
        serialDate64.setDescription("");
        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate4.getEndOfCurrentMonth(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "20-February-1900" + "'", str31.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate67);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        boolean boolean12 = timeSeries1.isEmpty();
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year23.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date28 = spreadsheetDate19.toDate();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date28, timeZone29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date49 = spreadsheetDate40.toDate();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries54.setDomainDescription("");
        java.lang.Object obj57 = timeSeries54.clone();
        java.lang.Class class58 = timeSeries54.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class58);
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date49, timeZone61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone61);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int67 = timeSeries66.getMaximumItemCount();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long71 = month70.getLastMillisecond();
        boolean boolean73 = month70.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries66.getDataItem((org.jfree.data.time.RegularTimePeriod) month70);
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries81.setDomainDescription("");
        java.lang.Object obj84 = timeSeries81.clone();
        java.lang.Class class85 = timeSeries81.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class85);
        java.util.Date date87 = null;
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date87, timeZone88);
        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month70, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class85);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate92 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate92);
        int int94 = day93.getDayOfMonth();
        long long95 = day93.getSerialIndex();
        java.util.Date date96 = day93.getEnd();
        java.util.TimeZone timeZone97 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date96, timeZone97);
        org.jfree.data.time.Day day99 = new org.jfree.data.time.Day(date28, timeZone97);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2147483647 + "'", int67 == 2147483647);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-58982659200001L) + "'", long71 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 20 + "'", int94 == 20);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 52L + "'", long95 == 52L);
        org.junit.Assert.assertNotNull(date96);
        org.junit.Assert.assertNotNull(timeZone97);
        org.junit.Assert.assertNotNull(regularTimePeriod98);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries5.setDomainDescription("");
        java.lang.Object obj8 = timeSeries5.clone();
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date29 = spreadsheetDate20.toDate();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date29, timeZone30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date50 = spreadsheetDate41.toDate();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries55.setDomainDescription("");
        java.lang.Object obj58 = timeSeries55.clone();
        java.lang.Class class59 = timeSeries55.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class59);
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date50, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date29, timeZone62);
        int int66 = year65.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year65.previous();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(11, year65);
        long long69 = month68.getLastMillisecond();
        int int70 = month68.getYearValue();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1900 + "'", int66 == 1900);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-2180102400001L) + "'", long69 == (-2180102400001L));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1900 + "'", int70 == 1900);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.util.Date date19 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean25 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long30 = month29.getLastMillisecond();
        boolean boolean32 = month29.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month29, (double) 3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean45 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean50 = spreadsheetDate47.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean52 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean58 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean59 = timeSeriesDataItem34.equals((java.lang.Object) spreadsheetDate44);
        boolean boolean60 = spreadsheetDate22.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        try {
            org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-457), (org.jfree.data.time.SerialDate) spreadsheetDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-58982659200001L) + "'", long30 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries18.setDomainDescription("");
        java.lang.Object obj21 = timeSeries18.clone();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener22);
        timeSeries18.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = day29.getDayOfMonth();
        long long31 = day29.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar36 = null;
        fixedMillisecond35.peg(calendar36);
        long long38 = fixedMillisecond35.getFirstMillisecond();
        long long39 = fixedMillisecond35.getFirstMillisecond();
        long long40 = fixedMillisecond35.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond35.getLastMillisecond(calendar42);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries10.setDomainDescription("");
        timeSeries10.setMaximumItemAge(0L);
        timeSeries10.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        int int20 = timeSeries10.getIndex(regularTimePeriod19);
        boolean boolean21 = timeSeries10.isEmpty();
        java.lang.Class class22 = timeSeries10.getTimePeriodClass();
        java.lang.String str23 = timeSeries10.getDomainDescription();
        boolean boolean24 = year8.equals((java.lang.Object) timeSeries10);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean44 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean45 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean46 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date47 = spreadsheetDate38.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean53 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean54 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean55 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int56 = spreadsheetDate26.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int18 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date23 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean30 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int31 = spreadsheetDate14.getYYYY();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean7 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.String str9 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int17 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean19 = spreadsheetDate1.isOn(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20-February-1900" + "'", str9.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        boolean boolean6 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int9 = timeSeries8.getMaximumItemCount();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long13 = month12.getLastMillisecond();
        boolean boolean15 = month12.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.setDomainDescription("");
        java.lang.Object obj26 = timeSeries23.clone();
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class27);
        int int33 = month12.getMonth();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries35.setDomainDescription("");
        java.lang.Object obj38 = timeSeries35.clone();
        long long39 = timeSeries35.getMaximumItemAge();
        timeSeries35.clear();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int44 = month43.getYearValue();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long48 = month47.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries51.setDomainDescription("");
        timeSeries51.setMaximumItemAge(0L);
        timeSeries51.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean59 = timeSeries51.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries49.addAndOrUpdate(timeSeries51);
        boolean boolean61 = month12.equals((java.lang.Object) timeSeries60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(0L);
        long long64 = fixedMillisecond63.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond63.previous();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar70 = null;
        fixedMillisecond69.peg(calendar70);
        long long72 = fixedMillisecond69.getFirstMillisecond();
        long long73 = fixedMillisecond69.getMiddleMillisecond();
        java.lang.String str74 = fixedMillisecond69.toString();
        java.util.Date date75 = fixedMillisecond69.getTime();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75, timeZone76);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries82.setDomainDescription("");
        java.lang.Object obj85 = timeSeries82.clone();
        java.lang.Class class86 = timeSeries82.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries87 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class86);
        java.util.Date date88 = null;
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date75, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = year91.previous();
        try {
            timeSeries1.update(regularTimePeriod92, (java.lang.Number) 1560192824376L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58982659200001L) + "'", long13 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-58982659200001L) + "'", long48 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str74.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(obj85);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(8);
        int int26 = year23.compareTo((java.lang.Object) spreadsheetDate25);
        int int27 = spreadsheetDate25.toSerial();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate2.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: ERROR : Relative To String" + "'", str2.equals("org.jfree.data.general.SeriesException: ERROR : Relative To String"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        int int9 = timeSeriesDataItem5.compareTo((java.lang.Object) seriesException8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.0d + "'", number6.equals(7.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean16 = timeSeries15.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries15.getTimePeriods();
        timeSeries15.removeAgedItems((long) 2147483647, false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        long long8 = day7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2204640000000L) + "'", long8 == (-2204640000000L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date23 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean30 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean53 = spreadsheetDate40.isBefore(serialDate52);
        boolean boolean54 = spreadsheetDate2.isBefore(serialDate52);
        java.lang.String str55 = serialDate52.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str55);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.Calendar calendar7 = null;
        try {
            month6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean13 = spreadsheetDate3.isBefore(serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date32 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean40 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate3.getNearestDayOfWeek(3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(serialDate42);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getMiddleMillisecond(calendar14);
//        long long16 = fixedMillisecond9.getLastMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192853470L + "'", long15 == 1560192853470L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192853470L + "'", long16 == 1560192853470L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 8);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 106L + "'", long3 == 106L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries10.setDomainDescription("");
//        java.lang.Object obj13 = timeSeries10.clone();
//        java.lang.Class class14 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "hi!", "1900", class14);
//        java.util.Date date17 = regularTimePeriod3.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond21.peg(calendar22);
//        long long24 = fixedMillisecond21.getFirstMillisecond();
//        long long25 = fixedMillisecond21.getMiddleMillisecond();
//        java.lang.String str26 = fixedMillisecond21.toString();
//        java.util.Date date27 = fixedMillisecond21.getTime();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries34.setDomainDescription("");
//        java.lang.Object obj37 = timeSeries34.clone();
//        java.lang.Class class38 = timeSeries34.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class38);
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date40, timeZone41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date27, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date17, timeZone41);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str26.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        long long12 = day10.getSerialIndex();
//        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
//        java.lang.String str15 = day10.toString();
//        java.lang.String str16 = day10.toString();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries18.setDomainDescription("");
//        java.lang.Object obj21 = timeSeries18.clone();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries18.removePropertyChangeListener(propertyChangeListener22);
//        timeSeries18.removeAgedItems((long) (byte) -1, true);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int30 = day29.getDayOfMonth();
//        long long31 = day29.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day29.previous();
//        int int34 = day29.getDayOfMonth();
//        int int35 = day10.compareTo((java.lang.Object) day29);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 43574 + "'", int35 == 43574);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        java.lang.Object obj19 = timeSeries16.clone();
        java.lang.Class class20 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        java.util.Date date31 = day28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date31, timeZone32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int12 = spreadsheetDate4.getDayOfWeek();
        spreadsheetDate4.setDescription("September");
        try {
            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries5.setDomainDescription("");
        java.lang.Object obj8 = timeSeries5.clone();
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date29 = spreadsheetDate20.toDate();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date29, timeZone30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date50 = spreadsheetDate41.toDate();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries55.setDomainDescription("");
        java.lang.Object obj58 = timeSeries55.clone();
        java.lang.Class class59 = timeSeries55.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class59);
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date50, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date29, timeZone62);
        int int66 = year65.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year65.previous();
        try {
            org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (byte) 0, year65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1900 + "'", int66 == 1900);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        timeSeries8.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries13.setDomainDescription("");
        java.lang.Object obj16 = timeSeries13.clone();
        long long17 = timeSeries13.getMaximumItemAge();
        timeSeries13.clear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int22 = month21.getYearValue();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long26 = month25.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month25);
        boolean boolean29 = month21.equals((java.lang.Object) 2147483647);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        java.util.Date date31 = month21.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month21.previous();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58982659200001L) + "'", long26 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date28 = spreadsheetDate19.toDate();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date28, timeZone29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date49 = spreadsheetDate40.toDate();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries54.setDomainDescription("");
        java.lang.Object obj57 = timeSeries54.clone();
        java.lang.Class class58 = timeSeries54.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class58);
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date49, timeZone61);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date28, timeZone61);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar69 = null;
        fixedMillisecond68.peg(calendar69);
        long long71 = fixedMillisecond68.getFirstMillisecond();
        long long72 = fixedMillisecond68.getMiddleMillisecond();
        java.lang.String str73 = fixedMillisecond68.toString();
        java.util.Date date74 = fixedMillisecond68.getTime();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date74, timeZone75);
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries81.setDomainDescription("");
        java.lang.Object obj84 = timeSeries81.clone();
        java.lang.Class class85 = timeSeries81.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class85);
        java.util.Date date87 = null;
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date87, timeZone88);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date74, timeZone88);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date28, timeZone88);
        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond(date28);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str73.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod89);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.addChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries8.getTimePeriod(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Overwritten values from: 0.0" + "'", comparable9.equals("Overwritten values from: 0.0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.setDomainDescription("");
        java.lang.Object obj26 = timeSeries23.clone();
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date18, timeZone30);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries1.addChangeListener(seriesChangeListener29);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        long long18 = timeSeries16.getMaximumItemAge();
        timeSeries16.setDomainDescription("Overwritten values from: 0.0");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.util.Date date27 = fixedMillisecond22.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        timeSeries16.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Preceding" + "'", str17.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        long long9 = month8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 23640L + "'", long9 == 23640L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getDayOfMonth();
        long long6 = day2.getMiddleMillisecond();
        int int7 = day2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 100L);
        java.lang.Object obj10 = timeSeriesDataItem9.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = timeSeriesDataItem9.compareTo((java.lang.Object) day16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2204596800001L) + "'", long6 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Thursday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month13.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries10.setDomainDescription("");
        java.lang.Object obj13 = timeSeries10.clone();
        java.lang.Class class14 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class14);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries21.setDomainDescription("");
        java.lang.Object obj24 = timeSeries21.clone();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener25);
        timeSeries21.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = day32.getDayOfMonth();
        long long34 = day32.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries38.setDomainDescription("");
        java.lang.Object obj41 = timeSeries38.clone();
        long long42 = timeSeries38.getMaximumItemAge();
        timeSeries38.clear();
        java.util.List list44 = timeSeries38.getItems();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean49 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean55 = spreadsheetDate52.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean60 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean61 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean62 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.util.Date date63 = spreadsheetDate54.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries19.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries1.addAndOrUpdate(timeSeries67);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 20 + "'", int33 == 20);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertNotNull(timeSeries68);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str18 = spreadsheetDate9.toString();
        int int19 = spreadsheetDate9.toSerial();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20-February-1900" + "'", str18.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(30);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        long long7 = timeSeries1.getMaximumItemAge();
        boolean boolean8 = timeSeries1.getNotify();
        long long9 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "March" + "'", str1.equals("March"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Year year9 = month8.getYear();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1800);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1800) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        long long18 = timeSeries16.getMaximumItemAge();
        timeSeries16.setDomainDescription("Overwritten values from: 0.0");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.util.Date date27 = fixedMillisecond22.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.lang.Object obj29 = timeSeries16.clone();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Preceding" + "'", str17.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month5.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        int int2 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass4 = day3.getClass();
//        long long5 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries1.addChangeListener(seriesChangeListener9);
//        try {
//            timeSeries1.delete(7, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        long long9 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        int int15 = day12.getDayOfMonth();
        long long16 = day12.getMiddleMillisecond();
        int int17 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 100L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        long long23 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond22.previous();
        boolean boolean25 = timeSeriesDataItem19.equals((java.lang.Object) regularTimePeriod24);
        timeSeries1.add(timeSeriesDataItem19);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2204596800001L) + "'", long16 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int13 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate5.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) 'a');
        int int20 = spreadsheetDate17.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        java.util.List list7 = timeSeries1.getItems();
        timeSeries1.clear();
        timeSeries1.fireSeriesChanged();
        boolean boolean10 = timeSeries1.isEmpty();
        java.lang.String str11 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        long long18 = timeSeries16.getMaximumItemAge();
        timeSeries16.setMaximumItemCount(30);
        timeSeries16.setNotify(false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Preceding" + "'", str17.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries18.setDomainDescription("");
        java.lang.Object obj21 = timeSeries18.clone();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener22);
        timeSeries18.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = day29.getDayOfMonth();
        long long31 = day29.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar36 = null;
        fixedMillisecond35.peg(calendar36);
        long long38 = fixedMillisecond35.getFirstMillisecond();
        long long39 = fixedMillisecond35.getFirstMillisecond();
        long long40 = fixedMillisecond35.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.lang.String str42 = fixedMillisecond35.toString();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str42.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        int int27 = month15.getMonth();
//        long long28 = month15.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1211L + "'", long28 == 1211L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        long long8 = fixedMillisecond5.getFirstMillisecond();
        long long9 = fixedMillisecond5.getFirstMillisecond();
        java.util.Date date10 = fixedMillisecond5.getTime();
        boolean boolean11 = day2.equals((java.lang.Object) date10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 11);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        long long14 = fixedMillisecond8.getLastMillisecond();
        long long15 = fixedMillisecond8.getSerialIndex();
        long long16 = fixedMillisecond8.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date28 = spreadsheetDate19.toDate();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date28, timeZone29);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(class31);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int13 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate5.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) 'a');
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        long long12 = day10.getSerialIndex();
//        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries15.setDomainDescription("");
//        java.lang.Object obj18 = timeSeries15.clone();
//        java.lang.Class class19 = timeSeries15.getTimePeriodClass();
//        java.lang.String str20 = timeSeries15.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        int int24 = day23.getDayOfMonth();
//        long long25 = day23.getSerialIndex();
//        int int26 = day23.getDayOfMonth();
//        long long27 = day23.getMiddleMillisecond();
//        java.lang.Number number28 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 5, true);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries33.setDomainDescription("");
//        java.lang.Object obj36 = timeSeries33.clone();
//        long long37 = timeSeries33.getMaximumItemAge();
//        timeSeries33.clear();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int42 = month41.getYearValue();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long46 = month45.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month41, (org.jfree.data.time.RegularTimePeriod) month45);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries49.setDomainDescription("");
//        timeSeries49.setMaximumItemAge(0L);
//        timeSeries49.setKey((java.lang.Comparable) 9223372036854775807L);
//        boolean boolean57 = timeSeries49.equals((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries47.addAndOrUpdate(timeSeries49);
//        boolean boolean59 = day23.equals((java.lang.Object) timeSeries49);
//        try {
//            java.lang.Number number61 = timeSeries49.getValue((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2204596800001L) + "'", long27 == (-2204596800001L));
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-58982659200001L) + "'", long46 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate3.getDayOfWeek();
        int int12 = spreadsheetDate3.toSerial();
        java.util.Date date13 = spreadsheetDate3.toDate();
        int int14 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate24.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.util.Date date33 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long44 = month43.getLastMillisecond();
        boolean boolean46 = month43.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (double) 3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean53 = spreadsheetDate50.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean59 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean64 = spreadsheetDate61.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean65 = spreadsheetDate58.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean66 = spreadsheetDate52.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean72 = spreadsheetDate58.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean73 = timeSeriesDataItem48.equals((java.lang.Object) spreadsheetDate58);
        boolean boolean74 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int75 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-58982659200001L) + "'", long44 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate11 = null;
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth(serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries8.setDomainDescription("");
//        java.lang.Object obj11 = timeSeries8.clone();
//        java.lang.Class class12 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, class12);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries16.setDomainDescription("");
//        java.lang.Object obj19 = timeSeries16.clone();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener20);
//        timeSeries16.removeAgedItems((long) (byte) -1, true);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        int int28 = day27.getDayOfMonth();
//        long long29 = day27.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.previous();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 20);
//        java.util.Calendar calendar34 = null;
//        try {
//            long long35 = day27.getLastMillisecond(calendar34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        boolean boolean6 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int9 = timeSeries8.getMaximumItemCount();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long13 = month12.getLastMillisecond();
        boolean boolean15 = month12.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.setDomainDescription("");
        java.lang.Object obj26 = timeSeries23.clone();
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class27);
        int int33 = month12.getMonth();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries35.setDomainDescription("");
        java.lang.Object obj38 = timeSeries35.clone();
        long long39 = timeSeries35.getMaximumItemAge();
        timeSeries35.clear();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int44 = month43.getYearValue();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long48 = month47.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries51.setDomainDescription("");
        timeSeries51.setMaximumItemAge(0L);
        timeSeries51.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean59 = timeSeries51.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries49.addAndOrUpdate(timeSeries51);
        boolean boolean61 = month12.equals((java.lang.Object) timeSeries60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(0L);
        long long64 = fixedMillisecond63.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond63.previous();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries67.addOrUpdate(regularTimePeriod68, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58982659200001L) + "'", long13 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-58982659200001L) + "'", long48 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(timeSeries67);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = month13.getMiddleMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month13.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58983955200001L) + "'", long16 == (-58983955200001L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries15.removeChangeListener(seriesChangeListener17);
        timeSeries15.setDescription("1969");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
//        long long12 = fixedMillisecond9.getLastMillisecond();
//        long long13 = fixedMillisecond9.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560192858359L + "'", long12 == 1560192858359L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192858359L + "'", long13 == 1560192858359L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", obj2.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", obj4.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", obj5.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", obj6.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries17.setDomainDescription("");
        timeSeries17.setMaximumItemAge(0L);
        timeSeries17.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean25 = timeSeries17.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries17);
        try {
            timeSeries26.delete((-460), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        timeSeries26.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(43574);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 43574");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(43574);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.setDomainDescription("");
        java.lang.Object obj26 = timeSeries23.clone();
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date18, timeZone30);
        java.lang.String str33 = year32.toString();
        java.util.Date date34 = year32.getEnd();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        int int49 = spreadsheetDate41.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate41.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean55 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate53, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean60 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean66 = spreadsheetDate63.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean71 = spreadsheetDate68.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
        boolean boolean72 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
        boolean boolean73 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate65);
        java.util.Date date74 = spreadsheetDate65.toDate();
        boolean boolean75 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int83 = year32.compareTo((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 3 + "'", int49 == 3);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond12.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond12.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries1.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getDayOfMonth();
        long long6 = day2.getMiddleMillisecond();
        int int7 = day2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 100L);
        long long10 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2204596800001L) + "'", long6 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2204553600001L) + "'", long10 == (-2204553600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate21.getPreviousDayOfWeek(7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long11 = month10.getLastMillisecond();
        boolean boolean13 = month10.equals((java.lang.Object) 9223372036854775807L);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = day17.getDayOfMonth();
        long long19 = day17.getSerialIndex();
        long long20 = day17.getFirstMillisecond();
        java.lang.Number number21 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, number21);
        timeSeries1.setMaximumItemAge((long) 'a');
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58982659200001L) + "'", long11 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2204640000000L) + "'", long20 == (-2204640000000L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = day27.getDayOfMonth();
        long long29 = day27.getSerialIndex();
        java.util.Date date30 = day27.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date30, timeZone32);
        int int34 = year23.compareTo((java.lang.Object) date30);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        java.lang.Object obj19 = timeSeries16.clone();
        java.lang.Class class20 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class20);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries25.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        boolean boolean12 = timeSeries1.isEmpty();
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        timeSeries16.setMaximumItemAge(0L);
        timeSeries16.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        int int26 = timeSeries16.getIndex(regularTimePeriod25);
        boolean boolean27 = timeSeries16.isEmpty();
        java.lang.Class class28 = timeSeries16.getTimePeriodClass();
        java.lang.String str29 = timeSeries16.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries16);
        timeSeries30.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560192789625L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.Comparable comparable10 = timeSeries8.getKey();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Overwritten values from: 0.0" + "'", comparable9.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Overwritten values from: 0.0" + "'", comparable10.equals("Overwritten values from: 0.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries1.add(regularTimePeriod12, (java.lang.Number) 1560192789625L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date24 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean31 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean50 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.util.Date date51 = spreadsheetDate42.toDate();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean63 = spreadsheetDate60.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean68 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean69 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean70 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        java.util.Date date71 = spreadsheetDate62.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean77 = spreadsheetDate62.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        int int78 = spreadsheetDate62.getMonth();
        boolean boolean79 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(serialDate80);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int15 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int28 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate20.getNearestDayOfWeek(1);
        java.lang.String str31 = spreadsheetDate20.toString();
        boolean boolean32 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate20.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "20-February-1900" + "'", str31.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries24.setDomainDescription("");
        java.lang.Object obj27 = timeSeries24.clone();
        java.lang.Class class28 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class28);
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class28);
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        java.util.Collection collection37 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = null;
        try {
            java.lang.Number number39 = timeSeries33.getValue(regularTimePeriod38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.util.List list9 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date24 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean31 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate41.isBefore(serialDate53);
        boolean boolean55 = spreadsheetDate3.isBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate3.setDescription("July");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        boolean boolean5 = month2.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean23 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean25 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean32 = timeSeriesDataItem7.equals((java.lang.Object) spreadsheetDate17);
        java.lang.Object obj33 = timeSeriesDataItem7.clone();
        java.lang.Object obj34 = timeSeriesDataItem7.clone();
        java.lang.Number number35 = timeSeriesDataItem7.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 3.0d + "'", number35.equals(3.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Object obj25 = null;
        boolean boolean26 = year23.equals(obj25);
        java.util.Calendar calendar27 = null;
        try {
            year23.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Overwritten values from: 0.0");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean44 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean45 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean46 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date47 = spreadsheetDate38.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean53 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean54 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean55 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int56 = spreadsheetDate26.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean61 = spreadsheetDate58.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean69 = spreadsheetDate66.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean74 = spreadsheetDate71.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate68.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        int int76 = spreadsheetDate68.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate78 = spreadsheetDate68.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean82 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate68, (org.jfree.data.time.SerialDate) spreadsheetDate80, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate85);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate85);
        int int88 = spreadsheetDate68.compare(serialDate87);
        boolean boolean89 = spreadsheetDate60.isOnOrAfter(serialDate87);
        int int90 = spreadsheetDate26.compare(serialDate87);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2 + "'", int56 == 2);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2 + "'", int88 == 2);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2 + "'", int90 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        timeSeries5.setRangeDescription("July");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond9.peg(calendar10);
        long long12 = fixedMillisecond9.getFirstMillisecond();
        long long13 = fixedMillisecond9.getMiddleMillisecond();
        java.lang.String str14 = fixedMillisecond9.toString();
        java.util.Date date15 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year18.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getDayOfMonth();
        long long6 = day2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.previous();
        java.lang.String str9 = regularTimePeriod8.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2204596800001L) + "'", long6 == (-2204596800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19-February-1900" + "'", str9.equals("19-February-1900"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getDayOfMonth();
        long long6 = day2.getMiddleMillisecond();
        int int7 = day2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 100L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeriesDataItem9.equals(obj11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2204596800001L) + "'", long6 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Date date5 = day0.getStart();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.util.Date date44 = spreadsheetDate35.toDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean46 = spreadsheetDate21.isAfter(serialDate45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from: 0.0");
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str51 = seriesException50.toString();
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) seriesException50);
        java.lang.Throwable[] throwableArray53 = timePeriodFormatException48.getSuppressed();
        boolean boolean54 = spreadsheetDate21.equals((java.lang.Object) throwableArray53);
        int int55 = spreadsheetDate21.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", str51.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        java.lang.String str8 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries17.setDomainDescription("");
        timeSeries17.setMaximumItemAge(0L);
        timeSeries17.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean25 = timeSeries17.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries17);
        java.lang.Class class27 = timeSeries17.getTimePeriodClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        java.lang.Class<?> wildcardClass6 = timeSeries1.getClass();
        boolean boolean7 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries9.setDomainDescription("");
        java.lang.Object obj12 = timeSeries9.clone();
        long long13 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.addAndOrUpdate(timeSeries15);
        java.util.List list17 = timeSeries9.getItems();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries18.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries18.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        try {
            timeSeries1.update(5, (java.lang.Number) 1560192795562L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = day5.getDayOfMonth();
        long long7 = day5.getSerialIndex();
        java.util.Date date8 = day5.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        boolean boolean6 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries8.setDomainDescription("");
        java.lang.Object obj11 = timeSeries8.clone();
        long long12 = timeSeries8.getMaximumItemAge();
        timeSeries8.clear();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int17 = month16.getYearValue();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long21 = month20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month20);
        boolean boolean24 = month16.equals((java.lang.Object) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month16.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        java.util.Date date31 = day28.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31);
        boolean boolean34 = month16.equals((java.lang.Object) day33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, 0.0d);
        timeSeries1.add(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58982659200001L) + "'", long21 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        boolean boolean6 = timeSeries1.isEmpty();
        java.util.List list7 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries15.removeAgedItems(false);
        timeSeries15.clear();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(43574);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.util.Date date19 = spreadsheetDate10.toDate();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries24.setDomainDescription("");
//        java.lang.Object obj27 = timeSeries24.clone();
//        java.lang.Class class28 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class28);
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date19, timeZone31);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries35.setDomainDescription("");
//        java.lang.Object obj38 = timeSeries35.clone();
//        java.lang.Class class39 = timeSeries35.getTimePeriodClass();
//        java.util.Collection collection40 = timeSeries35.getTimePeriods();
//        int int41 = year33.compareTo((java.lang.Object) collection40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        java.lang.String str44 = serialDate43.toString();
//        int int45 = year33.compareTo((java.lang.Object) str44);
//        long long46 = year33.getFirstMillisecond();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(5, year33);
//        long long48 = month47.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208960000000L) + "'", long46 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2195913600001L) + "'", long48 == (-2195913600001L));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.Comparable comparable10 = timeSeries8.getKey();
        timeSeries8.removeAgedItems(false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Overwritten values from: 0.0" + "'", comparable9.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Overwritten values from: 0.0" + "'", comparable10.equals("Overwritten values from: 0.0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, (-460), 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries18.setDomainDescription("");
        java.lang.Object obj21 = timeSeries18.clone();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener22);
        timeSeries18.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = day29.getDayOfMonth();
        long long31 = day29.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries35.setDomainDescription("");
        java.lang.Object obj38 = timeSeries35.clone();
        long long39 = timeSeries35.getMaximumItemAge();
        timeSeries35.clear();
        java.util.List list41 = timeSeries35.getItems();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean52 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean58 = spreadsheetDate51.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.util.Date date60 = spreadsheetDate51.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries16.addAndOrUpdate(timeSeries35);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries64.addChangeListener(seriesChangeListener65);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(timeSeries64);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.util.Date date19 = spreadsheetDate10.toDate();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries24.setDomainDescription("");
        java.lang.Object obj27 = timeSeries24.clone();
        java.lang.Class class28 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class28);
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date19, timeZone31);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(2, year33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long29 = month28.getLastMillisecond();
        boolean boolean31 = month28.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean44 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean49 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean57 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean58 = timeSeriesDataItem33.equals((java.lang.Object) spreadsheetDate43);
        boolean boolean59 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.String str60 = spreadsheetDate21.getDescription();
        java.lang.Object obj61 = null;
        boolean boolean62 = spreadsheetDate21.equals(obj61);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58982659200001L) + "'", long29 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries13.setDomainDescription("");
        java.lang.Object obj16 = timeSeries13.clone();
        long long17 = timeSeries13.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries20.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        int int31 = day28.getDayOfMonth();
        long long32 = day28.getMiddleMillisecond();
        int int33 = day28.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100L);
        java.lang.Object obj36 = timeSeriesDataItem35.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        long long39 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
        boolean boolean41 = timeSeriesDataItem35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = timeSeriesDataItem35.compareTo((java.lang.Object) day42);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day42, (double) (-58985251200000L), true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries50.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries50.removePropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int58 = day57.getDayOfMonth();
        long long59 = day57.getSerialIndex();
        long long60 = day57.getFirstMillisecond();
        long long61 = day57.getSerialIndex();
        int int62 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) day57);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "Overwritten values from: 0.0" + "'", comparable21.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2204596800001L) + "'", long32 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 20 + "'", int58 == 20);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 52L + "'", long59 == 52L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-2204640000000L) + "'", long60 == (-2204640000000L));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 52L + "'", long61 == 52L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.lang.String str2 = fixedMillisecond1.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean23 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean28 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.util.Date date31 = spreadsheetDate22.toDate();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date31, timeZone32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean44 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean49 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.util.Date date52 = spreadsheetDate43.toDate();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries57.setDomainDescription("");
        java.lang.Object obj60 = timeSeries57.clone();
        java.lang.Class class61 = timeSeries57.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class61);
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date63, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date52, timeZone64);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date31, timeZone64);
        int int68 = year67.getYear();
        boolean boolean69 = fixedMillisecond1.equals((java.lang.Object) year67);
        java.util.Calendar calendar70 = null;
        try {
            long long71 = year67.getFirstMillisecond(calendar70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(class61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1900 + "'", int68 == 1900);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        java.lang.Object obj8 = timeSeriesDataItem5.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries11.setDomainDescription("");
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        int int15 = timeSeriesDataItem5.compareTo((java.lang.Object) collection14);
        java.lang.Number number16 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.0d + "'", number6.equals(7.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 7.0d + "'", number7.equals(7.0d));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 7.0d + "'", number16.equals(7.0d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2177424000001L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 6);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date28 = spreadsheetDate19.toDate();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date28, timeZone29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date49 = spreadsheetDate40.toDate();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries54.setDomainDescription("");
        java.lang.Object obj57 = timeSeries54.clone();
        java.lang.Class class58 = timeSeries54.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class58);
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date49, timeZone61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone61);
        int int65 = year64.getYear();
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries67.setDomainDescription("");
        java.lang.Object obj70 = timeSeries67.clone();
        long long71 = timeSeries67.getMaximumItemAge();
        java.lang.Comparable comparable72 = timeSeries67.getKey();
        java.lang.Class<?> wildcardClass73 = timeSeries67.getClass();
        timeSeries67.setMaximumItemCount(0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = day78.getDayOfMonth();
        long long80 = day78.getSerialIndex();
        long long81 = day78.getFirstMillisecond();
        long long82 = day78.getSerialIndex();
        int int83 = day78.getDayOfMonth();
        java.lang.Number number84 = null;
        timeSeries67.add((org.jfree.data.time.RegularTimePeriod) day78, number84, true);
        boolean boolean87 = year64.equals((java.lang.Object) day78);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1900 + "'", int65 == 1900);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 9223372036854775807L + "'", long71 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable72 + "' != '" + 0.0d + "'", comparable72.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 20 + "'", int79 == 20);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 52L + "'", long80 == 52L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-2204640000000L) + "'", long81 == (-2204640000000L));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 52L + "'", long82 == 52L);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 20 + "'", int83 == 20);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener27);
//        long long29 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean40 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean45 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean46 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean47 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        java.util.Date date48 = spreadsheetDate39.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean54 = spreadsheetDate51.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean60 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean65 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean66 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean67 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        java.util.Date date68 = spreadsheetDate59.toDate();
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries73.setDomainDescription("");
//        java.lang.Object obj76 = timeSeries73.clone();
//        java.lang.Class class77 = timeSeries73.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class77);
//        java.util.Date date79 = null;
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date79, timeZone80);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date68, timeZone80);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date48, timeZone80);
//        timeSeries1.setKey((java.lang.Comparable) day83);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(obj76);
//        org.junit.Assert.assertNotNull(class77);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond28.peg(calendar29);
//        long long31 = fixedMillisecond28.getFirstMillisecond();
//        long long32 = fixedMillisecond28.getFirstMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getFirstMillisecond(calendar33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond28.getMiddleMillisecond(calendar35);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        boolean boolean5 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("July");
        java.lang.String str8 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "July" + "'", str8.equals("July"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("September");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from: 0.0");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        java.lang.String str9 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", str4.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        java.lang.Object obj19 = timeSeries16.clone();
        java.lang.Class class20 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        java.util.Date date31 = day28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date31, timeZone32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries36.setDomainDescription("");
        java.lang.Object obj39 = timeSeries36.clone();
        long long40 = timeSeries36.getMaximumItemAge();
        timeSeries36.clear();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int45 = month44.getYearValue();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long49 = month48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month44.next();
        int int52 = month34.compareTo((java.lang.Object) month44);
        long long53 = month34.getSerialIndex();
        java.util.Calendar calendar54 = null;
        try {
            long long55 = month34.getMiddleMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-58982659200001L) + "'", long49 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1800 + "'", int52 == 1800);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 22802L + "'", long53 == 22802L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        java.lang.Object obj8 = timeSeriesDataItem5.clone();
        java.lang.Number number9 = timeSeriesDataItem5.getValue();
        java.lang.Object obj10 = timeSeriesDataItem5.clone();
        timeSeriesDataItem5.setValue((java.lang.Number) 106L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.0d + "'", number6.equals(7.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 7.0d + "'", number7.equals(7.0d));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 7.0d + "'", number9.equals(7.0d));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries10.setDomainDescription("");
        timeSeries10.setMaximumItemAge(0L);
        timeSeries10.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        int int20 = timeSeries10.getIndex(regularTimePeriod19);
        boolean boolean21 = timeSeries10.isEmpty();
        java.lang.Class class22 = timeSeries10.getTimePeriodClass();
        java.lang.String str23 = timeSeries10.getDomainDescription();
        boolean boolean24 = year8.equals((java.lang.Object) timeSeries10);
        timeSeries10.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = day29.getDayOfMonth();
        long long31 = day29.getSerialIndex();
        int int32 = day29.getDayOfMonth();
        long long33 = day29.getMiddleMillisecond();
        int int34 = day29.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100L);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(0L);
        long long40 = fixedMillisecond39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond39.previous();
        boolean boolean42 = timeSeriesDataItem36.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        int int44 = timeSeriesDataItem36.compareTo((java.lang.Object) day43);
        timeSeries10.add(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2204596800001L) + "'", long33 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean16 = timeSeries15.isEmpty();
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((int) 'a', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = day2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        int int6 = day2.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2204553600001L) + "'", long3 == (-2204553600001L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int13 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate5.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) 'a');
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate5.getNearestDayOfWeek((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long12 = month11.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 7);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem14, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58982659200001L) + "'", long12 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 7.0d + "'", number15.equals(7.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean38 = spreadsheetDate28.isBefore(serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean49 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean54 = spreadsheetDate51.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean55 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        java.util.Date date57 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean63 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean65 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean66 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        java.lang.String str67 = spreadsheetDate22.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), (org.jfree.data.time.SerialDate) spreadsheetDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from: 0.0");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code." + "'", str4.equals("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Overwritten values from: 0.0"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int13 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate5.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date38 = spreadsheetDate29.toDate();
        boolean boolean39 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean50 = spreadsheetDate47.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean56 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean61 = spreadsheetDate58.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean62 = spreadsheetDate55.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean63 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean69 = spreadsheetDate55.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean70 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(30, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries11.setDomainDescription("");
        java.lang.Object obj14 = timeSeries11.clone();
        long long15 = timeSeries11.getMaximumItemAge();
        timeSeries11.clear();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int20 = month19.getYearValue();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long24 = month23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        fixedMillisecond27.peg(calendar28);
        long long30 = fixedMillisecond27.getFirstMillisecond();
        long long31 = fixedMillisecond27.getMiddleMillisecond();
        java.lang.String str32 = fixedMillisecond27.toString();
        boolean boolean33 = month19.equals((java.lang.Object) fixedMillisecond27);
        long long34 = month19.getSerialIndex();
        int int35 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-58982659200001L) + "'", long24 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str32.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1211L + "'", long34 == 1211L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date24 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean31 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean50 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.util.Date date51 = spreadsheetDate42.toDate();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean63 = spreadsheetDate60.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean68 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean69 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean70 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        java.util.Date date71 = spreadsheetDate62.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean77 = spreadsheetDate62.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        int int78 = spreadsheetDate62.getMonth();
        boolean boolean79 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate82 = spreadsheetDate62.getPreviousDayOfWeek(7);
        boolean boolean84 = spreadsheetDate62.equals((java.lang.Object) (-457));
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries20.setDomainDescription("");
        java.lang.Object obj23 = timeSeries20.clone();
        java.lang.Class class24 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class24);
        timeSeries25.setDescription("Preceding");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 1.0f);
        int int33 = month13.compareTo((java.lang.Object) timeSeries25);
        timeSeries25.clear();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        boolean boolean17 = timeSeries16.getNotify();
        java.lang.String str18 = timeSeries16.getDescription();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries17.setDomainDescription("");
        timeSeries17.setMaximumItemAge(0L);
        timeSeries17.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean25 = timeSeries17.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.addChangeListener(seriesChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        java.lang.String str6 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean26 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate3.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean39 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int40 = spreadsheetDate32.getDayOfWeek();
        int int41 = spreadsheetDate32.getMonth();
        boolean boolean42 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560192789625L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        long long9 = timeSeries1.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        timeSeries9.setDescription("Preceding");
        timeSeries9.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.util.Date date0 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries5.setDomainDescription("");
        java.lang.Object obj8 = timeSeries5.clone();
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date29 = spreadsheetDate20.toDate();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date29, timeZone30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date50 = spreadsheetDate41.toDate();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries55.setDomainDescription("");
        java.lang.Object obj58 = timeSeries55.clone();
        java.lang.Class class59 = timeSeries55.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class59);
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date50, timeZone62);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date29, timeZone62);
        try {
            org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date0, timeZone62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate5.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int13 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate5.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean19 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate17, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date38 = spreadsheetDate29.toDate();
        boolean boolean39 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int40 = spreadsheetDate29.toSerial();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 52 + "'", int40 == 52);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setMaximumItemCount((int) '4');
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        long long9 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        int int15 = day12.getDayOfMonth();
        long long16 = day12.getMiddleMillisecond();
        int int17 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 100L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        long long23 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond22.previous();
        boolean boolean25 = timeSeriesDataItem19.equals((java.lang.Object) regularTimePeriod24);
        timeSeries1.add(timeSeriesDataItem19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar29 = null;
        fixedMillisecond28.peg(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.previous();
        long long32 = fixedMillisecond28.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 6);
        long long35 = fixedMillisecond28.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2204596800001L) + "'", long16 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(8);
        int int26 = year23.compareTo((java.lang.Object) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate30);
        java.lang.String str33 = spreadsheetDate30.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean42 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries44.setDomainDescription("");
        java.lang.Object obj47 = timeSeries44.clone();
        long long48 = timeSeries44.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries44.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries56.setDomainDescription("");
        java.lang.Object obj59 = timeSeries56.clone();
        long long60 = timeSeries56.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries56.addAndOrUpdate(timeSeries62);
        java.lang.Comparable comparable64 = timeSeries63.getKey();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries66.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries63.addAndOrUpdate(timeSeries66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate70);
        int int72 = day71.getDayOfMonth();
        long long73 = day71.getSerialIndex();
        int int74 = day71.getDayOfMonth();
        long long75 = day71.getMiddleMillisecond();
        int int76 = day71.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day71, (java.lang.Number) 100L);
        java.lang.Object obj79 = timeSeriesDataItem78.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond(0L);
        long long82 = fixedMillisecond81.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = fixedMillisecond81.previous();
        boolean boolean84 = timeSeriesDataItem78.equals((java.lang.Object) regularTimePeriod83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
        int int86 = timeSeriesDataItem78.compareTo((java.lang.Object) day85);
        timeSeries63.add((org.jfree.data.time.RegularTimePeriod) day85, (double) (-58985251200000L), true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, (java.lang.Number) (byte) 100);
        boolean boolean92 = spreadsheetDate25.equals((java.lang.Object) timeSeries44);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20-February-1900" + "'", str33.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + "Overwritten values from: 0.0" + "'", comparable64.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 20 + "'", int72 == 20);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 52L + "'", long73 == 52L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 20 + "'", int74 == 20);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-2204596800001L) + "'", long75 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.util.Date date19 = spreadsheetDate10.toDate();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries24.setDomainDescription("");
//        java.lang.Object obj27 = timeSeries24.clone();
//        java.lang.Class class28 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class28);
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date19, timeZone31);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries35.setDomainDescription("");
//        java.lang.Object obj38 = timeSeries35.clone();
//        java.lang.Class class39 = timeSeries35.getTimePeriodClass();
//        java.util.Collection collection40 = timeSeries35.getTimePeriods();
//        int int41 = year33.compareTo((java.lang.Object) collection40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        java.lang.String str44 = serialDate43.toString();
//        int int45 = year33.compareTo((java.lang.Object) str44);
//        long long46 = year33.getFirstMillisecond();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(5, year33);
//        long long48 = year33.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208960000000L) + "'", long46 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2177424000001L) + "'", long48 == (-2177424000001L));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date7 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond9.peg(calendar10);
        long long12 = fixedMillisecond9.getFirstMillisecond();
        long long13 = fixedMillisecond9.getMiddleMillisecond();
        java.lang.String str14 = fixedMillisecond9.toString();
        java.util.Date date15 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int20 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long24 = month23.getLastMillisecond();
        boolean boolean26 = month23.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries34.setDomainDescription("");
        java.lang.Object obj37 = timeSeries34.clone();
        java.lang.Class class38 = timeSeries34.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class38);
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date40, timeZone41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int47 = day46.getDayOfMonth();
        long long48 = day46.getSerialIndex();
        java.util.Date date49 = day46.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date49, timeZone50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date15, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date7, timeZone50);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-58982659200001L) + "'", long24 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 20 + "'", int47 == 20);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 52L + "'", long48 == 52L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        long long7 = fixedMillisecond1.getSerialIndex();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = null;
        timeSeriesDataItem5.setValue(number7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10);
        int int12 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond10);
        long long13 = fixedMillisecond10.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 7.0d + "'", number6.equals(7.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day25.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        java.util.Date date18 = spreadsheetDate9.toDate();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries23.setDomainDescription("");
//        java.lang.Object obj26 = timeSeries23.clone();
//        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date18, timeZone30);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries34.setDomainDescription("");
//        java.lang.Object obj37 = timeSeries34.clone();
//        java.lang.Class class38 = timeSeries34.getTimePeriodClass();
//        java.util.Collection collection39 = timeSeries34.getTimePeriods();
//        int int40 = year32.compareTo((java.lang.Object) collection39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        java.lang.String str43 = serialDate42.toString();
//        int int44 = year32.compareTo((java.lang.Object) str43);
//        long long45 = year32.getLastMillisecond();
//        java.util.Calendar calendar46 = null;
//        try {
//            year32.peg(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-2177424000001L) + "'", long45 == (-2177424000001L));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries18.setDomainDescription("");
        java.lang.Object obj21 = timeSeries18.clone();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener22);
        timeSeries18.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = day29.getDayOfMonth();
        long long31 = day29.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries35.setDomainDescription("");
        java.lang.Object obj38 = timeSeries35.clone();
        long long39 = timeSeries35.getMaximumItemAge();
        timeSeries35.clear();
        java.util.List list41 = timeSeries35.getItems();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean52 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean58 = spreadsheetDate51.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.util.Date date60 = spreadsheetDate51.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries16.addAndOrUpdate(timeSeries35);
        timeSeries64.setNotify(false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(timeSeries64);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1969L + "'", long2 == 1969L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        timeSeries8.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries13.setDomainDescription("");
        java.lang.Object obj16 = timeSeries13.clone();
        long long17 = timeSeries13.getMaximumItemAge();
        timeSeries13.clear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int22 = month21.getYearValue();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long26 = month25.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month25);
        boolean boolean29 = month21.equals((java.lang.Object) 2147483647);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        java.util.Date date31 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries36.setDomainDescription("");
        java.lang.Object obj39 = timeSeries36.clone();
        java.lang.Class class40 = timeSeries36.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class40);
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
        try {
            org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date31, timeZone43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58982659200001L) + "'", long26 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        long long11 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = day18.getDayOfMonth();
        long long20 = day18.getSerialIndex();
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getMiddleMillisecond();
        int int23 = day18.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 100L);
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        long long29 = fixedMillisecond28.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        boolean boolean31 = timeSeriesDataItem25.equals((java.lang.Object) regularTimePeriod30);
        timeSeries7.add(timeSeriesDataItem25);
        timeSeries1.add(timeSeriesDataItem25);
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries1.createCopy((-460), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0d + "'", comparable12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2204596800001L) + "'", long22 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thursday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.util.Date date44 = spreadsheetDate35.toDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean46 = spreadsheetDate21.isAfter(serialDate45);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate45, "2019", "19-February-1900", class49);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate3.getDayOfWeek();
        int int12 = spreadsheetDate3.toSerial();
        java.lang.String str13 = spreadsheetDate3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries15.setDomainDescription("");
        java.lang.Object obj18 = timeSeries15.clone();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener19);
        timeSeries15.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = day26.getDayOfMonth();
        long long28 = day26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries38.setDomainDescription("");
        java.lang.Object obj41 = timeSeries38.clone();
        java.lang.Class class42 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class42);
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date44, timeZone45);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class42);
        boolean boolean48 = timeSeries47.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries47.removeChangeListener(seriesChangeListener49);
        java.util.Collection collection51 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries56.setDomainDescription("");
        java.lang.Object obj59 = timeSeries56.clone();
        java.lang.Class class60 = timeSeries56.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean66 = spreadsheetDate63.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean72 = spreadsheetDate69.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean77 = spreadsheetDate74.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean78 = spreadsheetDate71.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.util.Date date80 = spreadsheetDate71.toDate();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date80, timeZone81);
        java.util.Date date83 = regularTimePeriod82.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries47.addOrUpdate(regularTimePeriod82, (double) 23640L);
        boolean boolean86 = spreadsheetDate3.equals((java.lang.Object) regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 20 + "'", int27 == 20);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNull(timeSeriesDataItem85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = month9.equals((java.lang.Object) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = day21.getDayOfMonth();
        long long23 = day21.getSerialIndex();
        java.util.Date date24 = day21.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        boolean boolean27 = month9.equals((java.lang.Object) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (-31507200000L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries9.setDomainDescription("");
        java.lang.Object obj12 = timeSeries9.clone();
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = day18.getDayOfMonth();
        long long20 = day18.getSerialIndex();
        java.util.Date date21 = day18.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries26.setDomainDescription("");
        java.lang.Object obj29 = timeSeries26.clone();
        java.lang.Class class30 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date50 = spreadsheetDate41.toDate();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date50, timeZone51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean63 = spreadsheetDate60.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean68 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean69 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean70 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        java.util.Date date71 = spreadsheetDate62.toDate();
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries76.setDomainDescription("");
        java.lang.Object obj79 = timeSeries76.clone();
        java.lang.Class class80 = timeSeries76.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class80);
        java.util.Date date82 = null;
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date82, timeZone83);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date71, timeZone83);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date50, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone83);
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date6, timeZone83);
        long long89 = day88.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(class80);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-57600000L) + "'", long89 == (-57600000L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        boolean boolean3 = year0.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        java.lang.String str6 = spreadsheetDate3.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int14 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean26 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate3.getFollowingDayOfWeek(1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean44 = spreadsheetDate41.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        boolean boolean45 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        boolean boolean46 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean52 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries54.setDomainDescription("");
//        java.lang.Object obj57 = timeSeries54.clone();
//        long long58 = timeSeries54.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries54.addAndOrUpdate(timeSeries60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (byte) 100);
//        long long65 = fixedMillisecond62.getLastMillisecond();
//        boolean boolean66 = spreadsheetDate49.equals((java.lang.Object) long65);
//        java.lang.Class<?> wildcardClass67 = spreadsheetDate49.getClass();
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560192873561L + "'", long65 == 1560192873561L);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(serialDate68);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        fixedMillisecond2.peg(calendar3);
        long long5 = fixedMillisecond2.getFirstMillisecond();
        long long6 = fixedMillisecond2.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond2.toString();
        java.util.Date date8 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        boolean boolean6 = timeSeries1.isEmpty();
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = month9.getLastMillisecond();
        java.lang.String str17 = month9.toString();
        int int18 = month9.getYearValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58982659200001L) + "'", long16 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "November 100" + "'", str17.equals("November 100"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, (int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        boolean boolean12 = timeSeries1.isEmpty();
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        timeSeries16.setMaximumItemAge(0L);
        timeSeries16.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        int int26 = timeSeries16.getIndex(regularTimePeriod25);
        boolean boolean27 = timeSeries16.isEmpty();
        java.lang.Class class28 = timeSeries16.getTimePeriodClass();
        java.lang.String str29 = timeSeries16.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = day33.getDayOfMonth();
        long long35 = day33.getSerialIndex();
        int int36 = day33.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day33.next();
        timeSeries1.add(regularTimePeriod37, (java.lang.Number) 1560192801616L, false);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(20, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int20 = spreadsheetDate10.toSerial();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        timeSeries1.clear();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int10 = month9.getYearValue();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long14 = month13.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
//        boolean boolean16 = timeSeries15.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        int int22 = day21.getDayOfMonth();
//        long long23 = day21.getSerialIndex();
//        int int24 = day21.getDayOfMonth();
//        long long25 = day21.getMiddleMillisecond();
//        int int26 = day21.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeriesDataItem28.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean40 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean45 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean46 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean47 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate50);
//        boolean boolean53 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries55.setDomainDescription("");
//        java.lang.Object obj58 = timeSeries55.clone();
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries55.removePropertyChangeListener(propertyChangeListener59);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries55.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass65 = day64.getClass();
//        long long66 = day64.getSerialIndex();
//        java.lang.Number number67 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.SerialDate serialDate68 = day64.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(100);
//        boolean boolean71 = spreadsheetDate50.isInRange(serialDate68, serialDate70);
//        boolean boolean72 = timeSeriesDataItem28.equals((java.lang.Object) spreadsheetDate50);
//        timeSeries15.add(timeSeriesDataItem28, true);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2204596800001L) + "'", long25 == (-2204596800001L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 43626L + "'", long66 == 43626L);
//        org.junit.Assert.assertNull(number67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year23.getMiddleMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        timeSeries9.setDomainDescription("March");
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.removeAgedItems(false);
//        java.lang.Comparable comparable5 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        long long11 = timeSeries7.getMaximumItemAge();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long20 = month19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = month15.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58982659200001L) + "'", long20 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(timeSeries26);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Object obj9 = timeSeries1.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        int int15 = day12.getDayOfMonth();
        long long16 = day12.getMiddleMillisecond();
        int int17 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 100L);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        java.lang.Number number21 = timeSeriesDataItem19.getValue();
        timeSeries1.add(timeSeriesDataItem19);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(6, 9999);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 1560192816022L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2204596800001L) + "'", long16 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 100L + "'", number21.equals(100L));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        java.util.Date date18 = spreadsheetDate9.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        long long21 = fixedMillisecond19.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2204639999031L) + "'", long20 == (-2204639999031L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2204639999031L) + "'", long21 == (-2204639999031L));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int3 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int21 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate13.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean27 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean32 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.util.Date date46 = spreadsheetDate37.toDate();
        boolean boolean47 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean48 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        timeSeries1.fireSeriesChanged();
        java.lang.String str17 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long3 = month2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass17 = day16.getClass();
//        long long18 = day16.getSerialIndex();
//        java.lang.Number number19 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
//        int int21 = month2.compareTo((java.lang.Object) serialDate20);
//        java.util.Calendar calendar22 = null;
//        try {
//            month2.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) '#');
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        long long10 = month5.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month5.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58982659200001L) + "'", long10 == (-58982659200001L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        boolean boolean12 = timeSeries1.isEmpty();
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean39 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int40 = spreadsheetDate32.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate32.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean46 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate44, (int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean51 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean62 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean63 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean64 = spreadsheetDate50.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.util.Date date65 = spreadsheetDate56.toDate();
        boolean boolean66 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean74 = spreadsheetDate21.isOnOrBefore(serialDate73);
        org.jfree.data.time.SerialDate serialDate75 = null;
        try {
            boolean boolean76 = spreadsheetDate21.isOnOrAfter(serialDate75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        timeSeries7.setDomainDescription("");
        boolean boolean11 = timeSeries7.isEmpty();
        long long12 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = day19.getDayOfMonth();
        long long21 = day19.getSerialIndex();
        boolean boolean22 = timeSeries14.equals((java.lang.Object) day19);
        int int23 = day19.getMonth();
        long long24 = day19.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2204640000000L) + "'", long24 == (-2204640000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem(52);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        java.lang.String str6 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean26 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean32 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int52 = spreadsheetDate48.getDayOfMonth();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean18 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.util.Date date19 = spreadsheetDate10.toDate();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries24.setDomainDescription("");
//        java.lang.Object obj27 = timeSeries24.clone();
//        java.lang.Class class28 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class28);
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date19, timeZone31);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries35.setDomainDescription("");
//        java.lang.Object obj38 = timeSeries35.clone();
//        java.lang.Class class39 = timeSeries35.getTimePeriodClass();
//        java.util.Collection collection40 = timeSeries35.getTimePeriods();
//        int int41 = year33.compareTo((java.lang.Object) collection40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        java.lang.String str44 = serialDate43.toString();
//        int int45 = year33.compareTo((java.lang.Object) str44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year33.next();
//        java.util.Date date47 = regularTimePeriod46.getStart();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date47, timeZone50);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date28 = spreadsheetDate19.toDate();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date28, timeZone29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date49 = spreadsheetDate40.toDate();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries54.setDomainDescription("");
        java.lang.Object obj57 = timeSeries54.clone();
        java.lang.Class class58 = timeSeries54.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class58);
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date49, timeZone61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone61);
        java.lang.String str65 = year64.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar68 = null;
        fixedMillisecond67.peg(calendar68);
        long long70 = fixedMillisecond67.getFirstMillisecond();
        long long71 = fixedMillisecond67.getMiddleMillisecond();
        java.util.Date date72 = fixedMillisecond67.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond67.previous();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond67.getFirstMillisecond(calendar74);
        int int76 = year64.compareTo((java.lang.Object) calendar74);
        java.util.Calendar calendar77 = null;
        try {
            year64.peg(calendar77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1900" + "'", str65.equals("1900"));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(20, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long13 = month12.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (double) 7);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        java.lang.Object obj18 = timeSeriesDataItem15.clone();
        timeSeries1.setKey((java.lang.Comparable) timeSeriesDataItem15);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58982659200001L) + "'", long13 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 7.0d + "'", number16.equals(7.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 7.0d + "'", number17.equals(7.0d));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.previous();
        int int17 = day12.getDayOfMonth();
        java.util.Calendar calendar18 = null;
        try {
            day12.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries17.setDomainDescription("");
        timeSeries17.setMaximumItemAge(0L);
        timeSeries17.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean25 = timeSeries17.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean43 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.util.Date date45 = spreadsheetDate36.toDate();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries50.setDomainDescription("");
        java.lang.Object obj53 = timeSeries50.clone();
        java.lang.Class class54 = timeSeries50.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class54);
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date56, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date45, timeZone57);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries61.setDomainDescription("");
        java.lang.Object obj64 = timeSeries61.clone();
        java.lang.Class class65 = timeSeries61.getTimePeriodClass();
        java.util.Collection collection66 = timeSeries61.getTimePeriods();
        int int67 = year59.compareTo((java.lang.Object) collection66);
        long long68 = year59.getFirstMillisecond();
        int int69 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year59);
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener70);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2208960000000L) + "'", long68 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        long long11 = year10.getLastMillisecond();
        long long12 = year10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        timeSeries1.setMaximumItemAge(0L);
//        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
//        java.lang.Class<?> wildcardClass8 = timeSeries1.getClass();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        long long11 = day9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.next();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries19.setDomainDescription("");
//        java.lang.Object obj22 = timeSeries19.clone();
//        java.lang.Class class23 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class23);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, "hi!", "1900", class23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.addAndOrUpdate(timeSeries25);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(timeSeries26);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long3 = month2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 7);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries7.setDomainDescription("");
//        java.lang.Object obj10 = timeSeries7.clone();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass17 = day16.getClass();
//        long long18 = day16.getSerialIndex();
//        java.lang.Number number19 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
//        int int21 = month2.compareTo((java.lang.Object) serialDate20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month2.previous();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(8);
        int int26 = year23.compareTo((java.lang.Object) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate30);
        java.lang.String str33 = spreadsheetDate30.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean42 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.util.Date date43 = spreadsheetDate30.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20-February-1900" + "'", str33.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date18 = spreadsheetDate9.toDate();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.setDomainDescription("");
        java.lang.Object obj26 = timeSeries23.clone();
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date18, timeZone30);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = year32.getMiddleMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        java.util.List list7 = timeSeries1.getItems();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean23 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean25 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date26 = spreadsheetDate17.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries31.setDomainDescription("");
        java.lang.Object obj34 = timeSeries31.clone();
        long long35 = timeSeries31.getMaximumItemAge();
        timeSeries31.clear();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int40 = month39.getYearValue();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long44 = month43.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) month39, (org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar48 = null;
        fixedMillisecond47.peg(calendar48);
        long long50 = fixedMillisecond47.getFirstMillisecond();
        long long51 = fixedMillisecond47.getMiddleMillisecond();
        java.lang.String str52 = fixedMillisecond47.toString();
        boolean boolean53 = month39.equals((java.lang.Object) fixedMillisecond47);
        int int54 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month39);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-58982659200001L) + "'", long44 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str52.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean23 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        boolean boolean30 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries32.setDomainDescription("");
//        java.lang.Object obj35 = timeSeries32.clone();
//        long long36 = timeSeries32.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries32.addAndOrUpdate(timeSeries38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (byte) 100);
//        long long43 = fixedMillisecond40.getLastMillisecond();
//        boolean boolean44 = spreadsheetDate27.equals((java.lang.Object) long43);
//        boolean boolean45 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries47.setDomainDescription("");
//        java.lang.Object obj50 = timeSeries47.clone();
//        java.beans.PropertyChangeListener propertyChangeListener51 = null;
//        timeSeries47.removePropertyChangeListener(propertyChangeListener51);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries47.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass57 = day56.getClass();
//        long long58 = day56.getSerialIndex();
//        java.lang.Number number59 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        org.jfree.data.time.SerialDate serialDate60 = day56.getSerialDate();
//        boolean boolean61 = spreadsheetDate27.isOnOrAfter(serialDate60);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192877586L + "'", long43 == 1560192877586L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43626L + "'", long58 == 43626L);
//        org.junit.Assert.assertNull(number59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setKey((java.lang.Comparable) 9223372036854775807L);
        java.lang.Object obj8 = timeSeries1.clone();
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection11 = timeSeries1.getTimePeriods();
        timeSeries1.setDescription("");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = day12.getDayOfMonth();
        long long14 = day12.getSerialIndex();
        long long15 = day12.getFirstMillisecond();
        long long16 = day12.getSerialIndex();
        int int17 = day12.getDayOfMonth();
        java.lang.Number number18 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day12, number18, true);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day12.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2204640000000L) + "'", long15 == (-2204640000000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        spreadsheetDate1.setDescription("");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        int int7 = day6.getDayOfMonth();
//        long long8 = day6.getSerialIndex();
//        int int9 = day6.getDayOfMonth();
//        long long10 = day6.getMiddleMillisecond();
//        int int11 = day6.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        boolean boolean31 = spreadsheetDate24.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        boolean boolean32 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        boolean boolean38 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries40.setDomainDescription("");
//        java.lang.Object obj43 = timeSeries40.clone();
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries40.removePropertyChangeListener(propertyChangeListener44);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries40.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass50 = day49.getClass();
//        long long51 = day49.getSerialIndex();
//        java.lang.Number number52 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) day49);
//        org.jfree.data.time.SerialDate serialDate53 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(100);
//        boolean boolean56 = spreadsheetDate35.isInRange(serialDate53, serialDate55);
//        boolean boolean57 = timeSeriesDataItem13.equals((java.lang.Object) spreadsheetDate35);
//        int int58 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2204596800001L) + "'", long10 == (-2204596800001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43626L + "'", long51 == 43626L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-49) + "'", int58 == (-49));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        java.lang.String str6 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str15 = spreadsheetDate3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries14.setDomainDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(8);
        int int26 = year23.compareTo((java.lang.Object) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate30);
        java.lang.String str33 = spreadsheetDate30.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean42 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate47);
        java.lang.String str50 = spreadsheetDate47.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int58 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean64 = spreadsheetDate61.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean69 = spreadsheetDate66.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate68);
        boolean boolean70 = spreadsheetDate63.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate68);
        int int71 = spreadsheetDate63.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate63.getNearestDayOfWeek(1);
        java.lang.String str74 = spreadsheetDate63.toString();
        boolean boolean75 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean76 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int77 = spreadsheetDate30.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate80);
        int int83 = spreadsheetDate80.getMonth();
        int int84 = spreadsheetDate80.getMonth();
        boolean boolean85 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20-February-1900" + "'", str33.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "20-February-1900" + "'", str50.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 3 + "'", int71 == 3);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "20-February-1900" + "'", str74.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 20 + "'", int77 == 20);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2 + "'", int83 == 2);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2 + "'", int84 == 2);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int10 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long14 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries17.setDomainDescription("");
        timeSeries17.setMaximumItemAge(0L);
        timeSeries17.setKey((java.lang.Comparable) 9223372036854775807L);
        boolean boolean25 = timeSeries17.equals((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries17);
        timeSeries15.setNotify(true);
        java.util.Collection collection29 = timeSeries15.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        boolean boolean8 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries10.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = day17.getDayOfMonth();
        long long19 = day17.getSerialIndex();
        long long20 = day17.getFirstMillisecond();
        long long21 = day17.getSerialIndex();
        int int22 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day17);
        int int24 = day2.compareTo((java.lang.Object) timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2204640000000L) + "'", long20 == (-2204640000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries8.setDomainDescription("");
//        java.lang.Object obj11 = timeSeries8.clone();
//        java.lang.Class class12 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, class12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = day17.getDayOfMonth();
//        long long19 = day17.getSerialIndex();
//        java.util.Date date20 = day17.getEnd();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean32 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        boolean boolean38 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        boolean boolean39 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        java.util.Date date40 = spreadsheetDate31.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean52 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        boolean boolean58 = spreadsheetDate51.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        boolean boolean59 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        java.util.Date date60 = spreadsheetDate51.toDate();
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries65.setDomainDescription("");
//        java.lang.Object obj68 = timeSeries65.clone();
//        java.lang.Class class69 = timeSeries65.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class69);
//        java.util.Date date71 = null;
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date71, timeZone72);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date60, timeZone72);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date40, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone72);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertNotNull(class69);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries8.setDomainDescription("");
//        java.lang.Object obj11 = timeSeries8.clone();
//        java.lang.Class class12 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, class12);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class15);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = day2.getDayOfMonth();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getDayOfMonth();
        long long6 = day2.getMiddleMillisecond();
        int int7 = day2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 100L);
        java.lang.Object obj10 = timeSeriesDataItem9.clone();
        java.lang.Object obj11 = timeSeriesDataItem9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries13.setDomainDescription("");
        java.lang.Object obj16 = timeSeries13.clone();
        long long17 = timeSeries13.getMaximumItemAge();
        timeSeries13.clear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int22 = month21.getYearValue();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long26 = month25.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month25);
        long long28 = month25.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month25.next();
        boolean boolean30 = timeSeriesDataItem9.equals((java.lang.Object) month25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2204596800001L) + "'", long6 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58982659200001L) + "'", long26 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-58983955200001L) + "'", long28 == (-58983955200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long5 = month4.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries9.setDomainDescription("");
//        java.lang.Object obj12 = timeSeries9.clone();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass19 = day18.getClass();
//        long long20 = day18.getSerialIndex();
//        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.SerialDate serialDate22 = day18.getSerialDate();
//        int int23 = month4.compareTo((java.lang.Object) serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(9, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate22);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58982659200001L) + "'", long5 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long7 = month6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 7);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        java.lang.Number number11 = timeSeriesDataItem9.getValue();
        int int12 = month2.compareTo((java.lang.Object) timeSeriesDataItem9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58982659200001L) + "'", long3 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58982659200001L) + "'", long7 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 7.0d + "'", number10.equals(7.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7.0d + "'", number11.equals(7.0d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long6 = month5.getLastMillisecond();
        boolean boolean8 = month5.equals((java.lang.Object) 9223372036854775807L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries16.setDomainDescription("");
        java.lang.Object obj19 = timeSeries16.clone();
        java.lang.Class class20 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "SerialDate.weekInMonthToString(): invalid code.", "20-February-1900", class20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        java.util.Date date31 = day28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date31, timeZone32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries36.setDomainDescription("");
        java.lang.Object obj39 = timeSeries36.clone();
        long long40 = timeSeries36.getMaximumItemAge();
        timeSeries36.clear();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int45 = month44.getYearValue();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long49 = month48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month44.next();
        int int52 = month34.compareTo((java.lang.Object) month44);
        long long53 = month34.getSerialIndex();
        java.lang.String str54 = month34.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58982659200001L) + "'", long6 == (-58982659200001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-58982659200001L) + "'", long49 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1800 + "'", int52 == 1800);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 22802L + "'", long53 == 22802L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "February 1900" + "'", str54.equals("February 1900"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries4.setDomainDescription("");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class8);
        timeSeries9.setDescription("Preceding");
        timeSeries9.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int14 = timeSeries9.getMaximumItemCount();
        try {
            java.lang.Number number16 = timeSeries9.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        timeSeries1.clear();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int10 = month9.getYearValue();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long14 = month13.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long19 = month18.getLastMillisecond();
//        boolean boolean21 = month18.equals((java.lang.Object) 9223372036854775807L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) 3);
//        int int24 = month9.compareTo((java.lang.Object) month18);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries26.setDomainDescription("");
//        java.lang.Object obj29 = timeSeries26.clone();
//        long long30 = timeSeries26.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries26.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) (byte) 100);
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond34.peg(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond34.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond34.next();
//        boolean boolean42 = month18.equals((java.lang.Object) fixedMillisecond34);
//        long long43 = fixedMillisecond34.getLastMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58982659200001L) + "'", long14 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58982659200001L) + "'", long19 == (-58982659200001L));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560192880422L + "'", long40 == 1560192880422L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192880422L + "'", long43 == 1560192880422L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.Comparable comparable10 = timeSeries8.getKey();
        java.lang.String str11 = timeSeries8.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries8.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Overwritten values from: 0.0" + "'", comparable9.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Overwritten values from: 0.0" + "'", comparable10.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries8.setDomainDescription("");
        java.lang.Object obj11 = timeSeries8.clone();
        long long12 = timeSeries8.getMaximumItemAge();
        timeSeries8.clear();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int17 = month16.getYearValue();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long21 = month20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month20);
        long long23 = month20.getMiddleMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month20, (double) 43626L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-58982659200001L) + "'", long21 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-58983955200001L) + "'", long23 == (-58983955200001L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date38 = spreadsheetDate29.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean45 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean51 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean62 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean63 = spreadsheetDate56.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean64 = spreadsheetDate50.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.util.Date date65 = spreadsheetDate56.toDate();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean71 = spreadsheetDate68.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean77 = spreadsheetDate74.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean82 = spreadsheetDate79.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean83 = spreadsheetDate76.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean84 = spreadsheetDate70.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        java.util.Date date85 = spreadsheetDate76.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean91 = spreadsheetDate76.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        int int92 = spreadsheetDate76.getMonth();
        boolean boolean93 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SerialDate serialDate96 = spreadsheetDate76.getPreviousDayOfWeek(7);
        int int97 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        int int2 = timeSeries1.getItemCount();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass4 = day3.getClass();
//        long long5 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 11);
//        int int9 = day3.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Object obj9 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries11.setDomainDescription("");
        java.lang.Object obj14 = timeSeries11.clone();
        long long15 = timeSeries11.getMaximumItemAge();
        timeSeries11.clear();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        int int20 = month19.getYearValue();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(11, (int) (byte) 100);
        long long24 = month23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean27 = month19.equals((java.lang.Object) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month19.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = day31.getDayOfMonth();
        long long33 = day31.getSerialIndex();
        java.util.Date date34 = day31.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
        boolean boolean37 = month19.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) (-31507200000L));
        long long40 = month19.getMiddleMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 7.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-58982659200001L) + "'", long24 == (-58982659200001L));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-58983955200001L) + "'", long40 == (-58983955200001L));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getMiddleMillisecond(calendar14);
//        long long16 = fixedMillisecond9.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192881475L + "'", long15 == 1560192881475L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560192881475L + "'", long16 == 1560192881475L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries13.setDomainDescription("");
        java.lang.Object obj16 = timeSeries13.clone();
        long long17 = timeSeries13.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries23.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries20.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = day28.getDayOfMonth();
        long long30 = day28.getSerialIndex();
        int int31 = day28.getDayOfMonth();
        long long32 = day28.getMiddleMillisecond();
        int int33 = day28.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 100L);
        java.lang.Object obj36 = timeSeriesDataItem35.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        long long39 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
        boolean boolean41 = timeSeriesDataItem35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = timeSeriesDataItem35.compareTo((java.lang.Object) day42);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day42, (double) (-58985251200000L), true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) (byte) 100);
        java.lang.Object obj49 = timeSeriesDataItem48.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "Overwritten values from: 0.0" + "'", comparable21.equals("Overwritten values from: 0.0"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2204596800001L) + "'", long32 == (-2204596800001L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(obj49);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond9.previous();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192881794L + "'", long15 == 1560192881794L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries1.setDomainDescription("");
//        java.lang.Object obj4 = timeSeries1.clone();
//        long long5 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 100);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond9.peg(calendar12);
//        long long14 = fixedMillisecond9.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192881822L + "'", long14 == 1560192881822L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries7.setDomainDescription("");
        java.lang.Object obj10 = timeSeries7.clone();
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class11);
        boolean boolean17 = timeSeries16.getNotify();
        int int18 = timeSeries16.getItemCount();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        java.lang.String str6 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries8.setDomainDescription("");
//        java.lang.Object obj11 = timeSeries8.clone();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass18 = day17.getClass();
//        long long19 = day17.getSerialIndex();
//        java.lang.Number number20 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries22.setDomainDescription("");
//        java.lang.Object obj25 = timeSeries22.clone();
//        java.lang.Class class26 = timeSeries22.getTimePeriodClass();
//        java.lang.String str27 = timeSeries22.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        int int31 = day30.getDayOfMonth();
//        long long32 = day30.getSerialIndex();
//        int int33 = day30.getDayOfMonth();
//        long long34 = day30.getMiddleMillisecond();
//        java.lang.Number number35 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 5, true);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries40.setDomainDescription("");
//        java.lang.Object obj43 = timeSeries40.clone();
//        long long44 = timeSeries40.getMaximumItemAge();
//        timeSeries40.clear();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        int int49 = month48.getYearValue();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(11, (int) (byte) 100);
//        long long53 = month52.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month52);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries56.setDomainDescription("");
//        timeSeries56.setMaximumItemAge(0L);
//        timeSeries56.setKey((java.lang.Comparable) 9223372036854775807L);
//        boolean boolean64 = timeSeries56.equals((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries54.addAndOrUpdate(timeSeries56);
//        boolean boolean66 = day30.equals((java.lang.Object) timeSeries56);
//        java.lang.Class class67 = timeSeries56.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries5.addAndOrUpdate(timeSeries56);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 20 + "'", int33 == 20);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2204596800001L) + "'", long34 == (-2204596800001L));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-58982659200001L) + "'", long53 == (-58982659200001L));
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(class67);
//        org.junit.Assert.assertNotNull(timeSeries68);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
        java.lang.String str6 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str21 = serialDate20.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "28-February-1900" + "'", str21.equals("28-February-1900"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.util.List list9 = timeSeries1.getItems();
        boolean boolean10 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries1.setDomainDescription("");
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        timeSeries1.removeAgedItems((long) (byte) -1, true);
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries18.setDomainDescription("");
        java.lang.Object obj21 = timeSeries18.clone();
        java.lang.Class class22 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1L, "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", "", class22);
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "Preceding", "SerialDate.weekInMonthToString(): invalid code.", class22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
        timeSeries29.setDomainDescription("");
        java.lang.Object obj32 = timeSeries29.clone();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener33);
        timeSeries29.removeAgedItems((long) (byte) -1, true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int41 = day40.getDayOfMonth();
        long long42 = day40.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries1.addAndOrUpdate(timeSeries27);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 52L + "'", long42 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeries45);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = day2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "Jan", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day2.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2204553600001L) + "'", long3 == (-2204553600001L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean23 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        boolean boolean30 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        timeSeries32.setDomainDescription("");
//        java.lang.Object obj35 = timeSeries32.clone();
//        long long36 = timeSeries32.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries32.addAndOrUpdate(timeSeries38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (byte) 100);
//        long long43 = fixedMillisecond40.getLastMillisecond();
//        boolean boolean44 = spreadsheetDate27.equals((java.lang.Object) long43);
//        boolean boolean45 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean50 = spreadsheetDate47.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate49);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean56 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate55);
//        java.lang.String str58 = spreadsheetDate55.toString();
//        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean64 = spreadsheetDate61.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean70 = spreadsheetDate67.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        boolean boolean75 = spreadsheetDate72.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        boolean boolean76 = spreadsheetDate69.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        boolean boolean77 = spreadsheetDate63.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate80);
//        boolean boolean83 = spreadsheetDate69.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate86);
//        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate86);
//        java.lang.String str89 = spreadsheetDate86.getDescription();
//        int int90 = spreadsheetDate86.getDayOfWeek();
//        boolean boolean91 = spreadsheetDate69.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate86);
//        boolean boolean92 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate49, (org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192882373L + "'", long43 == 1560192882373L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "20-February-1900" + "'", str58.equals("20-February-1900"));
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertNull(str89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 3 + "'", int90 == 3);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//    }
//}

