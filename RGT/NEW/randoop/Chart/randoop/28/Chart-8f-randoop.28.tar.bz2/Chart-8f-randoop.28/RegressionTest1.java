import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.Date date8 = week7.getStart();
        java.lang.Class class9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str13 = week12.toString();
        java.util.Date date14 = week12.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14);
        java.lang.Object obj18 = new java.lang.Object();
        java.lang.Class<?> wildcardClass19 = obj18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str26 = week25.toString();
        java.util.Date date27 = week25.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str31 = week30.toString();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean33 = week30.equals((java.lang.Object) timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone32);
        java.lang.Object obj35 = new java.lang.Object();
        java.lang.Class<?> wildcardClass36 = obj35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone38);
        java.lang.Class class42 = null;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str46 = week45.toString();
        java.util.Date date47 = week45.getEnd();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date47);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47);
        java.lang.Object obj51 = new java.lang.Object();
        java.lang.Class<?> wildcardClass52 = obj51.getClass();
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str59 = week58.toString();
        java.util.Date date60 = week58.getEnd();
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str64 = week63.toString();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean66 = week63.equals((java.lang.Object) timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date60, timeZone65);
        java.lang.Object obj68 = new java.lang.Object();
        java.lang.Class<?> wildcardClass69 = obj68.getClass();
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date70, timeZone71);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date60, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date47, timeZone71);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date14, timeZone71);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date8, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = week76.previous();
        java.lang.Class<?> wildcardClass78 = regularTimePeriod77.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 0" + "'", str26.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 0" + "'", str31.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 35, 0" + "'", str46.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Week 35, 0" + "'", str59.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Week 35, 0" + "'", str64.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getSerialIndex();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        int int5 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.Date date4 = null;
        java.lang.Object obj5 = new java.lang.Object();
        java.lang.Class<?> wildcardClass6 = obj5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str13 = week12.toString();
        java.util.Date date14 = week12.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str18 = week17.toString();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean20 = week17.equals((java.lang.Object) timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str25 = week24.toString();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean27 = week24.equals((java.lang.Object) timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date14, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 0" + "'", str18.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 0" + "'", str25.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.Object obj3 = new java.lang.Object();
        java.lang.Class<?> wildcardClass4 = obj3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        int int8 = week2.compareTo((java.lang.Object) regularTimePeriod7);
        long long9 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62147145600000L) + "'", long9 == (-62147145600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.lang.String str13 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        java.lang.String str15 = week2.toString();
        java.util.Date date16 = week2.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str20 = week19.toString();
        java.util.Date date21 = week19.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21);
        java.lang.Object obj24 = new java.lang.Object();
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        int int31 = week30.getWeek();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str35 = week34.toString();
        java.lang.Object obj36 = new java.lang.Object();
        java.lang.Class<?> wildcardClass37 = obj36.getClass();
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date38, timeZone39);
        boolean boolean41 = week34.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week34.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week34.previous();
        long long44 = week34.getSerialIndex();
        int int45 = week34.getYearValue();
        long long46 = week34.getSerialIndex();
        try {
            int int47 = week30.compareTo((java.lang.Object) week34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 0" + "'", str15.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 0" + "'", str20.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 0" + "'", str35.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str12 = week11.toString();
        java.util.Date date13 = week11.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13);
        java.util.Date date18 = week17.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean22 = week17.equals((java.lang.Object) week21);
        int int23 = week21.getYearValue();
        java.lang.Class<?> wildcardClass24 = week21.getClass();
        java.util.Date date25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str29 = week28.toString();
        java.lang.Object obj30 = new java.lang.Object();
        java.lang.Class<?> wildcardClass31 = obj30.getClass();
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date32, timeZone33);
        boolean boolean35 = week28.equals((java.lang.Object) regularTimePeriod34);
        int int36 = week28.getYearValue();
        int int38 = week28.compareTo((java.lang.Object) (short) -1);
        java.lang.String str39 = week28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week28.next();
        java.lang.String str41 = week28.toString();
        java.util.Date date42 = week28.getStart();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str46 = week45.toString();
        java.util.Date date47 = week45.getEnd();
        java.util.Date date48 = week45.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date42, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date5, timeZone49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 0" + "'", str12.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 0" + "'", str29.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 0" + "'", str39.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 35, 0" + "'", str41.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 35, 0" + "'", str46.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod52);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        int int5 = week2.getWeek();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str8 = week7.toString();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        long long10 = week7.getFirstMillisecond();
        long long11 = week7.getFirstMillisecond();
        boolean boolean12 = week2.equals((java.lang.Object) week7);
        java.lang.Object obj13 = null;
        boolean boolean14 = week2.equals(obj13);
        long long15 = week2.getLastMillisecond();
        long long16 = week2.getLastMillisecond();
        long long17 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 0" + "'", str8.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62147145600000L) + "'", long10 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62147145600000L) + "'", long11 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62146540800001L) + "'", long15 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62146540800001L) + "'", long16 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62146540800001L) + "'", long17 == (-62146540800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        int int6 = week2.getYearValue();
        int int7 = week2.getYearValue();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        boolean boolean14 = week2.equals((java.lang.Object) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62146540800001L) + "'", long8 == (-62146540800001L));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str10 = week9.toString();
        java.util.Date date11 = week9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11);
        java.util.Date date15 = week14.getStart();
        boolean boolean16 = week6.equals((java.lang.Object) week14);
        java.lang.Class<?> wildcardClass17 = week14.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str23 = week22.toString();
        java.util.Date date24 = week22.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24);
        java.lang.Object obj30 = new java.lang.Object();
        java.lang.Class<?> wildcardClass31 = obj30.getClass();
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class34);
        java.util.Date date36 = null;
        java.lang.Object obj37 = new java.lang.Object();
        java.lang.Class<?> wildcardClass38 = obj37.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Object obj42 = new java.lang.Object();
        java.lang.Class<?> wildcardClass43 = obj42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.util.Date date51 = week49.getEnd();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str55 = week54.toString();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean57 = week54.equals((java.lang.Object) timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone56);
        java.lang.Object obj59 = new java.lang.Object();
        java.lang.Class<?> wildcardClass60 = obj59.getClass();
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date51, timeZone62);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date51, timeZone65);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str70 = week69.toString();
        java.util.Date date71 = week69.getEnd();
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date71);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date71);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str78 = week77.toString();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean80 = week77.equals((java.lang.Object) timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date71, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date24, timeZone79);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 0" + "'", str10.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 0" + "'", str23.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 0" + "'", str55.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 35, 0" + "'", str70.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Week 35, 0" + "'", str78.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        boolean boolean12 = week2.equals((java.lang.Object) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 153L + "'", long3 == 153L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str4 = week3.toString();
        java.util.Date date5 = week3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        java.lang.Object obj9 = new java.lang.Object();
        java.lang.Class<?> wildcardClass10 = obj9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str17 = week16.toString();
        java.util.Date date18 = week16.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str22 = week21.toString();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean24 = week21.equals((java.lang.Object) timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
        java.lang.Object obj26 = new java.lang.Object();
        java.lang.Class<?> wildcardClass27 = obj26.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date18, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone29);
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str37 = week36.toString();
        java.util.Date date38 = week36.getEnd();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date38);
        java.lang.Object obj42 = new java.lang.Object();
        java.lang.Class<?> wildcardClass43 = obj42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.util.Date date51 = week49.getEnd();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str55 = week54.toString();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean57 = week54.equals((java.lang.Object) timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone56);
        java.lang.Object obj59 = new java.lang.Object();
        java.lang.Class<?> wildcardClass60 = obj59.getClass();
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date51, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone62);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date5, timeZone62);
        long long67 = week66.getLastMillisecond();
        java.util.Date date68 = week66.getEnd();
        int int69 = week66.getYearValue();
        java.lang.String str70 = week66.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 0" + "'", str4.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 0" + "'", str22.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 35, 0" + "'", str37.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 0" + "'", str55.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62115091200001L) + "'", long67 == (-62115091200001L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 35, 1" + "'", str70.equals("Week 35, 1"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str15 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 4);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        java.lang.Object obj10 = null;
        int int11 = week8.compareTo(obj10);
        long long12 = week8.getLastMillisecond();
        long long13 = week8.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62115091200001L) + "'", long12 == (-62115091200001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62115393600001L) + "'", long13 == (-62115393600001L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-5), 35);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getStart();
        long long5 = week2.getSerialIndex();
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 430L + "'", long5 == 430L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 430L + "'", long6 == 430L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getYearValue();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        long long12 = week2.getSerialIndex();
        int int13 = week2.getYearValue();
        int int14 = week2.getWeek();
        int int15 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.previous();
        long long17 = week2.getLastMillisecond();
        int int18 = week2.getYearValue();
        int int20 = week2.compareTo((java.lang.Object) (-59006419200000L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62146540800001L) + "'", long17 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        long long9 = week2.getLastMillisecond();
        int int10 = week2.getYearValue();
        long long11 = week2.getLastMillisecond();
        long long12 = week2.getFirstMillisecond();
        long long13 = week2.getLastMillisecond();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass15 = week14.getClass();
        boolean boolean16 = week2.equals((java.lang.Object) wildcardClass15);
        java.lang.Object obj17 = new java.lang.Object();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str25 = week24.toString();
        java.util.Date date26 = week24.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str30 = week29.toString();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean32 = week29.equals((java.lang.Object) timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone31);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str37 = week36.toString();
        java.lang.Object obj38 = new java.lang.Object();
        java.lang.Class<?> wildcardClass39 = obj38.getClass();
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
        boolean boolean43 = week36.equals((java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week36.previous();
        long long45 = week36.getMiddleMillisecond();
        java.util.Date date46 = week36.getEnd();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.lang.Object obj51 = new java.lang.Object();
        java.lang.Class<?> wildcardClass52 = obj51.getClass();
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
        boolean boolean56 = week49.equals((java.lang.Object) regularTimePeriod55);
        int int57 = week49.getYearValue();
        int int59 = week49.compareTo((java.lang.Object) (short) -1);
        java.lang.String str60 = week49.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week49.next();
        java.lang.String str62 = week49.toString();
        java.util.Date date63 = week49.getStart();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str67 = week66.toString();
        java.util.Date date68 = week66.getEnd();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date68);
        java.lang.Object obj71 = new java.lang.Object();
        java.lang.Class<?> wildcardClass72 = obj71.getClass();
        java.util.Date date73 = null;
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date73, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date68, timeZone74);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date63, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date46, timeZone74);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str82 = week81.toString();
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean84 = week81.equals((java.lang.Object) timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date46, timeZone83);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146540800001L) + "'", long9 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62146540800001L) + "'", long11 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62147145600000L) + "'", long12 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62146540800001L) + "'", long13 == (-62146540800001L));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 0" + "'", str25.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 0" + "'", str30.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 35, 0" + "'", str37.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62146843200001L) + "'", long45 == (-62146843200001L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 35, 0" + "'", str60.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 35, 0" + "'", str62.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Week 35, 0" + "'", str67.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Week 35, 0" + "'", str82.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
        java.util.Date date7 = year5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year5);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year4);
        long long9 = week8.getLastMillisecond();
        java.util.Date date10 = week8.getEnd();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546156799999L + "'", long9 == 1546156799999L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        long long10 = week2.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62147145600000L) + "'", long10 == (-62147145600000L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        java.lang.String str10 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 0" + "'", str10.equals("Week 35, 0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.lang.String str13 = week2.toString();
        int int14 = week2.getYearValue();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str9 = week8.toString();
        java.lang.Object obj10 = new java.lang.Object();
        java.lang.Class<?> wildcardClass11 = obj10.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        boolean boolean15 = week8.equals((java.lang.Object) regularTimePeriod14);
        int int16 = week8.getYearValue();
        java.lang.String str17 = week8.toString();
        java.lang.Class<?> wildcardClass18 = week8.getClass();
        long long19 = week8.getLastMillisecond();
        java.util.Date date20 = week8.getEnd();
        boolean boolean21 = week2.equals((java.lang.Object) date20);
        java.lang.String str22 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 0" + "'", str9.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62146540800001L) + "'", long19 == (-62146540800001L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 0" + "'", str22.equals("Week 35, 0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        long long12 = week2.getSerialIndex();
        int int13 = week2.getWeek();
        java.util.Date date14 = week2.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        int int16 = week15.getWeek();
        long long17 = week15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week15.next();
        long long19 = week15.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62115393600001L) + "'", long17 == (-62115393600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62115091200001L) + "'", long19 == (-62115091200001L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.lang.String str13 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        java.lang.Class<?> wildcardClass15 = week2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year15 = week14.getYear();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(9, year15);
        java.util.Date date17 = year15.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, year15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(2, year15);
        java.util.Date date20 = week19.getEnd();
        java.lang.Class class21 = null;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str25 = week24.toString();
        java.util.Date date26 = week24.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date26);
        java.lang.Object obj30 = new java.lang.Object();
        java.lang.Class<?> wildcardClass31 = obj30.getClass();
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str38 = week37.toString();
        java.util.Date date39 = week37.getEnd();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str43 = week42.toString();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean45 = week42.equals((java.lang.Object) timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date39, timeZone44);
        java.lang.Object obj47 = new java.lang.Object();
        java.lang.Class<?> wildcardClass48 = obj47.getClass();
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date39, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date20, timeZone50);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date9, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 0" + "'", str25.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 35, 0" + "'", str38.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 0" + "'", str43.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass1 = week0.getClass();
        java.lang.Object obj2 = null;
        int int3 = week0.compareTo(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, 100);
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        long long9 = week2.getLastMillisecond();
        int int10 = week2.getYearValue();
        long long11 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        java.lang.String str13 = week2.toString();
        long long14 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146540800001L) + "'", long9 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62146540800001L) + "'", long11 == (-62146540800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62146540800001L) + "'", long14 == (-62146540800001L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str7 = week6.toString();
        java.util.Date date8 = week6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date8);
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean17 = week12.equals((java.lang.Object) week16);
        int int18 = week16.getYearValue();
        try {
            int int19 = week2.compareTo((java.lang.Object) week16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 153L + "'", long3 == 153L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 0" + "'", str7.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        int int6 = week2.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62076384000000L) + "'", long3 == (-62076384000000L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 6);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str7 = week6.toString();
        java.util.Date date8 = week6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str14 = week13.toString();
        java.util.Date date15 = week13.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date15);
        java.lang.Object obj19 = new java.lang.Object();
        java.lang.Class<?> wildcardClass20 = obj19.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str27 = week26.toString();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str32 = week31.toString();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean34 = week31.equals((java.lang.Object) timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date28, timeZone33);
        java.lang.Object obj36 = new java.lang.Object();
        java.lang.Class<?> wildcardClass37 = obj36.getClass();
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date38, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date28, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 0" + "'", str7.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 0" + "'", str14.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 0" + "'", str27.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 0" + "'", str32.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(3, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 10, year4);
        long long9 = year4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        long long14 = week8.getFirstMillisecond();
        int int15 = week8.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week8.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62115696000000L) + "'", long14 == (-62115696000000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 430L + "'", long5 == 430L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 9);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        java.lang.String str9 = week2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61878009600001L) + "'", long6 == (-61878009600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61878009600001L) + "'", long8 == (-61878009600001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 9, 9" + "'", str9.equals("Week 9, 9"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        org.jfree.data.time.Year year4 = week3.getYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = week3.equals(obj5);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.String str12 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException9.getSuppressed();
        java.lang.String str25 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str29 = timePeriodFormatException28.toString();
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException28.getSuppressed();
        java.lang.String str31 = timePeriodFormatException28.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str34 = timePeriodFormatException33.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.String str41 = timePeriodFormatException37.toString();
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException37.getSuppressed();
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str47 = timePeriodFormatException46.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str50 = timePeriodFormatException49.toString();
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException56.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str50.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.Date date8 = week7.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        long long10 = week9.getSerialIndex();
        java.lang.Object obj11 = new java.lang.Object();
        java.lang.Class<?> wildcardClass12 = obj11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Object obj16 = new java.lang.Object();
        java.lang.Class<?> wildcardClass17 = obj16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str24 = week23.toString();
        java.util.Date date25 = week23.getEnd();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str29 = week28.toString();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean31 = week28.equals((java.lang.Object) timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date25, timeZone30);
        java.lang.Object obj33 = new java.lang.Object();
        java.lang.Class<?> wildcardClass34 = obj33.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date25, timeZone36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date25, timeZone39);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        int int42 = week9.compareTo((java.lang.Object) class41);
        java.util.Calendar calendar43 = null;
        try {
            long long44 = week9.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 88L + "'", long10 == 88L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 0" + "'", str24.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 0" + "'", str29.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str4 = week3.toString();
        java.util.Date date5 = week3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        java.lang.Object obj9 = new java.lang.Object();
        java.lang.Class<?> wildcardClass10 = obj9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str17 = week16.toString();
        java.util.Date date18 = week16.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str22 = week21.toString();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean24 = week21.equals((java.lang.Object) timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
        java.lang.Object obj26 = new java.lang.Object();
        java.lang.Class<?> wildcardClass27 = obj26.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date18, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone29);
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str37 = week36.toString();
        java.util.Date date38 = week36.getEnd();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date38);
        java.lang.Object obj42 = new java.lang.Object();
        java.lang.Class<?> wildcardClass43 = obj42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.util.Date date51 = week49.getEnd();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str55 = week54.toString();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean57 = week54.equals((java.lang.Object) timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone56);
        java.lang.Object obj59 = new java.lang.Object();
        java.lang.Class<?> wildcardClass60 = obj59.getClass();
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date51, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone62);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date5, timeZone62);
        long long67 = week66.getLastMillisecond();
        java.util.Date date68 = week66.getEnd();
        int int69 = week66.getYearValue();
        long long70 = week66.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 0" + "'", str4.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 0" + "'", str22.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 35, 0" + "'", str37.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 0" + "'", str55.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62115091200001L) + "'", long67 == (-62115091200001L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 88L + "'", long70 == 88L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str17 = week16.toString();
        java.lang.Object obj18 = new java.lang.Object();
        java.lang.Class<?> wildcardClass19 = obj18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        boolean boolean23 = week16.equals((java.lang.Object) regularTimePeriod22);
        int int24 = week16.getYearValue();
        boolean boolean25 = week8.equals((java.lang.Object) week16);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = week8.getMiddleMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        int int6 = week2.getWeek();
        long long7 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62146843200001L) + "'", long7 == (-62146843200001L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
        java.util.Date date7 = year5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 1, year5);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.util.Date date13 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 9);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        int int6 = week2.getYearValue();
        int int7 = week2.getYearValue();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        boolean boolean14 = week2.equals((java.lang.Object) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass15 = week2.getClass();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week2.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62146540800001L) + "'", long8 == (-62146540800001L));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.lang.Object obj17 = new java.lang.Object();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        boolean boolean22 = week15.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week15.previous();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str28 = week27.toString();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        long long30 = week27.getFirstMillisecond();
        long long31 = week27.getFirstMillisecond();
        int int32 = week15.compareTo((java.lang.Object) long31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str36 = week35.toString();
        java.util.Date date37 = week35.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str43 = week42.toString();
        java.util.Date date44 = week42.getEnd();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44);
        java.util.Date date48 = week47.getStart();
        boolean boolean49 = week39.equals((java.lang.Object) week47);
        boolean boolean50 = week15.equals((java.lang.Object) week39);
        int int51 = week2.compareTo((java.lang.Object) boolean50);
        int int52 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week2.next();
        int int54 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 0" + "'", str28.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62147145600000L) + "'", long30 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62147145600000L) + "'", long31 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 35, 0" + "'", str36.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 0" + "'", str43.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str20 = week19.toString();
        java.util.Date date21 = week19.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.lang.Object obj25 = new java.lang.Object();
        java.lang.Class<?> wildcardClass26 = obj25.getClass();
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str33 = week32.toString();
        java.util.Date date34 = week32.getEnd();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str38 = week37.toString();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean40 = week37.equals((java.lang.Object) timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date34, timeZone39);
        java.lang.Object obj42 = new java.lang.Object();
        java.lang.Class<?> wildcardClass43 = obj42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date34, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date21, timeZone45);
        java.lang.Class class49 = null;
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str53 = week52.toString();
        java.util.Date date54 = week52.getEnd();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date54);
        java.lang.Object obj58 = new java.lang.Object();
        java.lang.Class<?> wildcardClass59 = obj58.getClass();
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str66 = week65.toString();
        java.util.Date date67 = week65.getEnd();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str71 = week70.toString();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean73 = week70.equals((java.lang.Object) timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date67, timeZone72);
        java.lang.Object obj75 = new java.lang.Object();
        java.lang.Class<?> wildcardClass76 = obj75.getClass();
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date77, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date67, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone78);
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date21, timeZone78);
        long long83 = week82.getLastMillisecond();
        java.util.Date date84 = week82.getEnd();
        int int85 = week82.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException87 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str88 = timePeriodFormatException87.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException90 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str91 = timePeriodFormatException90.toString();
        timePeriodFormatException87.addSuppressed((java.lang.Throwable) timePeriodFormatException90);
        java.lang.Throwable[] throwableArray93 = timePeriodFormatException87.getSuppressed();
        java.lang.Throwable[] throwableArray94 = timePeriodFormatException87.getSuppressed();
        boolean boolean95 = week82.equals((java.lang.Object) timePeriodFormatException87);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException87);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 0" + "'", str20.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 0" + "'", str33.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 35, 0" + "'", str38.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Week 35, 0" + "'", str53.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertNotNull(class61);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Week 35, 0" + "'", str66.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Week 35, 0" + "'", str71.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-62115091200001L) + "'", long83 == (-62115091200001L));
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str88.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str91.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray93);
        org.junit.Assert.assertNotNull(throwableArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
        java.util.Date date8 = year6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) -1, year6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) -1, year6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 10, year6);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 9);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str16 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str19 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str22 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        int int34 = week2.compareTo((java.lang.Object) timePeriodFormatException25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61878009600001L) + "'", long6 == (-61878009600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61878009600001L) + "'", long8 == (-61878009600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        java.lang.String str11 = week2.toString();
        java.lang.Class<?> wildcardClass12 = week2.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.util.Date date17 = week15.getEnd();
        java.util.Date date18 = week15.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str24 = week23.toString();
        java.util.Date date25 = week23.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date28, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date28);
        java.lang.Class<?> wildcardClass33 = week32.getClass();
        int int34 = week32.getYearValue();
        long long35 = week32.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 0" + "'", str11.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 0" + "'", str24.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 88L + "'", long35 == 88L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass15 = week14.getClass();
        int int16 = week14.getWeek();
        java.util.Date date17 = week14.getEnd();
        java.lang.Object obj18 = new java.lang.Object();
        java.lang.Class<?> wildcardClass19 = obj18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str26 = week25.toString();
        java.util.Date date27 = week25.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str31 = week30.toString();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean33 = week30.equals((java.lang.Object) timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone32);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str38 = week37.toString();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean40 = week37.equals((java.lang.Object) timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date27, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date17, timeZone39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date9, timeZone39);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 0" + "'", str26.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 0" + "'", str31.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 35, 0" + "'", str38.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
        java.util.Date date8 = year6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2, year6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((-1), year6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, year6);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.String str12 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str24 = timePeriodFormatException9.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str15 = week14.toString();
        java.lang.Object obj16 = new java.lang.Object();
        java.lang.Class<?> wildcardClass17 = obj16.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        boolean boolean21 = week14.equals((java.lang.Object) regularTimePeriod20);
        int int22 = week14.getYearValue();
        java.lang.String str23 = week14.toString();
        java.lang.Class<?> wildcardClass24 = week14.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str28 = week27.toString();
        java.util.Date date29 = week27.getEnd();
        java.util.Date date30 = week27.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year35 = week34.getYear();
        java.util.Date date36 = week34.getEnd();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str40 = week39.toString();
        java.util.Date date41 = week39.getEnd();
        java.util.Date date42 = week39.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date36, timeZone43);
        java.lang.Class class46 = null;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.lang.Object obj51 = new java.lang.Object();
        java.lang.Class<?> wildcardClass52 = obj51.getClass();
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
        boolean boolean56 = week49.equals((java.lang.Object) regularTimePeriod55);
        int int57 = week49.getYearValue();
        int int59 = week49.compareTo((java.lang.Object) (short) -1);
        java.lang.String str60 = week49.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week49.next();
        java.lang.String str62 = week49.toString();
        java.util.Date date63 = week49.getStart();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str67 = week66.toString();
        java.util.Date date68 = week66.getEnd();
        java.util.Date date69 = week66.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date69, timeZone70);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date63, timeZone70);
        java.lang.Object obj73 = new java.lang.Object();
        java.lang.Class<?> wildcardClass74 = obj73.getClass();
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date63, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date36, timeZone76);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date11, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week80.previous();
        long long82 = regularTimePeriod81.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 0" + "'", str15.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 0" + "'", str23.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 0" + "'", str28.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 35, 0" + "'", str40.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 35, 0" + "'", str60.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 35, 0" + "'", str62.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Week 35, 0" + "'", str67.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-62115393600001L) + "'", long82 == (-62115393600001L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.String str12 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException9.getSuppressed();
        java.lang.String str25 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str29 = timePeriodFormatException28.toString();
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException28.getSuppressed();
        java.lang.String str31 = timePeriodFormatException28.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str34 = timePeriodFormatException33.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.String str41 = timePeriodFormatException37.toString();
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException37.getSuppressed();
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str47 = timePeriodFormatException46.toString();
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException46.getSuppressed();
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 6);
        long long3 = week2.getLastMillisecond();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61978406400001L) + "'", long3 == (-61978406400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.lang.String str13 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week2.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62146540800001L) + "'", long15 == (-62146540800001L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        java.util.Date date13 = regularTimePeriod12.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        long long12 = week2.getSerialIndex();
        int int13 = week2.getYearValue();
        int int14 = week2.getWeek();
        int int15 = week2.getYearValue();
        int int16 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62146843200001L) + "'", long3 == (-62146843200001L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year6);
        java.util.Date date8 = year6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) -1, year6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) -1, year6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(6, year6);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year4);
        long long9 = year4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        long long9 = week2.getLastMillisecond();
        int int10 = week2.getYearValue();
        long long11 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        java.util.Date date13 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146540800001L) + "'", long9 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62146540800001L) + "'", long11 == (-62146540800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        java.lang.Class<?> wildcardClass10 = week2.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str14 = week13.toString();
        java.lang.Object obj15 = new java.lang.Object();
        java.lang.Class<?> wildcardClass16 = obj15.getClass();
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
        boolean boolean20 = week13.equals((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week13.previous();
        java.util.Date date24 = regularTimePeriod23.getStart();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str28 = week27.toString();
        java.lang.Object obj29 = new java.lang.Object();
        java.lang.Class<?> wildcardClass30 = obj29.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        boolean boolean34 = week27.equals((java.lang.Object) regularTimePeriod33);
        int int35 = week27.getYearValue();
        int int37 = week27.compareTo((java.lang.Object) (short) -1);
        java.util.Date date38 = week27.getStart();
        long long39 = week27.getFirstMillisecond();
        int int40 = week27.getWeek();
        java.util.Date date41 = week27.getEnd();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str45 = week44.toString();
        java.lang.Object obj46 = new java.lang.Object();
        java.lang.Class<?> wildcardClass47 = obj46.getClass();
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone49);
        boolean boolean51 = week44.equals((java.lang.Object) regularTimePeriod50);
        int int52 = week44.getYearValue();
        int int54 = week44.compareTo((java.lang.Object) (short) -1);
        java.lang.String str55 = week44.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week44.next();
        java.lang.String str57 = week44.toString();
        java.util.Date date58 = week44.getStart();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str62 = week61.toString();
        java.util.Date date63 = week61.getEnd();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date63);
        java.lang.Object obj66 = new java.lang.Object();
        java.lang.Class<?> wildcardClass67 = obj66.getClass();
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date63, timeZone69);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date58, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date41, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone69);
        java.util.Date date75 = regularTimePeriod74.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 0" + "'", str14.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 0" + "'", str28.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62147145600000L) + "'", long39 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 35 + "'", int40 == 35);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 0" + "'", str45.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 0" + "'", str55.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Week 35, 0" + "'", str57.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 35, 0" + "'", str62.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        long long14 = week8.getFirstMillisecond();
        int int15 = week8.getYearValue();
        long long16 = week8.getFirstMillisecond();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (byte) 10, 8);
        boolean boolean20 = week8.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62115696000000L) + "'", long14 == (-62115696000000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62115696000000L) + "'", long16 == (-62115696000000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        int int5 = week2.getWeek();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Object obj7 = null;
        boolean boolean8 = week2.equals(obj7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str12 = week11.toString();
        java.lang.Object obj13 = new java.lang.Object();
        java.lang.Class<?> wildcardClass14 = obj13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        boolean boolean18 = week11.equals((java.lang.Object) regularTimePeriod17);
        int int19 = week11.getYearValue();
        int int21 = week11.compareTo((java.lang.Object) (short) -1);
        java.util.Date date22 = week11.getStart();
        int int23 = week11.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week11.previous();
        try {
            int int25 = week2.compareTo((java.lang.Object) week11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 0" + "'", str12.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35 + "'", int23 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        java.lang.String str11 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = regularTimePeriod12.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 0" + "'", str11.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str10 = week9.toString();
        java.util.Date date11 = week9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11);
        java.util.Date date15 = week14.getStart();
        boolean boolean16 = week6.equals((java.lang.Object) week14);
        int int17 = week6.getYearValue();
        java.util.Date date18 = week6.getEnd();
        java.util.Calendar calendar19 = null;
        try {
            week6.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 0" + "'", str10.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        java.lang.String str11 = week2.toString();
        java.lang.Class<?> wildcardClass12 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        java.lang.String str14 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 0" + "'", str11.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 0" + "'", str14.equals("Week 35, 0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (byte) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.lang.String str13 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        java.lang.String str15 = week2.toString();
        java.util.Date date16 = week2.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str20 = week19.toString();
        java.util.Date date21 = week19.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21);
        java.lang.Object obj24 = new java.lang.Object();
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        java.lang.Class<?> wildcardClass31 = timeZone27.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass35 = week34.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str39 = week38.toString();
        java.lang.Object obj40 = new java.lang.Object();
        java.lang.Class<?> wildcardClass41 = obj40.getClass();
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
        boolean boolean45 = week38.equals((java.lang.Object) regularTimePeriod44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week38.previous();
        long long47 = week38.getMiddleMillisecond();
        java.util.Date date48 = week38.getEnd();
        java.lang.Object obj49 = new java.lang.Object();
        java.lang.Class<?> wildcardClass50 = obj49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        boolean boolean52 = week38.equals((java.lang.Object) wildcardClass50);
        boolean boolean53 = week34.equals((java.lang.Object) week38);
        java.util.Date date54 = week38.getEnd();
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str58 = week57.toString();
        java.lang.Object obj59 = new java.lang.Object();
        java.lang.Class<?> wildcardClass60 = obj59.getClass();
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone62);
        boolean boolean64 = week57.equals((java.lang.Object) regularTimePeriod63);
        int int65 = week57.getYearValue();
        int int67 = week57.compareTo((java.lang.Object) (short) -1);
        java.lang.String str68 = week57.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week57.next();
        java.lang.String str70 = week57.toString();
        java.util.Date date71 = week57.getStart();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str75 = week74.toString();
        java.util.Date date76 = week74.getEnd();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date76);
        java.lang.Object obj79 = new java.lang.Object();
        java.lang.Class<?> wildcardClass80 = obj79.getClass();
        java.util.Date date81 = null;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date81, timeZone82);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date76, timeZone82);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date71, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date54, timeZone82);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 0" + "'", str15.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 0" + "'", str20.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 0" + "'", str39.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62146843200001L) + "'", long47 == (-62146843200001L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 0" + "'", str58.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Week 35, 0" + "'", str68.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 35, 0" + "'", str70.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Week 35, 0" + "'", str75.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod86);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = week2.equals((java.lang.Object) timeZone4);
        int int6 = week2.getYearValue();
        int int7 = week2.getYearValue();
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        boolean boolean14 = week2.equals((java.lang.Object) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass15 = week2.getClass();
        java.util.Date date16 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62146540800001L) + "'", long8 == (-62146540800001L));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62115696000000L) + "'", long6 == (-62115696000000L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.util.Date date0 = null;
        java.lang.Object obj1 = new java.lang.Object();
        java.lang.Class<?> wildcardClass2 = obj1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Object obj6 = new java.lang.Object();
        java.lang.Class<?> wildcardClass7 = obj6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str14 = week13.toString();
        java.util.Date date15 = week13.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str19 = week18.toString();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean21 = week18.equals((java.lang.Object) timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date15, timeZone20);
        java.lang.Object obj23 = new java.lang.Object();
        java.lang.Class<?> wildcardClass24 = obj23.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date15, timeZone26);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date15, timeZone29);
        java.util.Locale locale31 = null;
        try {
            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date0, timeZone29, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 0" + "'", str14.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 0" + "'", str19.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.Date date8 = week7.getStart();
        int int10 = week7.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        long long9 = week2.getLastMillisecond();
        int int10 = week2.getYearValue();
        java.lang.Class<?> wildcardClass11 = week2.getClass();
        long long12 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146540800001L) + "'", long9 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62146843200001L) + "'", long12 == (-62146843200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str4 = week3.toString();
        java.util.Date date5 = week3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        java.lang.Object obj9 = new java.lang.Object();
        java.lang.Class<?> wildcardClass10 = obj9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str17 = week16.toString();
        java.util.Date date18 = week16.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str22 = week21.toString();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean24 = week21.equals((java.lang.Object) timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone23);
        java.lang.Object obj26 = new java.lang.Object();
        java.lang.Class<?> wildcardClass27 = obj26.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date18, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date5, timeZone34);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str39 = week38.toString();
        java.util.Date date40 = week38.getEnd();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40);
        java.util.Date date45 = week44.getEnd();
        long long46 = week44.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week44.next();
        boolean boolean48 = week35.equals((java.lang.Object) regularTimePeriod47);
        int int49 = week35.getYearValue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 0" + "'", str4.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 0" + "'", str22.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 0" + "'", str39.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 88L + "'", long46 == 88L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, (int) (byte) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str16 = timePeriodFormatException15.toString();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException19.getSuppressed();
        int int23 = week12.compareTo((java.lang.Object) throwableArray22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.lang.Object obj17 = new java.lang.Object();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        boolean boolean22 = week15.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week15.previous();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str28 = week27.toString();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        long long30 = week27.getFirstMillisecond();
        long long31 = week27.getFirstMillisecond();
        int int32 = week15.compareTo((java.lang.Object) long31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str36 = week35.toString();
        java.util.Date date37 = week35.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str43 = week42.toString();
        java.util.Date date44 = week42.getEnd();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44);
        java.util.Date date48 = week47.getStart();
        boolean boolean49 = week39.equals((java.lang.Object) week47);
        boolean boolean50 = week15.equals((java.lang.Object) week39);
        int int51 = week2.compareTo((java.lang.Object) boolean50);
        int int52 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week2.next();
        long long54 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 0" + "'", str28.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62147145600000L) + "'", long30 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62147145600000L) + "'", long31 == (-62147145600000L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 35, 0" + "'", str36.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 0" + "'", str43.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62147145600000L) + "'", long54 == (-62147145600000L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2, year4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year11 = week10.getYear();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass16 = week15.getClass();
        int int17 = week15.getWeek();
        java.util.Date date18 = week15.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str22 = week21.toString();
        java.util.Date date23 = week21.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date23);
        java.util.Date date27 = week26.getStart();
        java.lang.Class class28 = null;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str32 = week31.toString();
        java.util.Date date33 = week31.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33);
        java.lang.Object obj37 = new java.lang.Object();
        java.lang.Class<?> wildcardClass38 = obj37.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str45 = week44.toString();
        java.util.Date date46 = week44.getEnd();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean52 = week49.equals((java.lang.Object) timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date46, timeZone51);
        java.lang.Object obj54 = new java.lang.Object();
        java.lang.Class<?> wildcardClass55 = obj54.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date46, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date33, timeZone57);
        java.lang.Class class61 = null;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str65 = week64.toString();
        java.util.Date date66 = week64.getEnd();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date66);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date66);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date66);
        java.lang.Object obj70 = new java.lang.Object();
        java.lang.Class<?> wildcardClass71 = obj70.getClass();
        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str78 = week77.toString();
        java.util.Date date79 = week77.getEnd();
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str83 = week82.toString();
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean85 = week82.equals((java.lang.Object) timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date79, timeZone84);
        java.lang.Object obj87 = new java.lang.Object();
        java.lang.Class<?> wildcardClass88 = obj87.getClass();
        java.util.Date date89 = null;
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass88, date89, timeZone90);
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date79, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date66, timeZone90);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date33, timeZone90);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date27, timeZone90);
        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date18, timeZone90);
        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date12, timeZone90);
        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date9, timeZone90);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 0" + "'", str22.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 0" + "'", str32.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 0" + "'", str45.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Week 35, 0" + "'", str65.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(class72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertNotNull(class74);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Week 35, 0" + "'", str78.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "Week 35, 0" + "'", str83.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        long long10 = week8.getSerialIndex();
        try {
            org.jfree.data.time.Year year11 = week8.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 88L + "'", long10 == 88L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2, year4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 11);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 582L + "'", long3 == 582L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        java.lang.String str11 = week2.toString();
        java.lang.Class<?> wildcardClass12 = week2.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.util.Date date17 = week15.getEnd();
        java.util.Date date18 = week15.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year24 = week23.getYear();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(9, year24);
        java.util.Date date26 = year24.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        java.lang.Class<?> wildcardClass30 = week29.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        java.lang.Object obj32 = new java.lang.Object();
        java.lang.Class<?> wildcardClass33 = obj32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Object obj37 = new java.lang.Object();
        java.lang.Class<?> wildcardClass38 = obj37.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str45 = week44.toString();
        java.util.Date date46 = week44.getEnd();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str50 = week49.toString();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean52 = week49.equals((java.lang.Object) timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date46, timeZone51);
        java.lang.Object obj54 = new java.lang.Object();
        java.lang.Class<?> wildcardClass55 = obj54.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date46, timeZone57);
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date46, timeZone60);
        java.lang.Object obj62 = new java.lang.Object();
        java.lang.Class<?> wildcardClass63 = obj62.getClass();
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str70 = week69.toString();
        java.util.Date date71 = week69.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str75 = week74.toString();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean77 = week74.equals((java.lang.Object) timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date71, timeZone76);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str82 = week81.toString();
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean84 = week81.equals((java.lang.Object) timeZone83);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date71, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date46, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone83);
        java.lang.Class class88 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 0" + "'", str11.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 0" + "'", str45.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 0" + "'", str50.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 35, 0" + "'", str70.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Week 35, 0" + "'", str75.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Week 35, 0" + "'", str82.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(class88);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass1 = week0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str9 = week8.toString();
        java.lang.Object obj10 = new java.lang.Object();
        java.lang.Class<?> wildcardClass11 = obj10.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        boolean boolean15 = week8.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week8.previous();
        boolean boolean18 = week2.equals((java.lang.Object) week8);
        long long19 = week8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 0" + "'", str9.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62147145600000L) + "'", long19 == (-62147145600000L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, year3);
        long long5 = year3.getMiddleMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 0, year3);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        int int12 = week2.compareTo((java.lang.Object) (short) -1);
        java.util.Date date13 = week2.getStart();
        int int14 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.previous();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        long long17 = regularTimePeriod15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62147448000001L) + "'", long17 == (-62147448000001L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 9);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61862284800001L) + "'", long3 == (-61862284800001L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.Date date8 = week7.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str13 = week12.toString();
        java.util.Date date14 = week12.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14);
        java.lang.Object obj18 = new java.lang.Object();
        java.lang.Class<?> wildcardClass19 = obj18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str26 = week25.toString();
        java.util.Date date27 = week25.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str31 = week30.toString();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean33 = week30.equals((java.lang.Object) timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone32);
        java.lang.Object obj35 = new java.lang.Object();
        java.lang.Class<?> wildcardClass36 = obj35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date8, timeZone38);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date8);
        java.util.Date date44 = week43.getStart();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str48 = week47.toString();
        java.util.Date date49 = week47.getEnd();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date49);
        java.util.Date date53 = week52.getStart();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date53);
        long long55 = week54.getSerialIndex();
        java.lang.Object obj56 = new java.lang.Object();
        java.lang.Class<?> wildcardClass57 = obj56.getClass();
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        java.lang.Object obj61 = new java.lang.Object();
        java.lang.Class<?> wildcardClass62 = obj61.getClass();
        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str69 = week68.toString();
        java.util.Date date70 = week68.getEnd();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str74 = week73.toString();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean76 = week73.equals((java.lang.Object) timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date70, timeZone75);
        java.lang.Object obj78 = new java.lang.Object();
        java.lang.Class<?> wildcardClass79 = obj78.getClass();
        java.util.Date date80 = null;
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass79, date80, timeZone81);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date70, timeZone81);
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date70, timeZone84);
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        int int87 = week54.compareTo((java.lang.Object) class86);
        int int88 = week43.compareTo((java.lang.Object) int87);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 0" + "'", str26.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 0" + "'", str31.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 35, 0" + "'", str48.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 88L + "'", long55 == 88L);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Week 35, 0" + "'", str69.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Week 35, 0" + "'", str74.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        int int14 = week12.getYearValue();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        int int16 = week12.getWeek();
        java.lang.Class<?> wildcardClass17 = week12.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getEnd();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        long long11 = week2.getMiddleMillisecond();
        java.util.Date date12 = week2.getEnd();
        java.lang.Object obj13 = new java.lang.Object();
        java.lang.Class<?> wildcardClass14 = obj13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        boolean boolean16 = week2.equals((java.lang.Object) wildcardClass14);
        long long17 = week2.getFirstMillisecond();
        java.util.Date date18 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62146843200001L) + "'", long11 == (-62146843200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62147145600000L) + "'", long17 == (-62147145600000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        int int9 = week2.getWeek();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str27 = timePeriodFormatException26.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str30 = timePeriodFormatException29.toString();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str36 = timePeriodFormatException35.toString();
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException35.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.String str41 = timePeriodFormatException39.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str44 = timePeriodFormatException43.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str47 = timePeriodFormatException46.toString();
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        java.lang.Object obj2 = null;
//        int int3 = week0.compareTo(obj2);
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
        java.util.Date date7 = year5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(2, year5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(4, year5);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        java.util.Date date13 = regularTimePeriod12.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        long long15 = week14.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62115696000001L) + "'", long15 == (-62115696000001L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        boolean boolean12 = week2.equals((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.String str17 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str20 = timePeriodFormatException19.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long26 = week25.getSerialIndex();
        int int27 = week25.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str32 = timePeriodFormatException31.toString();
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        boolean boolean35 = week25.equals((java.lang.Object) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str38 = timePeriodFormatException37.toString();
        java.lang.Throwable[] throwableArray39 = timePeriodFormatException37.getSuppressed();
        java.lang.String str40 = timePeriodFormatException37.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str43 = timePeriodFormatException42.toString();
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.String str51 = timePeriodFormatException46.toString();
        java.lang.Class<?> wildcardClass52 = timePeriodFormatException46.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str56 = week55.toString();
        java.lang.Object obj57 = new java.lang.Object();
        java.lang.Class<?> wildcardClass58 = obj57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        boolean boolean62 = week55.equals((java.lang.Object) regularTimePeriod61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week55.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week55.previous();
        long long65 = week55.getSerialIndex();
        int int66 = week55.getYearValue();
        int int67 = week55.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str70 = timePeriodFormatException69.toString();
        java.lang.Throwable[] throwableArray71 = timePeriodFormatException69.getSuppressed();
        java.lang.String str72 = timePeriodFormatException69.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str75 = timePeriodFormatException74.toString();
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException74);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException78 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException80 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException78.addSuppressed((java.lang.Throwable) timePeriodFormatException80);
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException78);
        java.lang.String str83 = timePeriodFormatException78.toString();
        java.lang.Throwable[] throwableArray84 = timePeriodFormatException78.getSuppressed();
        int int85 = week55.compareTo((java.lang.Object) timePeriodFormatException78);
        java.lang.String str86 = timePeriodFormatException78.toString();
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException78);
        java.lang.String str88 = timePeriodFormatException46.toString();
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 153L + "'", long3 == 153L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 153L + "'", long26 == 153L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str51.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 0" + "'", str56.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 35L + "'", long65 == 35L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 35 + "'", int67 == 35);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str70.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str72.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str75.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str83.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str86.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str88.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.Date date8 = week7.getEnd();
        java.lang.String str9 = week7.toString();
        try {
            org.jfree.data.time.Year year10 = week7.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 1" + "'", str9.equals("Week 35, 1"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 100, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 0);
        int int8 = week2.compareTo((java.lang.Object) '#');
        long long9 = week2.getLastMillisecond();
        java.lang.String str10 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146540800001L) + "'", long9 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 0" + "'", str10.equals("Week 35, 0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        long long12 = week2.getSerialIndex();
        int int13 = week2.getWeek();
        java.util.Date date14 = week2.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        int int16 = week15.getWeek();
        long long17 = week15.getMiddleMillisecond();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str21 = week20.toString();
        java.util.Date date22 = week20.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22);
        long long26 = week25.getMiddleMillisecond();
        java.util.Date date27 = week25.getStart();
        boolean boolean28 = week15.equals((java.lang.Object) week25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week15.next();
        long long30 = regularTimePeriod29.getMiddleMillisecond();
        java.util.Date date31 = regularTimePeriod29.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62115393600001L) + "'", long17 == (-62115393600001L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 0" + "'", str21.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62115393600001L) + "'", long26 == (-62115393600001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62114788800001L) + "'", long30 == (-62114788800001L));
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 9);
        int int4 = week2.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61878009600001L) + "'", long6 == (-61878009600001L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 9, 9");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 9, 9" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 9, 9"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        int int15 = week12.compareTo((java.lang.Object) "");
        long long16 = week12.getSerialIndex();
        try {
            org.jfree.data.time.Year year17 = week12.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.lang.Class<?> wildcardClass6 = year4.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year4);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(3, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 10, year4);
        java.lang.String str9 = week8.toString();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year4);
        java.util.Date date9 = week8.getStart();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Object obj5 = new java.lang.Object();
        java.lang.Class<?> wildcardClass6 = obj5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str13 = week12.toString();
        java.util.Date date14 = week12.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str18 = week17.toString();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean20 = week17.equals((java.lang.Object) timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone19);
        java.lang.Object obj22 = new java.lang.Object();
        java.lang.Class<?> wildcardClass23 = obj22.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date14, timeZone25);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date14);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 0" + "'", str13.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 0" + "'", str18.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getLastMillisecond();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62146540800001L) + "'", long6 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62146540800001L) + "'", long7 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62146843200001L) + "'", long8 == (-62146843200001L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        long long8 = week7.getMiddleMillisecond();
        long long9 = week7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62115393600001L) + "'", long8 == (-62115393600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 88L + "'", long9 == 88L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 0);
        boolean boolean13 = week8.equals((java.lang.Object) week12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str17 = week16.toString();
        java.lang.Object obj18 = new java.lang.Object();
        java.lang.Class<?> wildcardClass19 = obj18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        boolean boolean23 = week16.equals((java.lang.Object) regularTimePeriod22);
        int int24 = week16.getYearValue();
        boolean boolean25 = week8.equals((java.lang.Object) week16);
        long long26 = week16.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 0" + "'", str17.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.util.Date date17 = week15.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.lang.Object obj21 = new java.lang.Object();
        java.lang.Class<?> wildcardClass22 = obj21.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str29 = week28.toString();
        java.util.Date date30 = week28.getEnd();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str34 = week33.toString();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean36 = week33.equals((java.lang.Object) timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone35);
        java.lang.Object obj38 = new java.lang.Object();
        java.lang.Class<?> wildcardClass39 = obj38.getClass();
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date30, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date17, timeZone41);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date17, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date11, timeZone46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 0" + "'", str29.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 0" + "'", str34.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeZone46);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) -1, year3);
        long long6 = week5.getMiddleMillisecond();
        int int7 = week5.getWeek();
        java.util.Date date8 = week5.getEnd();
        long long9 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545249599999L + "'", long6 == 1545249599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1545551999999L + "'", long9 == 1545551999999L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2, year4);
        java.util.Date date9 = week8.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str14 = week13.toString();
        java.util.Date date15 = week13.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date15);
        java.lang.Object obj19 = new java.lang.Object();
        java.lang.Class<?> wildcardClass20 = obj19.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str27 = week26.toString();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str32 = week31.toString();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean34 = week31.equals((java.lang.Object) timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date28, timeZone33);
        java.lang.Object obj36 = new java.lang.Object();
        java.lang.Class<?> wildcardClass37 = obj36.getClass();
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date38, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date28, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date9, timeZone39);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date9);
        java.util.Date date45 = week44.getEnd();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 0" + "'", str14.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 0" + "'", str27.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 0" + "'", str32.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException5.toString();
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str23 = timePeriodFormatException14.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        int int11 = week2.getWeek();
        java.lang.String str12 = week2.toString();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.lang.Object obj17 = new java.lang.Object();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        boolean boolean22 = week15.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week15.previous();
        java.util.Date date26 = regularTimePeriod25.getStart();
        boolean boolean27 = week2.equals((java.lang.Object) date26);
        java.util.Date date28 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 0" + "'", str12.equals("Week 35, 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 153L + "'", long3 == 153L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        try {
            org.jfree.data.time.Year year8 = week7.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        int int11 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod8);
        int int10 = week2.getYearValue();
        java.lang.String str11 = week2.toString();
        java.lang.Class<?> wildcardClass12 = week2.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str16 = week15.toString();
        java.util.Date date17 = week15.getEnd();
        java.util.Date date18 = week15.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str24 = week23.toString();
        java.util.Date date25 = week23.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date28, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date28);
        java.lang.Class<?> wildcardClass33 = week32.getClass();
        java.util.Date date34 = week32.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 0" + "'", str11.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 0" + "'", str16.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 0" + "'", str24.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 8);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 8" + "'", str3.equals("Week 6, 8"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str17 = timePeriodFormatException16.toString();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException16.getSuppressed();
        java.lang.String str19 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str22 = timePeriodFormatException21.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException16.getSuppressed();
        java.lang.String str32 = timePeriodFormatException16.toString();
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException16.getSuppressed();
        int int34 = week2.compareTo((java.lang.Object) throwableArray33);
        long long35 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 0" + "'", str3.equals("Week 35, 0"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62146540800001L) + "'", long6 == (-62146540800001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62147145600000L) + "'", long35 == (-62147145600000L));
    }
}

