import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 10, (int) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        try {
            stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("#0a0a0a", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.data.Range range2 = null;
        try {
            dateAxis0.setRange(range2, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("#0a0a0a", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        float[] floatArray7 = new float[] { (short) 1, 10, (short) 0 };
        try {
            float[] floatArray8 = chartColor3.getComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-1L), "hi!", textAnchor2, textAnchor3, 12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = dateAxis0.draw(graphics2D4, 0.0d, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke((int) (byte) 1, stroke4);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        try {
            stackedBarRenderer3D2.setSeriesStroke((int) (byte) -1, stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        boolean boolean8 = stackedBarRenderer3D2.getBaseCreateEntities();
        java.lang.Object obj9 = stackedBarRenderer3D2.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 1.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        waferMapPlot0.datasetChanged(datasetChangeEvent1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("#0a0a0a", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        try {
            java.lang.String str9 = standardCategoryURLGenerator3.generateURL(categoryDataset6, (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("#0a0a0a", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 1L, 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        levelRenderer0.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition2, true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.lang.Object obj6 = labelBlock1.draw(graphics2D3, rectangle2D4, (java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getID();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        labelBlock1.setMargin(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets9.createInsetRectangle(rectangle2D11, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke8 = null;
        stackedBarRenderer3D6.setSeriesStroke((int) (byte) 1, stroke8);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D6.setBaseItemLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font3, (java.awt.Paint) chartColor13, 10.0f, textMeasurer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        boolean boolean1 = waferMapPlot0.isOutlineVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        waferMapPlot0.addChangeListener(plotChangeListener2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean5 = chartColor3.equals((java.lang.Object) intervalBarRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getAutoRangeMinimumSize();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        try {
            intervalBarRenderer4.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryDataset13, 0, 9999, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            org.jfree.data.Range range2 = intervalBarRenderer0.findRangeBounds(categoryDataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        boolean boolean8 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = stackedBarRenderer3D2.getDrawingSupplier();
        boolean boolean10 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        try {
            org.jfree.data.Range range10 = lineRenderer3D0.findRangeBounds(categoryDataset9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        java.awt.Font font4 = dateAxis2.getLabelFont();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("#0a0a0a", font4, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        dateAxis0.centerRange((double) (short) -1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.axis.AxisState axisState16 = dateAxis0.draw(graphics2D10, (double) 0.0f, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("#0a0a0a", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot16);
        java.util.Date date18 = dateAxis14.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        try {
            lineRenderer3D0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D11, categoryPlot12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryDataset19, 10, 13, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = null;
        try {
            xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (double) 10L, 1.0f, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("#0a0a0a", "hi!");
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 100L, (java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot17.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        boolean boolean1 = waferMapPlot0.isOutlineVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        waferMapPlot0.notifyListeners(plotChangeEvent2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        try {
            org.jfree.data.Range range7 = stackedBarRenderer3D2.findRangeBounds(categoryDataset6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 13, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = waferMapPlot2.getOutlinePaint();
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer1 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer1.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator4, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        java.awt.Font font9 = dateAxis7.getLabelFont();
        levelRenderer1.setBaseItemLabelFont(font9, false);
        org.jfree.chart.plot.Plot plot12 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("#0a0a0a", font9, plot12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart6.createBufferedImage(2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (2) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        try {
            xYPlot17.zoomDomainAxes((double) 86400000L, (double) 2, plotRenderingInfo20, point2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.6399999E7) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.awt.RenderingHints renderingHints12 = null;
        try {
            jFreeChart6.setRenderingHints(renderingHints12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot17.handleClick((int) (byte) 1, 0, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            jFreeChart6.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        int int28 = xYPlot17.getSeriesCount();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer29 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer29.setSeriesPaint((int) '4', (java.awt.Paint) chartColor34, true);
        java.awt.Color color37 = java.awt.Color.orange;
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor34, (java.awt.Paint) color37);
        xYPlot17.setRangeZeroBaselinePaint((java.awt.Paint) chartColor34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        boolean boolean8 = stackedBarRenderer3D2.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        try {
            stackedBarRenderer3D2.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D11, categoryPlot12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryDataset15, 100, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 1, stroke5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor10, stroke12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        try {
            valueMarker13.setLabelOffsetType(lengthAdjustmentType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D3.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicAnchor();
        java.awt.Font font16 = legendTitle14.getItemFont();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("WMAP_Plot", font16);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator3, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getAutoRangeMinimumSize();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        try {
            levelRenderer0.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryDataset13, 9999, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        java.lang.String str5 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#0a0a0a" + "'", str5.equals("#0a0a0a"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 4, (org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets6.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        java.awt.Stroke stroke9 = null;
        try {
            dateAxis0.setAxisLineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D2.setSeriesPaint(10, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = stackedBarRenderer3D2.initialise(graphics2D9, rectangle2D10, categoryPlot11, (int) (short) 0, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        waferMapPlot2.setNoDataMessage("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.resizeRange((double) (-1));
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setLabelURL("");
        java.awt.Shape shape13 = dateAxis5.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        waferMapPlot17.addChangeListener(plotChangeListener19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart21.setBorderVisible(true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart21.setBorderPaint((java.awt.Paint) color24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Stroke stroke28 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke34 = null;
        stackedBarRenderer3D32.setSeriesStroke(0, stroke34);
        stackedBarRenderer3D32.setBaseItemLabelsVisible(false);
        java.awt.Shape shape40 = stackedBarRenderer3D32.getItemShape((int) (short) 10, (-1));
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        int int42 = ringPlot41.getPieIndex();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot41.setBaseSectionOutlineStroke(stroke43);
        java.awt.Color color45 = java.awt.Color.DARK_GRAY;
        try {
            org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem(attributedString0, "#0a0a0a", "hi!", "", false, shape13, true, (java.awt.Paint) color24, false, (java.awt.Paint) color27, stroke28, true, shape40, stroke43, (java.awt.Paint) color45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem7 = legendItemCollection5.get((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke((int) (byte) 1, stroke4);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) chartColor9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot19);
        java.util.Date date21 = dateAxis17.getMaximumDate();
        boolean boolean22 = dateAxis17.isAutoRange();
        dateAxis17.setPositiveArrowVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        try {
            stackedBarRenderer3D2.drawItem(graphics2D11, categoryItemRendererState12, rectangle2D13, categoryPlot14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryDataset25, 7, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint1 = waferMapPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.util.List list9 = null;
        try {
            jFreeChart6.setSubtitles(list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle13.getPosition();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.lang.Object obj18 = legendTitle13.draw(graphics2D15, rectangle2D16, (java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart6.getSubtitle(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str27 = layer26.toString();
        java.util.Collection collection28 = xYPlot17.getRangeMarkers(layer26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray30 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer29 };
        xYPlot17.setRenderers(xYItemRendererArray30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.FOREGROUND" + "'", str27.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(xYItemRendererArray30);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createOutsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, (int) 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        int int11 = ringPlot10.getPieIndex();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot10.setBaseSectionOutlineStroke(stroke12);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        try {
            org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem(attributedString0, "", "LegendItemEntity: seriesKey=null, dataset=null", "hi!", shape9, stroke12, (java.awt.Paint) chartColor19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        java.awt.geom.Point2D point2D26 = null;
        try {
            xYPlot17.setQuadrantOrigin(point2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        boolean boolean1 = waferMapPlot0.isOutlineVisible();
        java.lang.Object obj2 = waferMapPlot0.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects2D0.getColumnIndex(comparable1);
        try {
            keyedObjects2D0.removeRow(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        java.awt.Stroke stroke6 = null;
        try {
            stackedBarRenderer3D2.setBaseStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.CENTER", graphics2D1, 0.0f, (float) 9999, textAnchor5, (double) 0, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        java.awt.Font font22 = xYPlot17.getNoDataMessageFont();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (byte) 1, (float) (byte) -1, 0.0f);
        xYPlot17.setDomainZeroBaselinePaint((java.awt.Paint) color26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            xYPlot17.drawOutline(graphics2D28, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot17.getIndexOf(xYItemRenderer26);
        boolean boolean28 = xYPlot17.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        int int20 = xYPlot17.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = lineRenderer3D0.getToolTipGenerator((int) '#', (int) '#');
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = lineRenderer3D0.initialise(graphics2D6, rectangle2D7, categoryPlot8, 1, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        java.lang.String str18 = rectangleEdge16.toString();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleEdge.LEFT" + "'", str18.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        try {
            org.jfree.chart.axis.DateTick dateTick9 = new org.jfree.chart.axis.DateTick(date4, "RectangleEdge.LEFT", textAnchor6, textAnchor7, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        boolean boolean10 = stackedBarRenderer3D2.getBaseSeriesVisible();
        java.lang.Boolean boolean12 = stackedBarRenderer3D2.getSeriesItemLabelsVisible((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.removeLegend();
        org.jfree.chart.event.ChartChangeListener chartChangeListener14 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray25 = legendTitle13.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = null;
        try {
            legendTitle13.setLegendItemGraphicPadding(rectangleInsets26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray25);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = waferMapPlot4.getOutlinePaint();
        stackedBarRenderer3D1.setBaseFillPaint(paint8, false);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesFillPaint((int) (byte) 0, paint12, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        java.awt.Color color8 = java.awt.Color.orange;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor5, (java.awt.Paint) color8);
        int int10 = chartColor5.getTransparency();
        float[] floatArray12 = new float[] { 1 };
        try {
            float[] floatArray13 = chartColor5.getComponents(floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = waferMapPlot4.getOutlinePaint();
        stackedBarRenderer3D1.setBaseFillPaint(paint8, false);
        java.awt.Stroke stroke12 = null;
        stackedBarRenderer3D1.setSeriesStroke(7, stroke12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        dateAxis6.resizeRange((double) (-1));
        dateAxis6.setTickLabelsVisible(false);
        boolean boolean12 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D19.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape22 = stackedBarRenderer3D19.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        waferMapPlot25.addChangeListener(plotChangeListener27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot25);
        jFreeChart29.setBorderVisible(true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart29.setBorderPaint((java.awt.Paint) color32);
        jFreeChart29.removeLegend();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart29.setBorderStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape22, stroke35, (java.awt.Paint) color37);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis6, shape22, "", "");
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) dateAxis6, rectangle2D42, 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.configureDomainAxes();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            xYPlot17.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D4.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape7 = stackedBarRenderer3D4.getBaseShape();
        try {
            java.awt.GradientPaint gradientPaint8 = standardGradientPaintTransformer0.transform(gradientPaint1, shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = null;
        dateAxis9.setStandardTickUnits(tickUnitSource13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis9.getLabelInsets();
        java.awt.Stroke stroke16 = dateAxis9.getAxisLineStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke22 = null;
        stackedBarRenderer3D20.setSeriesStroke((int) (byte) 1, stroke22);
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D20.setBaseItemLabelPaint((java.awt.Paint) chartColor27);
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor27, stroke29);
        dateAxis9.setAxisLineStroke(stroke29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryDataset32, (int) (byte) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 100, (double) (byte) -1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setNoDataMessage("#0a0a0a");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = null;
        try {
            xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getUseOutlinePaint();
        lineRenderer3D0.setDrawOutlines(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        ringPlot0.setCircular(false, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            dateAxis0.setTickLabelInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.lang.String str4 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, false);
        stackedBarRenderer3D2.setBase((double) 4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = stackedBarRenderer3D2.getSeriesToolTipGenerator(0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.plot.Plot plot7 = jFreeChart6.getPlot();
        plot7.setBackgroundImageAlignment((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            ringPlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedBarRenderer3D2.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke21 = null;
        stackedBarRenderer3D19.setSeriesStroke((int) (byte) 1, stroke21);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D19.setBaseItemLabelPaint((java.awt.Paint) chartColor26);
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor26, stroke28);
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) chartColor26);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke35 = null;
        stackedBarRenderer3D33.setSeriesStroke((int) (byte) 1, stroke35);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D33.setBaseItemLabelPaint((java.awt.Paint) chartColor40);
        java.awt.color.ColorSpace colorSpace42 = chartColor40.getColorSpace();
        float[] floatArray45 = new float[] { (byte) 100, 86400000L };
        try {
            float[] floatArray46 = chartColor26.getComponents(colorSpace42, floatArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(colorSpace42);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType6 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean7 = categoryLabelPositions5.equals((java.lang.Object) gradientPaintTransformType6);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions5, categoryLabelPosition8);
        boolean boolean10 = library4.equals((java.lang.Object) categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        boolean boolean9 = stackedBarRenderer3D2.isItemLabelVisible(2, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot17.getDomainAxis();
        xYPlot17.clearDomainMarkers((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(valueAxis20);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape11 = stackedBarRenderer3D8.getBaseShape();
        dateAxis4.setDownArrow(shape11);
        java.awt.Paint paint13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = null;
        dateAxis14.setStandardTickUnits(tickUnitSource18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis14.getLabelInsets();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        dateAxis14.setAxisLineStroke(stroke21);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer23 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor28 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer23.setSeriesPaint((int) '4', (java.awt.Paint) chartColor28, true);
        java.awt.Color color31 = java.awt.Color.orange;
        boolean boolean32 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor28, (java.awt.Paint) color31);
        int int33 = chartColor28.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "ChartChangeEventType.NEW_DATASET", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", shape11, paint13, stroke21, (java.awt.Paint) chartColor28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Paint paint2 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        int int22 = xYPlot17.getSeriesCount();
        boolean boolean23 = xYPlot17.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        boolean boolean11 = stackedBarRenderer3D2.isSeriesVisibleInLegend(100);
        java.awt.Paint paint13 = stackedBarRenderer3D2.lookupSeriesFillPaint(7);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds(categoryDataset14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        double double3 = ringPlot0.getInteriorGap();
        ringPlot0.setShadowYOffset(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle13.getSources();
        java.lang.String str19 = legendTitle13.getID();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        double double6 = stackedBarRenderer3D2.getYOffset();
        boolean boolean7 = stackedBarRenderer3D2.getRenderAsPercentages();
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) 1L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot17.getDomainAxisLocation();
        xYPlot17.setWeight(100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.setBorderVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart6.getLegend();
        jFreeChart6.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        double double15 = range14.getLowerBound();
        boolean boolean18 = range14.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(3.0d, range14);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean9 = chartColor7.equals((java.lang.Object) intervalBarRenderer8);
        stackedBarRenderer3D2.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor7, false);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) (short) 1, false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot17);
        java.awt.Font font31 = xYPlot17.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double1 = dateRange0.getUpperBound();
        double double2 = dateRange0.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            categoryPlot0.handleClick(7, (int) '4', plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        int int5 = stackedBarRenderer3D2.getRowCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean5 = chartColor3.equals((java.lang.Object) intervalBarRenderer4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = intervalBarRenderer4.getSeriesToolTipGenerator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        boolean boolean4 = dateAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 3);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator3, false);
        levelRenderer0.setItemLabelAnchorOffset(0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        waferMapPlot16.addChangeListener(plotChangeListener18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot16);
        jFreeChart20.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart20.removeProgressListener(chartProgressListener23);
        org.jfree.chart.plot.Plot plot25 = jFreeChart20.getPlot();
        legendTitle13.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plot25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        double double5 = categoryAxis3D1.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        dateAxis9.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setDefaultAutoRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = dateRange13.equals((java.lang.Object) rectangleEdge15);
        try {
            double double17 = categoryAxis3D1.getCategoryMiddle((int) (byte) 0, (int) (short) 10, rectangle2D8, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) (-1), (double) 4, 0.5d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.NEW_DATASET", "#0a0a0a");
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.clone(shape16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer28 = null;
        try {
            legendItem25.setFillPaintTransformer(gradientPaintTransformer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        double double6 = stackedBarRenderer3D2.getYOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        try {
            stackedBarRenderer3D2.setBaseNegativeItemLabelPosition(itemLabelPosition7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            textFragment1.draw(graphics2D3, (float) (byte) 100, (float) (-1), textAnchor6, (float) 7, (float) 100, (double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 1, (float) (byte) -1, 0.0f);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        try {
            jFreeChart6.plotChanged(plotChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        double double6 = stackedBarRenderer3D2.getYOffset();
        boolean boolean7 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint5 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot4.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock8, dataset9);
        categoryPlot4.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D14.setUpperMargin(1.0E-5d);
        double double17 = categoryAxis3D14.getLabelAngle();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        dateAxis19.resizeRange((double) (-1));
        dateAxis19.setTickLabelsVisible(false);
        dateAxis19.setLabelURL("");
        dateAxis19.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot31 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot31);
        java.util.Date date33 = dateAxis29.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        try {
            boxAndWhiskerRenderer0.drawHorizontalItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryDataset36, 2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(500, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        waferMapPlot8.addChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = waferMapPlot8.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        java.awt.Font font16 = dateAxis14.getLabelFont();
        org.jfree.chart.ChartColor chartColor20 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str21 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor20);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("", font16, (java.awt.Paint) chartColor20);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color3, (java.awt.Paint) color5, paint12, (java.awt.Paint) chartColor20);
        statisticalLineAndShapeRenderer2.setErrorIndicatorPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#0a0a0a" + "'", str21.equals("#0a0a0a"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean7 = dateRange4.equals((java.lang.Object) rectangleEdge6);
        java.lang.String str8 = rectangleEdge6.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart6.getTitle();
        org.jfree.data.gantt.TaskSeries taskSeries11 = new org.jfree.data.gantt.TaskSeries("");
        java.util.List list12 = taskSeries11.getTasks();
        jFreeChart6.setSubtitles(list12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(textTitle9);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleEdge.LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj5 = keyedObjects2D0.getObject((java.lang.Comparable) 1.0E-5d, (java.lang.Comparable) numberTickUnit4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock2);
        labelBlock2.setMargin((double) 10, (double) 3, (double) 0, (double) (-1));
        boolean boolean9 = sortOrder0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("VerticalAlignment.CENTER", graphics2D1, 0.0f, (float) '4', textAnchor4, (double) 5, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) -1);
        java.lang.String str5 = textBlockAnchor1.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        try {
            xYPlot17.setRenderer((int) (byte) -1, xYItemRenderer22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        java.awt.Paint paint26 = legendItem25.getFillPaint();
        java.lang.Comparable comparable27 = legendItem25.getSeriesKey();
        legendItem25.setSeriesKey((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(comparable27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "ChartChangeEventType.NEW_DATASET", (double) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineRenderer3D0.setSeriesURLGenerator(4, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12, false);
        int int15 = lineRenderer3D0.getPassCount();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke((int) (byte) 1, stroke19);
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D17.setBaseItemLabelPaint((java.awt.Paint) chartColor24);
        stackedBarRenderer3D2.setSeriesPaint((int) (short) 0, (java.awt.Paint) chartColor24, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke30 = null;
        stackedBarRenderer3D28.setSeriesStroke((int) (byte) 1, stroke30);
        org.jfree.chart.ChartColor chartColor35 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D28.setBaseItemLabelPaint((java.awt.Paint) chartColor35);
        java.awt.color.ColorSpace colorSpace37 = chartColor35.getColorSpace();
        float[] floatArray39 = new float[] { 10.0f };
        try {
            float[] floatArray40 = color24.getColorComponents(colorSpace37, floatArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(500, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot6);
        java.lang.String str8 = waferMapPlot6.getPlotType();
        boolean boolean9 = dateTickUnit3.equals((java.lang.Object) str8);
        java.util.Date date10 = null;
        try {
            java.util.Date date11 = dateTickUnit3.addToDate(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("hi!", timePeriod4);
        task2.addSubtask(task5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer(5, categoryItemRenderer4, true);
        categoryPlot0.setDomainGridlinesVisible(false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        stackedBarRenderer3D3.setWallPaint((java.awt.Paint) chartColor19);
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) chartColor19);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = chartColor19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.junit.Assert.assertNotNull(paintContext29);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = legendTitle13.getHorizontalAlignment();
        double double26 = legendTitle13.getHeight();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Paint paint15 = null;
        stackedBarRenderer3D2.setSeriesPaint((int) (short) 0, paint15, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor18, textAnchor19);
        stackedBarRenderer3D2.setBaseNegativeItemLabelPosition(itemLabelPosition20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = stackedBarRenderer3D2.initialise(graphics2D22, rectangle2D23, categoryPlot24, 0, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7);
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextBlockAnchor.CENTER", graphics2D1, (float) (byte) 0, (float) (byte) 0, textAnchor4, (double) 10.0f, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint2 = lineRenderer3D1.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        lineRenderer3D1.setSeriesPositiveItemLabelPosition(10, itemLabelPosition6);
        intervalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D15.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape18 = stackedBarRenderer3D15.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis19.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        waferMapPlot21.addChangeListener(plotChangeListener23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart25.setBorderVisible(true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart25.setBorderPaint((java.awt.Paint) color28);
        jFreeChart25.removeLegend();
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart25.setBorderStroke(stroke31);
        java.awt.Color color33 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape18, stroke31, (java.awt.Paint) color33);
        intervalBarRenderer0.setBaseOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) 4, (float) ' ', 0.0d, (float) (byte) 0, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = labelBlock1.clone();
        java.awt.Paint paint3 = labelBlock1.getPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isRangeCrosshairVisible();
        xYPlot17.setBackgroundImageAlignment(2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 8.0d };
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        java.util.Date date6 = dateAxis2.getMaximumDate();
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { date6, "SortOrder.ASCENDING" };
        double[] doubleArray14 = new double[] { 0.35d, '4', (byte) 100, (-2208960000000L), 0.5f };
        double[] doubleArray20 = new double[] { 0.35d, '4', (byte) 100, (-2208960000000L), 0.5f };
        double[] doubleArray26 = new double[] { 0.35d, '4', (byte) 100, (-2208960000000L), 0.5f };
        double[][] doubleArray27 = new double[][] { doubleArray14, doubleArray20, doubleArray26 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray8, doubleArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.plot.Plot plot7 = jFreeChart6.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart6.createBufferedImage((int) (byte) 0, (int) '#', (-1), chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            piePlot3D0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        int int8 = levelRenderer0.getColumnCount();
        double double9 = levelRenderer0.getItemMargin();
        levelRenderer0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isInverted();
        dateAxis15.resizeRange((double) (-1));
        dateAxis15.setTickLabelsVisible(false);
        dateAxis15.setLabelURL("");
        dateAxis15.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot27 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot27);
        java.util.Date date29 = dateAxis25.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot31.getDomainAxisLocation((int) (byte) 10);
        xYPlot31.setDomainCrosshairVisible(false);
        boolean boolean36 = levelRenderer0.hasListener((java.util.EventListener) xYPlot31);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot31.setDataset(xYDataset37);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        statisticalBarRenderer0.setSeriesStroke(3, stroke2, false);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        boolean boolean4 = dateAxis0.isTickMarksVisible();
        double double5 = dateAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        dateAxis11.resizeRange((double) (-1));
        dateAxis11.setTickLabelsVisible(false);
        dateAxis11.setLabelURL("");
        dateAxis11.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot23);
        java.util.Date date25 = dateAxis21.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot27.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomDomainAxes((double) 'a', plotRenderingInfo31, point2D32);
        xYPlot27.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot27.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection40 = xYPlot27.getRangeMarkers(10, layer39);
        try {
            categoryPlot0.addRangeMarker(marker9, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = null;
        try {
            jFreeChart6.titleChanged(titleChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.data.Range range4 = stackedBarRenderer3D2.findRangeBounds(categoryDataset3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getPieIndex();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot3.setBaseSectionOutlineStroke(stroke5);
        ringPlot0.setSeparatorStroke(stroke5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            ringPlot0.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.05d, 0.0d, (double) (byte) 100, (double) 500);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        java.awt.Font font16 = stackedBarRenderer3D3.getBaseItemLabelFont();
        ringPlot0.setLabelFont(font16);
        ringPlot0.setLabelLinkMargin((double) (-1L));
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("UnitType.ABSOLUTE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        legendTitle13.setID("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
//        java.lang.Object obj2 = segmentedTimeline0.clone();
//        long long3 = segmentedTimeline0.getStartTime();
//        long long4 = segmentedTimeline0.getStartTime();
//        segmentedTimeline0.setStartTime((long) (short) 1);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208960000000L) + "'", long3 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208960000000L) + "'", long4 == (-2208960000000L));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        int int28 = xYPlot17.getSeriesCount();
        java.awt.geom.Point2D point2D29 = null;
        try {
            xYPlot17.setQuadrantOrigin(point2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions3, categoryLabelPosition4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke11 = null;
        stackedBarRenderer3D9.setSeriesStroke(0, stroke11);
        stackedBarRenderer3D9.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean16 = categoryLabelPosition4.equals((java.lang.Object) stackedBarRenderer3D9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions2, categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getPieIndex();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot3.setBaseSectionOutlineStroke(stroke5);
        ringPlot0.setSeparatorStroke(stroke5);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke5, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D2.getItemVisible(1, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        stackedBarRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator12, true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = dateAxis0.draw(graphics2D18, (double) 172800000L, rectangle2D20, rectangle2D21, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        double double9 = stackedBarRenderer3D2.getLowerClip();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            xYPlot17.handleClick((int) 'a', (int) ' ', plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        org.jfree.chart.plot.Plot plot11 = jFreeChart6.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart6.handleClick(9999, 0, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.BorderArrangement borderArrangement7 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean8 = statisticalBarRenderer6.equals((java.lang.Object) borderArrangement7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean19 = stackedBarRenderer3D11.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedBarRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle22.getLegendItemGraphicAnchor();
        java.awt.Font font24 = legendTitle22.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle22.setPosition(rectangleEdge25);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        legendTitle22.setBackgroundPaint((java.awt.Paint) chartColor30);
        statisticalBarRenderer6.setErrorIndicatorPaint((java.awt.Paint) chartColor30);
        ringPlot1.setLabelBackgroundPaint((java.awt.Paint) chartColor30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart6.getSubtitle(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setBackgroundAlpha((float) (short) 100);
        ringPlot0.setLabelLinkMargin((double) (short) 100);
        boolean boolean9 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects2D0.getColumnIndex(comparable1);
        int int3 = keyedObjects2D0.getColumnCount();
        try {
            java.lang.Object obj6 = keyedObjects2D0.getObject((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        java.lang.String str8 = datasetChangeEvent6.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock1);
        labelBlock1.setMargin((double) 10, (double) 3, (double) 0, (double) (-1));
        labelBlock1.setPadding((double) (short) 10, (double) 100.0f, (double) (short) 1, (double) (-1));
        labelBlock1.setToolTipText("WMAP_Plot");
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        legendItem25.setDatasetIndex(10);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock1);
        labelBlock1.setMargin((double) 10, (double) 3, (double) 0, (double) (-1));
        java.lang.Object obj8 = labelBlock1.clone();
        java.lang.String str9 = labelBlock1.getURLText();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot3);
        java.util.Date date5 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot8);
        java.util.Date date10 = dateAxis6.getMaximumDate();
        boolean boolean11 = dateAxis6.isAutoRange();
        dateAxis6.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        dateAxis14.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        java.util.Date date20 = dateRange18.getLowerDate();
        dateAxis6.setMaximumDate(date20);
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions24, categoryLabelPosition25);
        org.jfree.chart.text.TextAnchor textAnchor27 = categoryLabelPosition25.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick29 = new org.jfree.chart.axis.DateTick(date20, "VerticalAlignment.CENTER", textAnchor23, textAnchor27, (double) 2.0f);
        try {
            org.jfree.data.gantt.Task task30 = new org.jfree.data.gantt.Task("Layer.FOREGROUND", date5, date20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        org.jfree.data.gantt.Task task3 = null;
        try {
            task2.addSubtask(task3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtask' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        dateAxis8.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis8.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        java.util.Date date14 = dateRange12.getLowerDate();
        dateAxis0.setMaximumDate(date14);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions18, categoryLabelPosition19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick23 = new org.jfree.chart.axis.DateTick(date14, "VerticalAlignment.CENTER", textAnchor17, textAnchor21, (double) 2.0f);
        java.lang.String str24 = dateTick23.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "VerticalAlignment.CENTER" + "'", str24.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        java.util.Collection collection26 = xYPlot17.getRangeMarkers(layer24);
        xYPlot17.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke7);
        dateAxis0.setLabelToolTip("SortOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getDomainAxisLocation();
        try {
            xYPlot17.setRangeAxisLocation((int) (byte) -1, axisLocation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint5 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot4.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock8, dataset9);
        categoryPlot4.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot4.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D16.setUpperMargin(1.0E-5d);
        double double19 = categoryAxis3D16.getLabelAngle();
        java.lang.Object obj20 = categoryAxis3D16.clone();
        categoryAxis3D16.setLowerMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        java.awt.Font font25 = dateAxis23.getLabelFont();
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray41 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray48 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray49 = new double[][] { doubleArray34, doubleArray41, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray49);
        boolean boolean51 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset50);
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryDataset50, 4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, 0.5f, (float) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        lineRenderer3D0.setUseOutlinePaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = lineRenderer3D0.getBaseToolTipGenerator();
        lineRenderer3D0.setSeriesShapesFilled((int) (short) 100, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer(5, categoryItemRenderer4, true);
        try {
            categoryPlot0.zoom(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Double double3 = task2.getPercentComplete();
        try {
            org.jfree.data.gantt.Task task5 = task2.getSubtask(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(double3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot5.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock9, dataset10);
        categoryPlot5.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot5.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D15.setUpperMargin(1.0E-5d);
        double double18 = categoryAxis3D15.getLabelAngle();
        double double19 = categoryAxis3D15.getUpperMargin();
        int int20 = categoryAxis3D15.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isInverted();
        java.awt.Font font23 = dateAxis21.getLabelFont();
        dateAxis21.setAutoTickUnitSelection(false);
        dateAxis21.setAutoRangeMinimumSize((double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isInverted();
        java.awt.Font font30 = dateAxis28.getLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = dateAxis28.getStandardTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource31);
        double[] doubleArray41 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray48 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray55 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray56 = new double[][] { doubleArray41, doubleArray48, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray56);
        boolean boolean58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset57);
        boolean boolean59 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset57);
        try {
            ganttRenderer0.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryDataset57, (int) (byte) -1, (int) (short) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-5d + "'", double19 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(tickUnitSource31);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis0.setTimeline(timeline3);
        org.jfree.data.Range range5 = dateAxis0.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        int int4 = lineRenderer3D0.getColumnCount();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot8.getDataset((int) 'a');
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot8.drawBackgroundImage(graphics2D12, rectangle2D13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D16.setUpperMargin(1.0E-5d);
        double double19 = categoryAxis3D16.getLabelAngle();
        double double20 = categoryAxis3D16.getUpperMargin();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isInverted();
        dateAxis22.resizeRange((double) (-1));
        dateAxis22.setTickLabelsVisible(false);
        dateAxis22.setLabelURL("");
        dateAxis22.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot34 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis32.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot34);
        java.util.Date date36 = dateAxis32.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer37);
        double[] doubleArray47 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray54 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray61 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray62 = new double[][] { doubleArray47, doubleArray54, doubleArray61 };
        org.jfree.data.category.CategoryDataset categoryDataset63 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray62);
        boolean boolean64 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset63);
        boolean boolean65 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset63);
        try {
            lineRenderer3D0.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryDataset63, 0, (int) (byte) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-5d + "'", double20 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        boolean boolean4 = dateAxis0.isTickMarksVisible();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = polarPlot6.getDataset();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean19 = stackedBarRenderer3D11.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedBarRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle22.getLegendItemGraphicAnchor();
        java.awt.Font font24 = legendTitle22.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle22.setPosition(rectangleEdge25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace28 = dateAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) polarPlot6, rectangle2D8, rectangleEdge25, axisSpace27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        java.lang.String str21 = legendItemEntity18.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str21.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("#0a0a0a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot17.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot17.setFixedRangeAxisSpace(axisSpace27);
        xYPlot17.mapDatasetToDomainAxis((int) (byte) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot7);
        java.lang.String str9 = waferMapPlot7.getPlotType();
        boolean boolean10 = categoryLabelWidthType2.equals((java.lang.Object) str9);
        java.lang.String str11 = categoryLabelWidthType2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "WMAP_Plot" + "'", str9.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str11.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) numberTickUnit22);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) "12/31/69");
        legendItemEntity18.setSeriesKey((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 1, stroke5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor10, stroke12);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.removeChangeListener(markerChangeListener14);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker13.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        java.util.Date date11 = dateAxis7.getMaximumDate();
        dateAxis0.setMaximumDate(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        double double5 = categoryAxis3D1.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        dateAxis9.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setDefaultAutoRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = dateRange13.equals((java.lang.Object) rectangleEdge15);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge15);
        try {
            double double18 = categoryAxis3D1.getCategoryMiddle((int) ' ', 4, rectangle2D8, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        dateAxis3.resizeRange((double) (-1));
        dateAxis3.setTickLabelsVisible(false);
        dateAxis3.setLabelURL("");
        dateAxis3.centerRange((double) (short) -1);
        dateAxis3.setLowerMargin((double) 1L);
        dateAxis3.zoomRange((-1.0d), (double) 9999);
        boolean boolean18 = stackedBarRenderer3D2.equals((java.lang.Object) 9999);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        dateAxis0.configure();
        java.awt.Shape shape10 = null;
        try {
            dateAxis0.setRightArrow(shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        java.awt.Font font6 = dateAxis4.getLabelFont();
        dateAxis4.setAutoTickUnitSelection(false);
        boolean boolean9 = dateAxis4.isVisible();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke14 = null;
        stackedBarRenderer3D12.setSeriesStroke(0, stroke14);
        stackedBarRenderer3D12.setBaseItemLabelsVisible(false);
        java.awt.Shape shape20 = stackedBarRenderer3D12.getItemShape((int) (short) 10, (-1));
        dateAxis4.setUpArrow(shape20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis22.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        waferMapPlot24.addChangeListener(plotChangeListener26);
        java.awt.Paint paint28 = waferMapPlot24.getOutlinePaint();
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color32 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot35 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        waferMapPlot35.addChangeListener(plotChangeListener37);
        java.awt.Paint paint39 = waferMapPlot35.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isInverted();
        java.awt.Font font43 = dateAxis41.getLabelFont();
        org.jfree.chart.ChartColor chartColor47 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str48 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor47);
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("", font43, (java.awt.Paint) chartColor47);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer50 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color30, (java.awt.Paint) color32, paint39, (java.awt.Paint) chartColor47);
        try {
            org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", shape20, paint28, stroke29, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "#0a0a0a" + "'", str48.equals("#0a0a0a"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("TextBlockAnchor.CENTER");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        boolean boolean6 = stackedBarRenderer3D2.isDrawBarOutline();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            stackedBarRenderer3D2.setSeriesFillPaint((-1), paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        java.awt.Shape shape9 = dateAxis1.getRightArrow();
        intervalBarRenderer0.setBaseShape(shape9);
        boolean boolean11 = intervalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        java.awt.Paint paint26 = xYPlot17.getDomainGridlinePaint();
        xYPlot17.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = null;
        try {
            xYPlot17.setDomainAxes(valueAxisArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("SortOrder.ASCENDING");
        projectInfo0.setLicenceText("");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke(0, stroke7);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        stackedBarRenderer3D5.notifyListeners(rendererChangeEvent11);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer16 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer16.setSeriesPaint((int) '4', (java.awt.Paint) chartColor21, true);
        stackedBarRenderer3D5.setWallPaint((java.awt.Paint) chartColor21);
        statisticalBarRenderer2.setErrorIndicatorPaint((java.awt.Paint) chartColor21);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) chartColor21);
        java.awt.Paint paint27 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint29 = ringPlot0.getSectionPaint((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) dateAxis7);
        java.awt.Paint paint12 = dateAxis7.getTickLabelPaint();
        boolean boolean13 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis7.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTickUnit14);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle13.getLegendItemGraphicEdge();
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Paint paint2 = ringPlot0.getBaseSectionOutlinePaint();
        double double3 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.lang.String str4 = waferMapPlot2.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        waferMapPlot2.setRenderer(waferMapRenderer7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        java.lang.String str21 = legendItemEntity18.getToolTipText();
        java.lang.String str22 = legendItemEntity18.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str22.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        int int22 = xYPlot17.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot17.getRangeAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot17.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        try {
            xYPlot17.setBackgroundImageAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        java.awt.Font font22 = xYPlot17.getNoDataMessageFont();
        int int23 = xYPlot17.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke31 = null;
        stackedBarRenderer3D29.setSeriesStroke(0, stroke31);
        stackedBarRenderer3D29.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        stackedBarRenderer3D29.notifyListeners(rendererChangeEvent35);
        stackedBarRenderer3D29.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.data.Range range40 = stackedBarRenderer3D29.findRangeBounds(categoryDataset39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range40, 0.0d);
        org.jfree.data.Range range43 = rectangleConstraint42.getHeightRange();
        org.jfree.chart.util.Size2D size2D44 = legendTitle13.arrange(graphics2D26, rectangleConstraint42);
        double double45 = rectangleConstraint42.getHeight();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineRenderer3D0.setSeriesURLGenerator(4, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12, false);
        lineRenderer3D0.setBaseShapesFilled(false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(500);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Paint paint2 = polarPlot0.getAngleLabelPaint();
        java.awt.Paint paint3 = null;
        polarPlot0.setAngleGridlinePaint(paint3);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setBackgroundAlpha((float) (short) 100);
        java.lang.Comparable comparable7 = null;
        try {
            java.awt.Paint paint8 = ringPlot0.getSectionPaint(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset((double) (byte) 100);
        java.lang.String str9 = rectangleInsets6.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = lineRenderer3D0.getToolTipGenerator((int) '#', (int) '#');
        lineRenderer3D0.setUseFillPaint(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        int int8 = levelRenderer0.getColumnCount();
        double double9 = levelRenderer0.getItemMargin();
        levelRenderer0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = levelRenderer0.getBaseToolTipGenerator();
        levelRenderer0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        float float3 = dateAxis0.getTickMarkInsideLength();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        stackedBarRenderer3D8.notifyListeners(rendererChangeEvent14);
        stackedBarRenderer3D8.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.data.Range range19 = stackedBarRenderer3D8.findRangeBounds(categoryDataset18);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = stackedBarRenderer3D8.getBaseToolTipGenerator();
        java.awt.Font font21 = stackedBarRenderer3D8.getBaseItemLabelFont();
        ringPlot5.setLabelFont(font21);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer23 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor28 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer23.setSeriesPaint((int) '4', (java.awt.Paint) chartColor28, true);
        java.awt.Color color31 = java.awt.Color.orange;
        boolean boolean32 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor28, (java.awt.Paint) color31);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("", font21, (java.awt.Paint) color31);
        dateAxis0.setTickLabelPaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer22 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer22.setSeriesPaint((int) '4', (java.awt.Paint) chartColor27, true);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) chartColor27);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot0.setDomainAxis(13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D34, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot0.getDomainAxisEdge();
        java.lang.String str38 = rectangleEdge37.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.BOTTOM" + "'", str38.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        boolean boolean2 = stackedAreaRenderer1.getRenderAsPercentages();
        boolean boolean3 = stackedAreaRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat6);
        dateAxis0.setTickUnit(dateTickUnit7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.data.Range range22 = stackedBarRenderer3D11.findRangeBounds(categoryDataset21);
        double double23 = range22.getLowerBound();
        boolean boolean26 = range22.intersects((double) (short) 0, (double) (short) 0);
        double double27 = range22.getCentralValue();
        dateAxis0.setDefaultAutoRange(range22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.5d + "'", double27 == 0.5d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = levelRenderer0.getSeriesItemLabelGenerator((int) (byte) 10);
        java.awt.Paint paint5 = levelRenderer0.getItemPaint((int) (byte) -1, 6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke((int) (byte) 1, stroke4);
        stackedBarRenderer3D2.setBase((double) 7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 1, stroke5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor10, stroke12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean23 = chartColor21.equals((java.lang.Object) intervalBarRenderer22);
        stackedBarRenderer3D16.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor21, false);
        valueMarker13.setLabelPaint((java.awt.Paint) chartColor21);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot29 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis27.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot29);
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = null;
        dateAxis27.setStandardTickUnits(tickUnitSource31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis27.getLabelInsets();
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        dateAxis27.setAxisLineStroke(stroke34);
        valueMarker13.setStroke(stroke34);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D37 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D37.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        lineRenderer3D37.drawRangeMarker(graphics2D40, categoryPlot41, valueAxis42, marker43, rectangle2D44);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer46 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor51 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer46.setSeriesPaint((int) '4', (java.awt.Paint) chartColor51, true);
        int int54 = levelRenderer46.getColumnCount();
        double double55 = levelRenderer46.getItemMargin();
        levelRenderer46.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator60 = levelRenderer46.getBaseToolTipGenerator();
        java.awt.Stroke stroke61 = levelRenderer46.getBaseOutlineStroke();
        lineRenderer3D37.setBaseOutlineStroke(stroke61, true);
        valueMarker13.setOutlineStroke(stroke61);
        java.awt.Font font65 = null;
        try {
            valueMarker13.setLabelFont(font65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.2d + "'", double55 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator60);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str8 = chartChangeEventType7.toString();
        boolean boolean9 = jFreeChart6.equals((java.lang.Object) chartChangeEventType7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        try {
            jFreeChart6.plotChanged(plotChangeEvent10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str8.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.resizeRange((double) (-1));
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setLabelURL("");
        java.awt.Shape shape13 = dateAxis5.getRightArrow();
        intervalBarRenderer4.setBaseShape(shape13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        waferMapPlot19.addChangeListener(plotChangeListener21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart23.setBorderVisible(true);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        java.awt.Color color28 = java.awt.Color.getColor("UnitType.ABSOLUTE", color26);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", "", "UnitType.ABSOLUTE", "SortOrder.ASCENDING", shape13, stroke15, (java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        stackedBarRenderer3D2.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        dateAxis14.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke24 = null;
        stackedBarRenderer3D22.setSeriesStroke(0, stroke24);
        stackedBarRenderer3D22.setBaseItemLabelsVisible(false);
        java.awt.Shape shape30 = stackedBarRenderer3D22.getItemShape((int) (short) 10, (-1));
        dateAxis14.setDownArrow(shape30);
        stackedBarRenderer3D2.setBaseShape(shape30, false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Font font2 = layeredBarRenderer0.getSeriesItemLabelFont(7);
        org.junit.Assert.assertNull(font2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean7 = dateRange4.equals((java.lang.Object) rectangleEdge6);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, 0.35d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setNoDataMessage("#0a0a0a");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke35 = null;
        stackedBarRenderer3D33.setSeriesStroke((int) (byte) 1, stroke35);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D33.setBaseItemLabelPaint((java.awt.Paint) chartColor40);
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor40, stroke42);
        xYPlot17.setRangeZeroBaselineStroke(stroke42);
        java.awt.Paint paint45 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot17.setDomainTickBandPaint(paint45);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot17.getDomainAxisForDataset(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean30 = groupedStackedBarRenderer0.equals((java.lang.Object) segmentedTimeline29);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer31 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray40 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray47 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray54 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray55 = new double[][] { doubleArray40, doubleArray47, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray55);
        org.jfree.data.Range range57 = groupedStackedBarRenderer31.findRangeBounds(categoryDataset56);
        org.jfree.data.Range range58 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset56);
        boolean boolean59 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 8.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isDomainCrosshairVisible();
        boolean boolean21 = xYPlot17.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isInverted();
        dateAxis22.resizeRange((double) (-1));
        dateAxis22.setTickLabelsVisible(false);
        dateAxis22.setLabelURL("");
        java.awt.Shape shape30 = dateAxis22.getRightArrow();
        boolean boolean31 = xYPlot17.equals((java.lang.Object) dateAxis22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        org.jfree.chart.block.BlockFrame blockFrame26 = legendTitle13.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer27 = legendTitle13.getItemContainer();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(blockFrame26);
        org.junit.Assert.assertNotNull(blockContainer27);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot17.getAxisOffset();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.Point2D point2D29 = null;
        org.jfree.chart.plot.PlotState plotState30 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            xYPlot17.draw(graphics2D27, rectangle2D28, point2D29, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke(0, stroke7);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        stackedBarRenderer3D5.notifyListeners(rendererChangeEvent11);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer16 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer16.setSeriesPaint((int) '4', (java.awt.Paint) chartColor21, true);
        stackedBarRenderer3D5.setWallPaint((java.awt.Paint) chartColor21);
        statisticalBarRenderer2.setErrorIndicatorPaint((java.awt.Paint) chartColor21);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) chartColor21);
        try {
            double double27 = ringPlot0.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleEdge.BOTTOM", graphics2D1, (float) 1, (float) ' ', textAnchor5, (double) (short) 1, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        jFreeChart6.setPadding(rectangleInsets7);
        double double10 = rectangleInsets7.trimHeight((double) (short) 10);
        double double12 = rectangleInsets7.extendWidth((double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        java.util.Date date11 = dateAxis7.getMaximumDate();
        dateAxis0.setMaximumDate(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.chart.axis.TickUnits tickUnits14 = new org.jfree.chart.axis.TickUnits();
        int int15 = year13.compareTo((java.lang.Object) tickUnits14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isInverted();
        dateAxis16.resizeRange((double) (-1));
        dateAxis16.setTickLabelsVisible(false);
        dateAxis16.setLabelURL("");
        dateAxis16.centerRange((double) (short) -1);
        dateAxis16.setLowerMargin((double) 1L);
        int int28 = year13.compareTo((java.lang.Object) dateAxis16);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke33 = null;
        stackedBarRenderer3D31.setSeriesStroke(0, stroke33);
        stackedBarRenderer3D31.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        stackedBarRenderer3D31.notifyListeners(rendererChangeEvent37);
        stackedBarRenderer3D31.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.data.Range range42 = stackedBarRenderer3D31.findRangeBounds(categoryDataset41);
        dateAxis16.setRange(range42, false, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createInsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot17.getIndexOf(xYItemRenderer26);
        java.awt.Paint paint28 = xYPlot17.getRangeZeroBaselinePaint();
        xYPlot17.setRangeCrosshairValue((double) 0L, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            legendTitle13.draw(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library10 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean11 = textLine5.equals((java.lang.Object) "#0a0a0a");
        boolean boolean12 = ringPlot0.equals((java.lang.Object) "#0a0a0a");
        double double13 = ringPlot0.getLabelGap();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedBarRenderer3D2.getBaseToolTipGenerator();
        java.awt.Paint paint16 = stackedBarRenderer3D2.getSeriesFillPaint(6);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart6.getSubtitle(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D8.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        java.util.Iterator iterator13 = legendItemCollection11.iterator();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(iterator13);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.resizeRange((double) (-1));
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setLabelURL("");
        dateAxis5.centerRange((double) (short) -1);
        dateAxis5.setLowerMargin((double) 1L);
        dateAxis5.zoomRange((-1.0d), (double) 9999);
        double double20 = dateAxis5.getFixedDimension();
        org.jfree.data.Range range21 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        dateAxis5.setInverted(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock1);
        labelBlock1.setMargin((double) 10, (double) 3, (double) 0, (double) (-1));
        labelBlock1.setPadding((double) (short) 10, (double) 100.0f, (double) (short) 1, (double) (-1));
        java.awt.Font font13 = labelBlock1.getFont();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.lang.String str2 = textFragment1.getText();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        dateAxis3.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        java.awt.Shape shape19 = stackedBarRenderer3D11.getItemShape((int) (short) 10, (-1));
        dateAxis3.setDownArrow(shape19);
        boolean boolean21 = textFragment1.equals((java.lang.Object) dateAxis3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D3.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) 100, (java.lang.Object) true);
        java.lang.Object obj7 = null;
        boolean boolean8 = keyedObject6.equals(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = null;
        try {
            waterfallBarRenderer0.setNegativeBarPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Image image30 = null;
        xYPlot17.setBackgroundImage(image30);
        boolean boolean32 = xYPlot17.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        java.awt.Paint paint11 = stackedBarRenderer3D2.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer2.getSeriesVisible(0);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
//        java.util.List list2 = axisCollection1.getAxesAtTop();
//        segmentedTimeline0.setExceptionSegments(list2);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
//        boolean boolean7 = segment5.contains((long) 3);
//        long long8 = segment5.getSegmentEnd();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(segment5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setBackgroundAlpha((float) (short) 100);
        int int7 = ringPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("12/31/69");
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke33 = xYPlot17.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.util.List list12 = jFreeChart6.getSubtitles();
        java.lang.Object obj13 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.setAntiAlias(false);
        jFreeChart6.setTextAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        ringPlot1.setLabelGenerator(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        double double6 = stackedBarRenderer3D2.getYOffset();
        boolean boolean7 = stackedBarRenderer3D2.getRenderAsPercentages();
        double double8 = stackedBarRenderer3D2.getMaximumBarWidth();
        stackedBarRenderer3D2.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean6 = lineRenderer3D0.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        double[] doubleArray20 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray35 = new double[][] { doubleArray20, doubleArray27, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray35);
        java.lang.String str39 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset37, 0);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean41 = dateAxis40.isInverted();
        dateAxis40.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange44 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis40.setDefaultAutoRange((org.jfree.data.Range) dateRange44);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke50 = null;
        stackedBarRenderer3D48.setSeriesStroke(0, stroke50);
        stackedBarRenderer3D48.setBaseItemLabelsVisible(false);
        java.awt.Shape shape56 = stackedBarRenderer3D48.getItemShape((int) (short) 10, (-1));
        dateAxis40.setDownArrow(shape56);
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity(shape56, "ChartChangeEventType.NEW_DATASET", "#0a0a0a");
        boolean boolean61 = standardCategorySeriesLabelGenerator8.equals((java.lang.Object) "ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str39.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateRange44);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) '#', valueAxis9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = null;
        dateAxis11.setStandardTickUnits(tickUnitSource15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis11.getLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets17.createInsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        jFreeChart8.setBorderVisible(false);
        boolean boolean15 = unitType0.equals((java.lang.Object) jFreeChart8);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, 3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Paint paint2 = ringPlot0.getBaseSectionOutlinePaint();
        double double3 = ringPlot0.getShadowXOffset();
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        dateAxis2.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean9 = dateRange6.equals((java.lang.Object) rectangleEdge8);
        boolean boolean10 = labelBlock1.equals((java.lang.Object) dateRange6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset((int) '#');
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryDataset6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset25);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.addCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        polarPlot6.zoom((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        boolean boolean7 = segment5.contains((long) 3);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtTop();
        segmentedTimeline8.setExceptionSegments(list10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline8.getSegment((long) 10);
        boolean boolean14 = segment5.after(segment13);
        segment5.inc((long) 8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }
}

