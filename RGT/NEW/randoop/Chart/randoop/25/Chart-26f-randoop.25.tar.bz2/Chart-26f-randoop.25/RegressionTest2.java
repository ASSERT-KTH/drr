import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke8 = null;
        stackedBarRenderer3D6.setSeriesStroke(0, stroke8);
        stackedBarRenderer3D6.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        stackedBarRenderer3D6.notifyListeners(rendererChangeEvent12);
        stackedBarRenderer3D6.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.data.Range range17 = stackedBarRenderer3D6.findRangeBounds(categoryDataset16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = stackedBarRenderer3D6.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke25 = null;
        stackedBarRenderer3D23.setSeriesStroke((int) (byte) 1, stroke25);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D23.setBaseItemLabelPaint((java.awt.Paint) chartColor30);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor30, stroke32);
        stackedBarRenderer3D6.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) chartColor30);
        lineRenderer3D0.setBaseFillPaint((java.awt.Paint) chartColor30, false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D37 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint38 = lineRenderer3D37.getWallPaint();
        lineRenderer3D37.setUseFillPaint(true);
        boolean boolean43 = lineRenderer3D37.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D37.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator45);
        double[] doubleArray57 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray64 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray71 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray72 = new double[][] { doubleArray57, doubleArray64, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray72);
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray72);
        java.lang.String str76 = standardCategorySeriesLabelGenerator45.generateLabel(categoryDataset74, 0);
        lineRenderer3D0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator45);
        java.awt.Shape shape78 = lineRenderer3D0.getBaseShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(categoryDataset74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str76.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(shape78);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(false);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot3.setDomainGridlinePaint(paint4);
        ringPlot0.setLabelShadowPaint(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        boolean boolean15 = stackedBarRenderer3D2.getItemCreateEntity(2, 13);
        java.awt.Paint paint17 = stackedBarRenderer3D2.getSeriesPaint(2);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        waferMapPlot20.addChangeListener(plotChangeListener22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot20);
        jFreeChart24.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart24.removeProgressListener(chartProgressListener27);
        boolean boolean29 = stackedBarRenderer3D2.equals((java.lang.Object) chartProgressListener27);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(3.0d);
        axisState1.cursorLeft(6.3072E10d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setUpperBound(0.0d);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D7 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D7.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        lineRenderer3D7.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        lineRenderer3D7.setBaseShapesFilled(false);
        lineRenderer3D7.setSeriesShapesFilled(100, true);
        java.awt.Paint paint22 = lineRenderer3D7.lookupSeriesFillPaint(3);
        dateAxis0.setLabelPaint(paint22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.KeyedObjects keyedObjects1 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj3 = keyedObjects1.getObject((java.lang.Comparable) true);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = dateAxis4.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        dateAxis4.setMaximumDate(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.chart.axis.TickUnits tickUnits18 = new org.jfree.chart.axis.TickUnits();
        int int19 = year17.compareTo((java.lang.Object) tickUnits18);
        java.lang.Object obj20 = keyedObjects1.getObject((java.lang.Comparable) year17);
        java.lang.Number number21 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) year17, number21);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleEdge.BOTTOM", timeZone1);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Paint paint2 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = waferMapPlot5.getOutlinePaint();
        ringPlot0.setSeparatorPaint(paint9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segment5.copy();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segment6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, 10.0d);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean6 = flowArrangement4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset12, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean19 = legendItemBlockContainer14.equals((java.lang.Object) chartColor18);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection21 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list22 = axisCollection21.getAxesAtTop();
        segmentedTimeline20.setExceptionSegments(list22);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment25 = segmentedTimeline20.getSegment((long) 10);
        boolean boolean27 = segment25.contains((long) 3);
        boolean boolean28 = segment25.inIncludeSegments();
        flowArrangement4.add((org.jfree.chart.block.Block) legendItemBlockContainer14, (java.lang.Object) segment25);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(segment25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setNoDataMessage("#0a0a0a");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke35 = null;
        stackedBarRenderer3D33.setSeriesStroke((int) (byte) 1, stroke35);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D33.setBaseItemLabelPaint((java.awt.Paint) chartColor40);
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor40, stroke42);
        xYPlot17.setRangeZeroBaselineStroke(stroke42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setVisible(false);
        xYPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot17.getRangeAxisForDataset((-1255));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 9);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.0d + "'", double2 == 17.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("ThreadContext");
        projectInfo0.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.KeyedObjects keyedObjects1 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj3 = keyedObjects1.getObject((java.lang.Comparable) true);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = dateAxis4.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        dateAxis4.setMaximumDate(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.chart.axis.TickUnits tickUnits18 = new org.jfree.chart.axis.TickUnits();
        int int19 = year17.compareTo((java.lang.Object) tickUnits18);
        java.lang.Object obj20 = keyedObjects1.getObject((java.lang.Comparable) year17);
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year17);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D8.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        java.lang.Object obj13 = legendItemCollection5.clone();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.resizeRange((double) (-1));
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setLabelURL("");
        dateAxis5.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot17);
        java.util.Date date19 = dateAxis15.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot21.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomDomainAxes((double) 'a', plotRenderingInfo25, point2D26);
        xYPlot21.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot21.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection34 = xYPlot21.getRangeMarkers(10, layer33);
        lineRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot21);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot21.getDomainAxisLocation((int) (short) 0);
        xYPlot21.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        levelRenderer0.setBaseURLGenerator(categoryURLGenerator8, false);
        double double11 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        boolean boolean2 = categoryPlot0.getDrawSharedDomainAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.util.ShapeList shapeList4 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-2208960000000L));
        shapeList4.setShape(4, shape7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ClassContext", "({0}, {1}) = {3} - {4}", "", "#0a0a0a", shape7, paint10);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(legendItemCollection7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("TextAnchor.HALF_ASCENT_CENTER", "({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        dateAxis9.resizeRange((double) (-1));
        dateAxis9.setTickLabelsVisible(false);
        dateAxis9.setLabelURL("");
        dateAxis9.centerRange((double) (short) -1);
        dateAxis9.setLowerMargin((double) 1L);
        dateAxis9.zoomRange((-1.0d), (double) 9999);
        double double24 = dateAxis9.getFixedDimension();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer25 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray41 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray48 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray49 = new double[][] { doubleArray34, doubleArray41, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray49);
        boolean boolean51 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset50);
        boolean boolean52 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset50);
        org.jfree.data.Range range53 = groupedStackedBarRenderer25.findRangeBounds(categoryDataset50);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean55 = groupedStackedBarRenderer25.equals((java.lang.Object) segmentedTimeline54);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer56 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray65 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray72 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray79 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray80 = new double[][] { doubleArray65, doubleArray72, doubleArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray80);
        org.jfree.data.Range range82 = groupedStackedBarRenderer56.findRangeBounds(categoryDataset81);
        org.jfree.data.Range range83 = groupedStackedBarRenderer25.findRangeBounds(categoryDataset81);
        java.lang.String str84 = range83.toString();
        dateAxis9.setRange(range83);
        boolean boolean87 = range83.contains(0.0d);
        dateAxis0.setRange(range83, true, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Range[0.0,300.0]" + "'", str84.equals("Range[0.0,300.0]"));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = waferMapPlot5.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        java.awt.Font font13 = dateAxis11.getLabelFont();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str18 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font13, (java.awt.Paint) chartColor17);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color2, paint9, (java.awt.Paint) chartColor17);
        java.awt.Paint paint21 = waterfallBarRenderer20.getFirstBarPaint();
        try {
            waterfallBarRenderer20.setSeriesItemLabelsVisible((-1255), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#0a0a0a" + "'", str18.equals("#0a0a0a"));
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        dateAxis2.resizeRange((double) (-1));
        dateAxis2.setTickLabelsVisible(false);
        dateAxis2.setLabelURL("");
        dateAxis2.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot14);
        java.util.Date date16 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot18.zoomDomainAxes((double) 'a', plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isInverted();
        java.awt.Font font27 = dateAxis25.getLabelFont();
        dateAxis25.setAutoTickUnitSelection(false);
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        xYPlot18.mapDatasetToDomainAxis((int) 'a', (int) (short) 1);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", (org.jfree.chart.plot.Plot) xYPlot18);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot35 = jFreeChart34.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        java.awt.Paint paint28 = legendItem25.getFillPaint();
        java.awt.Shape shape29 = legendItem25.getLine();
        java.lang.String str30 = legendItem25.getDescription();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "VerticalAlignment.CENTER" + "'", str30.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.Number[][] numberArray0 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 100L, 12.0d, 0.0f, 432000000L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray5 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray0, numberArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer22 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer22.setSeriesPaint((int) '4', (java.awt.Paint) chartColor27, true);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) chartColor27);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11);
        java.awt.Stroke stroke32 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearRangeMarkers(8);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(13, valueAxis9, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        java.awt.Shape shape21 = legendItemEntity18.getArea();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 500, 8.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 6.3072E10d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot6.zoomDomainAxes((double) 9999, plotRenderingInfo8, point2D9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        polarPlot6.setAngleLabelPaint(paint11);
        java.awt.Font font13 = polarPlot6.getAngleLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        java.awt.Font font22 = xYPlot17.getNoDataMessageFont();
        java.awt.Stroke stroke23 = xYPlot17.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot17.getRangeAxisEdge(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(3.0d);
        axisState1.cursorUp((double) 3600000L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) 2958465);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke11 = null;
        stackedBarRenderer3D9.setSeriesStroke((int) (byte) 1, stroke11);
        org.jfree.chart.ChartColor chartColor16 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D9.setBaseItemLabelPaint((java.awt.Paint) chartColor16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedBarRenderer3D9.getBaseNegativeItemLabelPosition();
        java.awt.Stroke stroke20 = stackedBarRenderer3D9.lookupSeriesStroke(4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke25 = null;
        stackedBarRenderer3D23.setSeriesStroke((int) (byte) 1, stroke25);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        stackedBarRenderer3D23.setSeriesToolTipGenerator((int) (byte) 10, categoryToolTipGenerator28, true);
        java.awt.Paint paint31 = stackedBarRenderer3D23.getBaseFillPaint();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", "", "ERROR : Relative To String", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", shape6, stroke20, paint31);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        xYPlot17.setDomainAxis(valueAxis21);
        xYPlot17.setDomainCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot17.getRenderer(8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        dateAxis3.resizeRange((double) (-1));
        dateAxis3.setTickLabelsVisible(false);
        dateAxis3.setLabelURL("");
        dateAxis3.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot15);
        java.util.Date date17 = dateAxis13.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot19.getDomainAxisLocation((int) (byte) 10);
        xYPlot19.setDomainCrosshairVisible(false);
        java.awt.Font font24 = xYPlot19.getNoDataMessageFont();
        java.awt.Color color28 = java.awt.Color.getHSBColor((float) (byte) 1, (float) (byte) -1, 0.0f);
        xYPlot19.setDomainZeroBaselinePaint((java.awt.Paint) color28);
        boolean boolean30 = chartRenderingInfo0.equals((java.lang.Object) xYPlot19);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Font font5 = dateAxis3.getLabelFont();
        boolean boolean6 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) font5);
        java.awt.Paint paint7 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke12 = null;
        stackedBarRenderer3D10.setSeriesStroke(0, stroke12);
        stackedBarRenderer3D10.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean18 = stackedBarRenderer3D10.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        stackedBarRenderer3D10.setPositiveItemLabelPositionFallback(itemLabelPosition19);
        boolean boolean23 = stackedBarRenderer3D10.getItemCreateEntity(2, 13);
        java.awt.Paint paint24 = stackedBarRenderer3D10.getWallPaint();
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        boolean boolean15 = polarPlot0.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = polarPlot0.getLegendItems();
        java.awt.Paint paint17 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        long long7 = segmentedTimeline0.getSegmentSize();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline0.getSegment((long) 9);
        long long11 = segmentedTimeline0.toTimelineValue(100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        java.awt.Font font7 = dateAxis5.getLabelFont();
        java.awt.Font font8 = dateAxis5.getLabelFont();
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) "#0a0a0a", font8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateLeftInset((double) 2);
        double double10 = rectangleInsets6.calculateTopOutset(0.35d);
        double double11 = rectangleInsets6.getRight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        java.awt.Stroke stroke26 = legendItem25.getLineStroke();
        org.jfree.data.general.Dataset dataset27 = legendItem25.getDataset();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(dataset27);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot17.getRangeAxis();
        int int31 = xYPlot17.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer22 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer22.setSeriesPaint((int) '4', (java.awt.Paint) chartColor27, true);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) chartColor27);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11);
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Stroke stroke33 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        boolean boolean37 = dateAxis36.isInverted();
        dateAxis36.resizeRange((double) (-1));
        dateAxis36.setTickLabelsVisible(false);
        dateAxis36.setLabelURL("");
        dateAxis36.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        boolean boolean47 = dateAxis46.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot48 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis46.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot48);
        java.util.Date date50 = dateAxis46.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot52.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        xYPlot52.zoomDomainAxes((double) 'a', plotRenderingInfo56, point2D57);
        xYPlot52.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = xYPlot52.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation63 = xYPlot52.getDomainAxisLocation(2);
        try {
            categoryPlot0.setDomainAxisLocation((-1255), axisLocation63, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultCategoryDataset0.setGroup(datasetGroup1);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getColumnKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) dateAxis7);
        java.awt.Shape shape12 = dateAxis0.getUpArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxisForDataset(9999);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str27 = layer26.toString();
        java.util.Collection collection28 = xYPlot17.getRangeMarkers(layer26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isInverted();
        dateAxis29.resizeRange((double) (-1));
        dateAxis29.setTickLabelsVisible(false);
        java.lang.String str35 = dateAxis29.getLabelURL();
        int int36 = xYPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Stroke stroke37 = xYPlot17.getDomainCrosshairStroke();
        double double38 = xYPlot17.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.FOREGROUND" + "'", str27.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        double double14 = range13.getLowerBound();
        boolean boolean17 = range13.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range13, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint19.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint19.toFixedWidth((double) 8);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        segment5.moveIndexToEnd();
        boolean boolean7 = segment5.inIncludeSegments();
        long long9 = segment5.calculateSegmentNumber((long) 8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Stroke stroke3 = null;
        valueMarker1.setOutlineStroke(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library10 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean11 = textLine5.equals((java.lang.Object) "#0a0a0a");
        boolean boolean12 = ringPlot0.equals((java.lang.Object) "#0a0a0a");
        java.awt.Stroke stroke13 = ringPlot0.getLabelOutlineStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke((int) (byte) 1, stroke19);
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D17.setBaseItemLabelPaint((java.awt.Paint) chartColor24);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor24, stroke26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot30 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis28.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot30);
        java.util.Date date32 = dateAxis28.getMaximumDate();
        boolean boolean33 = dateAxis28.isAutoRange();
        dateAxis28.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        boolean boolean37 = dateAxis36.isInverted();
        dateAxis36.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis36.setDefaultAutoRange((org.jfree.data.Range) dateRange40);
        java.util.Date date42 = dateRange40.getLowerDate();
        dateAxis28.setMaximumDate(date42);
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions48 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions46, categoryLabelPosition47);
        org.jfree.chart.text.TextAnchor textAnchor49 = categoryLabelPosition47.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick51 = new org.jfree.chart.axis.DateTick(date42, "VerticalAlignment.CENTER", textAnchor45, textAnchor49, (double) 2.0f);
        valueMarker27.setLabelTextAnchor(textAnchor49);
        boolean boolean53 = ringPlot0.equals((java.lang.Object) valueMarker27);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateRange40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
        org.junit.Assert.assertNotNull(categoryLabelPositions48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState(3.0d);
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke18 = null;
        stackedBarRenderer3D16.setSeriesStroke(0, stroke18);
        stackedBarRenderer3D16.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean24 = stackedBarRenderer3D16.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = null;
        stackedBarRenderer3D16.setPositiveItemLabelPositionFallback(itemLabelPosition25);
        double double27 = stackedBarRenderer3D16.getYOffset();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isInverted();
        java.awt.Font font30 = dateAxis28.getLabelFont();
        java.awt.Font font31 = dateAxis28.getLabelFont();
        stackedBarRenderer3D16.setBaseItemLabelFont(font31, true);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font31, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis((int) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer13 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer13.setSeriesPaint((int) '4', (java.awt.Paint) chartColor18, true);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) chartColor18);
        java.awt.Stroke stroke23 = stackedBarRenderer3D2.lookupSeriesStroke(4);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextAnchor.HALF_ASCENT_CENTER", "Pie Plot", "", image3, "ChartChangeEventType.NEW_DATASET", "SerialDate.weekInMonthToString(): invalid code.", "");
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("WMAP_Plot");
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) textFragment2);
        java.lang.String str4 = textFragment2.getText();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        boolean boolean7 = segment5.contains((long) 3);
        long long8 = segment5.getSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Font font5 = dateAxis3.getLabelFont();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setCircular(false);
        java.awt.Paint paint11 = ringPlot8.getLabelShadowPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint11, (float) 900000L, textMeasurer13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean25 = stackedBarRenderer3D17.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle28.getLegendItemGraphicAnchor();
        java.awt.Font font30 = legendTitle28.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle28.setPosition(rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle28.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment35, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement38, dataset39, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor45 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean46 = legendItemBlockContainer41.equals((java.lang.Object) chartColor45);
        legendTitle28.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor49 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor48, textBlockAnchor49);
        legendTitle28.setLegendItemGraphicAnchor(rectangleAnchor48);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor48, textBlockAnchor52);
        org.jfree.chart.text.TextLine textLine54 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D60 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke62 = null;
        stackedBarRenderer3D60.setSeriesStroke(0, stroke62);
        stackedBarRenderer3D60.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean68 = stackedBarRenderer3D60.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = null;
        stackedBarRenderer3D60.setPositiveItemLabelPositionFallback(itemLabelPosition69);
        stackedBarRenderer3D60.setBaseSeriesVisible(false, true);
        java.awt.Paint paint74 = stackedBarRenderer3D60.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer75 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D76 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint77 = lineRenderer3D76.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor79 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor80 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition81 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor79, textAnchor80);
        lineRenderer3D76.setSeriesPositiveItemLabelPosition(10, itemLabelPosition81);
        intervalBarRenderer75.setNegativeItemLabelPositionFallback(itemLabelPosition81);
        stackedBarRenderer3D60.setPositiveItemLabelPositionFallback(itemLabelPosition81);
        org.jfree.chart.text.TextAnchor textAnchor85 = itemLabelPosition81.getTextAnchor();
        textLine54.draw(graphics2D55, (float) (byte) 1, (float) 7, textAnchor85, (float) 500, (float) 1, (double) 8);
        org.jfree.chart.axis.CategoryTick categoryTick91 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "RectangleEdge.BOTTOM", textBlock14, textBlockAnchor52, textAnchor85, 10.0d);
        org.jfree.chart.text.TextBlock textBlock92 = categoryTick91.getLabel();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(textBlockAnchor49);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(itemLabelAnchor79);
        org.junit.Assert.assertNotNull(textAnchor80);
        org.junit.Assert.assertNotNull(textAnchor85);
        org.junit.Assert.assertNotNull(textBlock92);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D7.setUpperMargin(1.0E-5d);
        double double10 = categoryAxis3D7.getLabelAngle();
        java.lang.Object obj11 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        dateAxis12.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis12.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        java.util.Date date18 = dateRange16.getLowerDate();
        java.awt.Font font19 = categoryAxis3D7.getTickLabelFont((java.lang.Comparable) date18);
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) "WMAP_Plot", (java.lang.Comparable) date18);
        java.util.List list21 = defaultKeyedValues2D0.getColumnKeys();
        try {
            defaultKeyedValues2D0.removeRow(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.clearCornerTextItems();
        boolean boolean8 = polarPlot6.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot6.zoomRangeAxes((double) (byte) 0, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleEdge.LEFT");
        java.awt.Font font6 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 1.0f, 0.25d, 0.0d, (double) 100, font6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getUseOutlinePaint();
        lineRenderer3D0.setUseFillPaint(false);
        lineRenderer3D0.setXOffset((double) 9);
        boolean boolean9 = lineRenderer3D0.isSeriesItemLabelsVisible(4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        int int28 = xYPlot17.getRangeAxisCount();
        java.awt.Stroke stroke29 = xYPlot17.getDomainZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot17.getRendererForDataset(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYItemRenderer31);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowYOffset((double) 'a');
        ringPlot0.setCircular(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        boolean boolean15 = stackedBarRenderer3D2.getItemCreateEntity(2, 13);
        java.awt.Paint paint17 = stackedBarRenderer3D2.getSeriesPaint(2);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        stackedBarRenderer3D2.setBaseOutlineStroke(stroke18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        ringPlot1.setInnerSeparatorExtension(1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D10.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getNegativeItemLabelPositionFallback();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D10.setSeriesPaint(10, (java.awt.Paint) color15);
        ringPlot1.setLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer22 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean23 = chartColor21.equals((java.lang.Object) intervalBarRenderer22);
        ringPlot1.setLabelPaint((java.awt.Paint) chartColor21);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = ringPlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat4);
        int int6 = dateTickUnit5.getCalendarField();
        int int7 = dateTickUnit5.getCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        segmentedTimeline0.addException((long) (short) 1);
        long long5 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 86400000L + "'", long5 == 86400000L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        long long7 = segmentedTimeline0.getSegmentSize();
        long long8 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 432000000L + "'", long8 == 432000000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.awt.Font font4 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setOuterSeparatorExtension((double) 0L);
        boolean boolean5 = ringPlot0.getIgnoreZeroValues();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        waferMapPlot11.addChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = waferMapPlot11.getOutlinePaint();
        stackedBarRenderer3D8.setBaseFillPaint(paint15, false);
        ringPlot0.setSectionPaint((java.lang.Comparable) "TextAnchor.HALF_ASCENT_CENTER", paint15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isInverted();
        java.awt.Font font19 = dateAxis17.getLabelFont();
        java.awt.Color color20 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font19, (java.awt.Paint) color20);
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.CENTER", font19);
        polarPlot0.setAngleLabelFont(font19);
        java.lang.Object obj24 = polarPlot0.clone();
        java.awt.Stroke stroke25 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke(0, stroke7);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(false);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D5.setSeriesOutlinePaint(10, paint12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        ringPlot14.setCircular(false);
        java.awt.Paint paint17 = ringPlot14.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library24 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean25 = textLine19.equals((java.lang.Object) "#0a0a0a");
        boolean boolean26 = ringPlot14.equals((java.lang.Object) "#0a0a0a");
        java.awt.Stroke stroke27 = ringPlot14.getBaseSectionOutlineStroke();
        stackedBarRenderer3D5.setBaseStroke(stroke27);
        categoryPlot0.setRangeGridlineStroke(stroke27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke35 = null;
        stackedBarRenderer3D33.setSeriesStroke(0, stroke35);
        stackedBarRenderer3D33.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean41 = stackedBarRenderer3D33.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = null;
        stackedBarRenderer3D33.setPositiveItemLabelPositionFallback(itemLabelPosition42);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle44.getLegendItemGraphicAnchor();
        java.awt.Font font46 = legendTitle44.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle44.setPosition(rectangleEdge47);
        org.jfree.chart.ChartColor chartColor52 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        legendTitle44.setBackgroundPaint((java.awt.Paint) chartColor52);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent54 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle44);
        jFreeChart30.titleChanged(titleChangeEvent54);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(2958465);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "#0a0a0a");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline1.getSegmentsExcludedSize();
        java.lang.Object obj3 = segmentedTimeline1.clone();
        java.util.Date date5 = segmentedTimeline1.getDate(100L);
        boolean boolean7 = segmentedTimeline1.equals((java.lang.Object) 0.2d);
        long long8 = segmentedTimeline1.getSegmentSize();
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment16, 0.0d, 2.0d);
        double[] doubleArray30 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray37 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray44 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot50 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot50);
        java.util.Date date52 = dateAxis48.getMaximumDate();
        boolean boolean53 = dateAxis48.isAutoRange();
        dateAxis48.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        boolean boolean57 = dateAxis56.isInverted();
        dateAxis56.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis56.setDefaultAutoRange((org.jfree.data.Range) dateRange60);
        java.util.Date date62 = dateRange60.getLowerDate();
        dateAxis48.setMaximumDate(date62);
        org.jfree.chart.text.TextAnchor textAnchor65 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions66 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition67 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions68 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions66, categoryLabelPosition67);
        org.jfree.chart.text.TextAnchor textAnchor69 = categoryLabelPosition67.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick71 = new org.jfree.chart.axis.DateTick(date62, "VerticalAlignment.CENTER", textAnchor65, textAnchor69, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer72 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19, (org.jfree.data.general.Dataset) categoryDataset47, (java.lang.Comparable) date62);
        java.util.Date date73 = dateTickUnit14.addToDate(date62);
        boolean boolean74 = segmentedTimeline1.containsDomainValue(date62);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) boolean74, (java.lang.Comparable) 0L);
        try {
            java.lang.Comparable comparable78 = defaultCategoryDataset0.getColumnKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 172800000L + "'", long2 == 172800000L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateRange60);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(textAnchor65);
        org.junit.Assert.assertNotNull(categoryLabelPositions66);
        org.junit.Assert.assertNotNull(categoryLabelPositions68);
        org.junit.Assert.assertNotNull(textAnchor69);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        java.awt.Paint paint4 = boxAndWhiskerRenderer0.getSeriesFillPaint(3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator21 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator22 = null;
        java.lang.String str23 = legendItemEntity18.getImageMapAreaTag(toolTipTagFragmentGenerator21, uRLTagFragmentGenerator22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke28 = null;
        stackedBarRenderer3D26.setSeriesStroke(0, stroke28);
        stackedBarRenderer3D26.setBaseItemLabelsVisible(false);
        stackedBarRenderer3D26.setBaseItemLabelsVisible(false, true);
        java.awt.Stroke stroke37 = stackedBarRenderer3D26.getItemStroke(7, 0);
        java.awt.Paint paint39 = stackedBarRenderer3D26.getSeriesOutlinePaint(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = stackedBarRenderer3D26.getNegativeItemLabelPositionFallback();
        boolean boolean41 = legendItemEntity18.equals((java.lang.Object) stackedBarRenderer3D26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Paint paint2 = polarPlot0.getAngleLabelPaint();
        polarPlot0.addCornerTextItem("WMAP_Plot");
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset1, keyToGroupMap2);
        java.lang.Comparable comparable5 = keyToGroupMap2.getGroup((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET");
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap2);
        java.util.List list7 = keyToGroupMap2.getGroups();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Default Group" + "'", comparable5.equals("Default Group"));
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        java.awt.Shape shape9 = dateAxis1.getRightArrow();
        intervalBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        intervalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        boolean boolean14 = standardGradientPaintTransformer11.equals((java.lang.Object) "#0a0a0a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Font font5 = dateAxis3.getLabelFont();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setCircular(false);
        java.awt.Paint paint11 = ringPlot8.getLabelShadowPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint11, (float) 900000L, textMeasurer13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean25 = stackedBarRenderer3D17.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle28.getLegendItemGraphicAnchor();
        java.awt.Font font30 = legendTitle28.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle28.setPosition(rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle28.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment35, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement38, dataset39, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor45 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean46 = legendItemBlockContainer41.equals((java.lang.Object) chartColor45);
        legendTitle28.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor49 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor48, textBlockAnchor49);
        legendTitle28.setLegendItemGraphicAnchor(rectangleAnchor48);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor48, textBlockAnchor52);
        org.jfree.chart.text.TextLine textLine54 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D60 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke62 = null;
        stackedBarRenderer3D60.setSeriesStroke(0, stroke62);
        stackedBarRenderer3D60.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean68 = stackedBarRenderer3D60.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = null;
        stackedBarRenderer3D60.setPositiveItemLabelPositionFallback(itemLabelPosition69);
        stackedBarRenderer3D60.setBaseSeriesVisible(false, true);
        java.awt.Paint paint74 = stackedBarRenderer3D60.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer75 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D76 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint77 = lineRenderer3D76.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor79 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor80 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition81 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor79, textAnchor80);
        lineRenderer3D76.setSeriesPositiveItemLabelPosition(10, itemLabelPosition81);
        intervalBarRenderer75.setNegativeItemLabelPositionFallback(itemLabelPosition81);
        stackedBarRenderer3D60.setPositiveItemLabelPositionFallback(itemLabelPosition81);
        org.jfree.chart.text.TextAnchor textAnchor85 = itemLabelPosition81.getTextAnchor();
        textLine54.draw(graphics2D55, (float) (byte) 1, (float) 7, textAnchor85, (float) 500, (float) 1, (double) 8);
        org.jfree.chart.axis.CategoryTick categoryTick91 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "RectangleEdge.BOTTOM", textBlock14, textBlockAnchor52, textAnchor85, 10.0d);
        boolean boolean93 = categoryTick91.equals((java.lang.Object) "CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(textBlockAnchor49);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(itemLabelAnchor79);
        org.junit.Assert.assertNotNull(textAnchor80);
        org.junit.Assert.assertNotNull(textAnchor85);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        dateAxis0.centerRange((double) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        dateAxis11.resizeRange((double) (-1));
        dateAxis11.setTickLabelsVisible(false);
        dateAxis11.setLabelURL("");
        dateAxis11.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot23);
        java.util.Date date25 = dateAxis21.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot27.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomDomainAxes((double) 'a', plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isInverted();
        java.awt.Font font36 = dateAxis34.getLabelFont();
        dateAxis34.setAutoTickUnitSelection(false);
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot27.getRangeAxis();
        boolean boolean41 = dateAxis0.hasListener((java.util.EventListener) xYPlot27);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        xYPlot27.setRangeAxis(valueAxis42);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke(0, stroke7);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(false);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D5.setSeriesOutlinePaint(10, paint12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        ringPlot14.setCircular(false);
        java.awt.Paint paint17 = ringPlot14.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library24 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean25 = textLine19.equals((java.lang.Object) "#0a0a0a");
        boolean boolean26 = ringPlot14.equals((java.lang.Object) "#0a0a0a");
        java.awt.Stroke stroke27 = ringPlot14.getBaseSectionOutlineStroke();
        stackedBarRenderer3D5.setBaseStroke(stroke27);
        categoryPlot0.setRangeGridlineStroke(stroke27);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getID();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        labelBlock1.setMargin(rectangleInsets9);
        labelBlock1.setURLText("");
        double double13 = labelBlock1.getContentYOffset();
        java.lang.String str14 = labelBlock1.getToolTipText();
        java.lang.String str15 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        try {
            dateAxis0.setRange((double) 500, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setSeriesShapesFilled(100, true);
        java.awt.Paint paint15 = lineRenderer3D0.lookupSeriesFillPaint(3);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        dateAxis18.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke29 = null;
        stackedBarRenderer3D27.setSeriesStroke(0, stroke29);
        stackedBarRenderer3D27.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean35 = stackedBarRenderer3D27.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        stackedBarRenderer3D27.setPositiveItemLabelPositionFallback(itemLabelPosition36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D27);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer39 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor44 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer39.setSeriesPaint((int) '4', (java.awt.Paint) chartColor44, true);
        java.awt.Color color47 = java.awt.Color.orange;
        boolean boolean48 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor44, (java.awt.Paint) color47);
        legendTitle38.setBackgroundPaint((java.awt.Paint) chartColor44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = legendTitle38.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = legendTitle38.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle38.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D55 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke57 = null;
        stackedBarRenderer3D55.setSeriesStroke(0, stroke57);
        stackedBarRenderer3D55.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean63 = stackedBarRenderer3D55.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition64 = null;
        stackedBarRenderer3D55.setPositiveItemLabelPositionFallback(itemLabelPosition64);
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = legendTitle66.getLegendItemGraphicAnchor();
        java.awt.Font font68 = legendTitle66.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle66.setPosition(rectangleEdge69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = legendTitle66.getLegendItemGraphicEdge();
        double double72 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D52, rectangleEdge71);
        dateAxis18.setDownArrow((java.awt.Shape) rectangle2D52);
        try {
            lineRenderer3D0.drawOutline(graphics2D16, categoryPlot17, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D8.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D19.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape22 = stackedBarRenderer3D19.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        waferMapPlot25.addChangeListener(plotChangeListener27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot25);
        jFreeChart29.setBorderVisible(true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart29.setBorderPaint((java.awt.Paint) color32);
        jFreeChart29.removeLegend();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart29.setBorderStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape22, stroke35, (java.awt.Paint) color37);
        org.jfree.data.general.Dataset dataset39 = null;
        legendItem38.setDataset(dataset39);
        java.awt.Paint paint41 = legendItem38.getOutlinePaint();
        legendItemCollection11.add(legendItem38);
        java.awt.Paint paint43 = legendItem38.getFillPaint();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Paint paint2 = polarPlot0.getAngleLabelPaint();
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke8 = null;
        stackedBarRenderer3D6.setSeriesStroke(0, stroke8);
        stackedBarRenderer3D6.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean13 = categoryLabelPosition1.equals((java.lang.Object) stackedBarRenderer3D6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.ui.ProjectInfo projectInfo15 = org.jfree.chart.JFreeChart.INFO;
        projectInfo15.setCopyright("SortOrder.ASCENDING");
        org.jfree.chart.axis.AxisCollection axisCollection18 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list19 = axisCollection18.getAxesAtTop();
        java.util.List list20 = axisCollection18.getAxesAtLeft();
        projectInfo15.setContributors(list20);
        projectInfo15.setLicenceName("SortOrder.ASCENDING");
        boolean boolean24 = textBlockAnchor14.equals((java.lang.Object) "SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(projectInfo15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateLeftInset((double) 2);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, paint9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 28799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23, dataset24, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean31 = legendItemBlockContainer26.equals((java.lang.Object) chartColor30);
        legendTitle13.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle13.getLegendItemGraphicPadding();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean16 = stackedBarRenderer3D8.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition17);
        stackedBarRenderer3D8.setBaseSeriesVisible(false, true);
        java.awt.Paint paint22 = stackedBarRenderer3D8.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint25 = lineRenderer3D24.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28);
        lineRenderer3D24.setSeriesPositiveItemLabelPosition(10, itemLabelPosition29);
        intervalBarRenderer23.setNegativeItemLabelPositionFallback(itemLabelPosition29);
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition29);
        org.jfree.chart.text.TextAnchor textAnchor33 = itemLabelPosition29.getTextAnchor();
        try {
            java.awt.Shape shape34 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ERROR : Relative To String", graphics2D1, (float) (byte) 1, (float) 9, textAnchor4, (double) (short) 0, textAnchor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor33);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        ringPlot1.setToolTipGenerator(pieToolTipGenerator2);
        boolean boolean4 = ringPlot1.getLabelLinksVisible();
        java.awt.Paint paint6 = ringPlot1.getSectionPaint((java.lang.Comparable) "12/31/69");
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = ringPlot1.getLabelDistributor();
        ringPlot1.setShadowXOffset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) gradientPaintTransformType1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions5, categoryLabelPosition6);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryLabelPosition6.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition6);
        org.jfree.chart.text.TextAnchor textAnchor10 = categoryLabelPosition6.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = lineRenderer3D0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = lineRenderer3D0.getSeriesURLGenerator((int) '4');
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = lineRenderer3D0.getToolTipGenerator((int) '#', (int) '#');
        boolean boolean6 = lineRenderer3D0.getBaseShapesFilled();
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth(3);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.FOREGROUND" + "'", str2.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = waferMapPlot5.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        java.awt.Font font13 = dateAxis11.getLabelFont();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str18 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font13, (java.awt.Paint) chartColor17);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color2, paint9, (java.awt.Paint) chartColor17);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D21 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint22 = lineRenderer3D21.getWallPaint();
        lineRenderer3D21.setUseFillPaint(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke29 = null;
        stackedBarRenderer3D27.setSeriesStroke(0, stroke29);
        stackedBarRenderer3D27.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        stackedBarRenderer3D27.notifyListeners(rendererChangeEvent33);
        stackedBarRenderer3D27.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.data.Range range38 = stackedBarRenderer3D27.findRangeBounds(categoryDataset37);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = stackedBarRenderer3D27.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke46 = null;
        stackedBarRenderer3D44.setSeriesStroke((int) (byte) 1, stroke46);
        org.jfree.chart.ChartColor chartColor51 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D44.setBaseItemLabelPaint((java.awt.Paint) chartColor51);
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor51, stroke53);
        stackedBarRenderer3D27.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) chartColor51);
        lineRenderer3D21.setBaseFillPaint((java.awt.Paint) chartColor51, false);
        waterfallBarRenderer20.setPositiveBarPaint((java.awt.Paint) chartColor51);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#0a0a0a" + "'", str18.equals("#0a0a0a"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke31 = null;
        stackedBarRenderer3D29.setSeriesStroke(0, stroke31);
        stackedBarRenderer3D29.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        stackedBarRenderer3D29.notifyListeners(rendererChangeEvent35);
        stackedBarRenderer3D29.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.data.Range range40 = stackedBarRenderer3D29.findRangeBounds(categoryDataset39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range40, 0.0d);
        org.jfree.data.Range range43 = rectangleConstraint42.getHeightRange();
        org.jfree.chart.util.Size2D size2D44 = legendTitle13.arrange(graphics2D26, rectangleConstraint42);
        org.jfree.chart.text.TextLine textLine45 = new org.jfree.chart.text.TextLine();
        boolean boolean46 = size2D44.equals((java.lang.Object) textLine45);
        size2D44.setWidth((double) 15);
        double double49 = size2D44.height;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D9 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D9.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineRenderer3D9.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        lineRenderer3D9.setBaseShapesFilled(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator21 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineRenderer3D9.setSeriesURLGenerator(4, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator21, false);
        stackedBarRenderer3D2.setSeriesURLGenerator((int) (short) 1, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator21, true);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("WMAP_Plot");
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) textFragment2);
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment2.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0.5f, (double) 500);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        java.util.Date date4 = dateAxis0.getMaximumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean16 = stackedBarRenderer3D8.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D8);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer20 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer20.setSeriesPaint((int) '4', (java.awt.Paint) chartColor25, true);
        java.awt.Color color28 = java.awt.Color.orange;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor25, (java.awt.Paint) color28);
        legendTitle19.setBackgroundPaint((java.awt.Paint) chartColor25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = legendTitle19.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendTitle19.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle19.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint35 = categoryPlot34.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot34.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock38, dataset39);
        categoryPlot34.datasetChanged(datasetChangeEvent40);
        boolean boolean42 = categoryPlot34.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke47 = null;
        stackedBarRenderer3D45.setSeriesStroke(0, stroke47);
        stackedBarRenderer3D45.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        stackedBarRenderer3D45.notifyListeners(rendererChangeEvent51);
        stackedBarRenderer3D45.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer56 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor61 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer56.setSeriesPaint((int) '4', (java.awt.Paint) chartColor61, true);
        stackedBarRenderer3D45.setWallPaint((java.awt.Paint) chartColor61);
        categoryPlot34.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot34.setDomainAxis(13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D68, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot34.getDomainAxisEdge();
        double double72 = dateAxis0.java2DToValue(0.0d, rectangle2D33, rectangleEdge71);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity73 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }
}

