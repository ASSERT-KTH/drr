import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects2D0.getColumnIndex(comparable1);
        java.lang.Comparable comparable3 = null;
        keyedObjects2D0.removeObject(comparable3, (java.lang.Comparable) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str8 = chartChangeEventType7.toString();
        boolean boolean9 = jFreeChart6.equals((java.lang.Object) chartChangeEventType7);
        java.lang.String str10 = chartChangeEventType7.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str8.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str10.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        waferMapPlot6.addChangeListener(plotChangeListener8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot6);
        jFreeChart10.setBorderVisible(true);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart10.getTitle();
        java.awt.Stroke stroke14 = jFreeChart10.getBorderStroke();
        dateAxis0.setTickMarkStroke(stroke14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(textTitle13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.util.List list12 = jFreeChart6.getSubtitles();
        java.lang.Object obj13 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        jFreeChart6.setTitle(textTitle15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage20 = jFreeChart6.createBufferedImage(0, 4, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (4) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.addCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        polarPlot6.setRenderer(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D3.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer15 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor20 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer15.setSeriesPaint((int) '4', (java.awt.Paint) chartColor20, true);
        java.awt.Color color23 = java.awt.Color.orange;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor20, (java.awt.Paint) color23);
        legendTitle14.setBackgroundPaint((java.awt.Paint) chartColor20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment27, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset31 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement30, dataset31, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor37 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean38 = legendItemBlockContainer33.equals((java.lang.Object) chartColor37);
        legendTitle14.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer33);
        org.jfree.chart.block.Arrangement arrangement40 = legendItemBlockContainer33.getArrangement();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke46 = null;
        stackedBarRenderer3D44.setSeriesStroke(0, stroke46);
        stackedBarRenderer3D44.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        stackedBarRenderer3D44.notifyListeners(rendererChangeEvent50);
        stackedBarRenderer3D44.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.data.Range range55 = stackedBarRenderer3D44.findRangeBounds(categoryDataset54);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range55, 0.0d);
        try {
            org.jfree.chart.util.Size2D size2D58 = centerArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer33, graphics2D41, rectangleConstraint57);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(arrangement40);
        org.junit.Assert.assertNotNull(range55);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 3600000L, (double) 28799999L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        ringPlot0.setShadowXOffset(1.0E-5d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = stackedBarRenderer3D2.getURLGenerator((int) (short) 1, (-1));
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot0.setRadiusGridlineStroke(stroke1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        org.jfree.data.Range range26 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        try {
            java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset25);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isInverted();
        dateAxis29.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis29.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke39 = null;
        stackedBarRenderer3D37.setSeriesStroke(0, stroke39);
        stackedBarRenderer3D37.setBaseItemLabelsVisible(false);
        java.awt.Shape shape45 = stackedBarRenderer3D37.getItemShape((int) (short) 10, (-1));
        dateAxis29.setDownArrow(shape45);
        groupedStackedBarRenderer0.setBaseShape(shape45);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.lang.Class<?> wildcardClass8 = ringPlot0.getClass();
        boolean boolean10 = ringPlot0.equals((java.lang.Object) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        categoryPlot0.configureDomainAxes();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowYOffset((double) 'a');
        java.awt.Stroke stroke5 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) true);
        float float6 = ringPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle1.getText();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke12 = null;
        stackedBarRenderer3D10.setSeriesStroke(0, stroke12);
        stackedBarRenderer3D10.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        stackedBarRenderer3D10.notifyListeners(rendererChangeEvent16);
        stackedBarRenderer3D10.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.data.Range range21 = stackedBarRenderer3D10.findRangeBounds(categoryDataset20);
        double double22 = range21.getLowerBound();
        boolean boolean25 = range21.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range21, 100.0d);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer28 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray37 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray44 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray51 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray52 = new double[][] { doubleArray37, doubleArray44, doubleArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray52);
        org.jfree.data.Range range54 = groupedStackedBarRenderer28.findRangeBounds(categoryDataset53);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint27.toRangeHeight(range54);
        try {
            org.jfree.chart.util.Size2D size2D56 = textTitle1.arrange(graphics2D7, rectangleConstraint55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.CENTER" + "'", str6.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke15 = null;
        stackedBarRenderer3D13.setSeriesStroke(0, stroke15);
        stackedBarRenderer3D13.setBaseItemLabelsVisible(false);
        java.awt.Shape shape21 = stackedBarRenderer3D13.getItemShape((int) (short) 10, (-1));
        dateAxis5.setDownArrow(shape21);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity23 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        stackedBarRenderer3D2.setBaseShape(shape21);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Default Group", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection7 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) '4');
        ringPlot1.setStartAngle((double) (short) -1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        double double5 = categoryAxis3D1.getUpperMargin();
        int int6 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        java.lang.String str21 = legendItemEntity18.getToolTipText();
        org.jfree.data.general.Dataset dataset22 = legendItemEntity18.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(dataset22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        java.awt.Font font4 = dateAxis2.getLabelFont();
        java.awt.Font font5 = dateAxis2.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        polarPlot7.addCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke10 = polarPlot7.getRadiusGridlineStroke();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock12, dataset13);
        polarPlot7.datasetChanged(datasetChangeEvent14);
        int int16 = numberTickUnit0.compareTo((java.lang.Object) polarPlot7);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) '#', valueAxis9);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        try {
            categoryPlot0.addDomainMarker((int) '4', categoryMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        boolean boolean15 = polarPlot0.isRangeZoomable();
        java.awt.Font font16 = polarPlot0.getAngleLabelFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot17.getDomainAxis();
        xYPlot17.configureRangeAxes();
        java.awt.Stroke stroke22 = xYPlot17.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean6 = categoryLabelPositions4.equals((java.lang.Object) gradientPaintTransformType5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot7.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock11, dataset12);
        categoryPlot7.datasetChanged(datasetChangeEvent13);
        boolean boolean15 = categoryPlot7.isRangeCrosshairLockedOnData();
        boolean boolean16 = gradientPaintTransformType5.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D18.setUpperMargin(1.0E-5d);
        double double21 = categoryAxis3D18.getLabelAngle();
        double double22 = categoryAxis3D18.getUpperMargin();
        categoryAxis3D18.addCategoryLabelToolTip((java.lang.Comparable) 0.35d, "RectangleEdge.LEFT");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isInverted();
        dateAxis26.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke36 = null;
        stackedBarRenderer3D34.setSeriesStroke(0, stroke36);
        stackedBarRenderer3D34.setBaseItemLabelsVisible(false);
        java.awt.Shape shape42 = stackedBarRenderer3D34.getItemShape((int) (short) 10, (-1));
        dateAxis26.setDownArrow(shape42);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis26);
        boolean boolean45 = dateAxis26.isVisible();
        double[] doubleArray54 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray61 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray68 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray69 = new double[][] { doubleArray54, doubleArray61, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray69);
        boolean boolean71 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset70);
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryDataset70, (int) (byte) 1, 3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-5d + "'", double22 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        categoryPlot0.clearDomainMarkers();
        java.util.List list6 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke(0, stroke9);
        stackedBarRenderer3D7.setBaseItemLabelsVisible(false);
        java.awt.Shape shape15 = stackedBarRenderer3D7.getItemShape((int) (short) 10, (-1));
        stackedBarRenderer3D2.setBaseShape(shape15);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, (double) 9999, 10.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getColumnKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str8 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor7);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) chartColor7);
        java.awt.Font font10 = textFragment9.getFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#0a0a0a" + "'", str8.equals("#0a0a0a"));
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot6.zoomDomainAxes((double) 9999, plotRenderingInfo8, point2D9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            polarPlot6.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        ringPlot1.setToolTipGenerator(pieToolTipGenerator2);
        boolean boolean4 = ringPlot1.getLabelLinksVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        java.util.Date date6 = dateRange4.getLowerDate();
        java.util.Date date7 = dateRange4.getLowerDate();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(9999);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxisForDataset(10);
        java.util.List list10 = categoryPlot0.getCategories();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setNoDataMessage("#0a0a0a");
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            boolean boolean31 = xYPlot17.removeAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        boolean boolean4 = dateAxis0.isTickMarksVisible();
        dateAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke8 = null;
        stackedBarRenderer3D6.setSeriesStroke((int) (byte) 1, stroke8);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D6.setBaseItemLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor13, stroke15);
        float float17 = valueMarker16.getAlpha();
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str19 = layer18.toString();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer18);
        categoryPlot0.setRangeCrosshairValue((double) 1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot0.getRangeAxisForDataset((int) (short) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.FOREGROUND" + "'", str19.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle1.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        java.awt.Shape shape9 = dateAxis1.getRightArrow();
        intervalBarRenderer0.setBaseShape(shape9);
        intervalBarRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getHeight();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        dateAxis12.resizeRange((double) (-1));
        dateAxis12.setTickLabelsVisible(false);
        boolean boolean18 = dateAxis12.isAutoTickUnitSelection();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D25.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot31 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        waferMapPlot31.addChangeListener(plotChangeListener33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot31);
        jFreeChart35.setBorderVisible(true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart35.setBorderPaint((java.awt.Paint) color38);
        jFreeChart35.removeLegend();
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart35.setBorderStroke(stroke41);
        java.awt.Color color43 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape28, stroke41, (java.awt.Paint) color43);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity47 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis12, shape28, "", "");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis12, rectangle2D48, (double) (byte) 10);
        try {
            categoryPlot10.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke(0, stroke9);
        stackedBarRenderer3D7.setBaseItemLabelsVisible(false);
        java.awt.Shape shape15 = stackedBarRenderer3D7.getItemShape((int) (short) 10, (-1));
        stackedBarRenderer3D2.setBaseShape(shape15);
        java.awt.Shape shape18 = stackedBarRenderer3D2.getSeriesShape(15);
        java.awt.Paint paint19 = stackedBarRenderer3D2.getBaseFillPaint();
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        dateAxis8.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis8.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        java.util.Date date14 = dateRange12.getLowerDate();
        dateAxis0.setMaximumDate(date14);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions18, categoryLabelPosition19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick23 = new org.jfree.chart.axis.DateTick(date14, "VerticalAlignment.CENTER", textAnchor17, textAnchor21, (double) 2.0f);
        double double24 = dateTick23.getValue();
        java.lang.String str25 = dateTick23.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "VerticalAlignment.CENTER" + "'", str25.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Object obj2 = stackedAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean6 = lineRenderer3D0.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        double[] doubleArray20 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray35 = new double[][] { doubleArray20, doubleArray27, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray35);
        java.lang.String str39 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset37, 0);
        try {
            java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset37);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str39.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setBackgroundAlpha((float) (short) 100);
        ringPlot0.setLabelLinkMargin((double) (short) 100);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        ringPlot0.markerChanged(markerChangeEvent9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.awt.Stroke stroke8 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke15 = null;
        stackedBarRenderer3D13.setSeriesStroke((int) (byte) 1, stroke15);
        org.jfree.chart.ChartColor chartColor20 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D13.setBaseItemLabelPaint((java.awt.Paint) chartColor20);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor20, stroke22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean33 = chartColor31.equals((java.lang.Object) intervalBarRenderer32);
        stackedBarRenderer3D26.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor31, false);
        valueMarker23.setLabelPaint((java.awt.Paint) chartColor31);
        boolean boolean37 = rectangleAnchor9.equals((java.lang.Object) chartColor31);
        ringPlot0.setSeparatorPaint((java.awt.Paint) chartColor31);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor39 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis0.java2DToValue(0.0d, rectangle2D4, rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        dateAxis0.centerRange((double) (short) -1);
        dateAxis0.setLowerMargin((double) 1L);
        dateAxis0.zoomRange((-1.0d), (double) 9999);
        double double15 = dateAxis0.getFixedDimension();
        java.lang.Object obj16 = dateAxis0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        java.awt.Paint paint4 = null;
        try {
            dateAxis0.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItem legendItem7 = stackedBarRenderer3D2.getLegendItem(2, (int) (byte) 100);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getUseOutlinePaint();
        lineRenderer3D0.setUseFillPaint(false);
        lineRenderer3D0.setXOffset((double) 9);
        lineRenderer3D0.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        dateAxis0.setLabel("RectangleEdge.LEFT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100);
        java.util.List list3 = keyedObjects2D0.getRowKeys();
        java.lang.Object obj4 = keyedObjects2D0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        stackedBarRenderer3D2.setBaseCreateEntities(true, true);
        java.awt.Stroke stroke14 = stackedBarRenderer3D2.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        java.awt.Paint paint26 = legendItem25.getFillPaint();
        java.awt.Paint paint27 = legendItem25.getOutlinePaint();
        java.awt.Stroke stroke28 = legendItem25.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        java.awt.Paint paint26 = legendItem25.getFillPaint();
        boolean boolean27 = legendItem25.isShapeFilled();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke((int) (byte) 1, stroke7);
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D5.setBaseItemLabelPaint((java.awt.Paint) chartColor12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor12, stroke14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean25 = chartColor23.equals((java.lang.Object) intervalBarRenderer24);
        stackedBarRenderer3D18.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor23, false);
        valueMarker15.setLabelPaint((java.awt.Paint) chartColor23);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot31 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot31);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = null;
        dateAxis29.setStandardTickUnits(tickUnitSource33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis29.getLabelInsets();
        java.awt.Stroke stroke36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        dateAxis29.setAxisLineStroke(stroke36);
        valueMarker15.setStroke(stroke36);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D39 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D39.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.Marker marker45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        lineRenderer3D39.drawRangeMarker(graphics2D42, categoryPlot43, valueAxis44, marker45, rectangle2D46);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer48 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor53 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer48.setSeriesPaint((int) '4', (java.awt.Paint) chartColor53, true);
        int int56 = levelRenderer48.getColumnCount();
        double double57 = levelRenderer48.getItemMargin();
        levelRenderer48.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator62 = levelRenderer48.getBaseToolTipGenerator();
        java.awt.Stroke stroke63 = levelRenderer48.getBaseOutlineStroke();
        lineRenderer3D39.setBaseOutlineStroke(stroke63, true);
        valueMarker15.setOutlineStroke(stroke63);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke71 = null;
        stackedBarRenderer3D69.setSeriesStroke(0, stroke71);
        stackedBarRenderer3D69.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean77 = stackedBarRenderer3D69.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = null;
        stackedBarRenderer3D69.setPositiveItemLabelPositionFallback(itemLabelPosition78);
        org.jfree.chart.title.LegendTitle legendTitle80 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D69);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = legendTitle80.getLegendItemGraphicAnchor();
        java.awt.Font font82 = legendTitle80.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle80.setPosition(rectangleEdge83);
        org.jfree.chart.ChartColor chartColor88 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        legendTitle80.setBackgroundPaint((java.awt.Paint) chartColor88);
        valueMarker15.setOutlinePaint((java.awt.Paint) chartColor88);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        boolean boolean92 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.2d + "'", double57 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor81);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = waferMapPlot5.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        java.awt.Font font13 = dateAxis11.getLabelFont();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str18 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font13, (java.awt.Paint) chartColor17);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color2, paint9, (java.awt.Paint) chartColor17);
        java.awt.Paint paint21 = waterfallBarRenderer20.getLastBarPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#0a0a0a" + "'", str18.equals("#0a0a0a"));
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        try {
            java.lang.Number number4 = defaultKeyedValues2D0.getValue((java.lang.Comparable) 0.35d, (java.lang.Comparable) "({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: ({0}, {1}) = {2}");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        java.lang.Number number5 = null;
        defaultKeyedValues2D0.addValue(number5, (java.lang.Comparable) (-1L), (java.lang.Comparable) 10.0f);
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) true, (java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("#0a0a0a", graphics2D1, (float) 'a', 100.0f, (double) (short) -1, 0.0f, (float) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        java.awt.Paint paint28 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot17.zoomRangeAxes((double) (-1.0f), 100.0d, plotRenderingInfo31, point2D32);
        boolean boolean34 = xYPlot17.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        java.awt.Paint paint26 = legendTitle13.getItemPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedBarRenderer3D2.getBaseToolTipGenerator();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        ringPlot16.setCircular(false);
        java.awt.Paint paint19 = ringPlot16.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library26 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean27 = textLine21.equals((java.lang.Object) "#0a0a0a");
        boolean boolean28 = ringPlot16.equals((java.lang.Object) "#0a0a0a");
        java.awt.Stroke stroke29 = ringPlot16.getBaseSectionOutlineStroke();
        stackedBarRenderer3D2.setSeriesOutlineStroke(1, stroke29, true);
        java.io.ObjectOutputStream objectOutputStream32 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke29, objectOutputStream32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        double[] doubleArray17 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray24 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray31 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray32 = new double[][] { doubleArray17, doubleArray24, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray32);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) true, (org.jfree.data.general.Dataset) categoryDataset33);
        try {
            java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset33);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis0.getStandardTickUnits();
        double double4 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke((int) (byte) 1, stroke9);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) chartColor14);
        java.awt.color.ColorSpace colorSpace16 = chartColor14.getColorSpace();
        boolean boolean17 = sortOrder4.equals((java.lang.Object) chartColor14);
        ringPlot1.setBaseSectionPaint((java.awt.Paint) chartColor14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape5 = stackedBarRenderer3D2.getBaseShape();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D12.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape15 = stackedBarRenderer3D12.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot18 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        waferMapPlot18.addChangeListener(plotChangeListener20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot18);
        jFreeChart22.setBorderVisible(true);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart22.setBorderPaint((java.awt.Paint) color25);
        jFreeChart22.removeLegend();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart22.setBorderStroke(stroke28);
        java.awt.Color color30 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape15, stroke28, (java.awt.Paint) color30);
        stackedBarRenderer3D2.setBaseFillPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean7 = textLine1.equals((java.lang.Object) "#0a0a0a");
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textLine1.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        dateAxis0.setFixedAutoRange((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        int int4 = taskSeries1.getItemCount();
        java.lang.Comparable comparable5 = null;
        try {
            taskSeries1.setKey(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        dateAxis1.setLowerMargin((double) 1L);
        dateAxis1.zoomRange((-1.0d), (double) 9999);
        double double16 = dateAxis1.getFixedDimension();
        java.awt.Font font17 = dateAxis1.getLabelFont();
        boolean boolean18 = tickUnits0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("ThreadContext");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7, dataset8, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean15 = legendItemBlockContainer10.equals((java.lang.Object) chartColor14);
        java.util.List list16 = legendItemBlockContainer10.getBlocks();
        projectInfo0.setContributors(list16);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        waferMapPlot17.addChangeListener(plotChangeListener19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot17);
        jFreeChart21.setBorderVisible(true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart21.setBorderPaint((java.awt.Paint) color24);
        jFreeChart21.setBorderVisible(false);
        jFreeChart21.removeLegend();
        legendTitle13.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart21);
        jFreeChart21.setBackgroundImageAlignment((int) '4');
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "#0a0a0a");
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "#0a0a0a" + "'", obj2.equals("#0a0a0a"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        dateAxis8.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis8.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean15 = dateRange12.equals((java.lang.Object) rectangleEdge14);
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge14);
        java.lang.String str17 = rectangleEdge14.toString();
        try {
            double double18 = dateAxis0.valueToJava2D((double) 10.0f, rectangle2D7, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean30 = groupedStackedBarRenderer0.equals((java.lang.Object) segmentedTimeline29);
        double double31 = groupedStackedBarRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        stackedBarRenderer3D2.setBaseSeriesVisible(false, true);
        java.awt.Paint paint16 = stackedBarRenderer3D2.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D18 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint19 = lineRenderer3D18.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor21 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor21, textAnchor22);
        lineRenderer3D18.setSeriesPositiveItemLabelPosition(10, itemLabelPosition23);
        intervalBarRenderer17.setNegativeItemLabelPositionFallback(itemLabelPosition23);
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition23);
        java.awt.Shape shape28 = stackedBarRenderer3D2.lookupSeriesShape((int) '#');
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) "", (java.lang.Comparable) 10L);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "Layer.FOREGROUND", (double) 1L, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        java.lang.String str2 = lengthConstraintType1.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LengthConstraintType.NONE" + "'", str2.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getUseOutlinePaint();
        lineRenderer3D0.setUseFillPaint(false);
        lineRenderer3D0.setXOffset((double) 9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        stackedBarRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke18 = null;
        stackedBarRenderer3D16.setSeriesStroke(0, stroke18);
        stackedBarRenderer3D16.setBaseItemLabelsVisible(false);
        java.awt.Shape shape24 = stackedBarRenderer3D16.getItemShape((int) (short) 10, (-1));
        stackedBarRenderer3D11.setBaseShape(shape24);
        lineRenderer3D0.setSeriesShape((int) (byte) 100, shape24);
        java.awt.Stroke stroke28 = lineRenderer3D0.getSeriesStroke(3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (byte) 100;
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) numberTickUnit22);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) "12/31/69");
        java.lang.String str26 = legendItemEntity18.getToolTipText();
        java.lang.String str27 = legendItemEntity18.getURLText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            piePlot3D0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 9);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.setBorderVisible(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        java.awt.Paint paint28 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot17.zoomRangeAxes((double) (-1.0f), 100.0d, plotRenderingInfo31, point2D32);
        java.lang.Object obj34 = xYPlot17.clone();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot17.getRangeAxisForDataset(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.clearCornerTextItems();
        boolean boolean8 = polarPlot6.isRangeZoomable();
        java.lang.String str9 = polarPlot6.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setCircular(false);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        int int14 = ringPlot13.getPieIndex();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot13.setBaseSectionOutlineStroke(stroke15);
        ringPlot10.setSeparatorStroke(stroke15);
        polarPlot6.setRadiusGridlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        boolean boolean7 = segment5.contains((long) 3);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtTop();
        segmentedTimeline8.setExceptionSegments(list10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline8.getSegment((long) 10);
        boolean boolean14 = segment5.after(segment13);
        long long15 = segment5.getSegmentNumber();
        long long17 = segment5.calculateSegmentNumber(100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        lineRenderer3D0.setBaseShapesVisible(false);
        lineRenderer3D0.setSeriesShapesVisible((int) '4', (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke14 = null;
        stackedBarRenderer3D12.setSeriesStroke(0, stroke14);
        stackedBarRenderer3D12.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean20 = stackedBarRenderer3D12.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        stackedBarRenderer3D12.setPositiveItemLabelPositionFallback(itemLabelPosition21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle23.getLegendItemGraphicAnchor();
        java.awt.Font font25 = legendTitle23.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle23.setPosition(rectangleEdge26);
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        legendTitle23.setBackgroundPaint((java.awt.Paint) chartColor31);
        lineRenderer3D0.setSeriesItemLabelPaint(6, (java.awt.Paint) chartColor31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Object obj0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        waferMapPlot3.addChangeListener(plotChangeListener5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot3);
        jFreeChart7.setBorderVisible(true);
        float float10 = jFreeChart7.getBackgroundImageAlpha();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.addCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke9 = polarPlot6.getRadiusGridlineStroke();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock11, dataset12);
        polarPlot6.datasetChanged(datasetChangeEvent13);
        java.awt.Font font15 = polarPlot6.getAngleLabelFont();
        java.awt.Paint paint16 = null;
        try {
            polarPlot6.setAngleLabelPaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot17.getRenderer((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition5);
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setSeriesShapesFilled((int) (short) 1, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 432000000L + "'", long7 == 432000000L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        java.awt.Font font22 = xYPlot17.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot17.zoomDomainAxes((double) 86400000L, plotRenderingInfo24, point2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot17.getRangeAxisEdge(5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        java.awt.Font font26 = dateAxis24.getLabelFont();
        dateAxis24.setAutoTickUnitSelection(false);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot17.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot17.setFixedRangeAxisSpace(axisSpace31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(valueAxis30);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray2 = new float[] { '4' };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart6.getTitle();
        java.lang.Object obj10 = new java.lang.Object();
        boolean boolean11 = jFreeChart6.equals(obj10);
        int int12 = jFreeChart6.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getID();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        labelBlock1.setMargin(rectangleInsets9);
        double double11 = labelBlock1.getWidth();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.awt.Stroke stroke8 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(false);
        java.awt.Paint paint3 = null;
        try {
            ringPlot0.setSeparatorPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        ringPlot2.setToolTipGenerator(pieToolTipGenerator3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("Polar Plot", (org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Paint paint6 = ringPlot2.getBaseSectionPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = ringPlot2.getLegendItems();
        int int8 = legendItemCollection7.getItemCount();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setBaseItemLabelsVisible(false);
        boolean boolean23 = stackedBarRenderer3D17.getBaseCreateEntities();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer25 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer25.setSeriesPaint((int) '4', (java.awt.Paint) chartColor30, true);
        java.awt.Color color33 = java.awt.Color.orange;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor30, (java.awt.Paint) color33);
        stackedBarRenderer3D17.setSeriesItemLabelPaint(13, (java.awt.Paint) chartColor30, false);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) chartColor30);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isInverted();
        dateAxis38.resizeRange((double) (-1));
        dateAxis38.setTickLabelsVisible(false);
        java.lang.String str44 = dateAxis38.getLabelURL();
        java.awt.Font font45 = dateAxis38.getTickLabelFont();
        polarPlot0.setAngleLabelFont(font45);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font45);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D8.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D19.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape22 = stackedBarRenderer3D19.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        waferMapPlot25.addChangeListener(plotChangeListener27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot25);
        jFreeChart29.setBorderVisible(true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart29.setBorderPaint((java.awt.Paint) color32);
        jFreeChart29.removeLegend();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart29.setBorderStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape22, stroke35, (java.awt.Paint) color37);
        org.jfree.data.general.Dataset dataset39 = null;
        legendItem38.setDataset(dataset39);
        java.awt.Paint paint41 = legendItem38.getOutlinePaint();
        legendItemCollection11.add(legendItem38);
        java.awt.Paint paint43 = legendItem38.getLinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) (short) 10);
        java.awt.Shape shape4 = stackedBarRenderer3D2.getSeriesShape(1);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = null;
        dateAxis17.setStandardTickUnits(tickUnitSource21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke28 = null;
        stackedBarRenderer3D26.setSeriesStroke(0, stroke28);
        stackedBarRenderer3D26.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean34 = stackedBarRenderer3D26.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        stackedBarRenderer3D26.setPositiveItemLabelPositionFallback(itemLabelPosition35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D26);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer38 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor43 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer38.setSeriesPaint((int) '4', (java.awt.Paint) chartColor43, true);
        java.awt.Color color46 = java.awt.Color.orange;
        boolean boolean47 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor43, (java.awt.Paint) color46);
        legendTitle37.setBackgroundPaint((java.awt.Paint) chartColor43);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = legendTitle37.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendTitle37.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle37.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke56 = null;
        stackedBarRenderer3D54.setSeriesStroke(0, stroke56);
        stackedBarRenderer3D54.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean62 = stackedBarRenderer3D54.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = null;
        stackedBarRenderer3D54.setPositiveItemLabelPositionFallback(itemLabelPosition63);
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = legendTitle65.getLegendItemGraphicAnchor();
        java.awt.Font font67 = legendTitle65.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle65.setPosition(rectangleEdge68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = legendTitle65.getLegendItemGraphicEdge();
        double double71 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D51, rectangleEdge70);
        dateAxis17.setDownArrow((java.awt.Shape) rectangle2D51);
        try {
            legendTitle13.draw(graphics2D16, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) 'a', 0, (int) (byte) 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean6 = lineRenderer3D0.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        boolean boolean10 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D17.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape20 = stackedBarRenderer3D17.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        waferMapPlot23.addChangeListener(plotChangeListener25);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot23);
        jFreeChart27.setBorderVisible(true);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart27.setBorderPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart27.setBorderStroke(stroke33);
        java.awt.Color color35 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape20, stroke33, (java.awt.Paint) color35);
        lineRenderer3D0.setBaseStroke(stroke33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        java.awt.Font font7 = dateAxis0.getTickLabelFont();
        try {
            dateAxis0.setRangeAboutValue(0.0d, (double) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.57536E10) <= upper (-1.57536E10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = dateAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot10);
        java.util.Date date12 = dateAxis8.getMaximumDate();
        dateAxis1.setMaximumDate(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("VerticalAlignment.CENTER", (org.jfree.data.time.TimePeriod) year14);
        long long16 = year14.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year14.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation7 = axisLocation6.getOpposite();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.util.List list12 = jFreeChart6.getSubtitles();
        java.awt.Paint paint13 = jFreeChart6.getBorderPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.lang.String str2 = plotOrientation1.toString();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        stackedBarRenderer3D2.setDrawBarOutline(false);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setToolTipText("");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke(0, stroke9);
        stackedBarRenderer3D7.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean15 = stackedBarRenderer3D7.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedBarRenderer3D7.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D7);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer19 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer19.setSeriesPaint((int) '4', (java.awt.Paint) chartColor24, true);
        java.awt.Color color27 = java.awt.Color.orange;
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor24, (java.awt.Paint) color27);
        legendTitle18.setBackgroundPaint((java.awt.Paint) chartColor24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle18.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle18.getBounds();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isInverted();
        dateAxis34.resizeRange((double) (-1));
        dateAxis34.setTickLabelsVisible(false);
        dateAxis34.setLabelURL("");
        dateAxis34.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot46 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot46);
        java.util.Date date48 = dateAxis44.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer49);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot50.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot50.zoomDomainAxes((double) 'a', plotRenderingInfo54, point2D55);
        xYPlot50.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot50.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot50.getDomainAxisLocation((int) (byte) 10);
        try {
            java.lang.Object obj63 = labelBlock1.draw(graphics2D4, rectangle2D32, (java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        java.awt.Font font7 = dateAxis1.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        org.jfree.chart.block.BlockFrame blockFrame26 = legendTitle13.getFrame();
        java.lang.String str27 = legendTitle13.getID();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(blockFrame26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getPieIndex();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot3.setBaseSectionOutlineStroke(stroke5);
        ringPlot0.setSeparatorStroke(stroke5);
        ringPlot0.setSectionDepth((double) (short) 100);
        ringPlot0.setShadowYOffset((double) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects2D0.getColumnIndex(comparable1);
        java.util.List list3 = keyedObjects2D0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) borderArrangement1);
        java.awt.Paint paint3 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.configureDomainAxes();
        int int21 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = null;
        try {
            xYPlot17.setOrientation(plotOrientation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) labelBlock1);
        labelBlock1.setMargin((double) 10, (double) 3, (double) 0, (double) (-1));
        labelBlock1.setURLText("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        dateAxis0.setFixedAutoRange((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator3, false);
        java.awt.Stroke stroke7 = levelRenderer0.lookupSeriesStroke((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        float float9 = jFreeChart6.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle10 = null;
        try {
            jFreeChart6.addLegend(legendTitle10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = intervalBarRenderer0.getSeriesPaint((int) (short) 10);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        dateAxis0.centerRange((double) (short) -1);
        dateAxis0.setLowerMargin((double) 1L);
        dateAxis0.zoomRange((-1.0d), (double) 9999);
        double double15 = dateAxis0.getFixedDimension();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray25 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray32 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray39 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray40 = new double[][] { doubleArray25, doubleArray32, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray40);
        boolean boolean42 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset41);
        boolean boolean43 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset41);
        org.jfree.data.Range range44 = groupedStackedBarRenderer16.findRangeBounds(categoryDataset41);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline45 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean46 = groupedStackedBarRenderer16.equals((java.lang.Object) segmentedTimeline45);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer47 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray56 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray63 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray70 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray71 = new double[][] { doubleArray56, doubleArray63, doubleArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray71);
        org.jfree.data.Range range73 = groupedStackedBarRenderer47.findRangeBounds(categoryDataset72);
        org.jfree.data.Range range74 = groupedStackedBarRenderer16.findRangeBounds(categoryDataset72);
        java.lang.String str75 = range74.toString();
        dateAxis0.setRange(range74);
        double double77 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(segmentedTimeline45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Range[0.0,300.0]" + "'", str75.equals("Range[0.0,300.0]"));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        blockResult0.setEntityCollection(entityCollection3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        double double14 = range13.getLowerBound();
        boolean boolean17 = range13.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.data.Range range20 = org.jfree.data.Range.expand(range13, (double) 86400000L, (double) 6);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        int int22 = ringPlot21.getPieIndex();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot21.setBaseSectionOutlineStroke(stroke23);
        double double25 = ringPlot21.getInteriorGap();
        ringPlot21.setExplodePercent((java.lang.Comparable) "WMAP_Plot", (double) 5);
        boolean boolean29 = range13.equals((java.lang.Object) ringPlot21);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.25d + "'", double25 == 0.25d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset((double) (byte) 100);
        double double9 = rectangleInsets6.getBottom();
        double double10 = rectangleInsets6.getRight();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke15 = null;
        stackedBarRenderer3D13.setSeriesStroke(0, stroke15);
        stackedBarRenderer3D13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean21 = stackedBarRenderer3D13.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        stackedBarRenderer3D13.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D13);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer25 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer25.setSeriesPaint((int) '4', (java.awt.Paint) chartColor30, true);
        java.awt.Color color33 = java.awt.Color.orange;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor30, (java.awt.Paint) color33);
        legendTitle24.setBackgroundPaint((java.awt.Paint) chartColor30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = legendTitle24.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = legendTitle24.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle24.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke43 = null;
        stackedBarRenderer3D41.setSeriesStroke(0, stroke43);
        stackedBarRenderer3D41.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean49 = stackedBarRenderer3D41.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = null;
        stackedBarRenderer3D41.setPositiveItemLabelPositionFallback(itemLabelPosition50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = legendTitle52.getLegendItemGraphicAnchor();
        java.awt.Font font54 = legendTitle52.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle52.setPosition(rectangleEdge55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle52.getLegendItemGraphicEdge();
        double double58 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D38, rectangleEdge57);
        rectangleInsets6.trim(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        dateAxis0.setAutoTickUnitSelection(false);
        java.lang.String str5 = dateAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke6 = null;
        stackedBarRenderer3D4.setSeriesStroke(0, stroke6);
        stackedBarRenderer3D4.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        stackedBarRenderer3D4.notifyListeners(rendererChangeEvent10);
        stackedBarRenderer3D4.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range15 = stackedBarRenderer3D4.findRangeBounds(categoryDataset14);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedBarRenderer3D4.getBaseToolTipGenerator();
        java.awt.Font font17 = stackedBarRenderer3D4.getBaseItemLabelFont();
        ringPlot1.setLabelFont(font17);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer19 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer19.setSeriesPaint((int) '4', (java.awt.Paint) chartColor24, true);
        java.awt.Color color27 = java.awt.Color.orange;
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor24, (java.awt.Paint) color27);
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("", font17, (java.awt.Paint) color27);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke37 = null;
        stackedBarRenderer3D35.setSeriesStroke(0, stroke37);
        stackedBarRenderer3D35.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean43 = stackedBarRenderer3D35.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        stackedBarRenderer3D35.setPositiveItemLabelPositionFallback(itemLabelPosition44);
        stackedBarRenderer3D35.setBaseSeriesVisible(false, true);
        java.awt.Paint paint49 = stackedBarRenderer3D35.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D51 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint52 = lineRenderer3D51.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor54 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor54, textAnchor55);
        lineRenderer3D51.setSeriesPositiveItemLabelPosition(10, itemLabelPosition56);
        intervalBarRenderer50.setNegativeItemLabelPositionFallback(itemLabelPosition56);
        stackedBarRenderer3D35.setPositiveItemLabelPositionFallback(itemLabelPosition56);
        org.jfree.chart.text.TextAnchor textAnchor60 = itemLabelPosition56.getTextAnchor();
        try {
            textLine29.draw(graphics2D30, (float) 2958465, (float) (-1), textAnchor60, (float) (byte) 0, 0.0f, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(itemLabelAnchor54);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(textAnchor60);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("ThreadContext");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ThreadContext" + "'", str4.equals("ThreadContext"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer22 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer22.setSeriesPaint((int) '4', (java.awt.Paint) chartColor27, true);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) chartColor27);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11);
        boolean boolean32 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        int int8 = levelRenderer0.getColumnCount();
        double double9 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        boolean boolean4 = dateAxis0.isTickMarksVisible();
        dateAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setInverted(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        int int4 = lineRenderer3D0.getColumnCount();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean16 = stackedBarRenderer3D8.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D8);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer20 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer20.setSeriesPaint((int) '4', (java.awt.Paint) chartColor25, true);
        java.awt.Color color28 = java.awt.Color.orange;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor25, (java.awt.Paint) color28);
        legendTitle19.setBackgroundPaint((java.awt.Paint) chartColor25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement35 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment31, verticalAlignment32, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement35, dataset36, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor42 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean43 = legendItemBlockContainer38.equals((java.lang.Object) chartColor42);
        legendTitle19.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer38);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke49 = null;
        stackedBarRenderer3D47.setSeriesStroke((int) (byte) 1, stroke49);
        org.jfree.chart.ChartColor chartColor54 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D47.setBaseItemLabelPaint((java.awt.Paint) chartColor54);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = stackedBarRenderer3D47.getBaseNegativeItemLabelPosition();
        java.awt.Stroke stroke58 = stackedBarRenderer3D47.lookupSeriesStroke(4);
        boolean boolean59 = legendTitle19.equals((java.lang.Object) stroke58);
        lineRenderer3D0.setSeriesOutlineStroke((int) (short) 100, stroke58, true);
        boolean boolean62 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) (short) 10);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D3 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint4 = lineRenderer3D3.getWallPaint();
        lineRenderer3D3.setUseFillPaint(true);
        boolean boolean9 = lineRenderer3D3.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray30 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray37 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray38 = new double[][] { doubleArray23, doubleArray30, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray38);
        java.lang.String str42 = standardCategorySeriesLabelGenerator11.generateLabel(categoryDataset40, 0);
        org.jfree.data.Range range43 = stackedBarRenderer3D2.findRangeBounds(categoryDataset40);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str42.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ChartChangeEventType.NEW_DATASET");
        java.lang.Object obj2 = standardCategoryURLGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 1, stroke5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor10, stroke12);
        double double14 = valueMarker13.getValue();
        java.awt.Paint paint15 = valueMarker13.getOutlinePaint();
        java.awt.Paint paint16 = valueMarker13.getPaint();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        java.lang.Object obj5 = categoryAxis3D1.clone();
        double double6 = categoryAxis3D1.getUpperMargin();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        java.awt.Font font11 = dateAxis9.getLabelFont();
        java.awt.Font font12 = dateAxis9.getLabelFont();
        java.util.Date date13 = dateAxis9.getMaximumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean25 = stackedBarRenderer3D17.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer29 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer29.setSeriesPaint((int) '4', (java.awt.Paint) chartColor34, true);
        java.awt.Color color37 = java.awt.Color.orange;
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor34, (java.awt.Paint) color37);
        legendTitle28.setBackgroundPaint((java.awt.Paint) chartColor34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = legendTitle28.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendTitle28.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle28.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint44 = categoryPlot43.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot43.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset48 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock47, dataset48);
        categoryPlot43.datasetChanged(datasetChangeEvent49);
        boolean boolean51 = categoryPlot43.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke56 = null;
        stackedBarRenderer3D54.setSeriesStroke(0, stroke56);
        stackedBarRenderer3D54.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent60 = null;
        stackedBarRenderer3D54.notifyListeners(rendererChangeEvent60);
        stackedBarRenderer3D54.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer65 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor70 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer65.setSeriesPaint((int) '4', (java.awt.Paint) chartColor70, true);
        stackedBarRenderer3D54.setWallPaint((java.awt.Paint) chartColor70);
        categoryPlot43.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D54);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D77 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot43.setDomainAxis(13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D77, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = categoryPlot43.getDomainAxisEdge();
        double double81 = dateAxis9.java2DToValue(0.0d, rectangle2D42, rectangleEdge80);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list83 = categoryAxis3D1.refreshTicks(graphics2D7, axisState8, rectangle2D42, rectangleEdge82);
        int int84 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(list83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D6.getNegativeItemLabelPositionFallback();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D6.setSeriesPaint(10, (java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = null;
        dateAxis14.setStandardTickUnits(tickUnitSource18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis14.getLabelInsets();
        java.awt.Stroke stroke21 = dateAxis14.getAxisLineStroke();
        stackedBarRenderer3D6.setSeriesOutlineStroke((int) (byte) 100, stroke21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        stackedBarRenderer3D6.setWallPaint(paint23);
        boolean boolean25 = keyToGroupMap0.equals((java.lang.Object) paint23);
        int int26 = keyToGroupMap0.getGroupCount();
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart6.getTitle();
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart6.addProgressListener(chartProgressListener12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(textTitle11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot6.zoomDomainAxes((double) 9999, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        polarPlot6.zoomDomainAxes((double) '#', (double) (-2208960000000L), plotRenderingInfo13, point2D14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        dateAxis2.resizeRange((double) (-1));
        dateAxis2.setTickLabelsVisible(false);
        dateAxis2.setLabelURL("");
        dateAxis2.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot14);
        java.util.Date date16 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot18.zoomDomainAxes((double) 'a', plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isInverted();
        java.awt.Font font27 = dateAxis25.getLabelFont();
        dateAxis25.setAutoTickUnitSelection(false);
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        xYPlot18.mapDatasetToDomainAxis((int) 'a', (int) (short) 1);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", (org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot18.getRangeAxis();
        double double36 = xYPlot18.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Paint paint1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke6 = null;
        stackedBarRenderer3D4.setSeriesStroke((int) (byte) 1, stroke6);
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) chartColor11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D4.getBaseNegativeItemLabelPosition();
        java.awt.Stroke stroke15 = stackedBarRenderer3D4.lookupSeriesStroke(4);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", paint1, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth((int) 'a', 0.0d);
        layeredBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearRangeMarkers(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis((int) (byte) 1);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("#0a0a0a", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        java.awt.Font font7 = dateAxis0.getTickLabelFont();
        boolean boolean8 = dateAxis0.isInverted();
        java.awt.Font font9 = null;
        try {
            dateAxis0.setTickLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        ganttRenderer0.setMinimumBarLength((double) (short) 1);
        double double4 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.35d + "'", double4 == 0.35d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean6 = chartColor4.equals((java.lang.Object) intervalBarRenderer5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = intervalBarRenderer5.getGradientPaintTransformer();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) intervalBarRenderer5);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        int int10 = stackedBarRenderer3D2.getPassCount();
        java.awt.Stroke stroke13 = stackedBarRenderer3D2.getItemOutlineStroke((int) (short) 0, 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        boolean boolean19 = dateAxis0.isVisible();
        double double20 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearRangeMarkers(8);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D10.setUpperMargin(1.0E-5d);
        double double13 = categoryAxis3D10.getLabelAngle();
        java.lang.Object obj14 = categoryAxis3D10.clone();
        double double15 = categoryAxis3D10.getUpperMargin();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isInverted();
        java.awt.Font font20 = dateAxis18.getLabelFont();
        java.awt.Font font21 = dateAxis18.getLabelFont();
        java.util.Date date22 = dateAxis18.getMaximumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke28 = null;
        stackedBarRenderer3D26.setSeriesStroke(0, stroke28);
        stackedBarRenderer3D26.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean34 = stackedBarRenderer3D26.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        stackedBarRenderer3D26.setPositiveItemLabelPositionFallback(itemLabelPosition35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D26);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer38 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor43 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer38.setSeriesPaint((int) '4', (java.awt.Paint) chartColor43, true);
        java.awt.Color color46 = java.awt.Color.orange;
        boolean boolean47 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor43, (java.awt.Paint) color46);
        legendTitle37.setBackgroundPaint((java.awt.Paint) chartColor43);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = legendTitle37.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendTitle37.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle37.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint53 = categoryPlot52.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset54 = categoryPlot52.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset57 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent58 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock56, dataset57);
        categoryPlot52.datasetChanged(datasetChangeEvent58);
        boolean boolean60 = categoryPlot52.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke65 = null;
        stackedBarRenderer3D63.setSeriesStroke(0, stroke65);
        stackedBarRenderer3D63.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent69 = null;
        stackedBarRenderer3D63.notifyListeners(rendererChangeEvent69);
        stackedBarRenderer3D63.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer74 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor79 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer74.setSeriesPaint((int) '4', (java.awt.Paint) chartColor79, true);
        stackedBarRenderer3D63.setWallPaint((java.awt.Paint) chartColor79);
        categoryPlot52.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D63);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D86 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot52.setDomainAxis(13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D86, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot52.getDomainAxisEdge();
        double double90 = dateAxis18.java2DToValue(0.0d, rectangle2D51, rectangleEdge89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list92 = categoryAxis3D10.refreshTicks(graphics2D16, axisState17, rectangle2D51, rectangleEdge91);
        java.awt.geom.Point2D point2D93 = null;
        org.jfree.chart.plot.PlotState plotState94 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        categoryPlot0.draw(graphics2D8, rectangle2D51, point2D93, plotState94, plotRenderingInfo95);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-5d + "'", double15 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertNotNull(list92);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setSeriesShapesFilled(100, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean25 = stackedBarRenderer3D17.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition26);
        stackedBarRenderer3D17.setBaseSeriesVisible(false, true);
        java.awt.Paint paint31 = stackedBarRenderer3D17.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D33 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint34 = lineRenderer3D33.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor36, textAnchor37);
        lineRenderer3D33.setSeriesPositiveItemLabelPosition(10, itemLabelPosition38);
        intervalBarRenderer32.setNegativeItemLabelPositionFallback(itemLabelPosition38);
        stackedBarRenderer3D17.setPositiveItemLabelPositionFallback(itemLabelPosition38);
        org.jfree.chart.text.TextAnchor textAnchor42 = itemLabelPosition38.getTextAnchor();
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(4, itemLabelPosition38, false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = categoryLabelPosition1.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions4, categoryLabelPosition5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean10 = categoryLabelPositions8.equals((java.lang.Object) gradientPaintTransformType9);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions8, categoryLabelPosition11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions13, categoryLabelPosition14);
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryLabelPosition14.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions8, categoryLabelPosition14);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition1, categoryLabelPosition5, categoryLabelPosition7, categoryLabelPosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        boolean boolean6 = dateAxis0.isAutoTickUnitSelection();
        double double7 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot8.setDomainGridlinePaint(paint9);
        dateAxis0.setLabelPaint(paint9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        double double14 = range13.getLowerBound();
        boolean boolean17 = range13.intersects(8.0d, (double) 0L);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getPieIndex();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot3.setBaseSectionOutlineStroke(stroke5);
        org.jfree.chart.plot.Plot plot7 = ringPlot3.getRootPlot();
        ringPlot3.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.lang.Class<?> wildcardClass11 = ringPlot3.getClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", (java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass11);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(uRL14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        taskSeries1.removeChangeListener(seriesChangeListener2);
        taskSeries1.setKey((java.lang.Comparable) 0.35d);
        taskSeries1.setDescription("");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, 10.0d);
        flowArrangement4.clear();
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setDomainCrosshairVisible(false);
        java.awt.Font font22 = xYPlot17.getNoDataMessageFont();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (byte) 1, (float) (byte) -1, 0.0f);
        xYPlot17.setDomainZeroBaselinePaint((java.awt.Paint) color26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot17.getDomainAxis();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(valueAxis28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("Default Group");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        java.awt.Paint paint28 = xYPlot17.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot17.getRangeAxisLocation();
        int int30 = xYPlot17.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null");
        java.awt.Paint paint2 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        boolean boolean11 = stackedBarRenderer3D2.isSeriesVisibleInLegend(100);
        java.awt.Paint paint13 = stackedBarRenderer3D2.lookupSeriesFillPaint(7);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint17 = lineRenderer3D16.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor19, textAnchor20);
        lineRenderer3D16.setSeriesPositiveItemLabelPosition(10, itemLabelPosition21);
        intervalBarRenderer15.setNegativeItemLabelPositionFallback(itemLabelPosition21);
        stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition(3, itemLabelPosition21);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot26.getDomainAxisLocation();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke34 = null;
        stackedBarRenderer3D32.setSeriesStroke((int) (byte) 1, stroke34);
        org.jfree.chart.ChartColor chartColor39 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D32.setBaseItemLabelPaint((java.awt.Paint) chartColor39);
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor39, stroke41);
        float float43 = valueMarker42.getAlpha();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        categoryPlot26.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42, layer44);
        categoryPlot26.setRangeCrosshairValue((double) 1);
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke55 = null;
        stackedBarRenderer3D53.setSeriesStroke(0, stroke55);
        stackedBarRenderer3D53.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean61 = stackedBarRenderer3D53.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = null;
        stackedBarRenderer3D53.setPositiveItemLabelPositionFallback(itemLabelPosition62);
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D53);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer65 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor70 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer65.setSeriesPaint((int) '4', (java.awt.Paint) chartColor70, true);
        java.awt.Color color73 = java.awt.Color.orange;
        boolean boolean74 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor70, (java.awt.Paint) color73);
        legendTitle64.setBackgroundPaint((java.awt.Paint) chartColor70);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment76 = legendTitle64.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = legendTitle64.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D78 = legendTitle64.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D81 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke83 = null;
        stackedBarRenderer3D81.setSeriesStroke(0, stroke83);
        stackedBarRenderer3D81.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean89 = stackedBarRenderer3D81.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition90 = null;
        stackedBarRenderer3D81.setPositiveItemLabelPositionFallback(itemLabelPosition90);
        org.jfree.chart.title.LegendTitle legendTitle92 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D81);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor93 = legendTitle92.getLegendItemGraphicAnchor();
        java.awt.Font font94 = legendTitle92.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle92.setPosition(rectangleEdge95);
        org.jfree.chart.util.RectangleEdge rectangleEdge97 = legendTitle92.getLegendItemGraphicEdge();
        double double98 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D78, rectangleEdge97);
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D25, categoryPlot26, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment76);
        org.junit.Assert.assertNotNull(rectangleAnchor77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor93);
        org.junit.Assert.assertNotNull(font94);
        org.junit.Assert.assertNotNull(rectangleEdge95);
        org.junit.Assert.assertNotNull(rectangleEdge97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.util.List list2 = taskSeries1.getTasks();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", timePeriod6);
        java.lang.Double double8 = task7.getPercentComplete();
        taskSeries1.remove(task7);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D10 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D10.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D17.setUpperMargin(1.0E-5d);
        double double20 = categoryAxis3D17.getLabelAngle();
        java.lang.Object obj21 = categoryAxis3D17.clone();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isInverted();
        dateAxis22.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange26);
        java.util.Date date28 = dateRange26.getLowerDate();
        java.awt.Font font29 = categoryAxis3D17.getTickLabelFont((java.lang.Comparable) date28);
        defaultKeyedValues2D10.removeValue((java.lang.Comparable) "WMAP_Plot", (java.lang.Comparable) date28);
        taskSeries1.setKey((java.lang.Comparable) "WMAP_Plot");
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(double8);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        ringPlot0.setIgnoreZeroValues(true);
        java.awt.Paint paint10 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double[] doubleArray8 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray15 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray22 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray23 = new double[][] { doubleArray8, doubleArray15, doubleArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray23);
        boolean boolean25 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset24);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 100.0d + "'", number26.equals(100.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        dateAxis2.resizeRange((double) (-1));
        dateAxis2.setTickLabelsVisible(false);
        dateAxis2.setLabelURL("");
        dateAxis2.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot14);
        java.util.Date date16 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot18.zoomDomainAxes((double) 'a', plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isInverted();
        java.awt.Font font27 = dateAxis25.getLabelFont();
        dateAxis25.setAutoTickUnitSelection(false);
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        xYPlot18.mapDatasetToDomainAxis((int) 'a', (int) (short) 1);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", (org.jfree.chart.plot.Plot) xYPlot18);
        xYPlot18.setDomainCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Font font1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot5);
        jFreeChart9.setBorderVisible(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart9.setBorderPaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.getColor("UnitType.ABSOLUTE", color12);
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.LEFT", font1, (java.awt.Paint) color12, (float) 9, 1, textMeasurer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean30 = groupedStackedBarRenderer0.equals((java.lang.Object) segmentedTimeline29);
        org.jfree.data.KeyToGroupMap keyToGroupMap31 = null;
        try {
            groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'map' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        java.lang.Object obj5 = categoryAxis3D1.clone();
        categoryAxis3D1.setLowerMargin(0.0d);
        categoryAxis3D1.setCategoryLabelPositionOffset(3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setBaseItemLabelsVisible(false);
        boolean boolean23 = stackedBarRenderer3D17.getBaseCreateEntities();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer25 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer25.setSeriesPaint((int) '4', (java.awt.Paint) chartColor30, true);
        java.awt.Color color33 = java.awt.Color.orange;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor30, (java.awt.Paint) color33);
        stackedBarRenderer3D17.setSeriesItemLabelPaint(13, (java.awt.Paint) chartColor30, false);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) chartColor30);
        boolean boolean38 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis0.setTickUnit(dateTickUnit5, false, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.data.Range range22 = stackedBarRenderer3D11.findRangeBounds(categoryDataset21);
        double double23 = range22.getLowerBound();
        boolean boolean26 = range22.intersects((double) (short) 0, (double) (short) 0);
        double double27 = range22.getLength();
        dateAxis0.setRange(range22);
        java.awt.Stroke stroke29 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean6 = lineRenderer3D0.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        double[] doubleArray20 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray35 = new double[][] { doubleArray20, doubleArray27, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray35);
        java.lang.String str39 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset37, 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment40, verticalAlignment41, 0.0d, 2.0d);
        double[] doubleArray55 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray62 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray69 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray70 = new double[][] { doubleArray55, doubleArray62, doubleArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray70);
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray70);
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis();
        boolean boolean74 = dateAxis73.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot75 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis73.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot75);
        java.util.Date date77 = dateAxis73.getMaximumDate();
        boolean boolean78 = dateAxis73.isAutoRange();
        dateAxis73.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        boolean boolean82 = dateAxis81.isInverted();
        dateAxis81.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange85 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis81.setDefaultAutoRange((org.jfree.data.Range) dateRange85);
        java.util.Date date87 = dateRange85.getLowerDate();
        dateAxis73.setMaximumDate(date87);
        org.jfree.chart.text.TextAnchor textAnchor90 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions91 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition92 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions93 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions91, categoryLabelPosition92);
        org.jfree.chart.text.TextAnchor textAnchor94 = categoryLabelPosition92.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick96 = new org.jfree.chart.axis.DateTick(date87, "VerticalAlignment.CENTER", textAnchor90, textAnchor94, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer97 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement44, (org.jfree.data.general.Dataset) categoryDataset72, (java.lang.Comparable) date87);
        try {
            java.lang.String str99 = standardCategorySeriesLabelGenerator8.generateLabel(categoryDataset72, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str39.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(dateRange85);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(textAnchor90);
        org.junit.Assert.assertNotNull(categoryLabelPositions91);
        org.junit.Assert.assertNotNull(categoryLabelPositions93);
        org.junit.Assert.assertNotNull(textAnchor94);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) dateAxis7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis0.getTickMarkPosition();
        dateAxis0.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) '4');
        float float4 = ringPlot1.getBackgroundAlpha();
        ringPlot1.setShadowXOffset((double) 1L);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 1, stroke5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor10, stroke12);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.removeChangeListener(markerChangeListener14);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        int int17 = ringPlot16.getPieIndex();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke23 = null;
        stackedBarRenderer3D21.setSeriesStroke(0, stroke23);
        stackedBarRenderer3D21.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        stackedBarRenderer3D21.notifyListeners(rendererChangeEvent27);
        stackedBarRenderer3D21.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer32 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor37 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer32.setSeriesPaint((int) '4', (java.awt.Paint) chartColor37, true);
        stackedBarRenderer3D21.setWallPaint((java.awt.Paint) chartColor37);
        statisticalBarRenderer18.setErrorIndicatorPaint((java.awt.Paint) chartColor37);
        ringPlot16.setBaseSectionOutlinePaint((java.awt.Paint) chartColor37);
        java.awt.Paint paint43 = ringPlot16.getLabelShadowPaint();
        valueMarker13.setPaint(paint43);
        java.awt.Color color45 = java.awt.Color.YELLOW;
        valueMarker13.setOutlinePaint((java.awt.Paint) color45);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.String str20 = legendItemEntity18.toString();
        org.jfree.data.general.Dataset dataset21 = legendItemEntity18.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str20.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(dataset21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearRangeMarkers(8);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        lineRenderer3D0.setSeriesShapesFilled((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) '4');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke(0, stroke9);
        stackedBarRenderer3D7.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean15 = stackedBarRenderer3D7.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedBarRenderer3D7.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D7);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer19 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer19.setSeriesPaint((int) '4', (java.awt.Paint) chartColor24, true);
        java.awt.Color color27 = java.awt.Color.orange;
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor24, (java.awt.Paint) color27);
        legendTitle18.setBackgroundPaint((java.awt.Paint) chartColor24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle18.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle18.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke37 = null;
        stackedBarRenderer3D35.setSeriesStroke(0, stroke37);
        stackedBarRenderer3D35.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean43 = stackedBarRenderer3D35.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        stackedBarRenderer3D35.setPositiveItemLabelPositionFallback(itemLabelPosition44);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendTitle46.getLegendItemGraphicAnchor();
        java.awt.Font font48 = legendTitle46.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle46.setPosition(rectangleEdge49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = legendTitle46.getLegendItemGraphicEdge();
        double double52 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D32, rectangleEdge51);
        try {
            ringPlot1.drawBackground(graphics2D4, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        double double6 = stackedBarRenderer3D2.getYOffset();
        try {
            stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        boolean boolean4 = dateAxis0.isTickMarksVisible();
        org.jfree.data.Range range5 = dateAxis0.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.plot.Plot plot7 = jFreeChart6.getPlot();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        double double15 = range14.getLowerBound();
        boolean boolean16 = piePlot3D0.equals((java.lang.Object) double15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke21 = null;
        stackedBarRenderer3D19.setSeriesStroke(0, stroke21);
        stackedBarRenderer3D19.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean27 = stackedBarRenderer3D19.equals((java.lang.Object) 10.0f);
        stackedBarRenderer3D19.setBaseCreateEntities(true, true);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        int int33 = ringPlot32.getPieIndex();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot32.setBaseSectionOutlineStroke(stroke34);
        org.jfree.chart.plot.Plot plot36 = ringPlot32.getRootPlot();
        ringPlot32.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.awt.Stroke stroke40 = ringPlot32.getSeparatorStroke();
        stackedBarRenderer3D19.setSeriesOutlineStroke((int) '#', stroke40, true);
        piePlot3D0.setLabelLinkStroke(stroke40);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(plot36);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke11 = null;
        stackedBarRenderer3D9.setSeriesStroke(0, stroke11);
        stackedBarRenderer3D9.setBaseItemLabelsVisible(false);
        java.awt.Shape shape17 = stackedBarRenderer3D9.getItemShape((int) (short) 10, (-1));
        dateAxis1.setDownArrow(shape17);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        java.lang.String str20 = legendItemEntity19.toString();
        java.lang.Comparable comparable21 = legendItemEntity19.getSeriesKey();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        legendItemEntity19.setSeriesKey((java.lang.Comparable) numberTickUnit23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str27 = labelBlock26.getID();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot30 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis28.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot30);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = null;
        dateAxis28.setStandardTickUnits(tickUnitSource32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis28.getLabelInsets();
        labelBlock26.setMargin(rectangleInsets34);
        boolean boolean36 = numberTickUnit23.equals((java.lang.Object) labelBlock26);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection38 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list39 = axisCollection38.getAxesAtTop();
        segmentedTimeline37.setExceptionSegments(list39);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment42 = segmentedTimeline37.getSegment((long) 10);
        segment42.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment44 = segment42.copy();
        try {
            java.lang.Number number45 = defaultCategoryDataset0.getValue((java.lang.Comparable) numberTickUnit23, (java.lang.Comparable) segment42);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: org.jfree.chart.axis.SegmentedTimeline$Segment@30149a9c");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str20.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(segment42);
        org.junit.Assert.assertNotNull(segment44);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        ringPlot1.setInnerSeparatorExtension(1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D10.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getNegativeItemLabelPositionFallback();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D10.setSeriesPaint(10, (java.awt.Paint) color15);
        ringPlot1.setLabelPaint((java.awt.Paint) color15);
        ringPlot1.setCircular(false, false);
        java.awt.Paint paint21 = ringPlot1.getLabelLinkPaint();
        ringPlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 2.0d);
        double[] doubleArray15 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray22 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray29 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray30 = new double[][] { doubleArray15, doubleArray22, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot35 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot35);
        java.util.Date date37 = dateAxis33.getMaximumDate();
        boolean boolean38 = dateAxis33.isAutoRange();
        dateAxis33.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isInverted();
        dateAxis41.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis41.setDefaultAutoRange((org.jfree.data.Range) dateRange45);
        java.util.Date date47 = dateRange45.getLowerDate();
        dateAxis33.setMaximumDate(date47);
        org.jfree.chart.text.TextAnchor textAnchor50 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition52 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions51, categoryLabelPosition52);
        org.jfree.chart.text.TextAnchor textAnchor54 = categoryLabelPosition52.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick56 = new org.jfree.chart.axis.DateTick(date47, "VerticalAlignment.CENTER", textAnchor50, textAnchor54, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer57 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.data.general.Dataset) categoryDataset32, (java.lang.Comparable) date47);
        boolean boolean58 = legendItemBlockContainer57.isEmpty();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(textAnchor50);
        org.junit.Assert.assertNotNull(categoryLabelPositions51);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray20 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray35 = new double[][] { doubleArray20, doubleArray27, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray35);
        org.jfree.data.Range range37 = groupedStackedBarRenderer11.findRangeBounds(categoryDataset36);
        java.lang.Comparable comparable38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isInverted();
        java.awt.Font font41 = dateAxis39.getLabelFont();
        java.awt.Font font42 = dateAxis39.getLabelFont();
        java.text.DateFormat dateFormat45 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat45);
        dateAxis39.setTickUnit(dateTickUnit46);
        java.lang.String str49 = dateTickUnit46.valueToString(100.0d);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity50 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "RectangleEdge.LEFT", categoryDataset36, comparable38, (java.lang.Comparable) 100.0d);
        double[] doubleArray61 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray68 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray75 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray76 = new double[][] { doubleArray61, doubleArray68, doubleArray75 };
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray76);
        org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray76);
        categoryItemEntity50.setDataset(categoryDataset78);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "12/31/69" + "'", str49.equals("12/31/69"));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
        org.junit.Assert.assertNotNull(categoryDataset78);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7, categoryLabelWidthType8, (float) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor11 = categoryLabelPosition10.getRotationAnchor();
        try {
            java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("#0a0a0a", graphics2D1, (float) (byte) 100, (float) '#', textAnchor4, 0.0d, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Font font2 = dateAxis0.getLabelFont();
        java.awt.Font font3 = dateAxis0.getLabelFont();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat6);
        dateAxis0.setTickUnit(dateTickUnit7);
        java.lang.String str10 = dateTickUnit7.valueToString(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = dateTickUnit7.equals((java.lang.Object) dateAxis11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12/31/69" + "'", str10.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.util.List list12 = jFreeChart6.getSubtitles();
        java.lang.Object obj13 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        jFreeChart6.setTitle(textTitle15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke21 = null;
        stackedBarRenderer3D19.setSeriesStroke(0, stroke21);
        stackedBarRenderer3D19.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean27 = stackedBarRenderer3D19.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        stackedBarRenderer3D19.setPositiveItemLabelPositionFallback(itemLabelPosition28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D19);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer31 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer31.setSeriesPaint((int) '4', (java.awt.Paint) chartColor36, true);
        java.awt.Color color39 = java.awt.Color.orange;
        boolean boolean40 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor36, (java.awt.Paint) color39);
        legendTitle30.setBackgroundPaint((java.awt.Paint) chartColor36);
        java.awt.Paint paint42 = legendTitle30.getItemPaint();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke48 = null;
        stackedBarRenderer3D46.setSeriesStroke(0, stroke48);
        stackedBarRenderer3D46.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        stackedBarRenderer3D46.notifyListeners(rendererChangeEvent52);
        stackedBarRenderer3D46.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.data.Range range57 = stackedBarRenderer3D46.findRangeBounds(categoryDataset56);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint(range57, 0.0d);
        org.jfree.data.Range range60 = rectangleConstraint59.getHeightRange();
        org.jfree.chart.util.Size2D size2D61 = legendTitle30.arrange(graphics2D43, rectangleConstraint59);
        jFreeChart6.addLegend(legendTitle30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertNotNull(size2D61);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) 8, (java.lang.Comparable) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 9999");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(9999);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxisForDataset(10);
        java.util.List list10 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D13.setUpperMargin(1.0E-5d);
        double double16 = categoryAxis3D13.getLabelAngle();
        java.lang.Object obj17 = categoryAxis3D13.clone();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isInverted();
        dateAxis18.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis18.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        java.util.Date date24 = dateRange22.getLowerDate();
        java.awt.Font font25 = categoryAxis3D13.getTickLabelFont((java.lang.Comparable) date24);
        categoryAxis3D13.setMaximumCategoryLabelLines(0);
        categoryPlot0.setDomainAxis(1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = dateAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot10);
        java.util.Date date12 = dateAxis8.getMaximumDate();
        dateAxis1.setMaximumDate(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("VerticalAlignment.CENTER", (org.jfree.data.time.TimePeriod) year14);
        long long16 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.previous();
        int int18 = year14.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        try {
            java.lang.Number number7 = defaultKeyedValues2D0.getValue((int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D2.setSeriesPaint(10, (java.awt.Paint) color7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = null;
        dateAxis10.setStandardTickUnits(tickUnitSource14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis10.getLabelInsets();
        java.awt.Stroke stroke17 = dateAxis10.getAxisLineStroke();
        stackedBarRenderer3D2.setSeriesOutlineStroke((int) (byte) 100, stroke17);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint20 = lineRenderer3D19.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23);
        lineRenderer3D19.setSeriesPositiveItemLabelPosition(10, itemLabelPosition24);
        stackedBarRenderer3D2.setBaseNegativeItemLabelPosition(itemLabelPosition24, false);
        double double28 = itemLabelPosition24.getAngle();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot17.getAxisOffset();
        java.awt.Paint paint27 = xYPlot17.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        java.awt.Stroke stroke4 = null;
        try {
            stackedBarRenderer3D1.setBaseStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart6.setBorderStroke(stroke12);
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart6.removeProgressListener(chartProgressListener14);
        java.awt.RenderingHints renderingHints16 = null;
        try {
            jFreeChart6.setRenderingHints(renderingHints16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Color color0 = java.awt.Color.black;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 1969;
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        java.util.Date date6 = dateRange4.getLowerDate();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, 0.0d, 2.0d);
        double[] doubleArray22 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray29 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray36 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray37 = new double[][] { doubleArray22, doubleArray29, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean41 = dateAxis40.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot42 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis40.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot42);
        java.util.Date date44 = dateAxis40.getMaximumDate();
        boolean boolean45 = dateAxis40.isAutoRange();
        dateAxis40.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isInverted();
        dateAxis48.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange52 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis48.setDefaultAutoRange((org.jfree.data.Range) dateRange52);
        java.util.Date date54 = dateRange52.getLowerDate();
        dateAxis40.setMaximumDate(date54);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions58 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition59 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions60 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions58, categoryLabelPosition59);
        org.jfree.chart.text.TextAnchor textAnchor61 = categoryLabelPosition59.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick63 = new org.jfree.chart.axis.DateTick(date54, "VerticalAlignment.CENTER", textAnchor57, textAnchor61, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer64 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11, (org.jfree.data.general.Dataset) categoryDataset39, (java.lang.Comparable) date54);
        org.jfree.data.time.DateRange dateRange65 = new org.jfree.data.time.DateRange(date6, date54);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateRange52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(categoryLabelPositions58);
        org.junit.Assert.assertNotNull(categoryLabelPositions60);
        org.junit.Assert.assertNotNull(textAnchor61);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("#0a0a0a");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        waferMapPlot5.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = waferMapPlot5.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        java.awt.Font font13 = dateAxis11.getLabelFont();
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str18 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor17);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font13, (java.awt.Paint) chartColor17);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer20 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color2, paint9, (java.awt.Paint) chartColor17);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = waterfallBarRenderer20.getPlot();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#0a0a0a" + "'", str18.equals("#0a0a0a"));
        org.junit.Assert.assertNull(categoryPlot21);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        java.awt.Paint paint28 = legendItem25.getOutlinePaint();
        int int29 = legendItem25.getDatasetIndex();
        boolean boolean30 = legendItem25.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Stroke stroke5 = lineRenderer3D0.lookupSeriesOutlineStroke((int) (byte) 1);
        boolean boolean8 = lineRenderer3D0.getItemShapeVisible(10, 500);
        java.lang.Object obj9 = lineRenderer3D0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke6 = null;
        stackedBarRenderer3D4.setSeriesStroke(0, stroke6);
        stackedBarRenderer3D4.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        stackedBarRenderer3D4.notifyListeners(rendererChangeEvent10);
        stackedBarRenderer3D4.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range15 = stackedBarRenderer3D4.findRangeBounds(categoryDataset14);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedBarRenderer3D4.getBaseToolTipGenerator();
        java.awt.Font font17 = stackedBarRenderer3D4.getBaseItemLabelFont();
        ringPlot1.setLabelFont(font17);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer19 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer19.setSeriesPaint((int) '4', (java.awt.Paint) chartColor24, true);
        java.awt.Color color27 = java.awt.Color.orange;
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor24, (java.awt.Paint) color27);
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("", font17, (java.awt.Paint) color27);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        int int31 = ringPlot30.getPieIndex();
        boolean boolean32 = ringPlot30.getIgnoreZeroValues();
        double double33 = ringPlot30.getInteriorGap();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke39 = null;
        stackedBarRenderer3D37.setSeriesStroke((int) (byte) 1, stroke39);
        org.jfree.chart.ChartColor chartColor44 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D37.setBaseItemLabelPaint((java.awt.Paint) chartColor44);
        boolean boolean46 = itemLabelAnchor34.equals((java.lang.Object) chartColor44);
        ringPlot30.setBaseSectionPaint((java.awt.Paint) chartColor44);
        float[] floatArray54 = new float[] { 2958465, (byte) -1, (-1), 15, 0, (short) -1 };
        float[] floatArray55 = chartColor44.getComponents(floatArray54);
        float[] floatArray56 = color27.getColorComponents(floatArray55);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.25d + "'", double33 == 0.25d);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean5 = chartColor3.equals((java.lang.Object) intervalBarRenderer4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = intervalBarRenderer4.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = intervalBarRenderer4.getSeriesItemLabelGenerator(9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.resizeRange((double) (-1));
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setLabelURL("");
        dateAxis5.centerRange((double) (short) -1);
        dateAxis5.setLowerMargin((double) 1L);
        dateAxis5.zoomRange((-1.0d), (double) 9999);
        double double20 = dateAxis5.getFixedDimension();
        org.jfree.data.Range range21 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        float float22 = dateAxis5.getTickMarkOutsideLength();
        dateAxis5.setVerticalTickLabels(true);
        dateAxis5.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(9999);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxisForDataset(10);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection12 = categoryPlot0.getDomainMarkers((int) (byte) 1, layer11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 100;
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setSeriesShapesFilled(100, true);
        java.awt.Paint paint15 = lineRenderer3D0.lookupSeriesFillPaint(3);
        lineRenderer3D0.setBaseLinesVisible(false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        double double5 = categoryAxis3D1.getUpperMargin();
        int int6 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        int int8 = ringPlot7.getPieIndex();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot7.setBaseSectionOutlineStroke(stroke9);
        double double11 = ringPlot7.getInteriorGap();
        double double12 = ringPlot7.getMinimumArcAngleToDraw();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str15 = labelBlock14.getID();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot18 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot18);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = null;
        dateAxis16.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis16.getLabelInsets();
        labelBlock14.setMargin(rectangleInsets22);
        ringPlot7.setInsets(rectangleInsets22, false);
        double double27 = rectangleInsets22.calculateLeftOutset((double) 172800000L);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.25d + "'", double11 == 0.25d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0E-5d + "'", double12 == 1.0E-5d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.clearRangeMarkers(8);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D4.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.KeyedObject keyedObject7 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) 100, (java.lang.Object) true);
        java.lang.Comparable comparable8 = keyedObject7.getKey();
        boolean boolean9 = shapeList0.equals((java.lang.Object) comparable8);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        int int11 = ringPlot10.getPieIndex();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot10.setBaseSectionOutlineStroke(stroke12);
        double double14 = ringPlot10.getInteriorGap();
        double double15 = ringPlot10.getMinimumArcAngleToDraw();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str18 = labelBlock17.getID();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis19.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = null;
        dateAxis19.setStandardTickUnits(tickUnitSource23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis19.getLabelInsets();
        labelBlock17.setMargin(rectangleInsets25);
        ringPlot10.setInsets(rectangleInsets25, false);
        boolean boolean29 = shapeList0.equals((java.lang.Object) ringPlot10);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 100 + "'", comparable8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25d + "'", double14 == 0.25d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-5d + "'", double15 == 1.0E-5d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        dateAxis2.resizeRange((double) (-1));
        dateAxis2.setTickLabelsVisible(false);
        dateAxis2.setLabelURL("");
        dateAxis2.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot14 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot14);
        java.util.Date date16 = dateAxis12.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot18.zoomDomainAxes((double) 'a', plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        int int26 = xYPlot18.getIndexOf(xYItemRenderer25);
        java.awt.Stroke stroke27 = xYPlot18.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = xYPlot18.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(plotOrientation28);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        boolean boolean11 = stackedBarRenderer3D2.isSeriesVisibleInLegend(100);
        java.awt.Paint paint13 = stackedBarRenderer3D2.lookupSeriesFillPaint(7);
        java.awt.Font font14 = null;
        stackedBarRenderer3D2.setBaseItemLabelFont(font14, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = dateAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot10);
        java.util.Date date12 = dateAxis8.getMaximumDate();
        dateAxis1.setMaximumDate(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("VerticalAlignment.CENTER", (org.jfree.data.time.TimePeriod) year14);
        task15.setDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        waferMapPlot2.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer8 = null;
        waferMapPlot2.setRenderer(waferMapRenderer8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        lineRenderer3D0.setBaseShapesVisible(false);
        lineRenderer3D0.setSeriesShapesVisible((int) '4', (java.lang.Boolean) true);
        boolean boolean9 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke7);
        java.awt.Shape shape9 = dateAxis0.getDownArrow();
        dateAxis0.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ClassContext", graphics2D1, (-1.0f), (float) 15, (double) 10, (-1.0f), (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        long long7 = segmentedTimeline0.getSegmentSize();
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment15, 0.0d, 2.0d);
        double[] doubleArray29 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray36 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray43 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray44);
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis47.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot49 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot49);
        java.util.Date date51 = dateAxis47.getMaximumDate();
        boolean boolean52 = dateAxis47.isAutoRange();
        dateAxis47.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        boolean boolean56 = dateAxis55.isInverted();
        dateAxis55.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis55.setDefaultAutoRange((org.jfree.data.Range) dateRange59);
        java.util.Date date61 = dateRange59.getLowerDate();
        dateAxis47.setMaximumDate(date61);
        org.jfree.chart.text.TextAnchor textAnchor64 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions65 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition66 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions67 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions65, categoryLabelPosition66);
        org.jfree.chart.text.TextAnchor textAnchor68 = categoryLabelPosition66.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick70 = new org.jfree.chart.axis.DateTick(date61, "VerticalAlignment.CENTER", textAnchor64, textAnchor68, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer71 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement18, (org.jfree.data.general.Dataset) categoryDataset46, (java.lang.Comparable) date61);
        java.util.Date date72 = dateTickUnit13.addToDate(date61);
        boolean boolean73 = segmentedTimeline0.containsDomainValue(date61);
        java.util.TimeZone timeZone74 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date61, timeZone74);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateRange59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(textAnchor64);
        org.junit.Assert.assertNotNull(categoryLabelPositions65);
        org.junit.Assert.assertNotNull(categoryLabelPositions67);
        org.junit.Assert.assertNotNull(textAnchor68);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeZone74);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        boolean boolean20 = xYPlot17.isDomainCrosshairVisible();
        boolean boolean21 = xYPlot17.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot17.setRangeAxisLocation(13, axisLocation23);
        java.awt.Paint paint25 = xYPlot17.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isInverted();
        dateAxis26.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke36 = null;
        stackedBarRenderer3D34.setSeriesStroke(0, stroke36);
        stackedBarRenderer3D34.setBaseItemLabelsVisible(false);
        java.awt.Shape shape42 = stackedBarRenderer3D34.getItemShape((int) (short) 10, (-1));
        dateAxis26.setDownArrow(shape42);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis26);
        xYPlot17.axisChanged(axisChangeEvent44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        segment5.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segment5.copy();
        segment7.dec((long) 1);
        long long10 = segment7.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(2, itemLabelPosition2, false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        java.awt.Font font8 = dateAxis6.getLabelFont();
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str13 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor12);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font8, (java.awt.Paint) chartColor12);
        boolean boolean15 = statisticalBarRenderer0.equals((java.lang.Object) textFragment14);
        java.awt.Paint paint16 = null;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#0a0a0a" + "'", str13.equals("#0a0a0a"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (short) 1, (double) 15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Paint paint2 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = polarPlot0.getRenderer();
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(polarItemRenderer3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int3 = java.awt.Color.HSBtoRGB(2.0f, (float) 100, (float) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1255) + "'", int3 == (-1255));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        segment5.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segment5.copy();
        segment7.dec((long) 1);
        segment7.moveIndexToStart();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segment7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean9 = chartColor7.equals((java.lang.Object) intervalBarRenderer8);
        stackedBarRenderer3D2.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor7, false);
        stackedBarRenderer3D2.setSeriesVisibleInLegend(9, (java.lang.Boolean) false, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D19.setUpperMargin(1.0E-5d);
        double double22 = categoryAxis3D19.getLabelAngle();
        java.lang.Object obj23 = categoryAxis3D19.clone();
        categoryAxis3D19.setLowerMargin(0.0d);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke31 = null;
        stackedBarRenderer3D29.setSeriesStroke(0, stroke31);
        stackedBarRenderer3D29.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean37 = stackedBarRenderer3D29.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        stackedBarRenderer3D29.setPositiveItemLabelPositionFallback(itemLabelPosition38);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D29);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer41 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor46 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer41.setSeriesPaint((int) '4', (java.awt.Paint) chartColor46, true);
        java.awt.Color color49 = java.awt.Color.orange;
        boolean boolean50 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor46, (java.awt.Paint) color49);
        legendTitle40.setBackgroundPaint((java.awt.Paint) chartColor46);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = legendTitle40.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = legendTitle40.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D54 = legendTitle40.getBounds();
        try {
            stackedBarRenderer3D2.drawDomainMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, categoryMarker26, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineRenderer3D0.getSeriesNegativeItemLabelPosition(13);
        boolean boolean15 = lineRenderer3D0.getItemLineVisible((int) '#', 7);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D8.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D8.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D19.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape22 = stackedBarRenderer3D19.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot25 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        waferMapPlot25.addChangeListener(plotChangeListener27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot25);
        jFreeChart29.setBorderVisible(true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart29.setBorderPaint((java.awt.Paint) color32);
        jFreeChart29.removeLegend();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart29.setBorderStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape22, stroke35, (java.awt.Paint) color37);
        org.jfree.data.general.Dataset dataset39 = null;
        legendItem38.setDataset(dataset39);
        legendItemCollection11.add(legendItem38);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        double double43 = dateAxis42.getAutoRangeMinimumSize();
        boolean boolean44 = legendItem38.equals((java.lang.Object) double43);
        boolean boolean45 = legendItem38.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        int int4 = lineRenderer3D0.getColumnCount();
        boolean boolean5 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        lineRenderer3D0.setYOffset(0.0d);
        boolean boolean9 = lineRenderer3D0.isSeriesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        boolean boolean13 = stackedBarRenderer3D2.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        dateAxis0.zoomRange((double) 7, (double) 10.0f);
        boolean boolean22 = dateAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = lineRenderer3D0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        try {
            legendItemCollection1.addAll(legendItemCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) 'a');
        categoryPlot0.setRangeCrosshairValue(0.0d);
        java.lang.Object obj6 = categoryPlot0.clone();
        java.lang.String str7 = categoryPlot0.getPlotType();
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke8 = null;
        stackedBarRenderer3D6.setSeriesStroke(0, stroke8);
        stackedBarRenderer3D6.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean13 = categoryLabelPosition1.equals((java.lang.Object) stackedBarRenderer3D6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryLabelPosition1.getLabelAnchor();
        float float15 = categoryLabelPosition1.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.95f + "'", float15 == 0.95f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(false);
        java.awt.Paint paint3 = ringPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int3 = java.awt.Color.HSBtoRGB((float) 900000L, (float) (-1255), (float) 172800000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "#0a0a0a");
        java.lang.Object obj2 = rendererChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = rendererChangeEvent1.getType();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "#0a0a0a" + "'", obj2.equals("#0a0a0a"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        waferMapPlot9.addChangeListener(plotChangeListener11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot9);
        jFreeChart13.setBorderVisible(true);
        double[] doubleArray24 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray31 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray38 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray39 = new double[][] { doubleArray24, doubleArray31, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) true, (org.jfree.data.general.Dataset) categoryDataset40);
        categoryPlot0.setDataset(6, categoryDataset40);
        try {
            org.jfree.data.general.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset40, (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextBlockAnchor.CENTER");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit3);
        double double5 = numberTickUnit3.getSize();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D8 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D8.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineRenderer3D8.drawRangeMarker(graphics2D11, categoryPlot12, valueAxis13, marker14, rectangle2D15);
        boolean boolean19 = lineRenderer3D8.getItemLineVisible((int) (short) 0, 0);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isInverted();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke29 = null;
        stackedBarRenderer3D27.setSeriesStroke((int) (byte) 1, stroke29);
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D27.setBaseItemLabelPaint((java.awt.Paint) chartColor34);
        java.awt.Stroke stroke36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor34, stroke36);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener38 = null;
        valueMarker37.removeChangeListener(markerChangeListener38);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        lineRenderer3D8.drawRangeMarker(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.plot.Marker) valueMarker37, rectangle2D40);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str43 = layer42.toString();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37, layer42);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        int int46 = ringPlot45.getPieIndex();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot45.setBaseSectionOutlineStroke(stroke47);
        org.jfree.chart.plot.Plot plot49 = ringPlot45.getRootPlot();
        ringPlot45.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        ringPlot45.setIgnoreZeroValues(true);
        java.awt.Stroke stroke55 = ringPlot45.getLabelLinkStroke();
        valueMarker37.setStroke(stroke55);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Layer.FOREGROUND" + "'", str43.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(plot49);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        segment5.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segment5.copy();
        segment7.dec((long) 1);
        boolean boolean12 = segment7.contained((long) 500, (long) 'a');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke31 = null;
        stackedBarRenderer3D29.setSeriesStroke(0, stroke31);
        stackedBarRenderer3D29.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        stackedBarRenderer3D29.notifyListeners(rendererChangeEvent35);
        stackedBarRenderer3D29.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.data.Range range40 = stackedBarRenderer3D29.findRangeBounds(categoryDataset39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range40, 0.0d);
        org.jfree.data.Range range43 = rectangleConstraint42.getHeightRange();
        org.jfree.chart.util.Size2D size2D44 = legendTitle13.arrange(graphics2D26, rectangleConstraint42);
        double double45 = rectangleConstraint42.getWidth();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D1.setUseFillPaint(true);
        lineRenderer3D1.setUseOutlinePaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = lineRenderer3D1.getBaseToolTipGenerator();
        java.awt.Font font9 = lineRenderer3D1.getItemLabelFont(9999, (int) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("12/31/69", font9);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot9);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) dateAxis7);
        dateAxis0.setTickMarkInsideLength((float) 9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.data.Range range13 = stackedBarRenderer3D2.findRangeBounds(categoryDataset12);
        double double14 = range13.getLowerBound();
        boolean boolean17 = range13.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        boolean boolean19 = range13.equals((java.lang.Object) itemLabelAnchor18);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        int int2 = ringPlot1.getPieIndex();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot1.setBaseSectionOutlineStroke(stroke3);
        org.jfree.chart.plot.Plot plot5 = ringPlot1.getRootPlot();
        ringPlot1.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.lang.Class<?> wildcardClass9 = ringPlot1.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("CategoryLabelWidthType.RANGE", (java.lang.Class) wildcardClass9);
        boolean boolean11 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean6 = lineRenderer3D0.getItemShapeFilled((int) (byte) 1, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        lineRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        boolean boolean10 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke12 = lineRenderer3D0.lookupSeriesOutlineStroke(9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineRenderer3D0.getNegativeItemLabelPosition((int) (byte) 1, 2958465);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.Range range1 = null;
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        dateAxis7.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setDefaultAutoRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange11.getLowerDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange3, lengthConstraintType5, (double) 500, (org.jfree.data.Range) dateRange11, lengthConstraintType15);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray41 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray42 = new double[][] { doubleArray27, doubleArray34, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray42);
        boolean boolean44 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset43);
        boolean boolean45 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset43);
        org.jfree.data.Range range46 = groupedStackedBarRenderer18.findRangeBounds(categoryDataset43);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline47 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean48 = groupedStackedBarRenderer18.equals((java.lang.Object) segmentedTimeline47);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer49 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray58 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray65 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray72 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray73 = new double[][] { doubleArray58, doubleArray65, doubleArray72 };
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray73);
        org.jfree.data.Range range75 = groupedStackedBarRenderer49.findRangeBounds(categoryDataset74);
        org.jfree.data.Range range76 = groupedStackedBarRenderer18.findRangeBounds(categoryDataset74);
        java.lang.String str77 = range76.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType78 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint(4.0d, range1, lengthConstraintType15, (double) 0L, range76, lengthConstraintType78);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(segmentedTimeline47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(categoryDataset74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Range[0.0,300.0]" + "'", str77.equals("Range[0.0,300.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType78);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedBarRenderer3D2.setSeriesToolTipGenerator(10, categoryToolTipGenerator9, false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("#0a0a0a", "UnitType.ABSOLUTE", "LengthConstraintType.NONE", "LegendItemEntity: seriesKey=null, dataset=null");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        try {
            dateAxis0.setRange((double) 5, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        java.lang.Number number5 = null;
        defaultKeyedValues2D0.addValue(number5, (java.lang.Comparable) (-1L), (java.lang.Comparable) 10.0f);
        java.lang.Comparable comparable11 = null;
        try {
            defaultKeyedValues2D0.setValue((java.lang.Number) (byte) 10, (java.lang.Comparable) 1.0f, comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("ThreadContext");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        projectInfo0.setCopyright("({0}, {1}) = {2}");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        int int4 = lineRenderer3D0.getColumnCount();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean16 = stackedBarRenderer3D8.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D8);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer20 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer20.setSeriesPaint((int) '4', (java.awt.Paint) chartColor25, true);
        java.awt.Color color28 = java.awt.Color.orange;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor25, (java.awt.Paint) color28);
        legendTitle19.setBackgroundPaint((java.awt.Paint) chartColor25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement35 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment31, verticalAlignment32, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement35, dataset36, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor42 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean43 = legendItemBlockContainer38.equals((java.lang.Object) chartColor42);
        legendTitle19.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer38);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke49 = null;
        stackedBarRenderer3D47.setSeriesStroke((int) (byte) 1, stroke49);
        org.jfree.chart.ChartColor chartColor54 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D47.setBaseItemLabelPaint((java.awt.Paint) chartColor54);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = stackedBarRenderer3D47.getBaseNegativeItemLabelPosition();
        java.awt.Stroke stroke58 = stackedBarRenderer3D47.lookupSeriesStroke(4);
        boolean boolean59 = legendTitle19.equals((java.lang.Object) stroke58);
        lineRenderer3D0.setSeriesOutlineStroke((int) (short) 100, stroke58, true);
        lineRenderer3D0.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke69 = null;
        stackedBarRenderer3D67.setSeriesStroke(0, stroke69);
        stackedBarRenderer3D67.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent73 = null;
        stackedBarRenderer3D67.notifyListeners(rendererChangeEvent73);
        boolean boolean76 = stackedBarRenderer3D67.isSeriesVisibleInLegend(100);
        java.awt.Paint paint78 = stackedBarRenderer3D67.lookupSeriesFillPaint(7);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer80 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D81 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint82 = lineRenderer3D81.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor84 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor85 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition86 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor84, textAnchor85);
        lineRenderer3D81.setSeriesPositiveItemLabelPosition(10, itemLabelPosition86);
        intervalBarRenderer80.setNegativeItemLabelPositionFallback(itemLabelPosition86);
        stackedBarRenderer3D67.setSeriesNegativeItemLabelPosition(3, itemLabelPosition86);
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition86, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertNotNull(itemLabelAnchor84);
        org.junit.Assert.assertNotNull(textAnchor85);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowYOffset((double) 'a');
        java.awt.Paint paint4 = ringPlot0.getBaseSectionPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke9 = null;
        stackedBarRenderer3D7.setSeriesStroke((int) (byte) 1, stroke9);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) chartColor14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D7.getBaseNegativeItemLabelPosition();
        java.awt.Stroke stroke18 = stackedBarRenderer3D7.lookupSeriesStroke(4);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis19.getTickLabelInsets();
        java.lang.String str22 = rectangleInsets21.toString();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder(paint4, stroke18, rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str22.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        boolean boolean2 = stackedAreaRenderer1.getRenderAsPercentages();
        int int3 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setIgnoreZeroValues(false);
        boolean boolean4 = paintList0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D2.getItemVisible(1, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = stackedBarRenderer3D2.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("({0}, {1}) = {3} - {4}", "PlotOrientation.VERTICAL", "org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", "org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) chartColor5, true);
        int int8 = levelRenderer0.getColumnCount();
        double double9 = levelRenderer0.getItemMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke16 = null;
        stackedBarRenderer3D14.setSeriesStroke(0, stroke16);
        stackedBarRenderer3D14.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean22 = stackedBarRenderer3D14.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        stackedBarRenderer3D14.setPositiveItemLabelPositionFallback(itemLabelPosition23);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D14);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer26 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer26.setSeriesPaint((int) '4', (java.awt.Paint) chartColor31, true);
        java.awt.Color color34 = java.awt.Color.orange;
        boolean boolean35 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor31, (java.awt.Paint) color34);
        legendTitle25.setBackgroundPaint((java.awt.Paint) chartColor31);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = legendTitle25.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendTitle25.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle25.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke44 = null;
        stackedBarRenderer3D42.setSeriesStroke(0, stroke44);
        stackedBarRenderer3D42.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean50 = stackedBarRenderer3D42.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = null;
        stackedBarRenderer3D42.setPositiveItemLabelPositionFallback(itemLabelPosition51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = legendTitle53.getLegendItemGraphicAnchor();
        java.awt.Font font55 = legendTitle53.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle53.setPosition(rectangleEdge56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = legendTitle53.getLegendItemGraphicEdge();
        double double59 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D39, rectangleEdge58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint61 = categoryPlot60.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset63 = categoryPlot60.getDataset((int) 'a');
        categoryPlot60.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D67 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D67.setUpperMargin(1.0E-5d);
        double double70 = categoryAxis3D67.getLabelAngle();
        java.lang.Object obj71 = categoryAxis3D67.clone();
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        boolean boolean73 = dateAxis72.isInverted();
        dateAxis72.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange76 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis72.setDefaultAutoRange((org.jfree.data.Range) dateRange76);
        java.util.Date date78 = dateRange76.getLowerDate();
        java.awt.Font font79 = categoryAxis3D67.getTickLabelFont((java.lang.Comparable) date78);
        org.jfree.chart.axis.DateAxis dateAxis80 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset81 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            levelRenderer0.drawItem(graphics2D10, categoryItemRendererState11, rectangle2D39, categoryPlot60, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D67, (org.jfree.chart.axis.ValueAxis) dateAxis80, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset81, (int) (short) 100, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(categoryDataset63);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dateRange76);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(font79);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Font font5 = dateAxis3.getLabelFont();
        boolean boolean6 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) font5);
        java.awt.Paint paint7 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        try {
            statisticalLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean30 = groupedStackedBarRenderer0.equals((java.lang.Object) segmentedTimeline29);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer31 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray40 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray47 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray54 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray55 = new double[][] { doubleArray40, doubleArray47, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray55);
        org.jfree.data.Range range57 = groupedStackedBarRenderer31.findRangeBounds(categoryDataset56);
        org.jfree.data.Range range58 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset56);
        org.jfree.data.KeyToGroupMap keyToGroupMap59 = new org.jfree.data.KeyToGroupMap();
        keyToGroupMap59.mapKeyToGroup((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 1);
        groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap59);
        int int64 = groupedStackedBarRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getPieIndex();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot2.setBaseSectionOutlineStroke(stroke4);
        org.jfree.chart.plot.Plot plot6 = ringPlot2.getRootPlot();
        ringPlot2.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        java.lang.Class<?> wildcardClass10 = ringPlot2.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(inputStream12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle1.getText();
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        java.awt.Paint paint8 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.CENTER" + "'", str6.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        boolean boolean2 = stackedAreaRenderer1.getRenderAsPercentages();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getPieIndex();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        stackedBarRenderer3D8.notifyListeners(rendererChangeEvent14);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer19 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer19.setSeriesPaint((int) '4', (java.awt.Paint) chartColor24, true);
        stackedBarRenderer3D8.setWallPaint((java.awt.Paint) chartColor24);
        statisticalBarRenderer5.setErrorIndicatorPaint((java.awt.Paint) chartColor24);
        ringPlot3.setBaseSectionOutlinePaint((java.awt.Paint) chartColor24);
        boolean boolean30 = stackedAreaRenderer1.hasListener((java.util.EventListener) ringPlot3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = levelRenderer0.getSeriesItemLabelGenerator((int) (byte) 10);
        levelRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.setNoDataMessage("#0a0a0a");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke35 = null;
        stackedBarRenderer3D33.setSeriesStroke((int) (byte) 1, stroke35);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D33.setBaseItemLabelPaint((java.awt.Paint) chartColor40);
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor40, stroke42);
        xYPlot17.setRangeZeroBaselineStroke(stroke42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setVisible(false);
        xYPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        xYPlot17.clearDomainMarkers((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        java.awt.Paint paint28 = legendItem25.getFillPaint();
        java.lang.String str29 = legendItem25.getURLText();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(2, itemLabelPosition2, false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        java.awt.Font font8 = dateAxis6.getLabelFont();
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        java.lang.String str13 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color) chartColor12);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font8, (java.awt.Paint) chartColor12);
        boolean boolean15 = statisticalBarRenderer0.equals((java.lang.Object) textFragment14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        java.awt.Font font21 = dateAxis19.getLabelFont();
        boolean boolean22 = statisticalLineAndShapeRenderer18.equals((java.lang.Object) font21);
        java.awt.Paint paint23 = statisticalLineAndShapeRenderer18.getErrorIndicatorPaint();
        boolean boolean24 = statisticalBarRenderer0.equals((java.lang.Object) paint23);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#0a0a0a" + "'", str13.equals("#0a0a0a"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) 'a');
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D7 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D7.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        lineRenderer3D7.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        lineRenderer3D7.setBaseShapesFilled(false);
        lineRenderer3D7.setSeriesShapesFilled(100, true);
        java.awt.Paint paint22 = lineRenderer3D7.lookupSeriesFillPaint(3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D25.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D25.getNegativeItemLabelPositionFallback();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D25.setSeriesPaint(10, (java.awt.Paint) color30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot35 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot35);
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = null;
        dateAxis33.setStandardTickUnits(tickUnitSource37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis33.getLabelInsets();
        java.awt.Stroke stroke40 = dateAxis33.getAxisLineStroke();
        stackedBarRenderer3D25.setSeriesOutlineStroke((int) (byte) 100, stroke40);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D42 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint43 = lineRenderer3D42.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor45 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor45, textAnchor46);
        lineRenderer3D42.setSeriesPositiveItemLabelPosition(10, itemLabelPosition47);
        stackedBarRenderer3D25.setBaseNegativeItemLabelPosition(itemLabelPosition47, false);
        lineRenderer3D7.setBaseNegativeItemLabelPosition(itemLabelPosition47, true);
        categoryPlot0.setRenderer(500, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D7, true);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        boolean boolean57 = dateAxis56.isInverted();
        dateAxis56.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis56.setDefaultAutoRange((org.jfree.data.Range) dateRange60);
        categoryPlot0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis56);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(itemLabelAnchor45);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateRange60);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = categoryPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        dateAxis5.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        java.util.Date date11 = dateRange9.getLowerDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = rectangleConstraint12.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange1, lengthConstraintType3, (double) 500, (org.jfree.data.Range) dateRange9, lengthConstraintType13);
        java.lang.String str15 = lengthConstraintType13.toString();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LengthConstraintType.NONE" + "'", str15.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23, dataset24, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean31 = legendItemBlockContainer26.equals((java.lang.Object) chartColor30);
        legendTitle13.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = legendTitle13.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle13.getLegendItemGraphicPadding();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        boolean boolean6 = dateAxis0.isAutoTickUnitSelection();
        java.text.DateFormat dateFormat7 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateFormat7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        java.awt.Font font4 = dateAxis2.getLabelFont();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setCircular(false);
        java.awt.Paint paint10 = ringPlot7.getLabelShadowPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint10, (float) 900000L, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock13.draw(graphics2D14, (float) 1969, 0.0f, textBlockAnchor17, (float) 0L, (float) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D7 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D7.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D14.setUpperMargin(1.0E-5d);
        double double17 = categoryAxis3D14.getLabelAngle();
        java.lang.Object obj18 = categoryAxis3D14.clone();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isInverted();
        dateAxis19.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        java.util.Date date25 = dateRange23.getLowerDate();
        java.awt.Font font26 = categoryAxis3D14.getTickLabelFont((java.lang.Comparable) date25);
        defaultKeyedValues2D7.removeValue((java.lang.Comparable) "WMAP_Plot", (java.lang.Comparable) date25);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment28 = segmentedTimeline0.getSegment(date25);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(segment28);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean7 = dateRange4.equals((java.lang.Object) rectangleEdge6);
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot17.getDomainAxis();
        xYPlot17.setRangeCrosshairLockedOnData(false);
        xYPlot17.setWeight((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(valueAxis20);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        java.awt.Font font13 = dateAxis11.getLabelFont();
        dateAxis11.setAutoTickUnitSelection(false);
        boolean boolean16 = dateAxis11.isVisible();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke21 = null;
        stackedBarRenderer3D19.setSeriesStroke(0, stroke21);
        stackedBarRenderer3D19.setBaseItemLabelsVisible(false);
        java.awt.Shape shape27 = stackedBarRenderer3D19.getItemShape((int) (short) 10, (-1));
        dateAxis11.setUpArrow(shape27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment30, verticalAlignment31, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement34, dataset35, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor41 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean42 = legendItemBlockContainer37.equals((java.lang.Object) chartColor41);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer44 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor49 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer44.setSeriesPaint((int) '4', (java.awt.Paint) chartColor49, true);
        java.awt.Color color52 = java.awt.Color.orange;
        boolean boolean53 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor49, (java.awt.Paint) color52);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer56 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        boolean boolean58 = dateAxis57.isInverted();
        dateAxis57.resizeRange((double) (-1));
        dateAxis57.setTickLabelsVisible(false);
        dateAxis57.setLabelURL("");
        java.awt.Shape shape65 = dateAxis57.getRightArrow();
        intervalBarRenderer56.setBaseShape(shape65);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        boolean boolean69 = dateAxis68.isInverted();
        java.awt.Font font70 = dateAxis68.getLabelFont();
        java.awt.Font font71 = dateAxis68.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer72 = null;
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot(xYDataset67, (org.jfree.chart.axis.ValueAxis) dateAxis68, polarItemRenderer72);
        polarPlot73.addCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Stroke stroke76 = polarPlot73.getRadiusGridlineStroke();
        java.awt.Color color77 = java.awt.Color.cyan;
        org.jfree.chart.LegendItem legendItem78 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "VerticalAlignment.CENTER", "Layer.FOREGROUND", "RectangleEdge.BOTTOM", true, shape27, true, (java.awt.Paint) chartColor41, false, (java.awt.Paint) chartColor49, stroke54, true, shape65, stroke76, (java.awt.Paint) color77);
        boolean boolean79 = ringPlot1.equals((java.lang.Object) false);
        java.awt.Paint paint80 = ringPlot1.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(paint80);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        double double3 = ringPlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot1.markerChanged(markerChangeEvent4);
        ringPlot1.setInnerSeparatorExtension(1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D10.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D10.getNegativeItemLabelPositionFallback();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D10.setSeriesPaint(10, (java.awt.Paint) color15);
        ringPlot1.setLabelPaint((java.awt.Paint) color15);
        ringPlot1.setCircular(false, false);
        java.awt.Paint paint21 = ringPlot1.getLabelLinkPaint();
        java.lang.String str22 = ringPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pie Plot" + "'", str22.equals("Pie Plot"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        dateAxis2.resizeRange(0.5d);
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-2208960000000L));
        shapeList7.setShape(4, shape10);
        dateAxis2.setDownArrow(shape10);
        boolean boolean13 = ringPlot0.equals((java.lang.Object) dateAxis2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer1 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer1.setSeriesBarWidth((int) 'a', 0.0d);
        double double5 = layeredBarRenderer1.getItemMargin();
        boolean boolean6 = verticalAlignment0.equals((java.lang.Object) layeredBarRenderer1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        dateAxis0.setLowerMargin((double) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        double double4 = categoryAxis3D1.getLabelAngle();
        java.lang.Object obj5 = categoryAxis3D1.clone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        dateAxis6.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setDefaultAutoRange((org.jfree.data.Range) dateRange10);
        java.util.Date date12 = dateRange10.getLowerDate();
        java.awt.Font font13 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) date12);
        categoryAxis3D1.setMaximumCategoryLabelLines(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions16, categoryLabelPosition17);
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis3D1.setCategoryLabelPositionOffset(5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke((int) (byte) 1, stroke4);
        double double6 = stackedBarRenderer3D2.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D3.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) 100, (java.lang.Object) true);
        java.lang.Object obj7 = keyedObject6.getObject();
        java.lang.Object obj8 = keyedObject6.getObject();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        keyedObject6.setObject((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + true + "'", obj7.equals(true));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + true + "'", obj8.equals(true));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer14 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer14.setSeriesPaint((int) '4', (java.awt.Paint) chartColor19, true);
        java.awt.Color color22 = java.awt.Color.orange;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor19, (java.awt.Paint) color22);
        legendTitle13.setBackgroundPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint25 = legendTitle13.getItemPaint();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke31 = null;
        stackedBarRenderer3D29.setSeriesStroke(0, stroke31);
        stackedBarRenderer3D29.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        stackedBarRenderer3D29.notifyListeners(rendererChangeEvent35);
        stackedBarRenderer3D29.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.data.Range range40 = stackedBarRenderer3D29.findRangeBounds(categoryDataset39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range40, 0.0d);
        org.jfree.data.Range range43 = rectangleConstraint42.getHeightRange();
        org.jfree.chart.util.Size2D size2D44 = legendTitle13.arrange(graphics2D26, rectangleConstraint42);
        size2D44.setHeight(1.0d);
        size2D44.height = 0.05d;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(size2D44);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(2958465);
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) "ThreadContext");
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        boolean boolean2 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart6.setBorderPaint((java.awt.Paint) color9);
        jFreeChart6.removeLegend();
        java.util.List list12 = jFreeChart6.getSubtitles();
        java.lang.Object obj13 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        jFreeChart6.setTitle(textTitle15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart6.getLegend(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        boolean boolean7 = segment5.contains((long) 3);
        long long8 = segment5.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.Object obj2 = dataPackageResources0.getObject("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key Category Plot");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean5 = lineRenderer3D0.getItemLineVisible((int) (byte) 100, 10);
        java.lang.Object obj6 = lineRenderer3D0.clone();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke11 = null;
        stackedBarRenderer3D9.setSeriesStroke(0, stroke11);
        stackedBarRenderer3D9.setBaseItemLabelsVisible(false);
        java.awt.Shape shape17 = stackedBarRenderer3D9.getItemShape((int) (short) 10, (-1));
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean27 = chartColor25.equals((java.lang.Object) intervalBarRenderer26);
        stackedBarRenderer3D20.setSeriesOutlinePaint((int) '#', (java.awt.Paint) chartColor25, false);
        stackedBarRenderer3D9.setBasePaint((java.awt.Paint) chartColor25, true);
        lineRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) chartColor25, false);
        lineRenderer3D0.setSeriesShapesFilled((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        xYPlot17.configureDomainAxes();
        float float21 = xYPlot17.getForegroundAlpha();
        java.awt.Stroke stroke22 = xYPlot17.getRangeCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        org.jfree.chart.axis.TickUnits tickUnits2 = new org.jfree.chart.axis.TickUnits();
        dateAxis0.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits2);
        java.text.DateFormat dateFormat8 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat8);
        int int10 = dateTickUnit9.getCalendarField();
        tickUnits2.add((org.jfree.chart.axis.TickUnit) dateTickUnit9);
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat14);
        java.lang.Object obj16 = null;
        boolean boolean17 = dateTickUnit15.equals(obj16);
        org.jfree.chart.axis.TickUnit tickUnit18 = tickUnits2.getLargerTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tickUnit18);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D3.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        stackedBarRenderer3D3.setBaseSeriesVisible(false, true);
        java.awt.Paint paint17 = stackedBarRenderer3D3.getBaseFillPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint20 = lineRenderer3D19.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23);
        lineRenderer3D19.setSeriesPositiveItemLabelPosition(10, itemLabelPosition24);
        intervalBarRenderer18.setNegativeItemLabelPositionFallback(itemLabelPosition24);
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition24);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition24.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor29 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor28, textAnchor29, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        boolean boolean6 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D13.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape16 = stackedBarRenderer3D13.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot19 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        waferMapPlot19.addChangeListener(plotChangeListener21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot19);
        jFreeChart23.setBorderVisible(true);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart23.setBorderPaint((java.awt.Paint) color26);
        jFreeChart23.removeLegend();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart23.setBorderStroke(stroke29);
        java.awt.Color color31 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape16, stroke29, (java.awt.Paint) color31);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity35 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis0, shape16, "", "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator36 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator37 = null;
        java.lang.String str38 = axisLabelEntity35.getImageMapAreaTag(toolTipTagFragmentGenerator36, uRLTagFragmentGenerator37);
        org.jfree.chart.axis.Axis axis39 = axisLabelEntity35.getAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNull(axis39);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Font font3 = dateAxis1.getLabelFont();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        polarPlot6.clearCornerTextItems();
        polarPlot6.setAngleGridlinesVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = null;
        dateAxis11.setStandardTickUnits(tickUnitSource15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis11.getLabelInsets();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke22 = null;
        stackedBarRenderer3D20.setSeriesStroke(0, stroke22);
        stackedBarRenderer3D20.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean28 = stackedBarRenderer3D20.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        stackedBarRenderer3D20.setPositiveItemLabelPositionFallback(itemLabelPosition29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D20);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer32 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor37 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer32.setSeriesPaint((int) '4', (java.awt.Paint) chartColor37, true);
        java.awt.Color color40 = java.awt.Color.orange;
        boolean boolean41 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor37, (java.awt.Paint) color40);
        legendTitle31.setBackgroundPaint((java.awt.Paint) chartColor37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = legendTitle31.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle31.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D45 = legendTitle31.getBounds();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke50 = null;
        stackedBarRenderer3D48.setSeriesStroke(0, stroke50);
        stackedBarRenderer3D48.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean56 = stackedBarRenderer3D48.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedBarRenderer3D48.setPositiveItemLabelPositionFallback(itemLabelPosition57);
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = legendTitle59.getLegendItemGraphicAnchor();
        java.awt.Font font61 = legendTitle59.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle59.setPosition(rectangleEdge62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = legendTitle59.getLegendItemGraphicEdge();
        double double65 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D45, rectangleEdge64);
        dateAxis11.setDownArrow((java.awt.Shape) rectangle2D45);
        java.awt.geom.Point2D point2D67 = null;
        org.jfree.chart.plot.PlotState plotState68 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        polarPlot6.draw(graphics2D10, rectangle2D45, point2D67, plotState68, plotRenderingInfo69);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-1255));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        java.awt.Shape shape16 = stackedBarRenderer3D8.getItemShape((int) (short) 10, (-1));
        dateAxis0.setDownArrow(shape16);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        java.lang.String str19 = legendItemEntity18.toString();
        java.lang.Comparable comparable20 = legendItemEntity18.getSeriesKey();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) numberTickUnit22);
        legendItemEntity18.setSeriesKey((java.lang.Comparable) "12/31/69");
        java.lang.String str26 = legendItemEntity18.getToolTipText();
        java.awt.Shape shape27 = legendItemEntity18.getArea();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str19.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin(1.0E-5d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        java.awt.Font font7 = dateAxis5.getLabelFont();
        java.awt.Font font8 = dateAxis5.getLabelFont();
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) "#0a0a0a", font8);
        categoryAxis3D1.configure();
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
        double double13 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        java.awt.Font font16 = stackedBarRenderer3D3.getBaseItemLabelFont();
        ringPlot0.setLabelFont(font16);
        ringPlot0.setSectionOutlinesVisible(true);
        double double20 = ringPlot0.getInteriorGap();
        boolean boolean21 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.25d + "'", double20 == 0.25d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        dateAxis0.resizeRange(0.5d);
        java.awt.Font font5 = dateAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot0.setDomainGridlinePaint(paint1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        categoryPlot0.setRenderer(5, (org.jfree.chart.renderer.category.CategoryItemRenderer) waterfallBarRenderer2);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer4 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer4.setSeriesPaint((int) '4', (java.awt.Paint) chartColor9, true);
        java.awt.Color color12 = java.awt.Color.orange;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor9, (java.awt.Paint) color12);
        waterfallBarRenderer2.setNegativeBarPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        stackedBarRenderer3D2.setBaseSeriesVisible(false, true);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isInverted();
        dateAxis16.resizeRange((double) (-1));
        dateAxis16.setTickLabelsVisible(false);
        dateAxis16.setLabelURL("");
        java.awt.Shape shape24 = dateAxis16.getRightArrow();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray36 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray43 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray50 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray51);
        org.jfree.data.Range range53 = groupedStackedBarRenderer27.findRangeBounds(categoryDataset52);
        java.lang.Comparable comparable54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        boolean boolean56 = dateAxis55.isInverted();
        java.awt.Font font57 = dateAxis55.getLabelFont();
        java.awt.Font font58 = dateAxis55.getLabelFont();
        java.text.DateFormat dateFormat61 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit62 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat61);
        dateAxis55.setTickUnit(dateTickUnit62);
        java.lang.String str65 = dateTickUnit62.valueToString(100.0d);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity66 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "RectangleEdge.LEFT", categoryDataset52, comparable54, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range67 = stackedBarRenderer3D2.findRangeBounds(categoryDataset52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "12/31/69" + "'", str65.equals("12/31/69"));
        org.junit.Assert.assertNotNull(range67);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) 'a');
        java.awt.Paint paint4 = categoryPlot0.getRangeCrosshairPaint();
        boolean boolean5 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setOuterSeparatorExtension((double) 0L);
        boolean boolean5 = ringPlot0.getIgnoreZeroValues();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D3.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) 100, (java.lang.Object) true);
        java.lang.Object obj7 = keyedObject6.getObject();
        java.lang.Object obj8 = keyedObject6.getObject();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        waferMapPlot11.addChangeListener(plotChangeListener13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot11);
        jFreeChart15.setBorderVisible(true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart15.setBorderPaint((java.awt.Paint) color18);
        jFreeChart15.setBorderVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart15.getLegend();
        org.jfree.chart.event.TitleChangeListener titleChangeListener23 = null;
        legendTitle22.addChangeListener(titleChangeListener23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle22.getLegendItemGraphicPadding();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray35 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray42 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray49 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray50 = new double[][] { doubleArray35, doubleArray42, doubleArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray50);
        org.jfree.data.Range range52 = groupedStackedBarRenderer26.findRangeBounds(categoryDataset51);
        boolean boolean53 = legendTitle22.equals((java.lang.Object) groupedStackedBarRenderer26);
        boolean boolean54 = keyedObject6.equals((java.lang.Object) legendTitle22);
        keyedObject6.setObject((java.lang.Object) "12/31/69");
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + true + "'", obj7.equals(true));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + true + "'", obj8.equals(true));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        segmentedTimeline0.setExceptionSegments(list2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((long) 10);
        boolean boolean7 = segment5.contains((long) 3);
        segment5.dec((long) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getRangeCrosshairPaint();
        categoryPlot10.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke15 = categoryPlot10.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot10.getRangeAxisEdge(9999);
        int int18 = categoryPlot10.getDatasetCount();
        try {
            int int19 = segment5.compareTo((java.lang.Object) int18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.resizeRange((double) (-1));
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setLabelURL("");
        dateAxis0.centerRange((double) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        dateAxis11.resizeRange((double) (-1));
        dateAxis11.setTickLabelsVisible(false);
        dateAxis11.setLabelURL("");
        dateAxis11.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot23);
        java.util.Date date25 = dateAxis21.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot27.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomDomainAxes((double) 'a', plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isInverted();
        java.awt.Font font36 = dateAxis34.getLabelFont();
        dateAxis34.setAutoTickUnitSelection(false);
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot27.getRangeAxis();
        boolean boolean41 = dateAxis0.hasListener((java.util.EventListener) xYPlot27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray43 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer42 };
        xYPlot27.setRenderers(xYItemRendererArray43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray43);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        boolean boolean10 = stackedBarRenderer3D2.getBaseSeriesVisible();
        java.awt.Paint paint13 = stackedBarRenderer3D2.getItemLabelPaint(2958465, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        lineRenderer3D0.setBaseShapesVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineRenderer3D0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        waferMapPlot4.addChangeListener(plotChangeListener6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart8.setBorderVisible(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart8.setBorderPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("UnitType.ABSOLUTE", color11);
        polarPlot0.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setBaseItemLabelsVisible(false);
        boolean boolean23 = stackedBarRenderer3D17.getBaseCreateEntities();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer25 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer25.setSeriesPaint((int) '4', (java.awt.Paint) chartColor30, true);
        java.awt.Color color33 = java.awt.Color.orange;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor30, (java.awt.Paint) color33);
        stackedBarRenderer3D17.setSeriesItemLabelPaint(13, (java.awt.Paint) chartColor30, false);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) chartColor30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 500, plotRenderingInfo39, point2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj1 = chartRenderingInfo0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        stackedBarRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke10 = null;
        stackedBarRenderer3D8.setSeriesStroke(0, stroke10);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false);
        stackedBarRenderer3D8.setBaseItemLabelsVisible(false, true);
        java.awt.Stroke stroke19 = stackedBarRenderer3D8.getItemStroke(7, 0);
        stackedBarRenderer3D2.setSeriesStroke((int) (short) 1, stroke19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot22.setRenderer(5, categoryItemRenderer26, true);
        java.awt.Stroke stroke29 = categoryPlot22.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke34 = null;
        stackedBarRenderer3D32.setSeriesStroke(0, stroke34);
        stackedBarRenderer3D32.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean40 = stackedBarRenderer3D32.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        stackedBarRenderer3D32.setPositiveItemLabelPositionFallback(itemLabelPosition41);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D32);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer44 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor49 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer44.setSeriesPaint((int) '4', (java.awt.Paint) chartColor49, true);
        java.awt.Color color52 = java.awt.Color.orange;
        boolean boolean53 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor49, (java.awt.Paint) color52);
        legendTitle43.setBackgroundPaint((java.awt.Paint) chartColor49);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = legendTitle43.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = legendTitle43.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D57 = legendTitle43.getBounds();
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D21, categoryPlot22, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        java.awt.Paint paint28 = legendItem25.getOutlinePaint();
        java.awt.Shape shape29 = legendItem25.getLine();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = null;
        try {
            piePlot3D0.setNoDataMessagePaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', 100L);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D5.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D5.getNegativeItemLabelPositionFallback();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        stackedBarRenderer3D5.setSeriesPaint(10, (java.awt.Paint) color10);
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 100L, (java.lang.Object) 10);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("VerticalAlignment.CENTER", graphics2D1, (float) 1L, (float) 1L, textAnchor4, (double) 0L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        int int25 = xYPlot17.getIndexOf(xYItemRenderer24);
        java.awt.Stroke stroke26 = xYPlot17.getRangeGridlineStroke();
        float float27 = xYPlot17.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, 10.0d);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean6 = flowArrangement4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset12, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean19 = legendItemBlockContainer14.equals((java.lang.Object) chartColor18);
        java.util.List list20 = legendItemBlockContainer14.getBlocks();
        java.util.List list21 = legendItemBlockContainer14.getBlocks();
        org.jfree.chart.block.Arrangement arrangement22 = legendItemBlockContainer14.getArrangement();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = null;
        try {
            org.jfree.chart.util.Size2D size2D25 = flowArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer14, graphics2D23, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(arrangement22);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer5 = new org.jfree.chart.renderer.category.LevelRenderer();
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) levelRenderer5);
        double double7 = levelRenderer5.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = dateAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot10);
        java.util.Date date12 = dateAxis8.getMaximumDate();
        dateAxis1.setMaximumDate(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("VerticalAlignment.CENTER", (org.jfree.data.time.TimePeriod) year14);
        long long16 = year14.getLastMillisecond();
        long long17 = year14.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.Object obj2 = labelBlock1.clone();
        labelBlock1.setID("LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        xYPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot17.getAxisOffset();
        xYPlot17.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke17 = null;
        stackedBarRenderer3D15.setSeriesStroke(0, stroke17);
        stackedBarRenderer3D15.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        stackedBarRenderer3D15.notifyListeners(rendererChangeEvent21);
        stackedBarRenderer3D15.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.data.Range range26 = stackedBarRenderer3D15.findRangeBounds(categoryDataset25);
        double double27 = range26.getLowerBound();
        boolean boolean30 = range26.intersects((double) (short) 0, (double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range26, 100.0d);
        org.jfree.chart.util.Size2D size2D33 = columnArrangement4.arrange(blockContainer11, graphics2D12, rectangleConstraint32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment35, 100.0d, 10.0d);
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement38, dataset39, (java.lang.Comparable) 10.0d);
        org.jfree.chart.ChartColor chartColor45 = new org.jfree.chart.ChartColor(0, (int) (short) 10, 0);
        boolean boolean46 = legendItemBlockContainer41.equals((java.lang.Object) chartColor45);
        java.util.List list47 = legendItemBlockContainer41.getBlocks();
        java.util.List list48 = legendItemBlockContainer41.getBlocks();
        org.jfree.chart.block.Arrangement arrangement49 = legendItemBlockContainer41.getArrangement();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = null;
        try {
            org.jfree.chart.util.Size2D size2D52 = columnArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer41, graphics2D50, rectangleConstraint51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(arrangement49);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke7 = null;
        stackedBarRenderer3D5.setSeriesStroke(0, stroke7);
        stackedBarRenderer3D5.setBaseItemLabelsVisible(false);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D5.setSeriesOutlinePaint(10, paint12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        ringPlot14.setCircular(false);
        java.awt.Paint paint17 = ringPlot14.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library24 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean25 = textLine19.equals((java.lang.Object) "#0a0a0a");
        boolean boolean26 = ringPlot14.equals((java.lang.Object) "#0a0a0a");
        java.awt.Stroke stroke27 = ringPlot14.getBaseSectionOutlineStroke();
        stackedBarRenderer3D5.setBaseStroke(stroke27);
        categoryPlot0.setRangeGridlineStroke(stroke27);
        boolean boolean30 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "#0a0a0a");
        java.lang.Object obj33 = rendererChangeEvent32.getSource();
        java.lang.String str34 = rendererChangeEvent32.toString();
        java.lang.Object obj35 = rendererChangeEvent32.getSource();
        categoryPlot0.rendererChanged(rendererChangeEvent32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + "#0a0a0a" + "'", obj33.equals("#0a0a0a"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]" + "'", str34.equals("org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]"));
        org.junit.Assert.assertTrue("'" + obj35 + "' != '" + "#0a0a0a" + "'", obj35.equals("#0a0a0a"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        boxAndWhiskerRenderer0.setItemMargin(4.0d);
        java.awt.Paint paint6 = boxAndWhiskerRenderer0.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean2 = color0.equals((java.lang.Object) shape1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        int int25 = xYPlot17.getIndexOf(xYItemRenderer24);
        java.awt.Stroke stroke26 = xYPlot17.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot17.getOrientation();
        java.util.List list28 = xYPlot17.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape5 = stackedBarRenderer3D2.getBaseShape();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, 0.0d, 2.0d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray27 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray34 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray41 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray42 = new double[][] { doubleArray27, doubleArray34, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray42);
        boolean boolean44 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset43);
        boolean boolean45 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset43);
        org.jfree.data.Range range46 = groupedStackedBarRenderer18.findRangeBounds(categoryDataset43);
        boolean boolean47 = columnArrangement10.equals((java.lang.Object) categoryDataset43);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Font font5 = dateAxis3.getLabelFont();
        boolean boolean6 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) font5);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        dateAxis3.resizeRange((double) (-1));
        dateAxis3.setTickLabelsVisible(false);
        dateAxis3.setLabelURL("");
        dateAxis3.centerRange((double) (short) -1);
        dateAxis3.setLowerMargin((double) 1L);
        dateAxis3.zoomRange((-1.0d), (double) 9999);
        boolean boolean18 = stackedBarRenderer3D2.equals((java.lang.Object) 9999);
        java.awt.Paint paint20 = null;
        try {
            stackedBarRenderer3D2.setSeriesPaint((int) (short) -1, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke2);
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getRootPlot();
        ringPlot0.setExplodePercent((java.lang.Comparable) (byte) 0, (double) 100);
        ringPlot0.setIgnoreZeroValues(true);
        java.awt.Stroke stroke10 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setMinimumArcAngleToDraw((double) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextBlockAnchor.CENTER");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        dateAxis7.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis7.setDefaultAutoRange((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean14 = dateRange11.equals((java.lang.Object) rectangleEdge13);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = numberAxis3D1.draw(graphics2D3, (double) (byte) 1, rectangle2D5, rectangle2D6, rectangleEdge13, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 1L, (java.lang.Comparable) 7, (java.lang.Comparable) (byte) 1);
        java.lang.Number number5 = null;
        defaultKeyedValues2D0.addValue(number5, (java.lang.Comparable) (-1L), (java.lang.Comparable) 10.0f);
        defaultKeyedValues2D0.addValue((java.lang.Number) 1, (java.lang.Comparable) 900000L, (java.lang.Comparable) "VerticalAlignment.CENTER");
        try {
            java.lang.Comparable comparable14 = defaultKeyedValues2D0.getRowKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("SortOrder.ASCENDING");
        org.jfree.chart.axis.AxisCollection axisCollection3 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list4 = axisCollection3.getAxesAtTop();
        java.util.List list5 = axisCollection3.getAxesAtLeft();
        projectInfo0.setContributors(list5);
        projectInfo0.setLicenceName("RectangleEdge.BOTTOM");
        projectInfo0.setName("Default Group");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset((double) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean19 = stackedBarRenderer3D11.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        stackedBarRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        stackedBarRenderer3D11.setBaseSeriesVisible(false, true);
        boolean boolean25 = rectangleInsets6.equals((java.lang.Object) true);
        double double27 = rectangleInsets6.calculateTopOutset((double) 900000L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 15, 0.0d, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateLeftInset((double) 2);
        java.lang.String str9 = rectangleInsets6.toString();
        double double11 = rectangleInsets6.extendHeight(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.0d + "'", double11 == 6.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        dateAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double[] doubleArray12 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray19 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray26 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray27 = new double[][] { doubleArray12, doubleArray19, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "Polar Plot", doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(categoryDataset30);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        defaultCategoryDataset0.setGroup(datasetGroup1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, true);
        java.lang.Comparable comparable7 = null;
        try {
            defaultCategoryDataset0.setValue((double) 100L, (java.lang.Comparable) 1.0f, comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreZeroValues(false);
        double double3 = ringPlot0.getSectionDepth();
        ringPlot0.setShadowYOffset((double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) '#', valueAxis9);
        java.lang.Object obj11 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        java.awt.Font font16 = stackedBarRenderer3D3.getBaseItemLabelFont();
        ringPlot0.setLabelFont(font16);
        ringPlot0.setSectionOutlinesVisible(true);
        double double20 = ringPlot0.getInteriorGap();
        try {
            ringPlot0.setInteriorGap((double) (-2L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-2.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.25d + "'", double20 == 0.25d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        double double15 = range14.getLowerBound();
        boolean boolean16 = piePlot3D0.equals((java.lang.Object) double15);
        double double17 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        boolean boolean2 = outlierListCollection0.isLowFarOut();
        boolean boolean3 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean7 = textLine1.equals((java.lang.Object) "#0a0a0a");
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!");
        java.lang.String str10 = textFragment9.getText();
        textLine1.removeFragment(textFragment9);
        java.lang.String str12 = textFragment9.getText();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        java.util.Date date4 = segmentedTimeline0.getDate(100L);
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) 0.2d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D8.setUpperMargin(1.0E-5d);
        double double11 = categoryAxis3D8.getLabelAngle();
        java.lang.Object obj12 = categoryAxis3D8.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isInverted();
        dateAxis13.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange17);
        java.util.Date date19 = dateRange17.getLowerDate();
        java.awt.Font font20 = categoryAxis3D8.getTickLabelFont((java.lang.Comparable) date19);
        long long21 = segmentedTimeline0.getTime(date19);
        java.text.DateFormat dateFormat26 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat26);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, 0.0d, 2.0d);
        double[] doubleArray43 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray50 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray57 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray58 = new double[][] { doubleArray43, doubleArray50, doubleArray57 };
        org.jfree.data.category.CategoryDataset categoryDataset59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray58);
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", doubleArray58);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        boolean boolean62 = dateAxis61.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot63 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis61.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot63);
        java.util.Date date65 = dateAxis61.getMaximumDate();
        boolean boolean66 = dateAxis61.isAutoRange();
        dateAxis61.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        boolean boolean70 = dateAxis69.isInverted();
        dateAxis69.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange73 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis69.setDefaultAutoRange((org.jfree.data.Range) dateRange73);
        java.util.Date date75 = dateRange73.getLowerDate();
        dateAxis61.setMaximumDate(date75);
        org.jfree.chart.text.TextAnchor textAnchor78 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions79 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition80 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions81 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions79, categoryLabelPosition80);
        org.jfree.chart.text.TextAnchor textAnchor82 = categoryLabelPosition80.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick84 = new org.jfree.chart.axis.DateTick(date75, "VerticalAlignment.CENTER", textAnchor78, textAnchor82, (double) 2.0f);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer85 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement32, (org.jfree.data.general.Dataset) categoryDataset60, (java.lang.Comparable) date75);
        java.util.Date date86 = dateTickUnit27.addToDate(date75);
        try {
            segmentedTimeline0.addBaseTimelineException(date86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(categoryDataset59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dateRange73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(textAnchor78);
        org.junit.Assert.assertNotNull(categoryLabelPositions79);
        org.junit.Assert.assertNotNull(categoryLabelPositions81);
        org.junit.Assert.assertNotNull(textAnchor82);
        org.junit.Assert.assertNotNull(date86);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) gradientPaintTransformType1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot3.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock7, dataset8);
        categoryPlot3.datasetChanged(datasetChangeEvent9);
        boolean boolean11 = categoryPlot3.isRangeCrosshairLockedOnData();
        boolean boolean12 = gradientPaintTransformType1.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot3.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        java.awt.Font font4 = dateAxis2.getLabelFont();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setCircular(false);
        java.awt.Paint paint10 = ringPlot7.getLabelShadowPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint10, (float) 900000L, textMeasurer12);
        org.jfree.chart.text.TextLine textLine14 = textBlock13.getLastLine();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNull(textLine14);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D10.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape13 = stackedBarRenderer3D10.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        waferMapPlot16.addChangeListener(plotChangeListener18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot16);
        jFreeChart20.setBorderVisible(true);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart20.setBorderPaint((java.awt.Paint) color23);
        jFreeChart20.removeLegend();
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart20.setBorderStroke(stroke26);
        java.awt.Color color28 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape13, stroke26, (java.awt.Paint) color28);
        java.awt.Paint paint30 = legendItem29.getFillPaint();
        try {
            stackedBarRenderer3D2.setSeriesFillPaint((int) (byte) -1, paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(9999);
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke13 = null;
        stackedBarRenderer3D11.setSeriesStroke(0, stroke13);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        stackedBarRenderer3D11.notifyListeners(rendererChangeEvent17);
        stackedBarRenderer3D11.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer22 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor27 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer22.setSeriesPaint((int) '4', (java.awt.Paint) chartColor27, true);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) chartColor27);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D11);
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.SortOrder sortOrder33 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str34 = sortOrder33.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor35 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        boolean boolean36 = sortOrder33.equals((java.lang.Object) itemLabelAnchor35);
        categoryPlot0.setColumnRenderingOrder(sortOrder33);
        java.lang.String str38 = sortOrder33.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "SortOrder.ASCENDING" + "'", str34.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(itemLabelAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "SortOrder.ASCENDING" + "'", str38.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) 'a');
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot0.getDataset(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNotNull(categoryAnchor8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) labelBlock4, dataset5);
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) '#', valueAxis9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot0.getDomainGridlinePosition();
        java.awt.Paint paint12 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        boolean boolean12 = stackedBarRenderer3D3.isSeriesVisibleInLegend(100);
        java.awt.Paint paint14 = stackedBarRenderer3D3.lookupSeriesFillPaint(7);
        boolean boolean15 = lengthAdjustmentType0.equals((java.lang.Object) stackedBarRenderer3D3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        categoryPlot0.setRangeAxis(15, valueAxis4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicAnchor();
        java.awt.Font font15 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle13.setPosition(rectangleEdge16);
        double double18 = legendTitle13.getContentYOffset();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray9 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray16 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray23 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset25);
        org.jfree.data.Range range28 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset25);
        groupedStackedBarRenderer0.setItemMargin((double) 432000000L);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke5 = null;
        stackedBarRenderer3D3.setSeriesStroke(0, stroke5);
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent9);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds(categoryDataset13);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = stackedBarRenderer3D3.getBaseToolTipGenerator();
        java.awt.Font font16 = stackedBarRenderer3D3.getBaseItemLabelFont();
        ringPlot0.setLabelFont(font16);
        int int18 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean11 = stackedBarRenderer3D2.getItemVisible(1, 0);
        boolean boolean12 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer1 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("#0a0a0a");
        levelRenderer1.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator4, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isInverted();
        java.awt.Font font9 = dateAxis7.getLabelFont();
        levelRenderer1.setBaseItemLabelFont(font9, false);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("ERROR : Relative To String", font9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, (int) (short) -1, dateFormat2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isInverted();
        java.awt.Font font6 = dateAxis4.getLabelFont();
        dateAxis4.setAutoTickUnitSelection(false);
        boolean boolean9 = dateAxis4.isVisible();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke14 = null;
        stackedBarRenderer3D12.setSeriesStroke(0, stroke14);
        stackedBarRenderer3D12.setBaseItemLabelsVisible(false);
        java.awt.Shape shape20 = stackedBarRenderer3D12.getItemShape((int) (short) 10, (-1));
        dateAxis4.setUpArrow(shape20);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity24 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0, shape20, "org.jfree.chart.event.RendererChangeEvent[source=#0a0a0a]", "Default Group");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, 2, (int) (short) 0, 0, dateFormat4);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D7.setUpperMargin(1.0E-5d);
        double double10 = categoryAxis3D7.getLabelAngle();
        int int11 = dateTickUnit5.compareTo((java.lang.Object) double10);
        double double12 = dateTickUnit5.getSize();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6.3072E10d + "'", double12 == 6.3072E10d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isInverted();
        dateAxis1.resizeRange((double) (-1));
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setLabelURL("");
        dateAxis1.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot13);
        java.util.Date date15 = dateAxis11.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot17.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes((double) 'a', plotRenderingInfo21, point2D22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        int int25 = xYPlot17.getIndexOf(xYItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot17.setFixedDomainAxisSpace(axisSpace26);
        double double28 = xYPlot17.getRangeCrosshairValue();
        java.awt.Stroke stroke29 = xYPlot17.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        double double2 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.65d + "'", double2 == 0.65d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(9999);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxisForDataset(10);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray19 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray26 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[] doubleArray33 = new double[] { 0.0d, 100L, 2.0d, 0.25d, 100.0f, 100L };
        double[][] doubleArray34 = new double[][] { doubleArray19, doubleArray26, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "VerticalAlignment.CENTER", doubleArray34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.data.Range range38 = groupedStackedBarRenderer10.findRangeBounds(categoryDataset35);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) groupedStackedBarRenderer10, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart6.getTitle();
        java.lang.Object obj12 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke19 = null;
        stackedBarRenderer3D17.setSeriesStroke(0, stroke19);
        stackedBarRenderer3D17.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean25 = stackedBarRenderer3D17.equals((java.lang.Object) 10.0f);
        stackedBarRenderer3D17.setBaseSeriesVisibleInLegend(false, false);
        stackedBarRenderer3D17.setBase((double) 4);
        boolean boolean31 = stackedAreaRenderer14.equals((java.lang.Object) stackedBarRenderer3D17);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedAreaRenderer14);
        jFreeChart6.addLegend(legendTitle32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        try {
            jFreeChart6.plotChanged(plotChangeEvent34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(textTitle11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isInverted();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = dateAxis3.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        java.util.Date date14 = dateAxis10.getMaximumDate();
        dateAxis3.setMaximumDate(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.chart.axis.TickUnits tickUnits17 = new org.jfree.chart.axis.TickUnits();
        int int18 = year16.compareTo((java.lang.Object) tickUnits17);
        java.lang.Object obj19 = keyedObjects0.getObject((java.lang.Comparable) year16);
        long long20 = year16.getFirstMillisecond();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31507200000L) + "'", long20 == (-31507200000L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getRowKey((-1255));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextBlockAnchor.CENTER");
        numberAxis3D1.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str1.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean10 = stackedBarRenderer3D2.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Paint paint15 = null;
        stackedBarRenderer3D2.setSeriesPaint((int) (short) 0, paint15, true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint20 = lineRenderer3D19.getWallPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23);
        lineRenderer3D19.setSeriesPositiveItemLabelPosition(10, itemLabelPosition24);
        stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition24, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle1.getText();
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle1.getPosition();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.CENTER" + "'", str6.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        boolean boolean11 = lineRenderer3D0.getItemLineVisible((int) (short) 0, 0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke21 = null;
        stackedBarRenderer3D19.setSeriesStroke((int) (byte) 1, stroke21);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        stackedBarRenderer3D19.setBaseItemLabelPaint((java.awt.Paint) chartColor26);
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) chartColor26, stroke28);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener30 = null;
        valueMarker29.removeChangeListener(markerChangeListener30);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.plot.Marker) valueMarker29, rectangle2D32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isInverted();
        dateAxis34.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis34.setDefaultAutoRange((org.jfree.data.Range) dateRange38);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke44 = null;
        stackedBarRenderer3D42.setSeriesStroke(0, stroke44);
        stackedBarRenderer3D42.setBaseItemLabelsVisible(false);
        java.awt.Shape shape50 = stackedBarRenderer3D42.getItemShape((int) (short) 10, (-1));
        dateAxis34.setDownArrow(shape50);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity(shape50, "ChartChangeEventType.NEW_DATASET", "#0a0a0a");
        dateAxis14.setRightArrow(shape50);
        java.awt.Paint paint56 = dateAxis14.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultCategoryDataset0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot2);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        dateAxis8.setTickLabelsVisible(true);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis8.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        java.util.Date date14 = dateRange12.getLowerDate();
        dateAxis0.setMaximumDate(date14);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions18, categoryLabelPosition19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.axis.DateTick dateTick23 = new org.jfree.chart.axis.DateTick(date14, "VerticalAlignment.CENTER", textAnchor17, textAnchor21, (double) 2.0f);
        double double24 = dateTick23.getValue();
        java.lang.String str25 = dateTick23.getText();
        java.lang.Object obj26 = dateTick23.clone();
        double double27 = dateTick23.getValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "VerticalAlignment.CENTER" + "'", str25.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        stackedBarRenderer3D6.setAutoPopulateSeriesShape(false);
        java.awt.Shape shape9 = stackedBarRenderer3D6.getBaseShape();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        waferMapPlot12.addChangeListener(plotChangeListener14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) waferMapPlot12);
        jFreeChart16.setBorderVisible(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color19);
        jFreeChart16.removeLegend();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("#0a0a0a", "VerticalAlignment.CENTER", "#0a0a0a", "hi!", shape9, stroke22, (java.awt.Paint) color24);
        org.jfree.data.general.Dataset dataset26 = null;
        legendItem25.setDataset(dataset26);
        java.awt.Stroke stroke28 = legendItem25.getOutlineStroke();
        org.jfree.data.general.Dataset dataset29 = legendItem25.getDataset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendItem25.getFillPaintTransformer();
        java.awt.Paint paint31 = legendItem25.getLinePaint();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(dataset29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setUseFillPaint(true);
        boolean boolean5 = lineRenderer3D0.getItemLineVisible((int) (byte) 100, 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineRenderer3D0.getSeriesNegativeItemLabelPosition(6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setCircular(false);
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.ui.Library library10 = new org.jfree.chart.ui.Library("#0a0a0a", "#0a0a0a", "#0a0a0a", "hi!");
        boolean boolean11 = textLine5.equals((java.lang.Object) "#0a0a0a");
        boolean boolean12 = ringPlot0.equals((java.lang.Object) "#0a0a0a");
        ringPlot0.setCircular(true, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke4 = null;
        stackedBarRenderer3D2.setSeriesStroke(0, stroke4);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D2.notifyListeners(rendererChangeEvent8);
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        stackedBarRenderer3D2.setAutoPopulateSeriesPaint(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isInverted();
        dateAxis16.resizeRange((double) (-1));
        dateAxis16.setTickLabelsVisible(false);
        dateAxis16.setLabelURL("");
        dateAxis16.centerRange((double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isInverted();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot28 = new org.jfree.chart.plot.WaferMapPlot();
        dateAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot28);
        java.util.Date date30 = dateAxis26.getMaximumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot32.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot32.zoomDomainAxes((double) 'a', plotRenderingInfo36, point2D37);
        xYPlot32.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot32.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot32.getDomainAxisLocation((int) (byte) 10);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, (double) (byte) 0);
        java.awt.Stroke stroke50 = null;
        stackedBarRenderer3D48.setSeriesStroke(0, stroke50);
        stackedBarRenderer3D48.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        boolean boolean56 = stackedBarRenderer3D48.equals((java.lang.Object) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = null;
        stackedBarRenderer3D48.setPositiveItemLabelPositionFallback(itemLabelPosition57);
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D48);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer60 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.ChartColor chartColor65 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (short) 10, (int) (short) 10);
        levelRenderer60.setSeriesPaint((int) '4', (java.awt.Paint) chartColor65, true);
        java.awt.Color color68 = java.awt.Color.orange;
        boolean boolean69 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) chartColor65, (java.awt.Paint) color68);
        legendTitle59.setBackgroundPaint((java.awt.Paint) chartColor65);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment71 = legendTitle59.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = legendTitle59.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D73 = legendTitle59.getBounds();
        org.jfree.chart.axis.AxisCollection axisCollection74 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list75 = axisCollection74.getAxesAtTop();
        java.util.List list76 = axisCollection74.getAxesAtTop();
        xYPlot32.drawDomainTickBands(graphics2D45, rectangle2D73, list76);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint79 = categoryPlot78.getRangeCrosshairPaint();
        categoryPlot78.mapDatasetToRangeAxis(4, (int) (short) -1);
        java.awt.Stroke stroke83 = categoryPlot78.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation84 = categoryPlot78.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState87 = stackedBarRenderer3D2.initialise(graphics2D14, rectangle2D73, categoryPlot78, 1969, plotRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment71);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(list76);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(axisLocation84);
    }
}

