import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        try {
            timeSeries3.delete(1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        try {
            timeSeries3.delete((int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        java.lang.Class class11 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(class11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries3.add(timeSeriesDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(0, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.delete(4, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries3.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        try {
            java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setNotify(false);
//        java.util.List list7 = timeSeries3.getItems();
//        boolean boolean8 = timeSeries3.isEmpty();
//        timeSeries3.setMaximumItemCount((int) '4');
//        java.lang.Object obj11 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable16 = timeSeries15.getKey();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries15.addOrUpdate(timeSeriesDataItem21);
//        try {
//            timeSeries3.add(timeSeriesDataItem28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 10.0d + "'", comparable16.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (-1), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        java.util.Calendar calendar13 = null;
        try {
            day6.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        java.lang.Object obj11 = seriesChangeEvent8.getSource();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        try {
            timeSeries14.delete(0, 2147483647, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.removeAgedItems(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long16 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.previous();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185364794L + "'", long13 == 1560185364794L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185364794L + "'", long14 == 1560185364794L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185364794L + "'", long16 == 1560185364794L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.delete(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        long long5 = month0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        try {
//            timeSeriesDataItem16.setValue((java.lang.Number) 1560185364026L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass1 = month0.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        long long11 = day9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1.0f));
//        java.util.Date date14 = day9.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone15);
//        java.util.TimeZone timeZone17 = null;
//        java.util.Locale locale18 = null;
//        try {
//            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date14, timeZone17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getDayOfMonth();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries8.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) day19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        try {
            timeSeries7.delete(6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(6);
        int int3 = year2.getYear();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((-9999), year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (-1.0f));
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener11);
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) propertyChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        java.lang.Number number9 = null;
        try {
            timeSeries3.update(12, number9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        try {
//            java.lang.Number number33 = timeSeries9.getValue(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection21 = timeSeries20.getTimePeriods();
        java.lang.String str22 = timeSeries20.getDescription();
        timeSeries20.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
        timeSeries20.setKey((java.lang.Comparable) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (short) 0);
        java.util.Collection collection32 = timeSeries9.getTimePeriods();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        timeSeries7.clear();
        try {
            timeSeries7.update((int) (byte) 10, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        timeSeries3.removeAgedItems((long) '#', false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) '#');
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getLastMillisecond();
//        long long21 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection28 = timeSeries27.getTimePeriods();
//        boolean boolean29 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries27);
//        java.lang.Object obj30 = timeSeriesDataItem23.clone();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate(timeSeriesDataItem23);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(obj30);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.isEmpty();
        try {
            timeSeries1.delete((int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.createCopy(8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        int int2 = year1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day19.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
        java.lang.String str7 = year3.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 100);
        boolean boolean19 = month0.equals((java.lang.Object) timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        long long6 = fixedMillisecond5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.removeAgedItems(false);
        double double16 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date40 = fixedMillisecond18.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond18.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46);
        int int49 = day48.getDayOfMonth();
        boolean boolean50 = fixedMillisecond18.equals((java.lang.Object) int49);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 31 + "'", int49 == 31);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod18, (double) 25568L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
//        boolean boolean22 = timeSeriesDataItem20.isSelected();
//        try {
//            timeSeries3.add(timeSeriesDataItem20, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        java.util.Date date11 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        java.util.Date date11 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(6, year4);
        java.util.Calendar calendar9 = null;
        try {
            year4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod17, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate(timeSeriesDataItem19);
        try {
            int int22 = timeSeriesDataItem20.compareTo((java.lang.Object) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        int int8 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries3.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        try {
//            timeSeries8.delete(0, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        java.lang.String str25 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries31.removeAgedItems(false);
        timeSeries31.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.lang.Number number41 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) year39);
        int int43 = year39.compareTo((java.lang.Object) 1560185357792L);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries49 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year39, regularTimePeriod48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day6, seriesChangeInfo11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        java.lang.String str20 = timeSeries14.getDescription();
        try {
            timeSeries14.delete(0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNull(str20);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getLastMillisecond();
//        long long4 = day2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection11 = timeSeries10.getTimePeriods();
//        boolean boolean12 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries10);
//        java.lang.Class<?> wildcardClass13 = timeSeries10.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getStart();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass22 = month21.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int26 = fixedMillisecond24.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date27);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date27, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
//        java.util.Date date37 = year34.getStart();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date37, timeZone38);
//        boolean boolean40 = year1.equals((java.lang.Object) wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries3.removeAgedItems(1560185359743L, true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "10-June-2019", "10-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        long long5 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        java.util.Calendar calendar7 = null;
        try {
            month0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = month26.getLastMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries8.createCopy(1969, 11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.String str7 = timeSeries3.getDescription();
        timeSeries3.setMaximumItemCount((int) (short) 1);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries5.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        int int7 = year3.compareTo((java.lang.Object) 1560185357792L);
        java.util.Date date8 = year3.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year3.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries3.add(regularTimePeriod13, (java.lang.Number) 8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond17.getFirstMillisecond(calendar23);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond17.getMiddleMillisecond(calendar25);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setDescription("Wed Dec 31 16:00:00 PST 1969");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries15.removeAgedItems(false);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        timeSeries23.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        int int30 = fixedMillisecond28.compareTo((java.lang.Object) (-1.0f));
        int int31 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        long long32 = fixedMillisecond28.getMiddleMillisecond();
        java.lang.Number number33 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getLastMillisecond();
        java.lang.String str36 = month34.toString();
        boolean boolean37 = timeSeries3.equals((java.lang.Object) str36);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        timeSeries3.setMaximumItemCount(6);
        timeSeries3.removeAgedItems(1561964399999L, false);
        timeSeries3.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries3.add(regularTimePeriod20, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = regularTimePeriod3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "July 10" + "'", str4.equals("July 10"));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        int int31 = timeSeriesDataItem21.compareTo((java.lang.Object) (-9999));
//        try {
//            timeSeries3.add(timeSeriesDataItem21);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
//        java.lang.String str18 = timeSeries3.getDescription();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(str18);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(6, year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        boolean boolean12 = timeSeries5.getNotify();
        java.lang.String str13 = timeSeries5.getDescription();
        java.lang.String str14 = timeSeries5.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        double double5 = timeSeries3.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (short) 10);
        int int9 = year8.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) year8);
        timeSeriesDataItem3.setSelected(true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        long long6 = year3.getFirstMillisecond();
        java.lang.String str7 = year3.toString();
        java.util.Calendar calendar8 = null;
        try {
            year3.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) (short) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener30);
        timeSeries7.setMaximumItemAge(1560185367209L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        java.util.Date date13 = fixedMillisecond3.getTime();
        int int14 = year1.compareTo((java.lang.Object) date13);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        timeSeries39.removeAgedItems(false);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        java.util.List list11 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list11);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 2, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long16 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection21 = timeSeries20.getTimePeriods();
//        java.lang.String str22 = timeSeries20.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection27 = timeSeries26.getTimePeriods();
//        timeSeries26.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries26.addChangeListener(seriesChangeListener30);
//        java.lang.String str32 = timeSeries26.getRangeDescription();
//        java.util.Collection collection33 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getLastMillisecond();
//        long long36 = day34.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection43 = timeSeries42.getTimePeriods();
//        boolean boolean44 = timeSeriesDataItem38.equals((java.lang.Object) timeSeries42);
//        timeSeriesDataItem38.setValue((java.lang.Number) 1560185357630L);
//        timeSeries26.add(timeSeriesDataItem38, true);
//        timeSeries26.removeAgedItems(true);
//        int int51 = fixedMillisecond12.compareTo((java.lang.Object) timeSeries26);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185378635L + "'", long13 == 1560185378635L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185378635L + "'", long14 == 1560185378635L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185378635L + "'", long16 == 1560185378635L);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries45.removeAgedItems(false);
        timeSeries45.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Number number55 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) year53);
        int int57 = year53.compareTo((java.lang.Object) 1560185357792L);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year53, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection68 = timeSeries67.getTimePeriods();
        java.lang.String str69 = timeSeries67.getDescription();
        timeSeries67.removeAgedItems(false);
        timeSeries67.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection78 = timeSeries77.getTimePeriods();
        java.lang.String str79 = timeSeries77.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond(0L);
        int int83 = fixedMillisecond81.compareTo((java.lang.Object) (-1.0f));
        timeSeries77.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        long long85 = fixedMillisecond81.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries3.addAndOrUpdate(timeSeries67);
        java.lang.Class class88 = timeSeries67.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertNotNull(timeSeries87);
        org.junit.Assert.assertNull(class88);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
        try {
            timeSeries14.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        try {
            timeSeries3.delete((int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries9.getNextTimePeriod();
//        try {
//            timeSeries9.delete(31, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        timeSeries5.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        java.lang.Class<?> wildcardClass3 = month0.getClass();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        long long4 = fixedMillisecond3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964400000L + "'", long4 == 1561964400000L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        try {
            timeSeries3.delete(12, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        try {
            timeSeries3.delete((int) (short) -1, 1969, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.TimeSeries timeSeries16 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185380885L + "'", long13 == 1560185380885L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185380885L + "'", long14 == 1560185380885L);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (short) 10);
        int int9 = year8.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) year8);
        long long12 = year8.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass1 = month0.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        long long11 = day9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1.0f));
//        java.util.Date date14 = day9.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getDayOfMonth();
        java.util.Date date8 = day6.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        java.lang.String str7 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 100.0f + "'", obj6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100.0]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=100.0]"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.removeAgedItems((long) '#', false);
        try {
            java.lang.Number number13 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection17 = timeSeries16.getTimePeriods();
//        java.lang.String str18 = timeSeries16.getDescription();
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        timeSeries16.setKey((java.lang.Comparable) fixedMillisecond22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (short) 100);
//        try {
//            timeSeries8.setKey((java.lang.Comparable) timeSeriesDataItem27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        boolean boolean8 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries18.addChangeListener(seriesChangeListener22);
        java.lang.String str24 = timeSeries18.getRangeDescription();
        java.util.Collection collection25 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        timeSeries36.setKey((java.lang.Comparable) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        try {
            timeSeries3.delete((int) (short) 100, 3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day6, seriesChangeInfo11);
        java.lang.String str13 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries15.fireSeriesChanged();
        int int17 = timeSeries15.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        try {
            timeSeries15.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        long long12 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            day6.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185382439L + "'", long1 == 1560185382439L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185382439L + "'", long2 == 1560185382439L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185382439L + "'", long4 == 1560185382439L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185382439L + "'", long6 == 1560185382439L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        long long10 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day6, seriesChangeInfo11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = seriesChangeEvent12.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent12.getSummary();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNull(seriesChangeInfo13);
        org.junit.Assert.assertNull(seriesChangeInfo14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        try {
            timeSeries3.delete((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener16);
        try {
            timeSeries7.delete(4, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        try {
            timeSeries1.delete((int) (byte) 1, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getStart();
        long long15 = fixedMillisecond11.getMiddleMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond11.getMiddleMillisecond(calendar18);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, 0.0d);
        long long27 = month23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193199999L + "'", long8 == 1560193199999L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        java.util.Date date6 = month0.getEnd();
        java.lang.String str7 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries17.getRangeDescription();
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        int int25 = day6.compareTo((java.lang.Object) timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day6.previous();
        java.lang.String str27 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-1969" + "'", str27.equals("31-December-1969"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
        long long11 = fixedMillisecond3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setNotify(false);
//        java.util.List list7 = timeSeries3.getItems();
//        double double8 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        long long11 = day9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries17.removeAgedItems(false);
//        timeSeries17.setRangeDescription("10");
//        boolean boolean22 = timeSeriesDataItem13.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem13.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        long long26 = month25.getLastMillisecond();
//        long long27 = month25.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, "10", "10");
//        try {
//            int int31 = timeSeriesDataItem24.compareTo((java.lang.Object) "10");
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year1.previous();
        java.lang.Class<?> wildcardClass19 = year1.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Number number29 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        long long30 = year27.getFirstMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(4, year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        java.util.Calendar calendar33 = null;
        try {
            month31.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61851744000000L) + "'", long30 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Number number29 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        long long30 = year27.getFirstMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(4, year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries7.removeChangeListener(seriesChangeListener33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61851744000000L) + "'", long30 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        int int5 = month3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month3.previous();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        boolean boolean10 = month3.equals((java.lang.Object) seriesException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
        int int19 = day18.getMonth();
        int int20 = day18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        long long22 = day18.getSerialIndex();
        long long23 = day18.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 0);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25568L + "'", long22 == 25568L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28799999L + "'", long23 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        int int10 = day6.getDayOfMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Year year5 = month0.getYear();
        int int6 = month0.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem4.getPeriod();
//        java.lang.Object obj16 = timeSeriesDataItem4.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) (-1.0f));
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries9.addChangeListener(seriesChangeListener18);
        timeSeries9.setDescription("10-June-2019");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod23, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries9.addOrUpdate(timeSeriesDataItem25);
        int int27 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeries9);
        java.lang.Object obj28 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.String str7 = timeSeries3.getDescription();
        boolean boolean8 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (short) 10);
        int int34 = year33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        int int36 = month23.compareTo((java.lang.Object) timeSeries31);
        org.jfree.data.time.Year year37 = month23.getYear();
        long long38 = month23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1561964399999L);
//        boolean boolean7 = timeSeriesDataItem6.isSelected();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (java.lang.Number) 2147483647);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.next();
        java.util.Date date31 = month26.getEnd();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = month26.getMiddleMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        timeSeries7.setRangeDescription("June 2019");
        java.lang.Object obj25 = timeSeries7.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries7.addOrUpdate(timeSeriesDataItem26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        long long23 = day19.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28799999L + "'", long23 == 28799999L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
        java.lang.Class<?> wildcardClass15 = timeSeries3.getClass();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = year11.compareTo((java.lang.Object) 1560185357792L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 4, false);
        try {
            timeSeries3.delete((int) 'a', 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.removeAgedItems(true);
//        timeSeries9.clear();
//        try {
//            timeSeries9.delete(2147483647, 0, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = year11.compareTo((java.lang.Object) 1560185357792L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 4, false);
        double double19 = timeSeries3.getMaxY();
        double double20 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 31, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date18 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 0.0d);
        org.jfree.data.time.Year year24 = month21.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1560185359807L);
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) 1560185376261L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        long long5 = year2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(2147483647, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61835976000001L) + "'", long5 == (-61835976000001L));
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        java.lang.Object obj32 = null;
//        int int33 = timeSeriesDataItem21.compareTo(obj32);
//        timeSeriesDataItem21.setSelected(false);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.List list23 = timeSeries7.getItems();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemCount(0);
//        java.lang.String str39 = timeSeries33.getDomainDescription();
//        int int40 = year25.compareTo((java.lang.Object) str39);
//        long long41 = year25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year25.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        long long45 = day43.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy(regularTimePeriod42, (org.jfree.data.time.RegularTimePeriod) day43);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener47);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61157520000000L) + "'", long41 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        boolean boolean12 = timeSeries5.getNotify();
        java.lang.String str13 = timeSeries5.getDescription();
        try {
            java.lang.Number number15 = timeSeries5.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        long long18 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries5.removeAgedItems(false);
        timeSeries5.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Number number15 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        int int17 = year13.compareTo((java.lang.Object) 1560185357792L);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries1.setNotify(false);
        try {
            timeSeries1.update((int) '4', (java.lang.Number) 1560185357792L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent3.getSummary();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries45.removeAgedItems(false);
        timeSeries45.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Number number55 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) year53);
        int int57 = year53.compareTo((java.lang.Object) 1560185357792L);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year53, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection68 = timeSeries67.getTimePeriods();
        java.lang.String str69 = timeSeries67.getDescription();
        timeSeries67.removeAgedItems(false);
        timeSeries67.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection78 = timeSeries77.getTimePeriods();
        java.lang.String str79 = timeSeries77.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond(0L);
        int int83 = fixedMillisecond81.compareTo((java.lang.Object) (-1.0f));
        timeSeries77.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        long long85 = fixedMillisecond81.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries3.addAndOrUpdate(timeSeries67);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = timeSeries87.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertNotNull(timeSeries87);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) (-1.0f));
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries9.addChangeListener(seriesChangeListener18);
        timeSeries9.setDescription("10-June-2019");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod23, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries9.addOrUpdate(timeSeriesDataItem25);
        int int27 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries31.removeAgedItems(false);
        java.util.List list34 = timeSeries31.getItems();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(0);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) (-1L), false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) (-57600000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener34);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185389150L + "'", long1 == 1560185389150L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185389150L + "'", long2 == 1560185389150L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Date date9 = month8.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        timeSeries15.setDescription("10-June-2019");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (-1.0f));
//        java.lang.Object obj8 = timeSeriesDataItem7.clone();
//        timeSeriesDataItem7.setValue((java.lang.Number) 1L);
//        boolean boolean11 = month2.equals((java.lang.Object) 1L);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = month2.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560185363360L, false);
        boolean boolean36 = timeSeries3.isEmpty();
        java.lang.Class class37 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(class37);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185390619L + "'", long1 == 1560185390619L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185390619L + "'", long2 == 1560185390619L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185390619L + "'", long5 == 1560185390619L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) 0L);
        java.util.Date date9 = fixedMillisecond1.getStart();
        java.util.Date date10 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.String str7 = timeSeries3.getDescription();
        timeSeries3.setMaximumItemCount((int) (short) 1);
        int int10 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        long long17 = month16.getLastMillisecond();
//        long long18 = month16.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, "10", "10");
//        timeSeries21.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 25568L);
//        int int31 = timeSeriesDataItem4.compareTo((java.lang.Object) 25568L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int4 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) (-1.0f));
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries9.addChangeListener(seriesChangeListener18);
        timeSeries9.setDescription("10-June-2019");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod23, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries9.addOrUpdate(timeSeriesDataItem25);
        int int27 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getFirstMillisecond(calendar30);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries35.removeAgedItems(false);
        boolean boolean38 = fixedMillisecond29.equals((java.lang.Object) timeSeries35);
        timeSeries35.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        int int48 = day47.getMonth();
        int int49 = day47.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        long long52 = month51.getLastMillisecond();
        long long53 = month51.getSerialIndex();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        long long55 = month54.getLastMillisecond();
        long long56 = month54.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month51, (org.jfree.data.time.RegularTimePeriod) month54);
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 1560185378635L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1561964399999L + "'", long52 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 24234L + "'", long53 == 24234L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1561964399999L + "'", long55 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 24234L + "'", long56 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("10-June-2019");
        try {
            timeSeries3.delete(5, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = year11.compareTo((java.lang.Object) 1560185357792L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 4, false);
        int int19 = year11.getYear();
        long long20 = year11.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
        timeSeries14.setRangeDescription("July 10");
        java.lang.String str17 = timeSeries14.getRangeDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "July 10" + "'", str17.equals("July 10"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries3.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries22.removeAgedItems(false);
        boolean boolean25 = fixedMillisecond16.equals((java.lang.Object) timeSeries22);
        timeSeries22.setMaximumItemCount(0);
        java.lang.String str28 = timeSeries22.getDomainDescription();
        java.util.Collection collection29 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (-1.0f));
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(2, year5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 24234L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, (double) 5);
        timeSeries1.removeAgedItems((long) 31, true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries18.addChangeListener(seriesChangeListener22);
        timeSeries18.removeAgedItems((long) '#', false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond28.next();
        try {
            timeSeries1.add(regularTimePeriod34, (java.lang.Number) 12, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (-1.0f));
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries21.removeAgedItems(false);
//        timeSeries21.setRangeDescription("10");
//        boolean boolean26 = timeSeriesDataItem17.equals((java.lang.Object) "10");
//        timeSeries3.add(timeSeriesDataItem17);
//        java.lang.Object obj28 = timeSeriesDataItem17.clone();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(obj28);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (java.lang.Number) 2147483647);
        java.lang.String str7 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries39.removeAgedItems(false);
        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) timeSeries39);
        timeSeries39.setMaximumItemCount(0);
        java.lang.String str45 = timeSeries39.getDomainDescription();
        int int46 = year31.compareTo((java.lang.Object) str45);
        long long47 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year31.previous();
        java.lang.Class<?> wildcardClass49 = year31.getClass();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-9999));
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61157520000000L) + "'", long47 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 24234L);
        timeSeriesDataItem6.setValue((java.lang.Number) 1560185381782L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass1 = month0.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        long long11 = day9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1.0f));
//        java.util.Date date14 = day9.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        java.lang.String str15 = timeSeries13.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        long long21 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        timeSeries3.setMaximumItemAge((long) 8);
//        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560185363360L, false);
//        java.util.List list36 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection41 = timeSeries40.getTimePeriods();
//        java.lang.String str42 = timeSeries40.getDescription();
//        timeSeries40.removeAgedItems(false);
//        timeSeries40.setDomainDescription("");
//        timeSeries40.setMaximumItemAge((long) 9);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass50 = month49.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int54 = fixedMillisecond52.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date55 = fixedMillisecond52.getTime();
//        java.util.TimeZone timeZone56 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date55, timeZone56);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date55);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) 0.0d);
//        org.jfree.data.time.Year year61 = month58.getYear();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        long long63 = day62.getLastMillisecond();
//        long long64 = day62.getLastMillisecond();
//        boolean boolean65 = month58.equals((java.lang.Object) long64);
//        int int66 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month58);
//        java.util.Calendar calendar67 = null;
//        try {
//            long long68 = month58.getFirstMillisecond(calendar67);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(list36);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560236399999L + "'", long63 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        try {
            timeSeries15.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1560185376590L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day6, seriesChangeInfo11);
        java.util.Calendar calendar13 = null;
        try {
            day6.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        int int14 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
//        long long17 = month12.getLastMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
//        timeSeries8.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener22);
//        try {
//            timeSeries8.delete((int) (short) 0, (int) '#', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        try {
            timeSeries7.delete((int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        int int10 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1561964399999L);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
//        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        java.lang.String str20 = timeSeries14.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection25 = timeSeries24.getTimePeriods();
//        java.lang.String str26 = timeSeries24.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection31 = timeSeries30.getTimePeriods();
//        timeSeries30.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries30.addChangeListener(seriesChangeListener34);
//        java.lang.String str36 = timeSeries30.getRangeDescription();
//        java.util.Collection collection37 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        long long40 = day38.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection47 = timeSeries46.getTimePeriods();
//        boolean boolean48 = timeSeriesDataItem42.equals((java.lang.Object) timeSeries46);
//        timeSeriesDataItem42.setValue((java.lang.Number) 1560185357630L);
//        timeSeries30.add(timeSeriesDataItem42, true);
//        timeSeries30.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.next();
//        java.lang.Number number61 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) year59);
//        long long62 = year59.getFirstMillisecond();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(4, year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries14.addOrUpdate(timeSeriesDataItem64);
//        try {
//            java.lang.Object obj66 = timeSeriesDataItem65.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(number61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61851744000000L) + "'", long62 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        int int7 = year3.compareTo((java.lang.Object) 1560185357792L);
        long long8 = year3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61851744000000L) + "'", long8 == (-61851744000000L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year1.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 35L, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 35L + "'", obj3.equals(35L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        int int5 = month2.getYearValue();
        int int6 = month2.getMonth();
        long long7 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("31-December-1969");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = year11.compareTo((java.lang.Object) 1560185357792L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 4, false);
        double double19 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        long long21 = month20.getLastMillisecond();
        long long22 = month20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22, "10", "10");
        timeSeries25.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 25568L);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        java.lang.Number number38 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.addAndOrUpdate(timeSeries25);
        timeSeries3.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date6 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        timeSeries7.setNotify(false);
        java.lang.String str15 = timeSeries7.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getFirstMillisecond();
        long long12 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 25568L + "'", long12 == 25568L);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        timeSeries3.removeAgedItems((long) '#', false);
//        java.lang.Object obj12 = timeSeries3.clone();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection22 = timeSeries21.getTimePeriods();
//        boolean boolean23 = timeSeriesDataItem17.equals((java.lang.Object) timeSeries21);
//        java.lang.Number number24 = timeSeriesDataItem17.getValue();
//        timeSeries3.add(timeSeriesDataItem17);
//        timeSeries3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) '#', true);
        long long15 = fixedMillisecond11.getSerialIndex();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        java.lang.Class<?> wildcardClass18 = year1.getClass();
        long long19 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61125897600001L) + "'", long19 == (-61125897600001L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        int int11 = day6.getYear();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        java.util.Date date6 = month0.getEnd();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a', seriesChangeInfo1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        try {
            timeSeries7.delete((int) (short) 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date6 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.String str7 = timeSeries3.getDescription();
        timeSeries3.setMaximumItemCount((int) (short) 1);
        try {
            timeSeries3.delete((int) '4', 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
        timeSeries16.setKey((java.lang.Comparable) fixedMillisecond22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (short) 100);
        int int28 = day6.compareTo((java.lang.Object) timeSeriesDataItem27);
        int int29 = day6.getMonth();
        long long30 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 25568L + "'", long30 == 25568L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getLastMillisecond();
        java.util.Date date12 = day6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day6.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date4, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        long long6 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "10", "10");
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 25568L);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Number number22 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection29 = timeSeries28.getTimePeriods();
        timeSeries28.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries28.addChangeListener(seriesChangeListener32);
        int int34 = month23.compareTo((java.lang.Object) timeSeries28);
        boolean boolean35 = timeSeries28.getNotify();
        java.lang.String str36 = timeSeries28.getDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod38, (double) 25568L);
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection47 = timeSeries46.getTimePeriods();
        timeSeries46.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(0L);
        int int53 = fixedMillisecond51.compareTo((java.lang.Object) (-1.0f));
        int int54 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries46.addChangeListener(seriesChangeListener55);
        timeSeries46.setDescription("10-June-2019");
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month59.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod60, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries46.addOrUpdate(timeSeriesDataItem62);
        int int64 = timeSeriesDataItem40.compareTo((java.lang.Object) timeSeries46);
        timeSeries28.add(timeSeriesDataItem40);
        int int66 = year20.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int67 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeriesDataItem40);
        java.lang.Object obj68 = timeSeriesDataItem40.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(obj68);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
//        timeSeries3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560185363360L, false);
        java.util.List list36 = timeSeries3.getItems();
        double double37 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.56018536336E12d + "'", double37 == 1.56018536336E12d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.removeAgedItems((long) '#', false);
        java.lang.Object obj12 = timeSeries3.clone();
        try {
            java.lang.Number number14 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        timeSeries7.setNotify(false);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(2, year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 24234L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate(timeSeriesDataItem21);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem22.getPeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        long long8 = fixedMillisecond1.getFirstMillisecond();
        long long9 = fixedMillisecond1.getLastMillisecond();
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries7.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        int int10 = day6.getYear();
        java.util.Calendar calendar11 = null;
        try {
            day6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        int int4 = year1.getYear();
        long long5 = year1.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (java.lang.Number) 2147483647);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        long long9 = day7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection16 = timeSeries15.getTimePeriods();
//        boolean boolean17 = timeSeriesDataItem11.equals((java.lang.Object) timeSeries15);
//        java.lang.Class<?> wildcardClass18 = timeSeries15.getClass();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        int int21 = month19.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month19.previous();
//        long long24 = month19.getLastMillisecond();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (-1.0f));
//        timeSeries15.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener29);
//        java.util.Collection collection31 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertNotNull(collection31);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.removeAgedItems((long) '#', false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
        long long20 = regularTimePeriod19.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.fireSeriesChanged();
        java.lang.Class class5 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries17.getRangeDescription();
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        int int25 = day6.compareTo((java.lang.Object) timeSeries11);
        int int26 = day6.getYear();
        long long27 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Number number12 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) year10);
        boolean boolean13 = day6.equals((java.lang.Object) number12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day6.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries15.removeAgedItems(false);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond9.getMiddleMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond9.getLastMillisecond(calendar22);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond9.getFirstMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond9.getFirstMillisecond(calendar26);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        try {
//            timeSeries8.delete(100, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        long long6 = month4.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "10", "10");
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 25568L);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Number number22 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection29 = timeSeries28.getTimePeriods();
        timeSeries28.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries28.addChangeListener(seriesChangeListener32);
        int int34 = month23.compareTo((java.lang.Object) timeSeries28);
        boolean boolean35 = timeSeries28.getNotify();
        java.lang.String str36 = timeSeries28.getDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod38, (double) 25568L);
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection47 = timeSeries46.getTimePeriods();
        timeSeries46.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(0L);
        int int53 = fixedMillisecond51.compareTo((java.lang.Object) (-1.0f));
        int int54 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries46.addChangeListener(seriesChangeListener55);
        timeSeries46.setDescription("10-June-2019");
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month59.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod60, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries46.addOrUpdate(timeSeriesDataItem62);
        int int64 = timeSeriesDataItem40.compareTo((java.lang.Object) timeSeries46);
        timeSeries28.add(timeSeriesDataItem40);
        int int66 = year20.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int67 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeriesDataItem40);
        timeSeriesDataItem3.setValue((java.lang.Number) 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        long long6 = year3.getFirstMillisecond();
        long long7 = year3.getLastMillisecond();
        java.util.Date date8 = year3.getStart();
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820208000001L) + "'", long7 == (-61820208000001L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries22.removeAgedItems(false);
        boolean boolean25 = fixedMillisecond16.equals((java.lang.Object) timeSeries22);
        timeSeries22.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getFirstMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        int int35 = day34.getMonth();
        int int36 = day34.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) day34);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        java.lang.Number number44 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) year42);
        long long45 = year42.getFirstMillisecond();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(4, year42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61851744000000L) + "'", long45 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (java.lang.Number) 2147483647);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        java.lang.String str12 = timeSeries10.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries16.addChangeListener(seriesChangeListener20);
        java.lang.String str22 = timeSeries16.getRangeDescription();
        java.util.Collection collection23 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getStart();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        java.lang.String str36 = timeSeries34.getDescription();
        timeSeries34.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getFirstMillisecond(calendar41);
        timeSeries34.setKey((java.lang.Comparable) fixedMillisecond40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        int int47 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-2) + "'", int47 == (-2));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        java.lang.Number number40 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) year38);
//        long long41 = year38.getFirstMillisecond();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
//        int int44 = year38.getYear();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) 0L);
        java.util.Date date9 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185398730L + "'", long1 == 1560185398730L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185398730L + "'", long3 == 1560185398730L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185398730L + "'", long4 == 1560185398730L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185398730L + "'", long6 == 1560185398730L);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries7.getDataItem(regularTimePeriod32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        java.lang.Object obj32 = null;
//        int int33 = timeSeriesDataItem21.compareTo(obj32);
//        java.lang.Object obj34 = null;
//        int int35 = timeSeriesDataItem21.compareTo(obj34);
//        java.lang.Number number36 = timeSeriesDataItem21.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem21.getPeriod();
//        java.lang.Number number38 = timeSeriesDataItem21.getValue();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1560185357630L + "'", number36.equals(1560185357630L));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1560185357630L + "'", number38.equals(1560185357630L));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("10-June-2019");
        try {
            timeSeries3.update((int) ' ', (java.lang.Number) 1560185364026L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61125897600001L) + "'", long2 == (-61125897600001L));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries17.getRangeDescription();
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        int int25 = day6.compareTo((java.lang.Object) timeSeries11);
        long long26 = day6.getFirstMillisecond();
        long long27 = day6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-57600000L) + "'", long26 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-57600000L) + "'", long27 == (-57600000L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries3.update(regularTimePeriod10, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.lang.String str17 = timeSeries3.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy(9999, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.removeAgedItems((long) '#', false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
        long long20 = fixedMillisecond13.getLastMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        long long39 = day0.getLastMillisecond();
//        boolean boolean41 = day0.equals((java.lang.Object) "10");
//        java.util.Calendar calendar42 = null;
//        try {
//            day0.peg(calendar42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        long long8 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        boolean boolean12 = timeSeries5.getNotify();
        java.lang.String str13 = timeSeries5.getDescription();
        double double14 = timeSeries5.getMinY();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries17.removeAgedItems(false);
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) timeSeries17);
        java.util.Date date21 = fixedMillisecond11.getTime();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 1560185381582L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185399367L + "'", long2 == 1560185399367L);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        try {
            timeSeries5.update(8, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Number number29 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        long long30 = year27.getFirstMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(4, year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        int int33 = month31.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61851744000000L) + "'", long30 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date4, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (short) 10);
        int int34 = year33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        int int36 = month23.compareTo((java.lang.Object) timeSeries31);
        java.lang.String str37 = timeSeries31.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
//        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        java.lang.String str20 = timeSeries14.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection25 = timeSeries24.getTimePeriods();
//        java.lang.String str26 = timeSeries24.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection31 = timeSeries30.getTimePeriods();
//        timeSeries30.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries30.addChangeListener(seriesChangeListener34);
//        java.lang.String str36 = timeSeries30.getRangeDescription();
//        java.util.Collection collection37 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        long long40 = day38.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection47 = timeSeries46.getTimePeriods();
//        boolean boolean48 = timeSeriesDataItem42.equals((java.lang.Object) timeSeries46);
//        timeSeriesDataItem42.setValue((java.lang.Number) 1560185357630L);
//        timeSeries30.add(timeSeriesDataItem42, true);
//        timeSeries30.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.next();
//        java.lang.Number number61 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) year59);
//        long long62 = year59.getFirstMillisecond();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(4, year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries14.addOrUpdate(timeSeriesDataItem64);
//        boolean boolean66 = timeSeriesDataItem64.isSelected();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(number61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61851744000000L) + "'", long62 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        int int4 = day3.getDayOfMonth();
//        long long5 = day3.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            java.lang.Number number11 = timeSeries3.getValue(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection6 = timeSeries5.getTimePeriods();
//        timeSeries5.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int12 = fixedMillisecond10.compareTo((java.lang.Object) (-1.0f));
//        int int13 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getLastMillisecond();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries5.addChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        long long23 = month21.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.Year year25 = month21.getYear();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month21);
//        int int27 = day0.compareTo((java.lang.Object) month21);
//        java.lang.String str28 = month21.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(collection6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185402168L + "'", long15 == 1560185402168L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560185402168L + "'", long16 == 1560185402168L);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        boolean boolean25 = timeSeries7.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, "10-June-2019", "org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "10-June-2019", "Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date18 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 0.0d);
        org.jfree.data.time.Year year24 = month21.getYear();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month21.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries17.getRangeDescription();
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        int int25 = day6.compareTo((java.lang.Object) timeSeries11);
        long long26 = day6.getFirstMillisecond();
        int int27 = day6.getYear();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day6.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-57600000L) + "'", long26 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries7.removeAgedItems(1560185359807L, false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        long long6 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        boolean boolean12 = timeSeries5.getNotify();
        java.lang.String str13 = timeSeries5.getDescription();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (double) 25568L);
        boolean boolean19 = timeSeriesDataItem17.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        timeSeries23.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        int int30 = fixedMillisecond28.compareTo((java.lang.Object) (-1.0f));
        int int31 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries23.addChangeListener(seriesChangeListener32);
        timeSeries23.setDescription("10-June-2019");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod37, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries23.addOrUpdate(timeSeriesDataItem39);
        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries23);
        timeSeries5.add(timeSeriesDataItem17);
        timeSeriesDataItem17.setSelected(true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        timeSeries3.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = year11.compareTo((java.lang.Object) 1560185357792L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 4, false);
        double double19 = timeSeries3.getMaxY();
        boolean boolean20 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries3.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries5.removeAgedItems(false);
        timeSeries5.setRangeDescription("Value");
        java.lang.String str10 = timeSeries5.getDomainDescription();
        boolean boolean11 = day0.equals((java.lang.Object) str10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        int int8 = day7.getMonth();
        int int9 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.next();
        long long11 = day7.getSerialIndex();
        long long12 = day7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        java.lang.String str20 = year16.toString();
        boolean boolean21 = day7.equals((java.lang.Object) year16);
        try {
            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) -1, year16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        timeSeries3.setMaximumItemCount(6);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getStart();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries28.removeAgedItems(false);
        boolean boolean31 = fixedMillisecond22.equals((java.lang.Object) timeSeries28);
        timeSeries28.setMaximumItemCount(0);
        java.lang.String str34 = timeSeries28.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        java.lang.Number number40 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) year38);
        long long41 = year38.getFirstMillisecond();
        long long42 = year38.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61820208000001L) + "'", long42 == (-61820208000001L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        java.lang.String str7 = timeSeries3.getDescription();
        timeSeries3.setMaximumItemCount((int) (short) 1);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries3.removeAgedItems(false);
        java.util.List list6 = timeSeries3.getItems();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries5.removeAgedItems(false);
        timeSeries5.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Number number15 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        int int17 = year13.compareTo((java.lang.Object) 1560185357792L);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass15 = month14.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date20 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        long long25 = day23.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) (-1.0f));
//        java.util.Date date28 = day23.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28);
//        int int32 = timeSeriesDataItem4.compareTo((java.lang.Object) date28);
//        java.util.TimeZone timeZone33 = null;
//        java.util.Locale locale34 = null;
//        try {
//            org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date28, timeZone33, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.lang.String str17 = timeSeries3.getDescription();
        try {
            timeSeries3.delete(2, (int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        java.lang.Object obj32 = null;
//        int int33 = timeSeriesDataItem21.compareTo(obj32);
//        java.lang.Object obj34 = null;
//        int int35 = timeSeriesDataItem21.compareTo(obj34);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection40 = timeSeries39.getTimePeriods();
//        timeSeries39.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int46 = fixedMillisecond44.compareTo((java.lang.Object) (-1.0f));
//        int int47 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        long long48 = fixedMillisecond44.getMiddleMillisecond();
//        boolean boolean49 = timeSeriesDataItem21.equals((java.lang.Object) long48);
//        java.lang.Number number50 = timeSeriesDataItem21.getValue();
//        timeSeriesDataItem21.setSelected(false);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 1560185357630L + "'", number50.equals(1560185357630L));
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        int int16 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection21 = timeSeries20.getTimePeriods();
        java.lang.String str22 = timeSeries20.getDescription();
        timeSeries20.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
        timeSeries20.setKey((java.lang.Comparable) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (short) 0);
        timeSeries9.removeAgedItems(false);
        java.lang.Object obj34 = timeSeries9.clone();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(obj34);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1561964399999L);
//        timeSeriesDataItem6.setSelected(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        int int5 = month4.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Date date5 = year4.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        int int2 = year1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        int int14 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
//        long long17 = month12.getLastMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
//        timeSeries8.setDomainDescription("");
//        long long22 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond28.next();
//        long long30 = fixedMillisecond28.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        java.lang.String str25 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries7.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L, "", "June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getFirstMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond40.getStart();
        int int44 = day38.compareTo((java.lang.Object) date43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date48 = fixedMillisecond47.getTime();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries7.addAndOrUpdate(timeSeries31);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeries50.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeries50);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) 1560185357792L);
        java.lang.Number number6 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 25568.0d + "'", number6.equals(25568.0d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        boolean boolean8 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        java.lang.String str16 = year12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) 25568L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560185364794L);
        java.util.Date date21 = year12.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getLastMillisecond();
        long long16 = month14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, "10", "10");
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        java.util.Date date13 = fixedMillisecond3.getTime();
        int int14 = year1.compareTo((java.lang.Object) date13);
        int int15 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        java.util.List list14 = timeSeries3.getItems();
        boolean boolean15 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Date date9 = month8.getEnd();
        java.util.Date date10 = month8.getEnd();
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.removeAgedItems(1560185360204L, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) 1560185359743L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.next();
        java.lang.Class<?> wildcardClass31 = month26.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(6, year4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month8, seriesChangeInfo9);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        timeSeries3.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month32, (double) 1969);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(1560185357630L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        long long21 = month19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
//        org.jfree.data.time.Year year23 = month19.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month19);
//        try {
//            java.lang.Number number26 = timeSeries3.getValue((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185405060L + "'", long13 == 1560185405060L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185405060L + "'", long14 == 1560185405060L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getFirstMillisecond();
        int int12 = day6.getYear();
        long long13 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) '#', true);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries24.removeAgedItems(false);
        boolean boolean27 = fixedMillisecond18.equals((java.lang.Object) timeSeries24);
        java.util.Date date28 = fixedMillisecond18.getTime();
        int int29 = year16.compareTo((java.lang.Object) date28);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
        boolean boolean11 = timeSeries1.isEmpty();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: ");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries1.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable throwable5 = null;
        try {
            seriesException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        java.lang.String str19 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        long long21 = month20.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getFirstMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getStart();
//        long long27 = fixedMillisecond23.getMiddleMillisecond();
//        java.util.Date date28 = fixedMillisecond23.getStart();
//        boolean boolean29 = month20.equals((java.lang.Object) fixedMillisecond23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month20.next();
//        int int31 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185405692L + "'", long13 == 1560185405692L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185405692L + "'", long14 == 1560185405692L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185405789L + "'", long1 == 1560185405789L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185405789L + "'", long3 == 1560185405789L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185405789L + "'", long5 == 1560185405789L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185405789L + "'", long7 == 1560185405789L);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection6 = timeSeries5.getTimePeriods();
//        timeSeries5.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries5.addChangeListener(seriesChangeListener9);
//        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
//        double double12 = timeSeries5.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection17 = timeSeries16.getTimePeriods();
//        java.lang.String str18 = timeSeries16.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection23 = timeSeries22.getTimePeriods();
//        timeSeries22.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries22.addChangeListener(seriesChangeListener26);
//        java.lang.String str28 = timeSeries22.getRangeDescription();
//        java.util.Collection collection29 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries22);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getLastMillisecond();
//        long long32 = day30.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection39 = timeSeries38.getTimePeriods();
//        boolean boolean40 = timeSeriesDataItem34.equals((java.lang.Object) timeSeries38);
//        timeSeriesDataItem34.setValue((java.lang.Number) 1560185357630L);
//        timeSeries22.add(timeSeriesDataItem34, true);
//        java.lang.Object obj45 = null;
//        int int46 = timeSeriesDataItem34.compareTo(obj45);
//        java.lang.Object obj47 = null;
//        int int48 = timeSeriesDataItem34.compareTo(obj47);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection53 = timeSeries52.getTimePeriods();
//        timeSeries52.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int59 = fixedMillisecond57.compareTo((java.lang.Object) (-1.0f));
//        int int60 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        long long61 = fixedMillisecond57.getMiddleMillisecond();
//        boolean boolean62 = timeSeriesDataItem34.equals((java.lang.Object) long61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries5.addOrUpdate(timeSeriesDataItem34);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 10, 0);
//        timeSeries5.setKey((java.lang.Comparable) month66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.next();
//        int int70 = month68.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month68.next();
//        try {
//            timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month68, (java.lang.Number) 1560185364026L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(collection6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getStart();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass20 = month19.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int24 = fixedMillisecond22.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date25, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.previous();
//        java.util.Date date35 = year32.getStart();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date35, timeZone36);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
//        java.util.Date date40 = month38.getStart();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date40, timeZone41);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(class43);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries15.fireSeriesChanged();
        int int17 = timeSeries15.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        long long21 = month20.getLastMillisecond();
        long long22 = month20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.previous();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries34.removeAgedItems(false);
        boolean boolean37 = fixedMillisecond28.equals((java.lang.Object) timeSeries34);
        timeSeries34.setMaximumItemCount(0);
        java.lang.String str40 = timeSeries34.getDomainDescription();
        int int41 = year26.compareTo((java.lang.Object) str40);
        long long42 = year26.getFirstMillisecond();
        long long43 = year26.getFirstMillisecond();
        try {
            timeSeries15.update((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560185381782L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61157520000000L) + "'", long42 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61157520000000L) + "'", long43 == (-61157520000000L));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass1 = month0.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        long long11 = day9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1.0f));
//        java.util.Date date14 = day9.getStart();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
//        java.util.Date date22 = year19.getStart();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date22, timeZone23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        long long39 = day0.getLastMillisecond();
//        boolean boolean41 = day0.equals((java.lang.Object) "10");
//        java.util.Date date42 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date42);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.previous();
        long long13 = day6.getFirstMillisecond();
        int int14 = day6.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        int int10 = day6.getDayOfMonth();
        long long11 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        int int23 = month12.compareTo((java.lang.Object) timeSeries17);
        boolean boolean24 = timeSeries17.getNotify();
        java.lang.String str25 = timeSeries17.getDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries17);
        timeSeries26.removeAgedItems(true);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 1560185381782L);
        java.util.Calendar calendar34 = null;
        try {
            year30.peg(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1560185359807L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        org.jfree.data.time.Year year6 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 25568L);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.previous();
        long long13 = day6.getFirstMillisecond();
        int int14 = day6.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.lang.String str17 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getFirstMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        int int25 = day24.getMonth();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day24);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day24.getMiddleMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
        java.lang.String str7 = year3.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 25568L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        java.lang.Object obj11 = null;
        int int12 = timeSeriesDataItem9.compareTo(obj11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries7.setMaximumItemCount(1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod17, seriesChangeInfo18);
//        java.lang.String str20 = seriesChangeEvent19.toString();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]" + "'", str20.equals("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]"));
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries15.fireSeriesChanged();
        int int17 = timeSeries15.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        int int20 = timeSeries15.getItemCount();
        try {
            java.lang.Number number22 = timeSeries15.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        int int10 = month8.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month8.previous();
//        long long13 = month8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month8.previous();
//        int int15 = day0.compareTo((java.lang.Object) month8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1577865599999L, "", "Wed Dec 31 16:00:00 PST 1969");
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries3.equals(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getLastMillisecond();
        java.lang.String str3 = month1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) 1560185359807L);
        boolean boolean7 = year0.equals((java.lang.Object) timeSeriesDataItem6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries17.getRangeDescription();
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        int int25 = day6.compareTo((java.lang.Object) timeSeries11);
        long long26 = day6.getFirstMillisecond();
        int int27 = day6.getMonth();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str30 = timeSeries29.getRangeDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(2, year33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (double) 24234L);
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month35, (double) 5);
        int int40 = day6.compareTo((java.lang.Object) month35);
        java.util.Calendar calendar41 = null;
        try {
            day6.peg(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-57600000L) + "'", long26 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        java.lang.Object obj32 = null;
//        int int33 = timeSeriesDataItem21.compareTo(obj32);
//        java.lang.Object obj34 = null;
//        int int35 = timeSeriesDataItem21.compareTo(obj34);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection40 = timeSeries39.getTimePeriods();
//        timeSeries39.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int46 = fixedMillisecond44.compareTo((java.lang.Object) (-1.0f));
//        int int47 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        long long48 = fixedMillisecond44.getMiddleMillisecond();
//        boolean boolean49 = timeSeriesDataItem21.equals((java.lang.Object) long48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem21.getPeriod();
//        boolean boolean51 = timeSeriesDataItem21.isSelected();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond53.getFirstMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        int int59 = day58.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate60 = day58.getSerialDate();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate60);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day61, (double) 25568L);
//        boolean boolean64 = timeSeriesDataItem21.equals((java.lang.Object) timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 100.0f + "'", obj8.equals(100.0f));
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        int int10 = timeSeries3.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getStart();
        long long24 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Date date25 = fixedMillisecond20.getStart();
        boolean boolean26 = month17.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.Year year27 = month17.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(year27);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries15.fireSeriesChanged();
        int int17 = timeSeries15.getItemCount();
        long long18 = timeSeries15.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries15.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        java.util.List list16 = timeSeries7.getItems();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries18.addChangeListener(seriesChangeListener22);
        java.lang.String str24 = timeSeries18.getRangeDescription();
        java.util.Collection collection25 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        timeSeries36.setKey((java.lang.Comparable) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (-61125897600001L));
        java.lang.String str51 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        long long53 = month52.getLastMillisecond();
        java.lang.String str54 = month52.toString();
        java.lang.String str55 = month52.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month52.next();
        int int57 = month52.getYearValue();
        java.lang.Number number58 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month52);
        try {
            timeSeries3.delete(100, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-6.1125897600001E13d) + "'", number58.equals((-6.1125897600001E13d)));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries11.removeAgedItems(false);
        timeSeries11.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year19);
        int int23 = year19.compareTo((java.lang.Object) 1560185357792L);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 4, false);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 28799999L, true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        int int18 = timeSeries3.getMaximumItemCount();
//        try {
//            timeSeries3.delete((int) (short) 1, (int) (short) 10, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185409832L + "'", long13 == 1560185409832L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185409832L + "'", long14 == 1560185409832L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
        timeSeries14.removeAgedItems(false);
        int int17 = timeSeries14.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timeSeries14.getRangeDescription();
        try {
            java.lang.Number number22 = timeSeries14.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries3.getRangeDescription();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 1560185406185L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.lang.Number number17 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.next();
        java.lang.String str19 = year15.toString();
        boolean boolean20 = day6.equals((java.lang.Object) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day6.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getStart();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass20 = month19.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int24 = fixedMillisecond22.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date25, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.previous();
//        java.util.Date date35 = year32.getStart();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date35, timeZone36);
//        java.util.Date date38 = null;
//        java.util.TimeZone timeZone39 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date38, timeZone39);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 100.0f + "'", obj8.equals(100.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        java.lang.String str25 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries7.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L, "", "June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getFirstMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond40.getStart();
        int int44 = day38.compareTo((java.lang.Object) date43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date48 = fixedMillisecond47.getTime();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries7.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Year year52 = org.jfree.data.time.Year.parseYear("10");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Number number29 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        boolean boolean30 = day23.equals((java.lang.Object) number29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day23.next();
        int int32 = fixedMillisecond11.compareTo((java.lang.Object) regularTimePeriod31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDescription();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection43 = timeSeries42.getTimePeriods();
        timeSeries42.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries42.addChangeListener(seriesChangeListener46);
        java.lang.String str48 = timeSeries42.getRangeDescription();
        java.util.Collection collection49 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries42);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries42.createCopy((int) (short) 1, 2);
        java.lang.Class<?> wildcardClass53 = timeSeries52.getClass();
        boolean boolean54 = fixedMillisecond11.equals((java.lang.Object) timeSeries52);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass15 = month14.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date20 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        long long25 = day23.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) (-1.0f));
//        java.util.Date date28 = day23.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28);
//        int int32 = timeSeriesDataItem4.compareTo((java.lang.Object) date28);
//        java.util.TimeZone timeZone33 = null;
//        java.util.Locale locale34 = null;
//        try {
//            org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date28, timeZone33, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        timeSeries3.add(regularTimePeriod6, (double) 3);
        try {
            timeSeries3.delete(2147483647, 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1560185359743L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getFirstMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond8.getStart();
//        long long12 = fixedMillisecond8.getMiddleMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) long12);
//        long long14 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond0.previous();
//        java.util.Date date16 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone17 = null;
//        java.util.Locale locale18 = null;
//        try {
//            org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185411275L + "'", long1 == 1560185411275L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185411275L + "'", long2 == 1560185411275L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185411275L + "'", long6 == 1560185411275L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185411275L + "'", long14 == 1560185411275L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        java.util.Date date13 = fixedMillisecond3.getTime();
        int int14 = year1.compareTo((java.lang.Object) date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        java.util.Calendar calendar16 = null;
        try {
            month15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond11.previous();
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32" + "'", str2.equals("32"));
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
//        timeSeries3.fireSeriesChanged();
//        java.lang.String str19 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries27.removeAgedItems(false);
//        boolean boolean30 = fixedMillisecond21.equals((java.lang.Object) timeSeries27);
//        timeSeries27.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getFirstMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond34.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
//        int int40 = day39.getMonth();
//        int int41 = day39.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        long long44 = month43.getLastMillisecond();
//        long long45 = month43.getSerialIndex();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        long long47 = month46.getLastMillisecond();
//        long long48 = month46.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 10);
//        int int54 = year53.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
//        int int56 = month43.compareTo((java.lang.Object) timeSeries51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month43.previous();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 1560185394883L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1561964399999L + "'", long44 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 24234L + "'", long45 == 24234L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem21.getPeriod();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod32, number33);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
        timeSeries14.removeAgedItems(false);
        int int17 = timeSeries14.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timeSeries14.getRangeDescription();
        timeSeries14.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond16.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
//        int int22 = day21.getMonth();
//        int int23 = day21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
//        long long25 = day21.getSerialIndex();
//        long long26 = day21.getLastMillisecond();
//        boolean boolean27 = timeSeriesDataItem4.equals((java.lang.Object) day21);
//        java.lang.String str28 = day21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day21.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 25568L + "'", long25 == 25568L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-1969" + "'", str28.equals("31-December-1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 25568L);
//        int int12 = day9.getMonth();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries21.removeAgedItems(false);
//        timeSeries21.setRangeDescription("10");
//        boolean boolean26 = timeSeriesDataItem17.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem17.getPeriod();
//        timeSeriesDataItem17.setSelected(true);
//        boolean boolean30 = day9.equals((java.lang.Object) true);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int39 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener19);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185411781L + "'", long13 == 1560185411781L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185411781L + "'", long14 == 1560185411781L);
//        org.junit.Assert.assertNotNull(collection18);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener30);
        try {
            timeSeries7.update(4, (java.lang.Number) 1560150000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getDomainDescription();
        java.lang.Object obj14 = null;
        boolean boolean15 = timeSeries7.equals(obj14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries20.removeAgedItems(false);
        timeSeries20.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        java.lang.Number number30 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year28);
        int int32 = year28.compareTo((java.lang.Object) 1560185357792L);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 4, false);
        double double36 = timeSeries20.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries7.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        long long39 = month38.getLastMillisecond();
        long long40 = month38.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long40, "10", "10");
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(2, year46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) 24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
        java.lang.Number number52 = timeSeries43.getValue(regularTimePeriod51);
        int int53 = timeSeries7.getIndex(regularTimePeriod51);
        timeSeries7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: Value");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561964399999L + "'", long40 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        long long11 = fixedMillisecond1.getSerialIndex();
        java.util.Date date12 = fixedMillisecond1.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getLastMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Date date9 = month8.getEnd();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        java.lang.Number number40 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) year38);
//        long long41 = year38.getFirstMillisecond();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
//        int int44 = timeSeries9.getItemCount();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        timeSeries3.fireSeriesChanged();
        try {
            java.lang.Number number27 = timeSeries3.getValue((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        timeSeries3.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
        int int33 = day32.getMonth();
        int int34 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) '#', true);
        long long15 = fixedMillisecond11.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        long long31 = month30.getLastMillisecond();
        long long32 = month30.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long32, "10", "10");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(2, year38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) 24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        java.lang.Number number44 = timeSeries35.getValue(regularTimePeriod43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries7.addOrUpdate(regularTimePeriod43, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries18.addChangeListener(seriesChangeListener22);
        java.lang.String str24 = timeSeries18.getRangeDescription();
        java.util.Collection collection25 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        timeSeries36.setKey((java.lang.Comparable) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (-61125897600001L));
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond42.getMiddleMillisecond(calendar51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond42.previous();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        java.lang.String str39 = day0.toString();
//        long long40 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        int int6 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }
}

