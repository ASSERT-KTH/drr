import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.0d, (float) (short) 1, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 1, 0.0f, textAnchor4, (double) 'a', textAnchor6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
        org.junit.Assert.assertNotNull(uRL2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Stroke stroke3 = null;
        try {
            categoryAxis1.setAxisLineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.Plot plot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace8 = categoryAxis1.reserveSpace(graphics2D3, plot4, rectangle2D5, rectangleEdge6, axisSpace7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            textTitle1.setPadding(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            piePlot0.setInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            textTitle1.setMargin(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (short) -1);
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        multiplePiePlot1.setBackgroundPaint(paint3);
        boolean boolean6 = multiplePiePlot1.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 10.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot1.setDataset(pieDataset4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        textTitle16.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle16.getBounds();
        pieSectionEntity14.setArea((java.awt.Shape) rectangle2D22);
        java.lang.Object obj24 = pieSectionEntity14.clone();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator25 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator26 = null;
        try {
            java.lang.String str27 = pieSectionEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator25, uRLTagFragmentGenerator26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        textTitle16.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle16.getBounds();
        pieSectionEntity14.setArea((java.awt.Shape) rectangle2D22);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator24 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator25 = null;
        try {
            java.lang.String str26 = pieSectionEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator24, uRLTagFragmentGenerator25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, (float) (short) -1);
        java.awt.Color color7 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        boolean boolean13 = horizontalAlignment11.equals((java.lang.Object) (short) 1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftInset(1.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("", font3, (java.awt.Paint) color9, rectangleEdge10, horizontalAlignment11, verticalAlignment14, rectangleInsets15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        double double2 = piePlot0.getShadowYOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.05d, (double) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke5 = null;
        try {
            piePlot1.setLabelLinkStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 10.0d, 'a', "Pie Plot" };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { 4.0d, 2.0f, 1L };
        double[] doubleArray11 = new double[] { (byte) 10, 178, (short) 1 };
        double[] doubleArray15 = new double[] { (byte) 10, 178, (short) 1 };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray15 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray7, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font3);
        java.awt.Color color8 = java.awt.Color.red;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", font3, (java.awt.Paint) color8, (float) (byte) -1, (int) (byte) 0, textMeasurer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        textTitle4.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle4.getBounds();
        try {
            piePlot0.drawOutline(graphics2D2, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        try {
            textTitle2.setVerticalAlignment(verticalAlignment10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) stroke13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.calculateLeftInset(1.0d);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets17.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType28, lengthAdjustmentType29);
        try {
            legendTitle15.draw(graphics2D16, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.LegendItem legendItem3 = null;
        legendItemCollection0.add(legendItem3);
        java.lang.Object obj5 = legendItemCollection0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        textTitle5.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle5.getBounds();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset12, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        try {
            double double20 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, (int) (short) -1, 0, rectangle2D11, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        java.lang.String str8 = textTitle1.getText();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color3, (float) (short) -1);
        java.awt.Color color6 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color6);
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!", font9, (java.awt.Paint) color10, (float) (short) -1);
        textLine7.addFragment(textFragment12);
        java.lang.String str14 = textFragment12.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        boolean boolean2 = multiplePiePlot1.isOutlineVisible();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        multiplePiePlot1.axisChanged(axisChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftInset(1.0d);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets7.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType19);
        java.awt.geom.Point2D point2D21 = null;
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            multiplePiePlot1.draw(graphics2D6, rectangle2D17, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        java.awt.Font font10 = textTitle2.getFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle2.arrange(graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.setRange((double) (short) 10, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        multiplePiePlot1.setBackgroundPaint(paint3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            multiplePiePlot1.draw(graphics2D5, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        java.util.Date date4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            double double14 = dateAxis0.dateToJava2D(date4, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        double double4 = categoryAxis2.getLowerMargin();
        float float5 = categoryAxis2.getTickMarkInsideLength();
        categoryAxis2.setMaximumCategoryLabelLines((-1));
        java.awt.Font font8 = categoryAxis2.getLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.extendHeight((double) (byte) 100);
        try {
            org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=175,b=175]", font8, (java.awt.Paint) color9, rectangleEdge10, horizontalAlignment11, verticalAlignment12, rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 102.0d + "'", double15 == 102.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        double double3 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset((double) 1L);
        double double4 = rectangleInsets0.calculateTopInset((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        boolean boolean4 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range1, lengthConstraintType2, (double) 97, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D16, pieDataset17, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        textTitle25.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle25.getBounds();
        pieSectionEntity23.setArea((java.awt.Shape) rectangle2D31);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        try {
            double double35 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "Pie Plot", (java.lang.Comparable) (byte) 100, categoryDataset7, (double) 10, rectangle2D31, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        piePlot0.setForegroundAlpha((float) (short) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        boolean boolean9 = multiplePiePlot8.isOutlineVisible();
        java.lang.Comparable comparable10 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        multiplePiePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot0.equals((java.lang.Object) axisChangeEvent11);
        try {
            piePlot0.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D15, (float) (byte) -1, (float) 0L, textAnchor18, 0.0d, (float) 1L, (float) (short) 10);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, (float) 1L, (float) (byte) 0, textAnchor18, 1.0E-8d, (float) '#', (float) 4);
        java.lang.String str27 = textAnchor18.toString();
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 0, (float) 'a', textAnchor8, (double) 1, textAnchor18);
        try {
            java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=255,g=175,b=175]", graphics2D1, (float) (byte) -1, (float) 255, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str27.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        java.lang.String str2 = piePlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 4, (double) (short) 0, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset(1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.lang.Object obj15 = pieSectionEntity14.clone();
        java.lang.Object obj16 = pieSectionEntity14.clone();
        pieSectionEntity14.setURLText("Other");
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        boolean boolean3 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D14, rectangleEdge18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        double double24 = rectangleInsets22.calculateLeftInset(1.0d);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        textTitle26.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle26.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets22.createAdjustedRectangle(rectangle2D32, lengthAdjustmentType33, lengthAdjustmentType34);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        textTitle37.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle37.getBounds();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity50 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D43, pieDataset44, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        numberAxis51.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets();
        double double57 = rectangleInsets55.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("");
        textTitle59.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D65 = textTitle59.getBounds();
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets55.createOutsetRectangle(rectangle2D65, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double70 = numberAxis51.java2DToValue((double) (short) -1, rectangle2D65, rectangleEdge69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            org.jfree.chart.axis.AxisState axisState72 = numberAxis0.draw(graphics2D20, (double) (-1), rectangle2D32, rectangle2D43, rectangleEdge69, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 102.0d + "'", double57 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.NEGATIVE_INFINITY + "'", double70 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        java.awt.Paint paint8 = null;
        try {
            piePlot1.setLabelLinkPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = piePlot6.getLabelBackgroundPaint();
        java.awt.Paint paint8 = null;
        piePlot6.setShadowPaint(paint8);
        double double10 = piePlot6.getShadowXOffset();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        try {
            dateAxis0.zoomRange((double) (-1), 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D15, (float) (byte) -1, (float) 0L, textAnchor18, 0.0d, (float) 1L, (float) (short) 10);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, (float) 1L, (float) (byte) 0, textAnchor18, 1.0E-8d, (float) '#', (float) 4);
        java.lang.String str27 = textAnchor18.toString();
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 0, (float) 'a', textAnchor8, (double) 1, textAnchor18);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, 10.0f, textAnchor18, (double) (byte) 1, (float) 2, (float) (short) 100);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str27.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateTopInset((double) 500);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D16, pieDataset17, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis3.getCategoryStart(0, 100, rectangle2D16, rectangleEdge24);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getPadding();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelToolTip("");
        int int9 = categoryAxis6.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D19, pieDataset20, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis6.getCategoryStart(0, 100, rectangle2D19, rectangleEdge27);
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D19);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        textTitle33.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle33.getBounds();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity46 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D39, pieDataset40, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        numberAxis47.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets();
        double double53 = rectangleInsets51.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("");
        textTitle55.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D61 = textTitle55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets51.createOutsetRectangle(rectangle2D61, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double66 = numberAxis47.java2DToValue((double) (short) -1, rectangle2D61, rectangleEdge65);
        try {
            java.util.List list67 = numberAxis0.refreshTicks(graphics2D30, axisState31, rectangle2D39, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 102.0d + "'", double53 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.NEGATIVE_INFINITY + "'", double66 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=175,b=175]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.data.Range range3 = null;
        try {
            dateAxis0.setRange(range3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = piePlot6.getLabelBackgroundPaint();
        java.awt.Paint paint8 = null;
        piePlot6.setShadowPaint(paint8);
        double double10 = piePlot6.getShadowXOffset();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        piePlot6.setShadowPaint((java.awt.Paint) color12);
        java.lang.Object obj14 = piePlot6.clone();
        float float15 = piePlot6.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftInset(1.0d);
        double double3 = rectangleInsets0.getRight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = piePlot6.getLabelBackgroundPaint();
        java.awt.Paint paint8 = null;
        piePlot6.setShadowPaint(paint8);
        double double10 = piePlot6.getShadowXOffset();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        piePlot6.setShadowPaint((java.awt.Paint) color12);
        boolean boolean14 = piePlot6.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        piePlot0.setInteriorGap(0.2d);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) (short) -1);
        piePlotState1.setPieHRadius(1.0d);
        double double7 = piePlotState1.getTotal();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double19 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, (int) (byte) 1, 0, rectangle2D17, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        try {
            java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        dateAxis0.configure();
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        java.awt.Font font7 = categoryAxis1.getLabelFont();
        double double8 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color3, (float) (short) -1);
        java.awt.Color color6 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine7.getLastTextFragment();
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textFragment8.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textFragment8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        java.lang.Object obj10 = textTitle2.clone();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        java.awt.Shape shape5 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean3 = lengthConstraintType1.equals((java.lang.Object) rectangleInsets2);
        double double4 = rectangleInsets2.getRight();
        boolean boolean5 = lineBorder0.equals((java.lang.Object) double4);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Pie Plot", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        boolean boolean2 = piePlot0.isCircular();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        java.awt.Shape shape9 = dateAxis0.getDownArrow();
        java.lang.String str10 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1L), keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        basicProjectInfo4.setVersion("");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
        java.lang.String str3 = textFragment2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (short) 0, (double) 100, (double) (-1L), (double) 10.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        double double8 = piePlot1.getStartAngle();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Other");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getID();
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle1.addChangeListener(titleChangeListener3);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getAlpha();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createOutsetRectangle(rectangle2D19, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double24 = numberAxis5.java2DToValue((double) (short) -1, rectangle2D19, rectangleEdge23);
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color0.createContext(colorModel3, rectangle4, rectangle2D19, affineTransform25, renderingHints26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 102.0d + "'", double11 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(paintContext27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        java.awt.Image image4 = piePlot1.getBackgroundImage();
        double double5 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.addOptionalLibrary("TextAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        java.awt.Shape shape9 = dateAxis0.getDownArrow();
        java.util.Date date10 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        double double2 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D7, (float) (byte) -1, (float) 0L, textAnchor10, 0.0d, (float) 1L, (float) (short) 10);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.5f, (float) (short) 100, textAnchor4, 1.0d, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle2.getHorizontalAlignment();
        boolean boolean9 = textBlockAnchor0.equals((java.lang.Object) horizontalAlignment8);
        java.lang.String str10 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str10.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color1 = color0.brighter();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        java.lang.String str7 = basicProjectInfo6.getVersion();
        java.lang.String str8 = basicProjectInfo6.getLicenceName();
        boolean boolean9 = color0.equals((java.lang.Object) basicProjectInfo6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        boolean boolean3 = horizontalAlignment1.equals((java.lang.Object) (short) 1);
        boolean boolean4 = lengthConstraintType0.equals((java.lang.Object) horizontalAlignment1);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        double double5 = piePlot1.getMaximumLabelWidth();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int7 = color6.getAlpha();
        java.awt.color.ColorSpace colorSpace8 = color6.getColorSpace();
        boolean boolean9 = piePlot1.equals((java.lang.Object) colorSpace8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Color color0 = java.awt.Color.CYAN;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) color0, (java.lang.Object) "RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateLeftInset(1.0d);
        textTitle1.setMargin(rectangleInsets3);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot0.setURLGenerator(pieURLGenerator2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D14, pieDataset15, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets();
        double double27 = rectangleInsets25.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets25.createOutsetRectangle(rectangle2D35, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis40.setLabelToolTip("");
        categoryAxis40.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets();
        double double54 = rectangleInsets52.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        textTitle56.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle56.getBounds();
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets52.createOutsetRectangle(rectangle2D62, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double67 = numberAxis48.java2DToValue((double) (short) -1, rectangle2D62, rectangleEdge66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double69 = categoryAxis40.getCategoryJava2DCoordinate(categoryAnchor45, (int) (short) 0, 255, rectangle2D62, rectangleEdge68);
        double double70 = dateAxis22.java2DToValue((double) '4', rectangle2D38, rectangleEdge68);
        double double71 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (byte) -1, (int) 'a', rectangle2D14, rectangleEdge68);
        int int72 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 102.0d + "'", double27 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 102.0d + "'", double54 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.223372036854776E18d + "'", double70 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        java.awt.Font font10 = textTitle2.getFont();
        textTitle2.setURLText("ThreadContext");
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        try {
            polarPlot0.zoomRangeAxes(1.0E-5d, plotRenderingInfo3, point2D4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString6 = null;
        standardPieSectionLabelGenerator4.setAttributedLabel(500, attributedString6);
        boolean boolean9 = standardPieSectionLabelGenerator4.equals((java.lang.Object) 0.0f);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelLinkPaint(paint11);
        piePlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, (float) (short) -1);
        java.lang.String str5 = textFragment4.getText();
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textFragment4.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        java.awt.Shape shape7 = null;
        try {
            dateAxis0.setDownArrow(shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setLatestAngle(0.14d);
        piePlotState1.setLatestAngle((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, pieDataset16, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        pieSectionEntity22.setArea((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D30);
        piePlotState1.setLinkArea(rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D34 = piePlotState1.getExplodedPieArea();
        piePlotState1.setTotal((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(rectangle2D34);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint11 = piePlot10.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        piePlot10.setSimpleLabelOffset(rectangleInsets12);
        valueMarker9.setLabelOffset(rectangleInsets12);
        float float15 = valueMarker9.getAlpha();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint17 = piePlot16.getLabelOutlinePaint();
        java.awt.Stroke stroke18 = piePlot16.getLabelOutlineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot16.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color21 = java.awt.Color.PINK;
        float[] floatArray27 = new float[] { (short) 100, 10L, (short) 0, (-1.0f), (short) 1 };
        float[] floatArray28 = color21.getComponents(floatArray27);
        float[] floatArray29 = color19.getComponents(floatArray28);
        valueMarker9.setLabelPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int3 = color2.getAlpha();
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        float[] floatArray11 = new float[] { (byte) 100, 178, 100.0f, 100L, (byte) 0, 0 };
        float[] floatArray12 = color1.getComponents(colorSpace4, floatArray11);
        boolean boolean13 = blockBorder0.equals((java.lang.Object) floatArray11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset7);
        try {
            org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset7, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1000.0d + "'", number8.equals(1000.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.BOTTOM_LEFT", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray33 = null;
        try {
            categoryPlot19.setDomainAxes(categoryAxisArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        try {
            java.lang.String str17 = pieSectionEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.data.KeyToGroupMap keyToGroupMap8 = null;
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset7, keyToGroupMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis37.setLabelToolTip("");
        int int40 = categoryAxis37.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis37.setTickMarkStroke(stroke41);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = valueMarker43.getLabelOffsetType();
        org.jfree.chart.util.Layer layer45 = null;
        try {
            boolean boolean46 = categoryPlot19.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker43, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType44);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = piePlot3.getLabelOutlineStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        double double7 = piePlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setLatestAngle(0.14d);
        piePlotState1.setLatestAngle((double) 10.0f);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, pieDataset16, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        pieSectionEntity22.setArea((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D30);
        piePlotState1.setLinkArea(rectangle2D30);
        piePlotState1.setLatestAngle((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        boolean boolean7 = basicProjectInfo4.equals((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Pie Plot");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setAutoRangeIncludesZero(false);
        numberAxis3.setVerticalTickLabels(true);
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis3.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets16.calculateLeftInset(1.0d);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        textTitle20.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle20.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets16.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType27, lengthAdjustmentType28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        double double35 = rectangleInsets33.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        textTitle37.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets33.createOutsetRectangle(rectangle2D43, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis48.setLabelToolTip("");
        categoryAxis48.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor53 = null;
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        numberAxis56.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets();
        double double62 = rectangleInsets60.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        textTitle64.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D70 = textTitle64.getBounds();
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets60.createOutsetRectangle(rectangle2D70, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double75 = numberAxis56.java2DToValue((double) (short) -1, rectangle2D70, rectangleEdge74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double77 = categoryAxis48.getCategoryJava2DCoordinate(categoryAnchor53, (int) (short) 0, 255, rectangle2D70, rectangleEdge76);
        double double78 = dateAxis30.java2DToValue((double) '4', rectangle2D46, rectangleEdge76);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        try {
            org.jfree.chart.axis.AxisState axisState81 = numberAxis0.draw(graphics2D14, 1.0d, rectangle2D29, rectangle2D46, rectangleEdge79, plotRenderingInfo80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 102.0d + "'", double62 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + Double.NEGATIVE_INFINITY + "'", double75 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 9.223372036854776E18d + "'", double78 == 9.223372036854776E18d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        boolean boolean9 = multiplePiePlot8.isOutlineVisible();
        java.lang.Comparable comparable10 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        multiplePiePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot0.equals((java.lang.Object) axisChangeEvent11);
        boolean boolean14 = piePlot0.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        textTitle19.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle19.getBounds();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D25, pieDataset26, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle34.getBounds();
        pieSectionEntity32.setArea((java.awt.Shape) rectangle2D40);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets17.createInsetRectangle(rectangle2D40);
        try {
            piePlot0.drawOutline(graphics2D15, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        try {
            categoryPlot19.setRangeAxisLocation(axisLocation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setTickMarkInsideLength((float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        int int2 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        java.lang.String str4 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeIncludesZero(false);
        numberAxis2.setVerticalTickLabels(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis8.setLabelToolTip("");
        int int11 = categoryAxis8.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        textTitle15.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle15.getBounds();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity28 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D21, pieDataset22, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis8.getCategoryStart(0, 100, rectangle2D21, rectangleEdge29);
        numberAxis2.setDownArrow((java.awt.Shape) rectangle2D21);
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo();
        try {
            java.lang.Object obj33 = blockContainer0.draw(graphics2D1, rectangle2D21, (java.lang.Object) projectInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.JFreeChart jFreeChart3 = plotChangeEvent2.getChart();
        org.jfree.chart.JFreeChart jFreeChart4 = plotChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "ChartChangeEventType.GENERAL", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        java.awt.Shape shape9 = dateAxis0.getDownArrow();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint11 = piePlot10.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        piePlot10.setSimpleLabelOffset(rectangleInsets12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot10.setLegendLabelURLGenerator(pieURLGenerator14);
        java.awt.Paint paint16 = null;
        piePlot10.setBackgroundPaint(paint16);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot10);
        java.lang.String str19 = piePlot10.getPlotType();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pie Plot" + "'", str19.equals("Pie Plot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        org.jfree.data.Range range2 = null;
        try {
            numberAxis0.setDefaultAutoRange(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        piePlot0.setLabelGap((double) 10.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        java.lang.Object obj3 = legendItemCollection0.clone();
        try {
            org.jfree.chart.LegendItem legendItem5 = legendItemCollection0.get(178);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 178, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Other", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        textTitle3.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle3.getBounds();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity16 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D9, pieDataset10, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        textTitle18.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle18.getBounds();
        pieSectionEntity16.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24);
        try {
            blockContainer0.draw(graphics2D1, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 1.0E-8d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) (short) 1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) (byte) 100, 1.0E-8d);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle8.getHorizontalAlignment();
        boolean boolean15 = textTitle8.getNotify();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets();
        double double22 = rectangleInsets20.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets20.createOutsetRectangle(rectangle2D30, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double35 = numberAxis16.java2DToValue((double) (short) -1, rectangle2D30, rectangleEdge34);
        java.lang.String str36 = rectangleEdge34.toString();
        flowArrangement6.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) rectangleEdge34);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 102.0d + "'", double22 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleEdge.LEFT" + "'", str36.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis11.setLabelToolTip("");
        int int14 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis11.setTickMarkStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color9, stroke15);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (-1.0f), stroke15);
        piePlot1.setShadowXOffset((double) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str2 = plotOrientation1.toString();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot1.getLegendItems();
        org.jfree.data.general.DatasetGroup datasetGroup3 = multiplePiePlot1.getDatasetGroup();
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNull(datasetGroup3);
        org.junit.Assert.assertNotNull(tableOrder4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) 100L, 0.5f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-334) + "'", int3 == (-334));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "java.awt.Color[r=255,g=175,b=175]", doubleArray7);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getExplodedPieArea();
        org.junit.Assert.assertNull(rectangle2D2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        boolean boolean3 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = piePlot6.getLabelOutlinePaint();
        java.awt.Stroke stroke8 = piePlot6.getLabelOutlineStroke();
        double double9 = piePlot6.getInteriorGap();
        piePlot6.setCircular(true);
        categoryAxis5.setPlot((org.jfree.chart.plot.Plot) piePlot6);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.08d + "'", double9 == 0.08d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = java.awt.Color.PINK;
        float[] floatArray6 = new float[] { (short) 100, 10L, (short) 0, (-1.0f), (short) 1 };
        float[] floatArray7 = color0.getComponents(floatArray6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = piePlot8.getLabelOutlinePaint();
        java.awt.Stroke stroke10 = piePlot8.getLabelOutlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot8.setOutlinePaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.PINK;
        float[] floatArray19 = new float[] { (short) 100, 10L, (short) 0, (-1.0f), (short) 1 };
        float[] floatArray20 = color13.getComponents(floatArray19);
        float[] floatArray21 = color11.getComponents(floatArray20);
        float[] floatArray22 = color0.getComponents(floatArray20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        categoryPlot19.setRenderer(97, categoryItemRenderer44);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot19.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = new org.jfree.chart.LegendItemCollection();
        boolean boolean28 = legendItemCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.LegendItem legendItem29 = null;
        legendItemCollection26.add(legendItem29);
        categoryPlot19.setFixedLegendItems(legendItemCollection26);
        int int32 = legendItemCollection26.getItemCount();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = piePlot2.getLabelOutlinePaint();
        try {
            xYPlot0.setQuadrantPaint((int) (byte) 10, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.setTickMarkOutsideLength((float) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis8.setLabelToolTip("");
        categoryAxis8.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets();
        double double22 = rectangleInsets20.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets20.createOutsetRectangle(rectangle2D30, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double35 = numberAxis16.java2DToValue((double) (short) -1, rectangle2D30, rectangleEdge34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double37 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor13, (int) (short) 0, 255, rectangle2D30, rectangleEdge36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis0.java2DToValue(0.0d, rectangle2D30, rectangleEdge38);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 102.0d + "'", double22 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Paint paint2 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int3 = color2.getAlpha();
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        float[] floatArray11 = new float[] { (byte) 100, 178, 100.0f, 100L, (byte) 0, 0 };
        float[] floatArray12 = color1.getComponents(colorSpace4, floatArray11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint14 = piePlot13.getLabelOutlinePaint();
        java.awt.Stroke stroke15 = piePlot13.getLabelOutlineStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot13.setOutlinePaint((java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.PINK;
        float[] floatArray24 = new float[] { (short) 100, 10L, (short) 0, (-1.0f), (short) 1 };
        float[] floatArray25 = color18.getComponents(floatArray24);
        float[] floatArray26 = color16.getComponents(floatArray25);
        float[] floatArray27 = color0.getComponents(colorSpace4, floatArray26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (short) -1);
        java.lang.Object obj3 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis0.getTickUnit();
        double double10 = numberAxis0.getLowerMargin();
        double double11 = numberAxis0.getUpperBound();
        numberAxis0.centerRange((double) 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        boolean boolean2 = multiplePiePlot1.isOutlineVisible();
        double double3 = multiplePiePlot1.getLimit();
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        boolean boolean7 = multiplePiePlot6.isOutlineVisible();
        double double8 = multiplePiePlot6.getLimit();
        java.lang.String str9 = multiplePiePlot6.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder10 = multiplePiePlot6.getDataExtractOrder();
        multiplePiePlot1.setDataExtractOrder(tableOrder10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(tableOrder10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            categoryPlot19.addDomainMarker(2, categoryMarker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        textTitle14.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle14.getBounds();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D20, pieDataset21, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        pieSectionEntity27.setArea((java.awt.Shape) rectangle2D35);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35);
        piePlot12.setLegendItemShape((java.awt.Shape) rectangle2D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis40.setLabelToolTip("");
        categoryAxis40.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets();
        double double54 = rectangleInsets52.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        textTitle56.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle56.getBounds();
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets52.createOutsetRectangle(rectangle2D62, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double67 = numberAxis48.java2DToValue((double) (short) -1, rectangle2D62, rectangleEdge66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double69 = categoryAxis40.getCategoryJava2DCoordinate(categoryAnchor45, (int) (short) 0, 255, rectangle2D62, rectangleEdge68);
        double double70 = dateAxis0.valueToJava2D((double) 10L, rectangle2D35, rectangleEdge68);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 102.0d + "'", double54 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PlotOrientation.VERTICAL", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        java.lang.String str6 = basicProjectInfo4.getLicenceName();
        basicProjectInfo4.setCopyright("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = piePlot2.getLabelOutlinePaint();
        java.awt.Stroke stroke4 = piePlot2.getLabelOutlineStroke();
        double double5 = piePlot2.getInteriorGap();
        piePlot2.setCircular(true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        textTitle11.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity24 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D17, pieDataset18, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            piePlot2.draw(graphics2D9, rectangle2D17, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot0.handleClick(0, (int) (short) 0, plotRenderingInfo6);
        java.awt.Color color8 = java.awt.Color.red;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = piePlot0.getLabelPaint();
        try {
            piePlot0.setInteriorGap((double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) '#', (double) (-1.0f), (float) 2, (float) 2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        piePlot0.setIgnoreZeroValues(true);
        float float4 = piePlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        java.lang.Object obj3 = legendItemCollection0.clone();
        try {
            org.jfree.chart.LegendItem legendItem5 = legendItemCollection0.get(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        categoryAxis1.setAxisLineVisible(true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        boolean boolean27 = categoryPlot19.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D14, rectangleEdge18);
        org.jfree.data.Range range20 = null;
        try {
            numberAxis0.setDefaultAutoRange(range20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        int int4 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis1.setTickMarkStroke(stroke5);
        categoryAxis1.setFixedDimension(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        categoryAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        textTitle17.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets13.createOutsetRectangle(rectangle2D23, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = numberAxis9.java2DToValue((double) (short) -1, rectangle2D23, rectangleEdge27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double30 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 0, 255, rectangle2D23, rectangleEdge29);
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 102.0d + "'", double15 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        double double4 = categoryAxis1.getUpperMargin();
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        float float6 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range4 = numberAxis3D0.getRange();
        boolean boolean5 = numberAxis3D0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        piePlot3.setIgnoreZeroValues(true);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3);
        org.jfree.chart.plot.Plot plot8 = numberAxis0.getPlot();
        java.awt.Paint paint9 = null;
        try {
            numberAxis0.setTickLabelPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.lang.Object obj7 = textTitle1.clone();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D14 = textTitle1.arrange(graphics2D8, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (short) 0, (double) 100, (double) (-1L), (double) 10.0f);
        java.lang.Object obj7 = textTitle1.clone();
        java.lang.Object obj8 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font2, (java.awt.Paint) color3, (float) (short) -1);
        java.awt.Color color6 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine7.getLastTextFragment();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color10 = color9.brighter();
        boolean boolean11 = textLine7.equals((java.lang.Object) color10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textFragment8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart12.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Font font5 = dateAxis1.getLabelFont();
        boolean boolean6 = lineBorder0.equals((java.lang.Object) font5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment3.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelBackgroundPaint();
        java.awt.Paint paint2 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets3.createOutsetRectangle(rectangle2D13, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis18.setLabelToolTip("");
        categoryAxis18.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets30.createOutsetRectangle(rectangle2D40, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double45 = numberAxis26.java2DToValue((double) (short) -1, rectangle2D40, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor23, (int) (short) 0, 255, rectangle2D40, rectangleEdge46);
        double double48 = dateAxis0.java2DToValue((double) '4', rectangle2D16, rectangleEdge46);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        float float51 = categoryAxis50.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis50.getTickLabelInsets();
        double double54 = rectangleInsets52.calculateTopOutset((double) 178);
        dateAxis0.setTickLabelInsets(rectangleInsets52);
        double double57 = rectangleInsets52.calculateBottomInset((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 102.0d + "'", double5 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 102.0d + "'", double32 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 9.223372036854776E18d + "'", double48 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=175,b=175]", graphics2D1, (float) (short) -1, (float) (-334), 90.0d, (float) 0, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 255, (double) 255, 1.0E-5d, 0.08d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Other");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        boolean boolean5 = jFreeChart4.isNotify();
        java.util.List list6 = null;
        try {
            jFreeChart4.setSubtitles(list6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 10.0d);
        double double3 = rectangleConstraint2.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) -1);
        org.jfree.data.Range range6 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toRangeHeight(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D14, rectangleEdge18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = new org.jfree.chart.LegendItemCollection();
        boolean boolean22 = legendItemCollection20.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean22, jFreeChart23, (int) 'a', (int) (byte) 100);
        int int27 = chartProgressEvent26.getType();
        int int28 = chartProgressEvent26.getType();
        int int29 = chartProgressEvent26.getPercent();
        boolean boolean30 = rectangleEdge18.equals((java.lang.Object) int29);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset3 = polarPlot0.getDataset();
        org.junit.Assert.assertNull(xYDataset3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        java.awt.Stroke stroke8 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        double double9 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint10.toFixedHeight((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle1.arrange(graphics2D7, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        try {
            categoryPlot19.addDomainMarker(categoryMarker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        basicProjectInfo4.setLicenceName("java.awt.Color[r=255,g=175,b=175]");
        basicProjectInfo4.setVersion("");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.Point2D point2D44 = null;
        org.jfree.chart.plot.PlotState plotState45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            categoryPlot19.draw(graphics2D42, rectangle2D43, point2D44, plotState45, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke3);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot0.removeChangeListener(plotChangeListener4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot0.getLabelPadding();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        java.awt.Stroke stroke30 = categoryPlot19.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        int int8 = chartProgressEvent6.getType();
        org.jfree.chart.JFreeChart jFreeChart9 = chartProgressEvent6.getChart();
        chartProgressEvent6.setPercent((int) (short) 100);
        chartProgressEvent6.setPercent((int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(jFreeChart9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 10.0d);
        double double5 = rectangleConstraint4.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint4.toFixedHeight((double) (short) -1);
        try {
            org.jfree.chart.util.Size2D size2D8 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor1.distributeLabels((double) (-1), (double) (byte) 0);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets9.createOutsetRectangle(rectangle2D19, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double24 = numberAxis5.java2DToValue((double) (short) -1, rectangle2D19, rectangleEdge23);
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 102.0d + "'", double11 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        boolean boolean7 = dateAxis0.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis8.getTickMarkPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis12.getTickMarkPosition();
        dateAxis8.setTickMarkPosition(dateTickMarkPosition13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis8.setTickUnit(dateTickUnit15, false, false);
        dateAxis0.setTickUnit(dateTickUnit15, true, true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(dateTickUnit15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font4, (java.awt.Paint) color5, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!", font4);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color10, (float) 255, textMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) stroke13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        double double19 = categoryAxis18.getLowerMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis24.setLabelToolTip("");
        categoryAxis24.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets();
        double double38 = rectangleInsets36.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        textTitle40.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle40.getBounds();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets36.createOutsetRectangle(rectangle2D46, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double51 = numberAxis32.java2DToValue((double) (short) -1, rectangle2D46, rectangleEdge50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double53 = categoryAxis24.getCategoryJava2DCoordinate(categoryAnchor29, (int) (short) 0, 255, rectangle2D46, rectangleEdge52);
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray57, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray60);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis63.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        numberAxis66.setAutoRangeIncludesZero(false);
        numberAxis66.setVerticalTickLabels(true);
        boolean boolean71 = numberAxis66.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis63, (org.jfree.chart.axis.ValueAxis) numberAxis66, categoryItemRenderer72);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D74 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D74.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range78 = categoryPlot73.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D74);
        org.jfree.chart.axis.AxisSpace axisSpace79 = null;
        categoryPlot73.setFixedDomainAxisSpace(axisSpace79);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot73.getRangeAxisEdge();
        double double82 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor20, (int) (short) 10, 0, rectangle2D46, rectangleEdge81);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D83 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D83.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand87 = null;
        numberAxis3D83.setMarkerBand(markerAxisBand87);
        try {
            java.lang.Object obj89 = legendTitle15.draw(graphics2D16, rectangle2D46, (java.lang.Object) markerAxisBand87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 102.0d + "'", double38 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.NEGATIVE_INFINITY + "'", double51 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(range78);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) rectangleInsets1);
        double double3 = rectangleInsets1.getRight();
        double double5 = rectangleInsets1.calculateTopOutset(1.0E-5d);
        double double7 = rectangleInsets1.calculateLeftOutset((double) '4');
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, (float) (short) -1);
        java.lang.String str5 = textFragment4.getText();
        java.awt.Paint paint6 = textFragment4.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        textTitle5.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle5.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis19.setLabelToolTip("");
        categoryAxis19.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets();
        double double33 = rectangleInsets31.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        textTitle35.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets31.createOutsetRectangle(rectangle2D41, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double46 = numberAxis27.java2DToValue((double) (short) -1, rectangle2D41, rectangleEdge45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double48 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor24, (int) (short) 0, 255, rectangle2D41, rectangleEdge47);
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray52, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis58.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeIncludesZero(false);
        numberAxis61.setVerticalTickLabels(true);
        boolean boolean66 = numberAxis61.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis61, categoryItemRenderer67);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D69.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range73 = categoryPlot68.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D69);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        categoryPlot68.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot68.getRangeAxisEdge();
        double double77 = categoryAxis13.getCategoryJava2DCoordinate(categoryAnchor15, (int) (short) 10, 0, rectangle2D41, rectangleEdge76);
        double double78 = numberAxis0.java2DToValue((double) 2, rectangle2D11, rectangleEdge76);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 102.0d + "'", double33 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(range73);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        double double2 = dateAxis0.getFixedAutoRange();
        double double3 = dateAxis0.getUpperBound();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D15, (float) (byte) -1, (float) 0L, textAnchor18, 0.0d, (float) 1L, (float) (short) 10);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, (float) 1L, (float) (byte) 0, textAnchor18, 1.0E-8d, (float) '#', (float) 4);
        java.lang.String str27 = textAnchor18.toString();
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 0, (float) 'a', textAnchor8, (double) 1, textAnchor18);
        try {
            java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.text.TextUtilities.drawAlignedString("Pie Plot", graphics2D1, (float) (short) 100, (float) (byte) 1, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str27.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color4 = color3.brighter();
        categoryAxis1.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot6 = categoryAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) '4', 0.0d, (double) 10L, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean8 = lengthConstraintType6.equals((java.lang.Object) rectangleInsets7);
        double double9 = rectangleInsets7.getRight();
        double double11 = rectangleInsets7.calculateTopOutset(1.0E-5d);
        boolean boolean12 = unitType0.equals((java.lang.Object) double11);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int2 = color1.getTransparency();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        boolean boolean10 = multiplePiePlot9.isOutlineVisible();
        java.lang.Comparable comparable11 = multiplePiePlot9.getAggregatedItemsKey();
        piePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Other" + "'", comparable11.equals("Other"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint16 = piePlot15.getLabelOutlinePaint();
        piePlot15.setIgnoreZeroValues(true);
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement19.add((org.jfree.chart.block.Block) textTitle21, (java.lang.Object) stroke27);
        piePlot15.setBaseSectionOutlineStroke(stroke27);
        jFreeChart12.setBorderStroke(stroke27);
        try {
            java.awt.image.BufferedImage bufferedImage33 = jFreeChart12.createBufferedImage((int) (byte) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint7 = piePlot6.getLabelBackgroundPaint();
        java.awt.Paint paint8 = null;
        piePlot6.setShadowPaint(paint8);
        double double10 = piePlot6.getShadowXOffset();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        dateAxis0.setRange((double) (byte) 1, 90.0d);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle22.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets18.createOutsetRectangle(rectangle2D28, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis33.setLabelToolTip("");
        categoryAxis33.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = new org.jfree.chart.util.RectangleInsets();
        double double47 = rectangleInsets45.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        textTitle49.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle49.getBounds();
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets45.createOutsetRectangle(rectangle2D55, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double60 = numberAxis41.java2DToValue((double) (short) -1, rectangle2D55, rectangleEdge59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double62 = categoryAxis33.getCategoryJava2DCoordinate(categoryAnchor38, (int) (short) 0, 255, rectangle2D55, rectangleEdge61);
        double double63 = dateAxis15.java2DToValue((double) '4', rectangle2D31, rectangleEdge61);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        float float66 = categoryAxis65.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryAxis65.getTickLabelInsets();
        double double69 = rectangleInsets67.calculateTopOutset((double) 178);
        dateAxis15.setTickLabelInsets(rectangleInsets67);
        dateAxis0.setLabelInsets(rectangleInsets67);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 102.0d + "'", double20 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 102.0d + "'", double47 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 9.223372036854776E18d + "'", double63 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 2.0f + "'", float66 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.0d + "'", double69 == 2.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        boolean boolean2 = multiplePiePlot1.isOutlineVisible();
        double double3 = multiplePiePlot1.getLimit();
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot1.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(tableOrder5);
        org.junit.Assert.assertNotNull(tableOrder6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = new org.jfree.chart.LegendItemCollection();
        boolean boolean28 = legendItemCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.LegendItem legendItem29 = null;
        legendItemCollection26.add(legendItem29);
        categoryPlot19.setFixedLegendItems(legendItemCollection26);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        try {
            categoryPlot19.addDomainMarker((int) (short) -1, categoryMarker33, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart12.getLegend((int) '4');
        java.lang.Object obj17 = jFreeChart12.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getPadding();
        java.lang.String str4 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis3D20.setStandardTickUnits(tickUnitSource25);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(tickUnitSource25);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        double double8 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "Pie Plot", "Pie Plot", "");
        basicProjectInfo6.setLicenceName("java.awt.Color[r=255,g=175,b=175]");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) "TextAnchor.BOTTOM_LEFT");
        java.lang.Object obj5 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart12.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 0.0d);
        org.jfree.chart.block.Block block8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color10 = color9.brighter();
        flowArrangement7.add(block8, (java.lang.Object) color10);
        boolean boolean12 = categoryAxis3D1.equals((java.lang.Object) flowArrangement7);
        java.lang.String str14 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelToolTip("");
        int int9 = categoryAxis6.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        textTitle13.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D19, pieDataset20, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis6.getCategoryStart(0, 100, rectangle2D19, rectangleEdge27);
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D19);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis0.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot19.addChangeListener(plotChangeListener43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace45);
        categoryPlot19.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("rect", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        java.awt.Image image4 = piePlot1.getBackgroundImage();
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.lang.Object obj2 = standardPieSectionLabelGenerator1.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        categoryAxis4.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets16.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        textTitle20.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets16.createOutsetRectangle(rectangle2D26, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double31 = numberAxis12.java2DToValue((double) (short) -1, rectangle2D26, rectangleEdge30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor9, (int) (short) 0, 255, rectangle2D26, rectangleEdge32);
        boolean boolean34 = standardPieSectionLabelGenerator1.equals((java.lang.Object) categoryAnchor9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 102.0d + "'", double18 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        jFreeChart12.setTitle("Other");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets3.createOutsetRectangle(rectangle2D13, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis18.setLabelToolTip("");
        categoryAxis18.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets30.createOutsetRectangle(rectangle2D40, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double45 = numberAxis26.java2DToValue((double) (short) -1, rectangle2D40, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor23, (int) (short) 0, 255, rectangle2D40, rectangleEdge46);
        double double48 = dateAxis0.java2DToValue((double) '4', rectangle2D16, rectangleEdge46);
        dateAxis0.setLowerBound((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 102.0d + "'", double5 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 102.0d + "'", double32 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 9.223372036854776E18d + "'", double48 == 9.223372036854776E18d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = java.awt.Color.PINK;
        float[] floatArray7 = new float[] { (short) 100, 10L, (short) 0, (-1.0f), (short) 1 };
        float[] floatArray8 = color1.getComponents(floatArray7);
        float[] floatArray9 = color0.getColorComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 0.0d);
        org.jfree.chart.block.Block block8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color10 = color9.brighter();
        flowArrangement7.add(block8, (java.lang.Object) color10);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.awt.Paint paint2 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.awt.Shape shape2 = dateAxis0.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range7 = numberAxis3D3.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, 0.4d);
        dateAxis0.setRange(range7);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.lang.String str15 = pieSectionEntity14.getShapeType();
        pieSectionEntity14.setURLText("TextAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "rect" + "'", str15.equals("rect"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str2.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle2.getHorizontalAlignment();
        boolean boolean9 = textBlockAnchor0.equals((java.lang.Object) horizontalAlignment8);
        java.lang.Object obj10 = null;
        boolean boolean11 = textBlockAnchor0.equals(obj10);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis48.setLabelToolTip("");
        int int51 = categoryAxis48.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis48.setTickMarkStroke(stroke52);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color46, stroke52);
        xYPlot44.setRangeCrosshairStroke(stroke52);
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis59.setLabelToolTip("");
        int int62 = categoryAxis59.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke63 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis59.setTickMarkStroke(stroke63);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color57, stroke63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot67 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint68 = piePlot67.getLabelOutlinePaint();
        java.awt.Stroke stroke69 = piePlot67.getBaseSectionOutlineStroke();
        boolean boolean70 = rectangleAnchor66.equals((java.lang.Object) stroke69);
        valueMarker65.setOutlineStroke(stroke69);
        java.awt.Font font75 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color76 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment78 = new org.jfree.chart.text.TextFragment("hi!", font75, (java.awt.Paint) color76, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine79 = new org.jfree.chart.text.TextLine("", font75);
        org.jfree.chart.text.TextFragment textFragment80 = new org.jfree.chart.text.TextFragment("hi!", font75);
        valueMarker65.setLabelFont(font75);
        org.jfree.chart.util.Layer layer82 = null;
        xYPlot44.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker65, layer82);
        org.jfree.chart.util.Layer layer84 = null;
        try {
            boolean boolean85 = categoryPlot19.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker65, layer84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(color76);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        float float7 = piePlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range9 = numberAxis3D5.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint2.toRangeWidth(range9);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range9, 0.14d);
        double double13 = range12.getCentralValue();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset7, (double) 0.0f);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("XY Plot", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker9.getLabelOffsetType();
        java.awt.Font font11 = valueMarker9.getLabelFont();
        java.awt.Font font12 = valueMarker9.getLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelOutlinePaint();
        java.awt.Stroke stroke13 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) stroke13);
        valueMarker9.setOutlineStroke(stroke13);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font19, (java.awt.Paint) color20, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font19);
        valueMarker9.setLabelFont(font19);
        valueMarker9.setLabel("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        valueMarker9.notifyListeners(markerChangeEvent28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        try {
            valueMarker9.setLabelAnchor(rectangleAnchor30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot19.getDataset(15);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNull(categoryDataset28);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
        size2D5.setHeight((double) 100L);
        org.junit.Assert.assertNotNull(size2D5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        categoryAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getAlpha();
        java.awt.color.ColorSpace colorSpace7 = color5.getColorSpace();
        float[] floatArray14 = new float[] { (byte) 100, 178, 100.0f, 100L, (byte) 0, 0 };
        float[] floatArray15 = color4.getComponents(colorSpace7, floatArray14);
        boolean boolean16 = blockBorder3.equals((java.lang.Object) floatArray14);
        boolean boolean17 = chartChangeEventType2.equals((java.lang.Object) boolean16);
        titleChangeEvent1.setType(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis15.setTickMarkStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color13, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke25 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean26 = rectangleAnchor22.equals((java.lang.Object) stroke25);
        valueMarker21.setOutlineStroke(stroke25);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font31, (java.awt.Paint) color32, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font31);
        valueMarker21.setLabelFont(font31);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer38);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset41);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, (float) (byte) -1, (float) 0L, textAnchor14, 0.0d, (float) 1L, (float) (short) 10);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D7, (float) 1L, (float) (byte) 0, textAnchor14, 1.0E-8d, (float) '#', (float) 4);
        java.lang.String str23 = textAnchor14.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", graphics2D1, 2.0f, (float) (-334), textAnchor4, (double) 10.0f, textAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str23.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj2 = titleChangeEvent1.getSource();
        org.jfree.chart.title.Title title3 = titleChangeEvent1.getTitle();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(title3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 178, 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 0.4d, (double) 0L, rectangleAnchor5);
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getPieArea();
        double double3 = piePlotState1.getPieCenterX();
        org.jfree.chart.entity.EntityCollection entityCollection4 = piePlotState1.getEntityCollection();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(entityCollection4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = piePlot3.getLabelOutlineStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        piePlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString6 = null;
        standardPieSectionLabelGenerator4.setAttributedLabel(500, attributedString6);
        boolean boolean9 = standardPieSectionLabelGenerator4.equals((java.lang.Object) 0.0f);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getSeriesCount();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        double double8 = rectangleInsets6.calculateLeftInset(1.0d);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets6.createAdjustedRectangle(rectangle2D16, lengthAdjustmentType17, lengthAdjustmentType18);
        try {
            xYPlot0.drawBackground(graphics2D5, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis15.setTickMarkStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color13, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke25 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean26 = rectangleAnchor22.equals((java.lang.Object) stroke25);
        valueMarker21.setOutlineStroke(stroke25);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font31, (java.awt.Paint) color32, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font31);
        valueMarker21.setLabelFont(font31);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer38);
        int int40 = xYPlot0.getSeriesCount();
        xYPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font7, (java.awt.Paint) color8, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!", font7);
        boolean boolean13 = textFragment3.equals((java.lang.Object) textFragment12);
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textFragment12.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot19.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace29);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(valueAxis28);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 178, 0.0d);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets3.createOutsetRectangle(rectangle2D13, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis18.setLabelToolTip("");
        categoryAxis18.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets30.createOutsetRectangle(rectangle2D40, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double45 = numberAxis26.java2DToValue((double) (short) -1, rectangle2D40, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor23, (int) (short) 0, 255, rectangle2D40, rectangleEdge46);
        double double48 = dateAxis0.java2DToValue((double) '4', rectangle2D16, rectangleEdge46);
        org.jfree.data.Range range49 = null;
        try {
            dateAxis0.setRange(range49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 102.0d + "'", double5 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 102.0d + "'", double32 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 9.223372036854776E18d + "'", double48 == 9.223372036854776E18d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        double double8 = textTitle7.getContentXOffset();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        try {
            jFreeChart4.draw(graphics2D5, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment1.draw(graphics2D2, 0.0f, (float) 100L, textAnchor5, (float) 500, (float) (short) -1, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        textTitle5.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement3.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) stroke11);
        polarPlot0.setAngleGridlineStroke(stroke11);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis15.setTickMarkStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color13, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke25 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean26 = rectangleAnchor22.equals((java.lang.Object) stroke25);
        valueMarker21.setOutlineStroke(stroke25);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font31, (java.awt.Paint) color32, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font31);
        valueMarker21.setLabelFont(font31);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer38);
        java.awt.Paint paint40 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean3 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        categoryPlot19.clearRangeMarkers((int) '4');
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = null;
        try {
            categoryPlot19.addDomainMarker(categoryMarker22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) (byte) 100);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.calculateTopInset(0.08d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102.0d + "'", double2 == 102.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getLegendItems();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = new org.jfree.chart.LegendItemCollection();
        categoryPlot19.setFixedLegendItems(legendItemCollection30);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.setTickMarkOutsideLength((float) (short) 100);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.data.Range range8 = dateAxis0.getRange();
        dateAxis0.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        double double3 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) (short) -1);
        double double5 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        chartProgressEvent6.setType((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getPadding();
        java.awt.Font font4 = textTitle1.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getTextAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(500, attributedString4);
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getPercentFormat();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str9 = plotOrientation8.toString();
        boolean boolean10 = standardPieSectionLabelGenerator2.equals((java.lang.Object) str9);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.VERTICAL" + "'", str9.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) "TextAnchor.BOTTOM_LEFT");
        java.lang.Object obj5 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot19.getOrientation();
        boolean boolean31 = categoryPlot19.isDomainZoomable();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray26);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray32, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis38.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeIncludesZero(false);
        numberAxis41.setVerticalTickLabels(true);
        boolean boolean46 = numberAxis41.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range53 = categoryPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setAutoRangeIncludesZero(false);
        numberAxis57.setVerticalTickLabels(true);
        numberAxis57.setAutoRangeStickyZero(true);
        numberAxis57.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = numberAxis57.getTickUnit();
        numberAxis54.setTickUnit(numberTickUnit66);
        categoryPlot48.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot48.setRenderer((int) (short) 10, categoryItemRenderer70);
        org.jfree.chart.event.PlotChangeListener plotChangeListener72 = null;
        categoryPlot48.addChangeListener(plotChangeListener72);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation79 = xYPlot77.getDomainAxisLocation((int) (short) 0);
        categoryPlot48.setRangeAxisLocation((int) (short) 1, axisLocation79, false);
        categoryPlot19.setDomainAxisLocation(0, axisLocation79);
        java.awt.Color color84 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis86 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis86.setLabelToolTip("");
        int int89 = categoryAxis86.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke90 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis86.setTickMarkStroke(stroke90);
        org.jfree.chart.plot.ValueMarker valueMarker92 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color84, stroke90);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType93 = valueMarker92.getLabelOffsetType();
        try {
            boolean boolean94 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(numberTickUnit66);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 4 + "'", int89 == 4);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(lengthAdjustmentType93);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("PlotOrientation.VERTICAL", "Other", "Other", "Other");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Other" + "'", str5.equals("Other"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot0.handleClick(0, (int) (short) 0, plotRenderingInfo6);
        java.awt.Color color8 = java.awt.Color.red;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = piePlot0.getLabelPaint();
        boolean boolean11 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getTickMarkOutsideLength();
        double double15 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis13.getLabelInsets();
        double double18 = rectangleInsets16.calculateBottomOutset((double) 100);
        piePlot0.setLabelPadding(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        java.util.List list3 = null;
        projectInfo0.setContributors(list3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Paint paint12 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getRangeAxisForDataset(0);
        java.lang.String str15 = xYPlot0.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot0.setRenderer(xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot0.getRendererForDataset(xYDataset18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNull(xYItemRenderer19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelOutlinePaint();
        java.awt.Stroke stroke13 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) stroke13);
        valueMarker9.setOutlineStroke(stroke13);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font19, (java.awt.Paint) color20, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font19);
        valueMarker9.setLabelFont(font19);
        valueMarker9.setLabel("TextAnchor.BOTTOM_LEFT");
        java.awt.Paint paint28 = valueMarker9.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        categoryAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        textTitle17.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets13.createOutsetRectangle(rectangle2D23, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = numberAxis9.java2DToValue((double) (short) -1, rectangle2D23, rectangleEdge27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double30 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 0, 255, rectangle2D23, rectangleEdge29);
        categoryAxis1.setCategoryLabelPositionOffset(4);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 102.0d + "'", double15 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 0.5f };
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { "hi!", 0.14d };
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "java.awt.Color[r=255,g=175,b=175]", doubleArray12);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray4, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot19.getOrientation();
        categoryPlot19.clearRangeMarkers();
        boolean boolean32 = categoryPlot19.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.String str2 = categoryAxis3D1.getLabelURL();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 0.0d);
        org.jfree.chart.block.Block block8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color10 = color9.brighter();
        flowArrangement7.add(block8, (java.lang.Object) color10);
        boolean boolean12 = categoryAxis3D1.equals((java.lang.Object) flowArrangement7);
        flowArrangement7.clear();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis46.setLabelToolTip("");
        int int49 = categoryAxis46.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis46.setTickMarkStroke(stroke50);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color44, stroke50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = piePlot54.getLabelOutlinePaint();
        java.awt.Stroke stroke56 = piePlot54.getBaseSectionOutlineStroke();
        boolean boolean57 = rectangleAnchor53.equals((java.lang.Object) stroke56);
        valueMarker52.setOutlineStroke(stroke56);
        java.awt.Font font62 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment65 = new org.jfree.chart.text.TextFragment("hi!", font62, (java.awt.Paint) color63, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine66 = new org.jfree.chart.text.TextLine("", font62);
        org.jfree.chart.text.TextFragment textFragment67 = new org.jfree.chart.text.TextFragment("hi!", font62);
        valueMarker52.setLabelFont(font62);
        valueMarker52.setLabel("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.util.Layer layer71 = null;
        boolean boolean72 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker52, layer71);
        java.lang.Number[] numberArray77 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray79 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray80 = new java.lang.Number[][] { numberArray77, numberArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray80);
        categoryPlot19.setDataset((int) (byte) 100, categoryDataset81);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot83 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset81);
        org.jfree.data.general.PieDataset pieDataset85 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset81, (int) (byte) 0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
        org.junit.Assert.assertNotNull(pieDataset85);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Paint paint12 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot0.zoomDomainAxes(100.0d, plotRenderingInfo16, point2D17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis16.setLabelToolTip("");
        int int19 = categoryAxis16.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis16.setTickMarkStroke(stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color14, stroke20);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets();
        piePlot23.setSimpleLabelOffset(rectangleInsets25);
        valueMarker22.setLabelOffset(rectangleInsets25);
        float float28 = valueMarker22.getAlpha();
        org.jfree.chart.util.Layer layer29 = null;
        try {
            boolean boolean30 = xYPlot0.removeRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker22, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.setTickMarkOutsideLength((float) (short) 100);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D8.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range12 = numberAxis3D8.getRange();
        dateAxis0.setRange(range12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        boolean boolean5 = jFreeChart4.isNotify();
        try {
            java.awt.image.BufferedImage bufferedImage8 = jFreeChart4.createBufferedImage((int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        xYPlot0.setRangeAxis((int) ' ', valueAxis4, false);
        java.awt.Color color7 = java.awt.Color.WHITE;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color7);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        boolean boolean9 = multiplePiePlot8.isOutlineVisible();
        java.lang.Comparable comparable10 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        multiplePiePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot0.equals((java.lang.Object) axisChangeEvent11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        java.lang.String str16 = multiplePiePlot15.getPlotType();
        double double17 = multiplePiePlot15.getLimit();
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot15.getPieChart();
        boolean boolean19 = jFreeChart18.isNotify();
        java.awt.Stroke stroke20 = jFreeChart18.getBorderStroke();
        jFreeChart18.setTitle("ChartChangeEventType.GENERAL");
        piePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        java.util.List list24 = null;
        try {
            jFreeChart18.setSubtitles(list24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Multiple Pie Plot" + "'", str16.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        categoryPlot19.rendererChanged(rendererChangeEvent27);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getLowerMargin();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis8.setAxisLineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        int int4 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis1.setTickMarkStroke(stroke5);
        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelOutlinePaint();
        java.awt.Stroke stroke13 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) stroke13);
        valueMarker9.setOutlineStroke(stroke13);
        valueMarker9.setValue((double) 'a');
        java.awt.Color color18 = java.awt.Color.white;
        int int19 = color18.getRed();
        valueMarker9.setPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        int int33 = categoryPlot19.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot19.getRangeAxis((int) '4');
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(valueAxis35);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis2.setLabelToolTip("");
        categoryAxis2.setAxisLineVisible(false);
        java.awt.Font font8 = categoryAxis2.getTickLabelFont((java.lang.Comparable) "");
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_RIGHT", font8);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis2.setTickLabelPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis2.setTimeline(timeline6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = piePlot8.getLabelBackgroundPaint();
        java.awt.Paint paint10 = null;
        piePlot8.setShadowPaint(paint10);
        double double12 = piePlot8.getShadowXOffset();
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot8);
        dateAxis2.setAutoTickUnitSelection(true);
        try {
            xYPlot0.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        try {
            java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        java.awt.Paint paint7 = null;
        xYPlot0.setRangeTickBandPaint(paint7);
        double double9 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray21, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis27.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setAutoRangeIncludesZero(false);
        numberAxis30.setVerticalTickLabels(true);
        boolean boolean35 = numberAxis30.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D38.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range42 = categoryPlot37.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        java.awt.Stroke stroke43 = categoryPlot37.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        double double46 = categoryAxis1.getCategoryStart(15, (int) (byte) 0, rectangle2D14, rectangleEdge44);
        categoryAxis1.setTickMarkOutsideLength((float) ' ');
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot19.getDomainAxisLocation(1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range4 = numberAxis3D0.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range9 = numberAxis3D5.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range4, range9);
        java.lang.String str11 = rectangleConstraint10.toString();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str11.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis11.setLabelToolTip("");
        int int14 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis11.setTickMarkStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color9, stroke15);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (-1.0f), stroke15);
        piePlot1.zoom((double) '#');
        piePlot1.setMaximumLabelWidth((double) 10L);
        piePlot1.setCircular(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = titleChangeEvent1.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = numberAxis0.java2DToValue((double) (short) -1, rectangle2D14, rectangleEdge18);
        java.awt.Font font22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("hi!", font22, (java.awt.Paint) color23, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("", font22);
        numberAxis0.setLabelFont(font22);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeCrosshairStroke();
        java.awt.Paint paint26 = categoryPlot19.getRangeCrosshairPaint();
        categoryPlot19.setRangeCrosshairValue((double) 8, false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateBottomOutset((double) 100);
        double double8 = rectangleInsets4.trimHeight((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-5.0d) + "'", double8 == (-5.0d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = categoryPlot19.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition47 = dateAxis46.getTickMarkPosition();
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis46.setTickLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition51 = dateAxis50.getTickMarkPosition();
        dateAxis46.setTickMarkPosition(dateTickMarkPosition51);
        dateAxis46.setFixedAutoRange(0.08d);
        dateAxis46.setTickLabelsVisible(true);
        int int57 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(dateTickMarkPosition47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(dateTickMarkPosition51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.configure();
        double double5 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot0.handleClick(0, (int) (short) 0, plotRenderingInfo6);
        java.awt.Color color8 = java.awt.Color.red;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = piePlot0.getLabelPaint();
        piePlot0.setMinimumArcAngleToDraw((double) (short) 100);
        java.awt.Stroke stroke13 = piePlot0.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        multiplePiePlot1.setLimit((double) 10);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color6 = color5.brighter();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color8);
        java.lang.Comparable comparable10 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray8, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis14.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoRangeIncludesZero(false);
        numberAxis17.setVerticalTickLabels(true);
        boolean boolean22 = numberAxis17.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range29 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeIncludesZero(false);
        numberAxis33.setVerticalTickLabels(true);
        numberAxis33.setAutoRangeStickyZero(true);
        numberAxis33.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit42 = numberAxis33.getTickUnit();
        numberAxis30.setTickUnit(numberTickUnit42);
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot24.setRenderer((int) (short) 10, categoryItemRenderer46);
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        categoryPlot24.addChangeListener(plotChangeListener48);
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace50);
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot53.getDomainAxisLocation((int) (short) 0);
        categoryPlot24.setRangeAxisLocation((int) (short) 1, axisLocation55, false);
        xYPlot0.setRangeAxisLocation((int) '#', axisLocation55);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(numberTickUnit42);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray26);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray32, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis38.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeIncludesZero(false);
        numberAxis41.setVerticalTickLabels(true);
        boolean boolean46 = numberAxis41.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range53 = categoryPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setAutoRangeIncludesZero(false);
        numberAxis57.setVerticalTickLabels(true);
        numberAxis57.setAutoRangeStickyZero(true);
        numberAxis57.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = numberAxis57.getTickUnit();
        numberAxis54.setTickUnit(numberTickUnit66);
        categoryPlot48.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot48.setRenderer((int) (short) 10, categoryItemRenderer70);
        org.jfree.chart.event.PlotChangeListener plotChangeListener72 = null;
        categoryPlot48.addChangeListener(plotChangeListener72);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation79 = xYPlot77.getDomainAxisLocation((int) (short) 0);
        categoryPlot48.setRangeAxisLocation((int) (short) 1, axisLocation79, false);
        categoryPlot19.setDomainAxisLocation(0, axisLocation79);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer85 = null;
        categoryPlot19.setRenderer((int) (byte) 10, categoryItemRenderer85, false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(numberTickUnit66);
        org.junit.Assert.assertNotNull(axisLocation79);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.Plot plot1 = piePlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str3 = piePlot2.getPlotType();
        boolean boolean4 = piePlot1.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = piePlot1.getDrawingSupplier();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) piePlot1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        xYPlot0.axisChanged(axisChangeEvent3);
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.configure();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle6.getBounds();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D12, pieDataset13, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        piePlot4.setLegendItemShape((java.awt.Shape) rectangle2D27);
        dateAxis2.setDownArrow((java.awt.Shape) rectangle2D27);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis32.getTickMarkPosition();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis32.setTickLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.Timeline timeline36 = null;
        dateAxis32.setTimeline(timeline36);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint39 = piePlot38.getLabelBackgroundPaint();
        java.awt.Paint paint40 = null;
        piePlot38.setShadowPaint(paint40);
        double double42 = piePlot38.getShadowXOffset();
        dateAxis32.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot38);
        java.awt.Color color44 = java.awt.Color.YELLOW;
        piePlot38.setShadowPaint((java.awt.Paint) color44);
        java.lang.Object obj46 = piePlot38.clone();
        org.jfree.data.general.DatasetGroup datasetGroup47 = piePlot38.getDatasetGroup();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator48 = piePlot38.getLabelGenerator();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.plot.PiePlotState piePlotState51 = ringPlot0.initialise(graphics2D1, rectangle2D27, piePlot38, (java.lang.Integer) 500, plotRenderingInfo50);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNull(datasetGroup47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator48);
        org.junit.Assert.assertNotNull(piePlotState51);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis8.getTickLabelInsets();
        dateAxis0.setLabelInsets(rectangleInsets10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis13.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeIncludesZero(false);
        numberAxis16.setVerticalTickLabels(true);
        boolean boolean21 = numberAxis16.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range28 = categoryPlot23.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D24);
        boolean boolean29 = categoryPlot23.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot23.setRenderers(categoryItemRendererArray30);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray36, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis42.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeIncludesZero(false);
        numberAxis45.setVerticalTickLabels(true);
        boolean boolean50 = numberAxis45.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis45, categoryItemRenderer51);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D53.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range57 = categoryPlot52.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D53);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeIncludesZero(false);
        numberAxis61.setVerticalTickLabels(true);
        numberAxis61.setAutoRangeStickyZero(true);
        numberAxis61.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit70 = numberAxis61.getTickUnit();
        numberAxis58.setTickUnit(numberTickUnit70);
        categoryPlot52.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis58);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        categoryPlot52.setRenderer((int) (short) 10, categoryItemRenderer74);
        org.jfree.chart.event.PlotChangeListener plotChangeListener76 = null;
        categoryPlot52.addChangeListener(plotChangeListener76);
        org.jfree.chart.axis.AxisSpace axisSpace78 = null;
        categoryPlot52.setFixedDomainAxisSpace(axisSpace78);
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation83 = xYPlot81.getDomainAxisLocation((int) (short) 0);
        categoryPlot52.setRangeAxisLocation((int) (short) 1, axisLocation83, false);
        categoryPlot23.setDomainAxisLocation(0, axisLocation83);
        xYPlot0.setRangeAxisLocation(178, axisLocation83);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(numberTickUnit70);
        org.junit.Assert.assertNotNull(axisLocation83);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot19.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str32 = plotOrientation31.toString();
        categoryPlot19.setOrientation(plotOrientation31);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint35 = piePlot34.getLabelOutlinePaint();
        java.awt.Stroke stroke36 = piePlot34.getLabelOutlineStroke();
        double double37 = piePlot34.getInteriorGap();
        piePlot34.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = piePlot34.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset41);
        boolean boolean43 = multiplePiePlot42.isOutlineVisible();
        java.lang.Comparable comparable44 = multiplePiePlot42.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = null;
        multiplePiePlot42.axisChanged(axisChangeEvent45);
        boolean boolean47 = piePlot34.equals((java.lang.Object) axisChangeEvent45);
        boolean boolean48 = plotOrientation31.equals((java.lang.Object) piePlot34);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PlotOrientation.VERTICAL" + "'", str32.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.08d + "'", double37 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + "Other" + "'", comparable44.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range4 = numberAxis3D0.getRange();
        numberAxis3D0.setAutoRange(false);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.awt.Shape shape15 = pieSectionEntity14.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        chartEntity16.setToolTipText("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Multiple Pie Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range4 = numberAxis3D0.getRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range9 = numberAxis3D5.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range4, range9);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        java.lang.String str5 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset3, (java.lang.Comparable) "TextAnchor.BOTTOM_LEFT");
        boolean boolean6 = textBlockAnchor0.equals((java.lang.Object) str5);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray26);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray32, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis38.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeIncludesZero(false);
        numberAxis41.setVerticalTickLabels(true);
        boolean boolean46 = numberAxis41.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range53 = categoryPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setAutoRangeIncludesZero(false);
        numberAxis57.setVerticalTickLabels(true);
        numberAxis57.setAutoRangeStickyZero(true);
        numberAxis57.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = numberAxis57.getTickUnit();
        numberAxis54.setTickUnit(numberTickUnit66);
        categoryPlot48.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot48.setRenderer((int) (short) 10, categoryItemRenderer70);
        org.jfree.chart.event.PlotChangeListener plotChangeListener72 = null;
        categoryPlot48.addChangeListener(plotChangeListener72);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation79 = xYPlot77.getDomainAxisLocation((int) (short) 0);
        categoryPlot48.setRangeAxisLocation((int) (short) 1, axisLocation79, false);
        categoryPlot19.setDomainAxisLocation(0, axisLocation79);
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = categoryPlot19.getAxisOffset();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(numberTickUnit66);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(rectangleInsets83);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0L, "java.awt.Color[r=255,g=175,b=175]");
        double double8 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray26);
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray32, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis38.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeIncludesZero(false);
        numberAxis41.setVerticalTickLabels(true);
        boolean boolean46 = numberAxis41.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range53 = categoryPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setAutoRangeIncludesZero(false);
        numberAxis57.setVerticalTickLabels(true);
        numberAxis57.setAutoRangeStickyZero(true);
        numberAxis57.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = numberAxis57.getTickUnit();
        numberAxis54.setTickUnit(numberTickUnit66);
        categoryPlot48.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot48.setRenderer((int) (short) 10, categoryItemRenderer70);
        org.jfree.chart.event.PlotChangeListener plotChangeListener72 = null;
        categoryPlot48.addChangeListener(plotChangeListener72);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation79 = xYPlot77.getDomainAxisLocation((int) (short) 0);
        categoryPlot48.setRangeAxisLocation((int) (short) 1, axisLocation79, false);
        categoryPlot19.setDomainAxisLocation(0, axisLocation79);
        categoryPlot19.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset84 = categoryPlot19.getDataset();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(numberTickUnit66);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(categoryDataset84);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        java.awt.Font font7 = categoryAxis1.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = piePlot8.getLabelOutlinePaint();
        java.awt.Stroke stroke10 = piePlot8.getLabelOutlineStroke();
        double double11 = piePlot8.getInteriorGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot8.removeChangeListener(plotChangeListener12);
        boolean boolean14 = categoryAxis1.hasListener((java.util.EventListener) plotChangeListener12);
        java.awt.Stroke stroke15 = categoryAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        int int10 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        boolean boolean7 = piePlot0.isCircular();
        org.jfree.chart.plot.Plot plot8 = piePlot0.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot3.getDomainAxisLocation((int) (short) 0);
        xYPlot0.setRangeAxisLocation(axisLocation5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        piePlot0.setSimpleLabelOffset(rectangleInsets2);
        double double5 = rectangleInsets2.calculateBottomInset(1.0d);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets2.getUnitType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean11 = plotOrientation9.equals((java.lang.Object) color10);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        java.lang.Comparable comparable15 = pieSectionEntity14.getSectionKey();
        org.jfree.data.general.PieDataset pieDataset16 = pieSectionEntity14.getDataset();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0.0d + "'", comparable15.equals(0.0d));
        org.junit.Assert.assertNull(pieDataset16);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        piePlot3.setIgnoreZeroValues(true);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3);
        numberAxis0.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        boolean boolean5 = polarPlot0.isRangeZoomable();
        polarPlot0.setAngleGridlinesVisible(true);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis17.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeIncludesZero(false);
        numberAxis20.setVerticalTickLabels(true);
        boolean boolean25 = numberAxis20.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range32 = categoryPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot27.setFixedDomainAxisSpace(axisSpace33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot27.getRangeAxisEdge();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis39.setLabelToolTip("");
        int int42 = categoryAxis39.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis39.setTickMarkStroke(stroke43);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color37, stroke43);
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint47 = piePlot46.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets();
        piePlot46.setSimpleLabelOffset(rectangleInsets48);
        valueMarker45.setLabelOffset(rectangleInsets48);
        float float51 = valueMarker45.getAlpha();
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker45);
        java.awt.Stroke stroke53 = valueMarker45.getStroke();
        polarPlot0.setAngleGridlineStroke(stroke53);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 1.0f + "'", float51 == 1.0f);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getSeriesCount();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray10, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis16.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeIncludesZero(false);
        numberAxis19.setVerticalTickLabels(true);
        boolean boolean24 = numberAxis19.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer25);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range31 = categoryPlot26.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D27);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setAutoRangeIncludesZero(false);
        numberAxis35.setVerticalTickLabels(true);
        numberAxis35.setAutoRangeStickyZero(true);
        numberAxis35.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = numberAxis35.getTickUnit();
        numberAxis32.setTickUnit(numberTickUnit44);
        categoryPlot26.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot26.setRenderer((int) (short) 10, categoryItemRenderer48);
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        categoryPlot26.addChangeListener(plotChangeListener50);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace52);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot55.getDomainAxisLocation((int) (short) 0);
        categoryPlot26.setRangeAxisLocation((int) (short) 1, axisLocation57, false);
        xYPlot0.setRangeAxisLocation(axisLocation57);
        org.jfree.chart.axis.ValueAxis valueAxis61 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNull(valueAxis61);
    }
}

