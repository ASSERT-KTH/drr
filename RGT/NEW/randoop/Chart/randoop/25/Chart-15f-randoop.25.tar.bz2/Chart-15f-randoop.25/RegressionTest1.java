import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        piePlot3.setIgnoreZeroValues(true);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3);
        piePlot3.setForegroundAlpha((float) (short) 1);
        java.awt.Image image10 = null;
        piePlot3.setBackgroundImage(image10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Paint paint13 = piePlot3.getSectionOutlinePaint((java.lang.Comparable) numberTickUnit12);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        double double4 = categoryAxis1.getUpperMargin();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color9, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!", font8);
        categoryAxis1.setLabelFont(font8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        xYPlot0.setRangeAxis((int) ' ', valueAxis4, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis7.getTickMarkPosition();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis11.getTickMarkPosition();
        dateAxis7.setTickMarkPosition(dateTickMarkPosition12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis7.setTickUnit(dateTickUnit14, true, true);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeIncludesZero(false);
        numberAxis19.setVerticalTickLabels(true);
        numberAxis19.setAutoRangeStickyZero(true);
        numberAxis19.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis19.getTickUnit();
        double double29 = numberAxis19.getLowerMargin();
        boolean boolean30 = numberAxis19.isVerticalTickLabels();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        boolean boolean5 = jFreeChart4.isNotify();
        java.awt.Stroke stroke6 = jFreeChart4.getBorderStroke();
        jFreeChart4.setTitle("ChartChangeEventType.GENERAL");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) false);
        boolean boolean12 = jFreeChart4.equals((java.lang.Object) textBlockAnchor9);
        java.awt.RenderingHints renderingHints13 = null;
        try {
            jFreeChart4.setRenderingHints(renderingHints13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        xYPlot0.setRangeAxis((int) ' ', valueAxis4, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis7.getTickMarkPosition();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis11.getTickMarkPosition();
        dateAxis7.setTickMarkPosition(dateTickMarkPosition12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis7.setTickUnit(dateTickUnit14, true, true);
        int int18 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        xYPlot0.setRangeCrosshairVisible(false);
        java.awt.geom.Point2D point2D21 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot19.getDomainMarkers(layer45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(categoryItemRenderer47);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        jFreeChart12.fireChartChanged();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart12.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        org.jfree.chart.axis.TickUnit tickUnit3 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(tickUnit3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = new org.jfree.chart.LegendItemCollection();
        boolean boolean28 = legendItemCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.LegendItem legendItem29 = null;
        legendItemCollection26.add(legendItem29);
        categoryPlot19.setFixedLegendItems(legendItemCollection26);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray35, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis41.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoRangeIncludesZero(false);
        numberAxis44.setVerticalTickLabels(true);
        boolean boolean49 = numberAxis44.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer50);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D52.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range56 = categoryPlot51.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot51.zoomDomainAxes(1.0d, plotRenderingInfo58, point2D59, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = categoryPlot51.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str64 = plotOrientation63.toString();
        categoryPlot51.setOrientation(plotOrientation63);
        org.jfree.chart.util.SortOrder sortOrder66 = categoryPlot51.getColumnRenderingOrder();
        categoryPlot19.setColumnRenderingOrder(sortOrder66);
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNotNull(plotOrientation62);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "PlotOrientation.VERTICAL" + "'", str64.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(sortOrder66);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 178, 0.0d);
        size2D2.setHeight((double) 1.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font3);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            float float11 = textFragment8.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Paint paint12 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint13 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo15, point2D16, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot0.removeChangeListener(plotChangeListener4);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor7.distributeLabels((double) (-1), (double) (byte) 0);
        piePlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor7);
        piePlot0.setIgnoreZeroValues(true);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis17.setLabelToolTip("");
        int int20 = categoryAxis17.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis17.setTickMarkStroke(stroke21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color15, stroke21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint26 = piePlot25.getLabelOutlinePaint();
        java.awt.Stroke stroke27 = piePlot25.getBaseSectionOutlineStroke();
        boolean boolean28 = rectangleAnchor24.equals((java.lang.Object) stroke27);
        valueMarker23.setOutlineStroke(stroke27);
        java.awt.Font font33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font33, (java.awt.Paint) color34, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font33);
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("hi!", font33);
        valueMarker23.setLabelFont(font33);
        valueMarker23.setLabel("TextAnchor.BOTTOM_LEFT");
        double double42 = valueMarker23.getValue();
        java.awt.Font font43 = valueMarker23.getLabelFont();
        piePlot0.setLabelFont(font43);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.2d + "'", double42 == 0.2d);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) (short) -1);
        piePlotState1.setPieHRadius(1.0d);
        piePlotState1.setPassesRequired((int) (short) 0);
        double double9 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        java.lang.String str2 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str2.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        piePlot0.setMinimumArcAngleToDraw(100.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis5.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition6);
        dateAxis1.setFixedAutoRange(0.08d);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer10);
        java.awt.Stroke stroke12 = polarPlot11.getAngleGridlineStroke();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str15 = piePlot14.getPlotType();
        boolean boolean16 = piePlot13.equals((java.lang.Object) piePlot14);
        piePlot13.setExplodePercent((java.lang.Comparable) (-1L), 0.14d);
        boolean boolean20 = polarPlot11.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pie Plot" + "'", str15.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        int int5 = polarPlot0.getSeriesCount();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot0.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("rect");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("rect");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        boolean boolean9 = multiplePiePlot8.isOutlineVisible();
        java.lang.Comparable comparable10 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        multiplePiePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot0.equals((java.lang.Object) axisChangeEvent11);
        boolean boolean14 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.util.Rotation rotation15 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str16 = rotation15.toString();
        piePlot0.setDirection(rotation15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str16.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, false, false);
        java.util.TimeZone timeZone11 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getSeriesCount();
        java.awt.Color color5 = java.awt.Color.red;
        java.awt.Color color6 = color5.darker();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeIncludesZero(false);
        numberAxis9.setVerticalTickLabels(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        textTitle22.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle22.getBounds();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D28, pieDataset29, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis15.getCategoryStart(0, 100, rectangle2D28, rectangleEdge36);
        numberAxis9.setDownArrow((java.awt.Shape) rectangle2D28);
        double double39 = numberAxis9.getLowerMargin();
        xYPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis9, true);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setLabelToolTip("");
        int int34 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis31.setTickMarkStroke(stroke35);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color29, stroke35);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint39 = piePlot38.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        piePlot38.setSimpleLabelOffset(rectangleInsets40);
        valueMarker37.setLabelOffset(rectangleInsets40);
        float float43 = valueMarker37.getAlpha();
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        java.awt.Stroke stroke45 = valueMarker37.getStroke();
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray49, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis55.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setAutoRangeIncludesZero(false);
        numberAxis58.setVerticalTickLabels(true);
        boolean boolean63 = numberAxis58.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis55, (org.jfree.chart.axis.ValueAxis) numberAxis58, categoryItemRenderer64);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D66.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range70 = categoryPlot65.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D66);
        java.awt.Stroke stroke71 = categoryPlot65.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot65.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge72);
        java.lang.Class<?> wildcardClass74 = rectangleEdge73.getClass();
        try {
            java.util.EventListener[] eventListenerArray75 = valueMarker37.getListeners((java.lang.Class) wildcardClass74);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.util.RectangleEdge; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(wildcardClass74);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        double double10 = textTitle2.getWidth();
        double double11 = textTitle2.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle2.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setHorizontalAlignment(horizontalAlignment13);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getPieIndex();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
        size2D5.setHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(size2D5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range4 = numberAxis3D0.getRange();
        java.awt.Shape shape5 = numberAxis3D0.getRightArrow();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        textTitle5.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle5.getBounds();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset12, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        textTitle20.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle20.getBounds();
        pieSectionEntity18.setArea((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26);
        textTitle1.draw(graphics2D3, rectangle2D26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot28.getDomainAxisLocation((int) (short) 0);
        categoryPlot19.setDomainAxisLocation((int) (byte) 0, axisLocation30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setAutoRangeMinimumSize(3.0d, false);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        numberAxis3D32.setLowerMargin((double) 0.0f);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot19.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot19.setRenderer(0, categoryItemRenderer32, false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(plotOrientation30);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        textTitle7.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets3.createOutsetRectangle(rectangle2D13, false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis18.setLabelToolTip("");
        categoryAxis18.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        textTitle34.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets30.createOutsetRectangle(rectangle2D40, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double45 = numberAxis26.java2DToValue((double) (short) -1, rectangle2D40, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor23, (int) (short) 0, 255, rectangle2D40, rectangleEdge46);
        double double48 = dateAxis0.java2DToValue((double) '4', rectangle2D16, rectangleEdge46);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        float float51 = categoryAxis50.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis50.getTickLabelInsets();
        double double54 = rectangleInsets52.calculateTopOutset((double) 178);
        dateAxis0.setTickLabelInsets(rectangleInsets52);
        double double57 = rectangleInsets52.calculateTopInset((double) 0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 102.0d + "'", double5 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 102.0d + "'", double32 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 9.223372036854776E18d + "'", double48 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getSeriesCount();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint7 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((-1));
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        categoryPlot19.clearDomainAxes();
        categoryPlot19.setRangeCrosshairValue((double) 100.0f);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray31, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis37.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setAutoRangeIncludesZero(false);
        numberAxis40.setVerticalTickLabels(true);
        boolean boolean45 = numberAxis40.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer46);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D48.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range52 = categoryPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D48);
        java.awt.Stroke stroke53 = categoryPlot47.getRangeCrosshairStroke();
        java.awt.Paint paint54 = categoryPlot47.getRangeCrosshairPaint();
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot55.getDomainMarkers(layer56);
        int int58 = xYPlot55.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        xYPlot55.setFixedRangeAxisSpace(axisSpace59, true);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot55.getRangeAxisLocation();
        categoryPlot47.setDomainAxisLocation(axisLocation62);
        categoryPlot19.setDomainAxisLocation(axisLocation62);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.configure();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        float float30 = categoryAxis29.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis29.getTickLabelInsets();
        int int32 = categoryPlot19.getDomainAxisIndex(categoryAxis29);
        categoryAxis29.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        polarPlot2.setRadiusGridlinesVisible(false);
        polarPlot2.setAngleLabelsVisible(false);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleAnchor.BOTTOM", font1, (org.jfree.chart.plot.Plot) polarPlot2, false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int3 = color2.getAlpha();
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        float[] floatArray5 = null;
        float[] floatArray6 = color1.getColorComponents(colorSpace4, floatArray5);
        float[] floatArray13 = new float[] { (short) -1, 10, 4, (-1), 4, (short) -1 };
        float[] floatArray14 = color0.getComponents(colorSpace4, floatArray13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot28.getDomainAxisLocation((int) (short) 0);
        categoryPlot19.setDomainAxisLocation((int) (byte) 0, axisLocation30);
        java.awt.Color color33 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color34 = color33.brighter();
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint36 = piePlot35.getLabelOutlinePaint();
        java.awt.Stroke stroke37 = piePlot35.getLabelOutlineStroke();
        double double38 = piePlot35.getInteriorGap();
        piePlot35.setCircular(true);
        piePlot35.setLabelLinksVisible(false);
        java.awt.Paint paint43 = piePlot35.getShadowPaint();
        java.awt.Stroke stroke44 = piePlot35.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color34, stroke44);
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean47 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker45, layer46);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.08d + "'", double38 == 0.08d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelOutlinePaint();
        java.awt.Stroke stroke13 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) stroke13);
        valueMarker9.setOutlineStroke(stroke13);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font19, (java.awt.Paint) color20, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font19);
        valueMarker9.setLabelFont(font19);
        java.awt.Stroke stroke26 = valueMarker9.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.String str10 = multiplePiePlot9.getPlotType();
        double double11 = multiplePiePlot9.getLimit();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot9.getPieChart();
        boolean boolean13 = jFreeChart12.isNotify();
        chartProgressEvent6.setChart(jFreeChart12);
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart12.getLegend((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis18.getTickLabelInsets();
        double double22 = rectangleInsets20.calculateTopOutset((double) 178);
        double double24 = rectangleInsets20.calculateLeftInset(Double.NEGATIVE_INFINITY);
        jFreeChart12.setPadding(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1000.0d + "'", number8.equals(1000.0d));
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font12, (java.awt.Paint) color13, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font12);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font12);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_RIGHT", font12);
        boolean boolean19 = textTitle1.equals((java.lang.Object) font12);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis0.getTickUnit();
        double double10 = numberAxis0.getLowerMargin();
        java.awt.Font font11 = null;
        try {
            numberAxis0.setLabelFont(font11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        java.lang.Object obj3 = objectList1.get(100);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int3 = color2.getAlpha();
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        float[] floatArray11 = new float[] { (byte) 100, 178, 100.0f, 100L, (byte) 0, 0 };
        float[] floatArray12 = color1.getComponents(colorSpace4, floatArray11);
        float[] floatArray13 = color0.getComponents(floatArray12);
        int int14 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((-1));
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getDomainAxisEdge((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.lang.Object obj15 = pieSectionEntity14.clone();
        java.lang.Object obj16 = pieSectionEntity14.clone();
        java.lang.String str17 = pieSectionEntity14.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0,0,1,1" + "'", str17.equals("0,0,1,1"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        boolean boolean5 = polarPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 8, plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand4);
        numberAxis3D0.setRange((double) (-1), 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setLatestAngle(0.14d);
        piePlotState1.setTotal(0.0d);
        double double6 = piePlotState1.getPieCenterX();
        java.awt.geom.Rectangle2D rectangle2D7 = piePlotState1.getLinkArea();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis((int) (byte) 100);
        xYPlot0.clearRangeMarkers();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray10, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis16.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeIncludesZero(false);
        numberAxis19.setVerticalTickLabels(true);
        boolean boolean24 = numberAxis19.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer25);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range31 = categoryPlot26.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D27);
        java.awt.Stroke stroke32 = categoryPlot26.getRangeCrosshairStroke();
        java.awt.Paint paint33 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot34.getDomainMarkers(layer35);
        int int37 = xYPlot34.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot34.setFixedRangeAxisSpace(axisSpace38, true);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot34.getRangeAxisLocation();
        categoryPlot26.setDomainAxisLocation(axisLocation41);
        xYPlot0.setRangeAxisLocation((int) (byte) 1, axisLocation41, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        java.awt.Stroke stroke3 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) rectangleInsets1);
        boolean boolean4 = lengthConstraintType0.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray5, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis11.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeIncludesZero(false);
        numberAxis14.setVerticalTickLabels(true);
        boolean boolean19 = numberAxis14.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range26 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot21.getRangeAxisEdge();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis33.setLabelToolTip("");
        int int36 = categoryAxis33.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis33.setTickMarkStroke(stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color31, stroke37);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint41 = piePlot40.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets();
        piePlot40.setSimpleLabelOffset(rectangleInsets42);
        valueMarker39.setLabelOffset(rectangleInsets42);
        float float45 = valueMarker39.getAlpha();
        categoryPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke48 = xYPlot47.getRangeZeroBaselineStroke();
        categoryPlot21.setOutlineStroke(stroke48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        float float52 = categoryAxis51.getTickMarkOutsideLength();
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color54 = color53.brighter();
        categoryAxis51.setLabelPaint((java.awt.Paint) color53);
        java.awt.Stroke stroke56 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke48, (java.awt.Paint) color53, stroke56, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = piePlot2.getLabelOutlinePaint();
        java.awt.Stroke stroke4 = piePlot2.getLabelOutlineStroke();
        double double5 = piePlot2.getInteriorGap();
        piePlot2.setCircular(true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot2.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation10 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot2.setDirection(rotation10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(rotation10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        double double8 = rectangleInsets4.calculateTopOutset((double) 0.5f);
        categoryAxis1.setTickLabelInsets(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (short) 0, (double) 100, (double) (-1L), (double) 10.0f);
        java.lang.Object obj7 = textTitle1.clone();
        textTitle1.setText("");
        textTitle1.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint3 = piePlot2.getLabelOutlinePaint();
        java.awt.Stroke stroke4 = piePlot2.getLabelOutlineStroke();
        double double5 = piePlot2.getInteriorGap();
        piePlot2.setCircular(true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint9 = piePlot2.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        boolean boolean5 = polarPlot0.isRangeZoomable();
        polarPlot0.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot0.zoomDomainAxes(1000.0d, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.lang.Object obj15 = pieSectionEntity14.clone();
        org.jfree.data.general.PieDataset pieDataset16 = pieSectionEntity14.getDataset();
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray19, doubleArray20, doubleArray21, doubleArray22, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "java.awt.Color[r=255,g=175,b=175]", doubleArray24);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset25, (java.lang.Comparable) "PieSection: -1, 0(-1)");
        pieSectionEntity14.setDataset(pieDataset27);
        double double29 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset27);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(pieDataset16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0L, "java.awt.Color[r=255,g=175,b=175]");
        double double8 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot0.handleClick(0, (int) (short) 0, plotRenderingInfo6);
        java.awt.Color color8 = java.awt.Color.red;
        piePlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = piePlot0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.extendHeight((double) (byte) 100);
        double double15 = rectangleInsets11.calculateTopOutset((-1.0d));
        piePlot0.setInsets(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 102.0d + "'", double13 == 102.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getLegendItems();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        java.lang.String str2 = textTitle0.getToolTipText();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 0.0d);
        org.jfree.chart.block.Block block5 = null;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color7 = color6.brighter();
        flowArrangement4.add(block5, (java.lang.Object) color7);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range10 = numberAxis3D6.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, 0.4d);
        dateAxis0.setRange(range10);
        java.awt.Shape shape14 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = categoryPlot19.getOrientation();
        boolean boolean46 = categoryPlot19.isRangeGridlinesVisible();
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray50, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis56.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        numberAxis59.setAutoRangeIncludesZero(false);
        numberAxis59.setVerticalTickLabels(true);
        boolean boolean64 = numberAxis59.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis56, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer65);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D67.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range71 = categoryPlot66.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D67);
        categoryPlot66.clearDomainAxes();
        java.awt.Paint paint73 = categoryPlot66.getDomainGridlinePaint();
        categoryPlot19.setRangeCrosshairPaint(paint73);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNotNull(paint73);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("java.awt.Color[r=255,g=175,b=175]", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str3.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str4.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getUpperMargin();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        textTitle9.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, pieDataset16, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        textTitle24.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        pieSectionEntity22.setArea((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        float float35 = categoryAxis34.getTickMarkOutsideLength();
        double double36 = categoryAxis34.getLowerMargin();
        float float37 = categoryAxis34.getTickMarkInsideLength();
        categoryAxis34.setMaximumCategoryLabelLines((-1));
        java.awt.Font font40 = categoryAxis34.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint42 = piePlot41.getLabelOutlinePaint();
        java.awt.Stroke stroke43 = piePlot41.getLabelOutlineStroke();
        double double44 = piePlot41.getInteriorGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        piePlot41.removeChangeListener(plotChangeListener45);
        boolean boolean47 = categoryAxis34.hasListener((java.util.EventListener) plotChangeListener45);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        textTitle51.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle51.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis59.setLabelToolTip("");
        categoryAxis59.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis();
        numberAxis67.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = new org.jfree.chart.util.RectangleInsets();
        double double73 = rectangleInsets71.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle75 = new org.jfree.chart.title.TextTitle("");
        textTitle75.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D81 = textTitle75.getBounds();
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets71.createOutsetRectangle(rectangle2D81, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double86 = numberAxis67.java2DToValue((double) (short) -1, rectangle2D81, rectangleEdge85);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double88 = categoryAxis59.getCategoryJava2DCoordinate(categoryAnchor64, (int) (short) 0, 255, rectangle2D81, rectangleEdge87);
        double double89 = categoryAxis34.getCategoryEnd((int) '4', 0, rectangle2D57, rectangleEdge87);
        double double90 = categoryAxis1.getCategoryMiddle(2, (-1), rectangle2D30, rectangleEdge87);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 2.0f + "'", float35 == 2.0f);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.08d + "'", double44 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 102.0d + "'", double73 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + Double.NEGATIVE_INFINITY + "'", double86 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setLabelToolTip("");
        int int34 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis31.setTickMarkStroke(stroke35);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color29, stroke35);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint39 = piePlot38.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        piePlot38.setSimpleLabelOffset(rectangleInsets40);
        valueMarker37.setLabelOffset(rectangleInsets40);
        float float43 = valueMarker37.getAlpha();
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        java.awt.Stroke stroke45 = valueMarker37.getStroke();
        java.awt.Color color46 = java.awt.Color.red;
        java.awt.Color color47 = color46.darker();
        java.awt.Color color48 = color47.darker();
        valueMarker37.setPaint((java.awt.Paint) color48);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener50 = null;
        valueMarker37.addChangeListener(markerChangeListener50);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        piePlot0.setIgnoreZeroValues(true);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) stroke12);
        piePlot0.setBaseSectionOutlineStroke(stroke12);
        java.awt.Color color15 = java.awt.Color.red;
        java.awt.Color color16 = color15.darker();
        int int17 = color16.getRed();
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        java.lang.String str21 = multiplePiePlot20.getPlotType();
        double double22 = multiplePiePlot20.getLimit();
        org.jfree.chart.JFreeChart jFreeChart23 = multiplePiePlot20.getPieChart();
        boolean boolean24 = jFreeChart23.isNotify();
        java.awt.Stroke stroke25 = jFreeChart23.getBorderStroke();
        jFreeChart23.setTitle("ChartChangeEventType.GENERAL");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        java.awt.image.BufferedImage bufferedImage33 = jFreeChart23.createBufferedImage(97, 3, (double) (byte) 10, 0.2d, chartRenderingInfo32);
        piePlot0.setBackgroundImage((java.awt.Image) bufferedImage33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 178 + "'", int17 == 178);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Multiple Pie Plot" + "'", str21.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(bufferedImage33);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray31, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis37.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setAutoRangeIncludesZero(false);
        numberAxis40.setVerticalTickLabels(true);
        boolean boolean45 = numberAxis40.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer46);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D48.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range52 = categoryPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot47.zoomDomainAxes(1.0d, plotRenderingInfo54, point2D55, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = categoryPlot47.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation59 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str60 = plotOrientation59.toString();
        categoryPlot47.setOrientation(plotOrientation59);
        org.jfree.chart.util.SortOrder sortOrder62 = categoryPlot47.getColumnRenderingOrder();
        categoryPlot19.setRowRenderingOrder(sortOrder62);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(plotOrientation59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "PlotOrientation.VERTICAL" + "'", str60.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(sortOrder62);
        org.junit.Assert.assertNull(categoryItemRenderer64);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        boolean boolean5 = jFreeChart4.isNotify();
        java.awt.Paint paint6 = jFreeChart4.getBorderPaint();
        jFreeChart4.setTitle("java.awt.Color[r=255,g=175,b=175]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        int int15 = pieSectionEntity14.getPieIndex();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toFixedHeight((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D6.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range10 = numberAxis3D6.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint3.toRangeWidth(range10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint14.toFixedHeight((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedHeight((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range28 = numberAxis3D24.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint21.toRangeWidth(range28);
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude(range28, 0.14d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType32 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint(3.0d, range10, lengthConstraintType17, (double) 1, range31, lengthConstraintType32);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(lengthConstraintType32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.equals((java.lang.Object) '4');
        java.lang.Comparable comparable3 = null;
        boolean boolean4 = paintMap0.containsKey(comparable3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset7);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset7, (int) (byte) 0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis3.setLabelToolTip("");
        int int6 = categoryAxis3.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis3.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelOutlinePaint();
        java.awt.Stroke stroke13 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) stroke13);
        valueMarker9.setOutlineStroke(stroke13);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font19, (java.awt.Paint) color20, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font19);
        valueMarker9.setLabelFont(font19);
        valueMarker9.setLabel("TextAnchor.BOTTOM_LEFT");
        try {
            valueMarker9.setAlpha((float) (-334));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange(0.0d);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        piePlot3.setIgnoreZeroValues(true);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint9 = piePlot8.getLabelOutlinePaint();
        java.awt.Stroke stroke10 = piePlot8.getLabelOutlineStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString14 = null;
        standardPieSectionLabelGenerator12.setAttributedLabel(500, attributedString14);
        boolean boolean17 = standardPieSectionLabelGenerator12.equals((java.lang.Object) 0.0f);
        piePlot8.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        boolean boolean19 = numberAxis0.equals((java.lang.Object) standardPieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        java.lang.Object obj15 = pieSectionEntity14.clone();
        pieSectionEntity14.setURLText("java.awt.Color[r=255,g=175,b=175]");
        java.lang.Comparable comparable18 = null;
        pieSectionEntity14.setSectionKey(comparable18);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        java.awt.Paint paint7 = null;
        xYPlot0.setRangeTickBandPaint(paint7);
        xYPlot0.setDomainCrosshairValue(4.0d, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis15.setTickMarkStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color13, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke25 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean26 = rectangleAnchor22.equals((java.lang.Object) stroke25);
        valueMarker21.setOutlineStroke(stroke25);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font31, (java.awt.Paint) color32, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font31);
        valueMarker21.setLabelFont(font31);
        valueMarker21.setLabel("TextAnchor.BOTTOM_LEFT");
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        valueMarker21.setLabelPaint((java.awt.Paint) color40);
        org.jfree.chart.util.Layer layer42 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        textTitle16.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle16.getBounds();
        pieSectionEntity14.setArea((java.awt.Shape) rectangle2D22);
        java.lang.Object obj24 = pieSectionEntity14.clone();
        java.lang.String str25 = pieSectionEntity14.toString();
        java.lang.String str26 = pieSectionEntity14.getToolTipText();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PieSection: -1, 0(-1)" + "'", str25.equals("PieSection: -1, 0(-1)"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pie Plot" + "'", str26.equals("Pie Plot"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        java.awt.Stroke stroke8 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        int int9 = piePlot0.getPieIndex();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 178, 0.0d);
        double double3 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 178.0d + "'", double3 == 178.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        double double4 = piePlot1.getMaximumLabelWidth();
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets4.createOutsetRectangle(rectangle2D14, false, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray21, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis27.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setAutoRangeIncludesZero(false);
        numberAxis30.setVerticalTickLabels(true);
        boolean boolean35 = numberAxis30.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D38.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range42 = categoryPlot37.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        java.awt.Stroke stroke43 = categoryPlot37.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        double double46 = categoryAxis1.getCategoryStart(15, (int) (byte) 0, rectangle2D14, rectangleEdge44);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions47 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.0d + "'", double6 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        java.lang.Object obj3 = piePlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Comparable comparable2 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Other" + "'", comparable2.equals("Other"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        boolean boolean5 = polarPlot0.isRangeZoomable();
        polarPlot0.setAngleGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot0.getAxis();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getDomainAxis((int) (byte) 100);
        xYPlot9.clearRangeMarkers();
        polarPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleLabelPaint();
        java.lang.Object obj2 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        java.awt.Stroke stroke8 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        piePlot0.setCircular(false, false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis15.setLabelToolTip("");
        int int18 = categoryAxis15.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis15.setTickMarkStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color13, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint24 = piePlot23.getLabelOutlinePaint();
        java.awt.Stroke stroke25 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean26 = rectangleAnchor22.equals((java.lang.Object) stroke25);
        valueMarker21.setOutlineStroke(stroke25);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("hi!", font31, (java.awt.Paint) color32, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!", font31);
        valueMarker21.setLabelFont(font31);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot0.getRangeAxisEdge((int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot19.getAxisOffset();
        java.awt.Paint paint28 = categoryPlot19.getRangeCrosshairPaint();
        categoryPlot19.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot19.setRangeCrosshairStroke(stroke45);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        boolean boolean7 = dateAxis0.isAutoRange();
        dateAxis0.setTickMarkOutsideLength((float) 178);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        boolean boolean9 = multiplePiePlot8.isOutlineVisible();
        java.lang.Comparable comparable10 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        multiplePiePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot0.equals((java.lang.Object) axisChangeEvent11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot0.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperBound((double) 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot19.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str32 = plotOrientation31.toString();
        categoryPlot19.setOrientation(plotOrientation31);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot19.getColumnRenderingOrder();
        categoryPlot19.clearRangeAxes();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PlotOrientation.VERTICAL" + "'", str32.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        java.awt.Paint paint12 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint13 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint16 = piePlot15.getLabelOutlinePaint();
        piePlot15.setIgnoreZeroValues(true);
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement19.add((org.jfree.chart.block.Block) textTitle21, (java.lang.Object) stroke27);
        piePlot15.setBaseSectionOutlineStroke(stroke27);
        java.awt.Color color30 = java.awt.Color.red;
        java.awt.Color color31 = color30.darker();
        int int32 = color31.getRed();
        piePlot15.setLabelOutlinePaint((java.awt.Paint) color31);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 178 + "'", int32 == 178);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlpha((float) (byte) 1);
        java.lang.String str3 = polarPlot0.getPlotType();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle6.getBounds();
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Polar Plot" + "'", str3.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        boolean boolean7 = dateAxis0.isAutoRange();
        boolean boolean9 = dateAxis0.isHiddenValue((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace3);
        java.awt.Paint paint5 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis0.getTickLabelInsets();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis46.setLabelToolTip("");
        int int49 = categoryAxis46.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis46.setTickMarkStroke(stroke50);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color44, stroke50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = piePlot54.getLabelOutlinePaint();
        java.awt.Stroke stroke56 = piePlot54.getBaseSectionOutlineStroke();
        boolean boolean57 = rectangleAnchor53.equals((java.lang.Object) stroke56);
        valueMarker52.setOutlineStroke(stroke56);
        java.awt.Font font62 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment65 = new org.jfree.chart.text.TextFragment("hi!", font62, (java.awt.Paint) color63, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine66 = new org.jfree.chart.text.TextLine("", font62);
        org.jfree.chart.text.TextFragment textFragment67 = new org.jfree.chart.text.TextFragment("hi!", font62);
        valueMarker52.setLabelFont(font62);
        valueMarker52.setLabel("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.util.Layer layer71 = null;
        boolean boolean72 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker52, layer71);
        java.lang.String str73 = categoryPlot19.getPlotType();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Category Plot" + "'", str73.equals("Category Plot"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { (byte) 100 };
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "java.awt.Color[r=255,g=175,b=175]", doubleArray10);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray2, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getRangeAxisCount();
        xYPlot0.setNoDataMessage("ChartChangeEventType.GENERAL");
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeIncludesZero(false);
        numberAxis7.setVerticalTickLabels(true);
        numberAxis7.setAutoRangeStickyZero(true);
        numberAxis7.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis7.getTickUnit();
        double double17 = numberAxis7.getLowerMargin();
        double double18 = numberAxis7.getUpperBound();
        org.jfree.data.Range range19 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str2 = piePlot1.getPlotType();
        boolean boolean3 = piePlot0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis11.setLabelToolTip("");
        int int14 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis11.setTickMarkStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color9, stroke15);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (-1.0f), stroke15);
        piePlot1.zoom((double) '#');
        piePlot1.setMaximumLabelWidth((double) 10L);
        boolean boolean23 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        java.awt.Font font10 = textTitle2.getFont();
        java.lang.String str11 = textTitle2.getURLText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeIncludesZero(false);
        numberAxis28.setVerticalTickLabels(true);
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis28.getTickUnit();
        numberAxis25.setTickUnit(numberTickUnit37);
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot19.setRenderer((int) (short) 10, categoryItemRenderer41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis46.setLabelToolTip("");
        int int49 = categoryAxis46.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis46.setTickMarkStroke(stroke50);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color44, stroke50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint55 = piePlot54.getLabelOutlinePaint();
        java.awt.Stroke stroke56 = piePlot54.getBaseSectionOutlineStroke();
        boolean boolean57 = rectangleAnchor53.equals((java.lang.Object) stroke56);
        valueMarker52.setOutlineStroke(stroke56);
        java.awt.Font font62 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment65 = new org.jfree.chart.text.TextFragment("hi!", font62, (java.awt.Paint) color63, (float) (short) -1);
        org.jfree.chart.text.TextLine textLine66 = new org.jfree.chart.text.TextLine("", font62);
        org.jfree.chart.text.TextFragment textFragment67 = new org.jfree.chart.text.TextFragment("hi!", font62);
        valueMarker52.setLabelFont(font62);
        valueMarker52.setLabel("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.util.Layer layer71 = null;
        boolean boolean72 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker52, layer71);
        double double73 = categoryPlot19.getAnchorValue();
        double double74 = categoryPlot19.getAnchorValue();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation75 = null;
        try {
            boolean boolean76 = categoryPlot19.removeAnnotation(categoryAnnotation75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        polarPlot0.setAngleLabelsVisible(false);
        int int5 = polarPlot0.getSeriesCount();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        double double11 = textTitle10.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle10.getPadding();
        java.awt.Font font13 = textTitle10.getFont();
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("PlotOrientation.VERTICAL", font13);
        polarPlot0.setAngleLabelFont(font13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        double double3 = piePlot0.getInteriorGap();
        piePlot0.setCircular(true);
        piePlot0.setLabelLinksVisible(false);
        java.awt.Paint paint8 = piePlot0.getShadowPaint();
        piePlot0.zoom((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot0.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        double double6 = dateAxis0.getAutoRangeMinimumSize();
        try {
            dateAxis0.zoomRange((double) (short) 0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY((double) 178);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range11 = numberAxis3D7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint4.toRangeWidth(range11);
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range11, 0.14d);
        dateAxis0.setDefaultAutoRange(range11);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((-1));
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis5.getTickMarkPosition();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis5.setTickLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis5.setTimeline(timeline9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint12 = piePlot11.getLabelBackgroundPaint();
        java.awt.Paint paint13 = null;
        piePlot11.setShadowPaint(paint13);
        double double15 = piePlot11.getShadowXOffset();
        dateAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot11);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        piePlot11.setShadowPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(102.0d, (java.awt.Paint) color17, stroke19);
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20, layer21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString6 = null;
        standardPieSectionLabelGenerator4.setAttributedLabel(500, attributedString6);
        boolean boolean9 = standardPieSectionLabelGenerator4.equals((java.lang.Object) 0.0f);
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot0.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getContentXOffset();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle6.getHorizontalAlignment();
        boolean boolean13 = textBlockAnchor4.equals((java.lang.Object) horizontalAlignment12);
        textTitle1.setTextAlignment(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("PieSection: -1, 0(-1)", graphics2D1, (float) (short) 100, (float) 0L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        int int3 = xYPlot0.getDomainAxisCount();
        int int4 = xYPlot0.getRangeAxisCount();
        xYPlot0.setNoDataMessage("ChartChangeEventType.GENERAL");
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(xYDataset7);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        java.awt.Paint paint9 = dateAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets1.calculateRightOutset((double) (-1L));
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) stroke8);
        double double10 = textTitle2.getWidth();
        double double11 = textTitle2.getWidth();
        double double12 = textTitle2.getContentXOffset();
        double double13 = textTitle2.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis4.setLabelToolTip("");
        int int7 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setTickMarkStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color2, stroke8);
        xYPlot0.setRangeCrosshairStroke(stroke8);
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        int int16 = xYPlot13.getDomainAxisCount();
        xYPlot13.setWeight(4);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat20 = null;
        dateAxis19.setDateFormatOverride(dateFormat20);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis19.getTickMarkPosition();
        dateAxis19.setTickMarkOutsideLength((float) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis27.setLabelToolTip("");
        categoryAxis27.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets();
        double double41 = rectangleInsets39.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        textTitle43.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets39.createOutsetRectangle(rectangle2D49, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double54 = numberAxis35.java2DToValue((double) (short) -1, rectangle2D49, rectangleEdge53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double56 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor32, (int) (short) 0, 255, rectangle2D49, rectangleEdge55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis19.java2DToValue(0.0d, rectangle2D49, rectangleEdge57);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        numberAxis59.setAutoRangeIncludesZero(false);
        numberAxis59.setVerticalTickLabels(true);
        numberAxis59.setAutoRangeStickyZero(true);
        numberAxis59.setUpperBound((double) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition69 = dateAxis68.getTickMarkPosition();
        double double70 = dateAxis68.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat72 = null;
        dateAxis71.setDateFormatOverride(dateFormat72);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition74 = dateAxis71.getTickMarkPosition();
        java.awt.Font font75 = dateAxis71.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat77 = null;
        dateAxis76.setDateFormatOverride(dateFormat77);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition79 = dateAxis76.getTickMarkPosition();
        dateAxis76.setTickMarkOutsideLength((float) (short) 100);
        java.text.DateFormat dateFormat82 = null;
        dateAxis76.setDateFormatOverride(dateFormat82);
        org.jfree.data.Range range84 = dateAxis76.getRange();
        dateAxis76.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D87 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D87.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand91 = null;
        numberAxis3D87.setMarkerBand(markerAxisBand91);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray93 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, numberAxis59, dateAxis68, dateAxis71, dateAxis76, numberAxis3D87 };
        xYPlot13.setRangeAxes(valueAxisArray93);
        xYPlot0.setRangeAxes(valueAxisArray93);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 102.0d + "'", double41 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.NEGATIVE_INFINITY + "'", double54 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition74);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(dateTickMarkPosition79);
        org.junit.Assert.assertNotNull(range84);
        org.junit.Assert.assertNotNull(valueAxisArray93);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge(178);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle6.getBounds();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D12, pieDataset13, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor30);
        xYPlot0.setQuadrantOrigin(point2D32);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str31.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        dateAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis0.setFixedAutoRange(0.08d);
        java.awt.Shape shape9 = dateAxis0.getDownArrow();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint11 = piePlot10.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        piePlot10.setSimpleLabelOffset(rectangleInsets12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot10.setLegendLabelURLGenerator(pieURLGenerator14);
        java.awt.Paint paint16 = null;
        piePlot10.setBackgroundPaint(paint16);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot10);
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        textTitle21.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        columnArrangement19.add((org.jfree.chart.block.Block) textTitle21, (java.lang.Object) stroke27);
        piePlot10.setBaseSectionOutlineStroke(stroke27);
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint31 = piePlot30.getLabelOutlinePaint();
        java.awt.Stroke stroke32 = piePlot30.getLabelOutlineStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator34 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString36 = null;
        standardPieSectionLabelGenerator34.setAttributedLabel(500, attributedString36);
        boolean boolean39 = standardPieSectionLabelGenerator34.equals((java.lang.Object) 0.0f);
        piePlot30.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator34);
        piePlot10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 1L, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D7, pieDataset8, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        textTitle16.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle16.getBounds();
        pieSectionEntity14.setArea((java.awt.Shape) rectangle2D22);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22);
        java.lang.String str25 = chartEntity24.toString();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ChartEntity: tooltip = null" + "'", str25.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        java.lang.String str2 = numberAxis0.getLabel();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = categoryPlot19.getOrientation();
        java.awt.Stroke stroke46 = categoryPlot19.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean2, jFreeChart3, (int) 'a', (int) (byte) 100);
        int int7 = chartProgressEvent6.getType();
        int int8 = chartProgressEvent6.getType();
        org.jfree.chart.JFreeChart jFreeChart9 = chartProgressEvent6.getChart();
        chartProgressEvent6.setPercent((int) (short) 100);
        chartProgressEvent6.setPercent(0);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        java.lang.String str16 = multiplePiePlot15.getPlotType();
        double double17 = multiplePiePlot15.getLimit();
        org.jfree.chart.JFreeChart jFreeChart18 = multiplePiePlot15.getPieChart();
        boolean boolean19 = jFreeChart18.isNotify();
        java.awt.Paint paint20 = jFreeChart18.getBorderPaint();
        chartProgressEvent6.setChart(jFreeChart18);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray25, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setAutoRangeIncludesZero(false);
        numberAxis34.setVerticalTickLabels(true);
        boolean boolean39 = numberAxis34.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer40);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D42.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range46 = categoryPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D42);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot41.setFixedDomainAxisSpace(axisSpace47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot41.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        float float52 = categoryAxis51.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryAxis51.getTickLabelInsets();
        int int54 = categoryPlot41.getDomainAxisIndex(categoryAxis51);
        categoryAxis51.setLabelAngle((double) (short) 0);
        java.awt.Stroke stroke57 = categoryAxis51.getAxisLineStroke();
        try {
            jFreeChart18.setTextAntiAlias((java.lang.Object) categoryAxis51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.CategoryAxis@0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(jFreeChart9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Multiple Pie Plot" + "'", str16.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot1.getPieChart();
        jFreeChart4.setTitle("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot1.getDomainMarkers(layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot1.setRangeAxis((int) ' ', valueAxis5, false);
        java.awt.Color color8 = java.awt.Color.WHITE;
        xYPlot1.setDomainCrosshairPaint((java.awt.Paint) color8);
        java.awt.Color color10 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", color8);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelToolTip("");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        float float13 = categoryAxis12.getTickMarkOutsideLength();
        double double14 = categoryAxis12.getLowerMargin();
        float float15 = categoryAxis12.getTickMarkInsideLength();
        categoryAxis12.setMaximumCategoryLabelLines((-1));
        java.awt.Font font18 = categoryAxis12.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint20 = piePlot19.getLabelOutlinePaint();
        java.awt.Stroke stroke21 = piePlot19.getLabelOutlineStroke();
        double double22 = piePlot19.getInteriorGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        piePlot19.removeChangeListener(plotChangeListener23);
        boolean boolean25 = categoryAxis12.hasListener((java.util.EventListener) plotChangeListener23);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        textTitle29.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle29.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis37.setLabelToolTip("");
        categoryAxis37.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets();
        double double51 = rectangleInsets49.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        textTitle53.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D59 = textTitle53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets49.createOutsetRectangle(rectangle2D59, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double64 = numberAxis45.java2DToValue((double) (short) -1, rectangle2D59, rectangleEdge63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double66 = categoryAxis37.getCategoryJava2DCoordinate(categoryAnchor42, (int) (short) 0, 255, rectangle2D59, rectangleEdge65);
        double double67 = categoryAxis12.getCategoryEnd((int) '4', 0, rectangle2D35, rectangleEdge65);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        numberAxis68.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = new org.jfree.chart.util.RectangleInsets();
        double double74 = rectangleInsets72.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle("");
        textTitle76.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D82 = textTitle76.getBounds();
        java.awt.geom.Rectangle2D rectangle2D85 = rectangleInsets72.createOutsetRectangle(rectangle2D82, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double87 = numberAxis68.java2DToValue((double) (short) -1, rectangle2D82, rectangleEdge86);
        org.jfree.data.Range range88 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint90 = new org.jfree.chart.block.RectangleConstraint(range88, 10.0d);
        boolean boolean91 = rectangleEdge86.equals((java.lang.Object) range88);
        double double92 = categoryAxis6.getCategoryMiddle((int) (short) 10, 178, rectangle2D35, rectangleEdge86);
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.08d + "'", double22 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 102.0d + "'", double51 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.NEGATIVE_INFINITY + "'", double64 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 102.0d + "'", double74 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + Double.NEGATIVE_INFINITY + "'", double87 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.equals((java.lang.Object) '4');
        paintMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setLabelToolTip("");
        int int34 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis31.setTickMarkStroke(stroke35);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color29, stroke35);
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint39 = piePlot38.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        piePlot38.setSimpleLabelOffset(rectangleInsets40);
        valueMarker37.setLabelOffset(rectangleInsets40);
        float float43 = valueMarker37.getAlpha();
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke46 = xYPlot45.getRangeZeroBaselineStroke();
        categoryPlot19.setOutlineStroke(stroke46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot19.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.awt.Shape shape2 = dateAxis0.getRightArrow();
        boolean boolean3 = dateAxis0.isNegativeArrowVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = piePlotState6.getPieArea();
        double double8 = piePlotState6.getLatestAngle();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        textTitle10.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D16, pieDataset17, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        textTitle25.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle25.getBounds();
        pieSectionEntity23.setArea((java.awt.Shape) rectangle2D31);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31);
        piePlotState6.setExplodedPieArea(rectangle2D31);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray39, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis45.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setAutoRangeIncludesZero(false);
        numberAxis48.setVerticalTickLabels(true);
        boolean boolean53 = numberAxis48.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryItemRenderer54);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D56.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range60 = categoryPlot55.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D56);
        java.awt.Stroke stroke61 = categoryPlot55.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot55.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        java.lang.Class<?> wildcardClass64 = rectangleEdge63.getClass();
        double double65 = dateAxis0.valueToJava2D((double) (byte) -1, rectangle2D31, rectangleEdge63);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelOutlinePaint();
        java.awt.Stroke stroke2 = piePlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint4 = piePlot3.getLabelOutlinePaint();
        java.awt.Stroke stroke5 = piePlot3.getLabelOutlineStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        double double7 = piePlot0.getMaximumLabelWidth();
        java.awt.Color color8 = java.awt.Color.orange;
        piePlot0.setBaseSectionPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.mapDatasetToRangeAxis((int) (byte) 1, (int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis35.setLabelToolTip("");
        double double38 = categoryAxis35.getUpperMargin();
        boolean boolean39 = categoryAxis35.isAxisLineVisible();
        categoryPlot19.setDomainAxis((int) '4', categoryAxis35, false);
        categoryPlot19.setRangeCrosshairValue(1.0d, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = categoryPlot19.getOrientation();
        boolean boolean46 = categoryPlot19.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryPlot19.getInsets();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleInsets47);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BOTTOM_LEFT", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setAutoRangeStickyZero(true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, 0.14d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedHeight((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range16 = numberAxis3D12.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint9.toRangeWidth(range16);
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range16, 0.14d);
        numberAxis0.setRange(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        textTitle2.setPadding((double) (short) 0, (double) 100, (double) (-1L), (double) 10.0f);
        java.lang.Object obj8 = textTitle2.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle2.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment9, (double) 'a', 100.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray26);
        float float28 = categoryPlot19.getForegroundAlpha();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(500, attributedString4);
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        boolean boolean7 = piePlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot19.setRangeAxes(valueAxisArray30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot19.getDomainAxisEdge(15);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        boolean boolean25 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot19.zoomDomainAxes((double) (-1), plotRenderingInfo27, point2D28, false);
        categoryPlot19.clearRangeAxes();
        categoryPlot19.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundImageAlpha((float) (byte) 1);
        java.lang.String str3 = polarPlot0.getPlotType();
        java.awt.Paint paint4 = polarPlot0.getAngleGridlinePaint();
        boolean boolean5 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Polar Plot" + "'", str3.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        xYPlot0.setRangeAxis((int) ' ', valueAxis4, false);
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getLegendItems();
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str31 = piePlot30.getPlotType();
        boolean boolean32 = piePlot29.equals((java.lang.Object) piePlot30);
        piePlot29.setSimpleLabels(true);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot29.setLabelLinkStroke(stroke35);
        categoryPlot19.setRangeCrosshairStroke(stroke35);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Pie Plot" + "'", str31.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.awt.Shape shape2 = dateAxis0.getRightArrow();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        textTitle5.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle5.getBounds();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset12, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray26, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeIncludesZero(false);
        numberAxis32.setVerticalTickLabels(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis38.setLabelToolTip("");
        int int41 = categoryAxis38.getCategoryLabelPositionOffset();
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        textTitle45.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle45.getBounds();
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity58 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D51, pieDataset52, 0, 1, (java.lang.Comparable) 0.0d, "", "Pie Plot");
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis38.getCategoryStart(0, 100, rectangle2D51, rectangleEdge59);
        numberAxis32.setDownArrow((java.awt.Shape) rectangle2D51);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis63.setLabelToolTip("");
        categoryAxis63.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor68 = null;
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis();
        numberAxis71.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = new org.jfree.chart.util.RectangleInsets();
        double double77 = rectangleInsets75.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle("");
        textTitle79.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D85 = textTitle79.getBounds();
        java.awt.geom.Rectangle2D rectangle2D88 = rectangleInsets75.createOutsetRectangle(rectangle2D85, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double90 = numberAxis71.java2DToValue((double) (short) -1, rectangle2D85, rectangleEdge89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double92 = categoryAxis63.getCategoryJava2DCoordinate(categoryAnchor68, (int) (short) 0, 255, rectangle2D85, rectangleEdge91);
        double double93 = categoryAxis3D20.getCategorySeriesMiddle((java.lang.Comparable) "hi!", (java.lang.Comparable) 102.0d, categoryDataset30, 2.0d, rectangle2D51, rectangleEdge91);
        double double94 = dateAxis0.valueToJava2D(10.0d, rectangle2D11, rectangleEdge91);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 102.0d + "'", double77 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(rectangle2D88);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + Double.NEGATIVE_INFINITY + "'", double90 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis9.setLabelToolTip("");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeIncludesZero(false);
        numberAxis12.setVerticalTickLabels(true);
        boolean boolean17 = numberAxis12.isInverted();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D20.setAutoRangeMinimumSize(3.0d, false);
        org.jfree.data.Range range24 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomDomainAxes(1.0d, plotRenderingInfo26, point2D27, false);
        categoryPlot19.clearDomainMarkers((int) '#');
        java.awt.Paint paint32 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        float float35 = categoryAxis34.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis34.getTickLabelInsets();
        categoryPlot19.setDomainAxis(categoryAxis34);
        java.lang.String str38 = categoryAxis34.getLabelURL();
        categoryAxis34.removeCategoryLabelToolTip((java.lang.Comparable) "Pie Plot");
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 2.0f + "'", float35 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        double double3 = categoryAxis1.getLowerMargin();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryAxis1);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "java.awt.Color[r=255,g=175,b=175]", doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset18, (java.lang.Comparable) "PieSection: -1, 0(-1)");
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        textTitle25.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle25.getBounds();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity38 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D31, pieDataset32, (-1), (int) (short) 0, (java.lang.Comparable) (-1L), "Pie Plot", "");
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        textTitle40.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle40.getBounds();
        pieSectionEntity38.setArea((java.awt.Shape) rectangle2D46);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets23.createInsetRectangle(rectangle2D46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeIncludesZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets();
        double double55 = rectangleInsets53.extendHeight((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        textTitle57.setPadding((double) (byte) -1, (double) (byte) 0, 0.0d, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle57.getBounds();
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets53.createOutsetRectangle(rectangle2D63, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double68 = numberAxis49.java2DToValue((double) (short) -1, rectangle2D63, rectangleEdge67);
        double double69 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 0.14d, (java.lang.Comparable) (byte) 100, categoryDataset18, 10.0d, rectangle2D48, rectangleEdge67);
        categoryAxis1.setCategoryLabelPositionOffset(1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 102.0d + "'", double55 == 102.0d);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.NEGATIVE_INFINITY + "'", double68 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
    }
}

