import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10, (double) (-1), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        try {
            org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset28, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setNegativeArrowVisible(true);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double8 = dateAxis0.valueToJava2D((double) (byte) -1, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        java.awt.Font font6 = null;
        try {
            valueMarker3.setLabelFont(font6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        try {
            org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset28, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color1 = java.awt.Color.gray;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10.0f, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color6, stroke11, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        java.lang.String str6 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ClassContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraintType.RANGE" + "'", str1.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockBorder5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        try {
            java.util.Date date2 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.block.Arrangement arrangement6 = null;
        org.jfree.chart.block.Arrangement arrangement7 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0, arrangement6, arrangement7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Font font9 = null;
        try {
            valueMarker8.setLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        try {
            java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        polarPlot0.rendererChanged(rendererChangeEvent6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setNegativeArrowVisible(true);
        java.util.TimeZone timeZone5 = null;
        try {
            dateAxis0.setTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setNegativeArrowVisible(true);
        java.awt.Font font5 = null;
        try {
            dateAxis0.setTickLabelFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        try {
            java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            valueMarker3.setLabelOffsetType(lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Font font1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=128,g=128,b=128]", font1, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        java.awt.Stroke stroke3 = null;
        try {
            dateAxis0.setTickMarkStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) 0.0d);
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=128,g=128,b=128]", graphics2D1, (float) (short) 1, (float) (byte) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = piePlotState1.getInfo();
        piePlotState1.setPieCenterY((double) (byte) 100);
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        java.lang.Object obj3 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double7 = categoryAxis0.getCategoryEnd(10, (int) (byte) 10, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.String str1 = color0.toString();
        float[] floatArray4 = new float[] { (short) 1, 10.0f };
        try {
            float[] floatArray5 = color0.getRGBColorComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=128]"));
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            multiplePiePlot29.drawOutline(graphics2D30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double8 = dateAxis0.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis0.setTickUnit(dateTickUnit5);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 1, (float) (-1), 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-524308) + "'", int3 == (-524308));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        polarPlot1.setAngleLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Other");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = piePlotState1.getInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlotState1.setPieArea(rectangle2D3);
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer10 = new org.jfree.chart.text.G2TextMeasurer(graphics2D9);
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color6, 0.0f, (int) (byte) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.Point point5 = polarPlot0.translateValueThetaRadiusToJava2D((double) 10.0f, 0.0d, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "RectangleConstraintType.RANGE");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            boolean boolean6 = xYPlot0.removeDomainMarker(0, marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlotState1.setExplodedPieArea(rectangle2D3);
        piePlotState1.setPieWRadius((double) 2.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = piePlotState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            boolean boolean5 = xYPlot0.removeAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis0.setTimeline(timeline5);
        dateAxis0.centerRange((double) (byte) -1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            xYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=128,g=128,b=128]", "Other", "Other", "hi!", "hi!");
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) 'a', (int) '#', (int) (byte) 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperMargin((double) (byte) -1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 10, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(10.0d, range8, lengthConstraintType9, 0.0d, range11, lengthConstraintType12);
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray40 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray41 = new double[][] { doubleArray20, doubleArray25, doubleArray30, doubleArray35, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray41);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset42, false);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint13.toRangeHeight(range45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint46.toFixedHeight((double) '4');
        try {
            org.jfree.chart.util.Size2D size2D49 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(10.0d, range4, lengthConstraintType5, 0.0d, range7, lengthConstraintType8);
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset38, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint9.toRangeHeight(range41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint42.toFixedHeight((double) '4');
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray56 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray61 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray66 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray71 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray72 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset73, false);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset73);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint42.toRangeWidth(range76);
        org.jfree.data.Range range79 = org.jfree.data.Range.expandToInclude(range76, (double) (byte) -1);
        dateAxis0.setRange(range79, false, true);
        java.awt.Graphics2D graphics2D83 = null;
        org.jfree.chart.plot.PolarPlot polarPlot84 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent85 = null;
        polarPlot84.notifyListeners(plotChangeEvent85);
        boolean boolean88 = polarPlot84.equals((java.lang.Object) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace91 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace92 = dateAxis0.reserveSpace(graphics2D83, (org.jfree.chart.plot.Plot) polarPlot84, rectangle2D89, rectangleEdge90, axisSpace91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangleEdge90);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double2 = piePlot3D0.getExplodePercent((java.lang.Comparable) 100.0f);
        java.awt.Stroke stroke3 = piePlot3D0.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        org.jfree.data.Range range35 = dateAxis0.getDefaultAutoRange();
        try {
            java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) range35);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 10, (double) 8, 100.0d, 55.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection4 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str11 = basicProjectInfo10.getName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.lang.String str13 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraintType.RANGE" + "'", str5.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraintType.RANGE" + "'", str11.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str13.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray6 = new float[] { (short) 100, (short) 100, 2.0f, (-1L) };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        boolean boolean11 = textBlock5.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=128]");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 10, (double) (short) 100);
        boolean boolean12 = lengthConstraintType5.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "ClassContext", "hi!");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) (-1L), (-1.0d), (double) (byte) 100);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent2.setType(chartChangeEventType4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        java.lang.Comparable comparable30 = multiplePiePlot29.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset31 = multiplePiePlot29.getDataset();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + "Other" + "'", comparable30.equals("Other"));
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 8, (double) (short) 10, (double) 0.0f, 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        java.awt.Stroke stroke4 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes((double) 1, plotRenderingInfo6, point2D7, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        double double3 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot0.getRenderer();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', (double) 100.0f, plotRenderingInfo4, point2D5);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { (-524308), 10L, (short) 10, (short) 10, "java.awt.Color[r=128,g=128,b=128]" };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { 10.0f };
        double[] doubleArray13 = new double[] { (byte) -1, 90.0d, 15, (short) 1, (short) 1 };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray7, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'rowKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Shape shape1 = null;
        try {
            piePlot3D0.setLegendItemShape(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = null;
        dateAxis0.setTickUnit(dateTickUnit35, false, false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color16);
        valueMarker3.setLabelOffset(rectangleInsets15);
        double double19 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        piePlot3D0.setLabelPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot0.getAxis();
        polarPlot0.setOutlineVisible(false);
        int int9 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = java.awt.Color.cyan;
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker7.setStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color3, stroke8);
        org.jfree.chart.util.Layer layer11 = null;
        try {
            xYPlot0.addDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean3 = polarPlot0.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = polarPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYDataset4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        double double41 = range38.constrain((double) (byte) 10);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 10.0d + "'", double41 == 10.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot0.notifyListeners(plotChangeEvent6);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        polarPlot0.setAngleLabelFont(font8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot0.rendererChanged(rendererChangeEvent10);
        polarPlot0.removeCornerTextItem("java.awt.Color[r=128,g=128,b=128]");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            waferMapPlot1.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        polarPlot6.notifyListeners(plotChangeEvent7);
        boolean boolean10 = polarPlot6.equals((java.lang.Object) 0.0f);
        java.awt.Color color13 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot6.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer18 = new org.jfree.chart.text.G2TextMeasurer(graphics2D17);
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color13, (float) (byte) 10, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        xYPlot0.datasetChanged(datasetChangeEvent14);
        boolean boolean16 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        boolean boolean2 = waferMapPlot1.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ClassContext", font1, paint2, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot5.notifyListeners(plotChangeEvent6);
        boolean boolean9 = polarPlot5.equals((java.lang.Object) 0.0f);
        java.awt.Color color12 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot5.setBackgroundPaint((java.awt.Paint) color12);
        boolean boolean14 = textFragment4.equals((java.lang.Object) polarPlot5);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment4.draw(graphics2D15, 0.0f, (float) 255, textAnchor18, (float) (byte) 1, (float) 2, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        java.awt.Color color6 = java.awt.Color.cyan;
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color6, stroke11);
        xYPlot0.setDomainZeroBaselineStroke(stroke11);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot0.getRangeMarkers((-524308), layer16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double3 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D0.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot2.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot2.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder5);
        float float7 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        polarPlot0.datasetChanged(datasetChangeEvent6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        java.awt.geom.Rectangle2D rectangle2D3 = piePlotState1.getLinkArea();
        double double4 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color16);
        valueMarker3.setLabelOffset(rectangleInsets15);
        double double19 = rectangleInsets15.getBottom();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(100);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        java.awt.Shape shape3 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        try {
            org.jfree.chart.util.Size2D size2D43 = rectangleConstraint39.calculateConstrainedSize(size2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        java.lang.String str30 = range29.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Range[0.0,11.0]" + "'", str30.equals("Range[0.0,11.0]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Other", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ClassContext", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        boolean boolean35 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toFixedHeight((double) '4');
        double[] doubleArray48 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray69 = new double[][] { doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray69);
        org.jfree.data.Range range72 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset70, false);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset70);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint39.toRangeWidth(range73);
        org.jfree.data.Range range76 = org.jfree.data.Range.expandToInclude(range73, (double) (byte) -1);
        org.jfree.data.Range range79 = org.jfree.data.Range.expand(range76, (-8.0d), 10.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(range79);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        double double32 = range31.getLength();
        boolean boolean34 = range31.contains((double) 1L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 55.0d + "'", double32 == 55.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double3 = size2D2.getWidth();
        double double4 = size2D2.width;
        size2D2.height = 100L;
        size2D2.setHeight(0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = valueMarker8.getLabelOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        waferMapPlot2.markerChanged(markerChangeEvent3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=0,g=255,b=255]"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color4 = java.awt.Color.gray;
        java.lang.String str5 = color4.toString();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 128, (double) (short) 100, (double) 0.5f, (double) 100, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str5.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        textTitle2.setNotify(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        waferMapPlot2.setNoDataMessage("ClassContext");
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        try {
            multiplePiePlot32.setPieChart(jFreeChart33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setNegativeArrowVisible(true);
        java.lang.Object obj5 = dateAxis0.clone();
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(10.0d, range7, lengthConstraintType8, 0.0d, range10, lengthConstraintType11);
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray34 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray39 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray40 = new double[][] { doubleArray19, doubleArray24, doubleArray29, doubleArray34, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset41, false);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint12.toRangeHeight(range44);
        org.jfree.data.Range range47 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType48 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range50 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType51 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint(10.0d, range47, lengthConstraintType48, 0.0d, range50, lengthConstraintType51);
        double[] doubleArray59 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray64 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray69 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray74 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray79 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray80 = new double[][] { doubleArray59, doubleArray64, doubleArray69, doubleArray74, doubleArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray80);
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset81, false);
        org.jfree.data.Range range84 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset81);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint85 = rectangleConstraint52.toRangeHeight(range84);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint86 = rectangleConstraint12.toRangeHeight(range84);
        dateAxis0.setRange(range84, false, false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(lengthConstraintType48);
        org.junit.Assert.assertNotNull(lengthConstraintType51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(range84);
        org.junit.Assert.assertNotNull(rectangleConstraint85);
        org.junit.Assert.assertNotNull(rectangleConstraint86);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        java.lang.Comparable comparable4 = null;
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray34 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraintType.RANGE", "", doubleArray35);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double41 = categoryAxis0.getCategorySeriesMiddle(comparable4, (java.lang.Comparable) 10, categoryDataset37, (double) '4', rectangle2D39, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis0.setRange(date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(0.0d, 8.0d, (double) (short) 100, (double) 10, (java.awt.Paint) color7);
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        java.lang.Object obj10 = textTitle2.clone();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("ClassContext", font12, paint13, (float) (byte) 100);
        textTitle2.setFont(font12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) -1, 10.0d, 84.0d, (double) (byte) 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle2.getMargin();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.5f, (double) 100L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = ringPlot0.getURLGenerator();
        ringPlot0.setOuterSeparatorExtension((double) 1L);
        org.junit.Assert.assertNull(pieURLGenerator1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) (short) -1, 0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            xYPlot0.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        try {
            org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset28, (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperMargin((double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.gray;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color3);
        double double5 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Range[0.0,11.0]", "ClassContext", "ClassContext", "hi!", "");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (-8.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean10 = textAnchor8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean14 = textAnchor12.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, 0.0f, (float) 100, textAnchor8, 1.0d, textAnchor12);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[0.0,11.0]", graphics2D1, 0.0f, 0.0f, textAnchor8, (double) 10, 10.0f, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        piePlot3D0.setDarkerSides(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setInverted(false);
        double double40 = dateAxis2.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toFixedHeight((double) '4');
        double[] doubleArray48 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray69 = new double[][] { doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray69);
        org.jfree.data.Range range72 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset70, false);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset70);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint39.toRangeWidth(range73);
        org.jfree.data.Range range76 = org.jfree.data.Range.expandToInclude(range73, (double) (byte) -1);
        double double78 = range76.constrain(1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        java.awt.Paint paint8 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 90.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.extendHeight(0.0d);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Color color9 = java.awt.Color.black;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker11.setStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke12);
        java.awt.Stroke stroke15 = valueMarker14.getStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = valueMarker14.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3, false, true);
        java.awt.Shape shape7 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font2);
        org.jfree.chart.text.TextFragment textFragment7 = textLine6.getLastTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textFragment7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str11 = basicProjectInfo10.getName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        basicProjectInfo10.setCopyright("RectangleConstraintType.RANGE");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraintType.RANGE" + "'", str5.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraintType.RANGE" + "'", str11.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (short) 10, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        size2D2.setHeight((double) (-1));
        size2D2.setHeight((double) 0.5f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', (double) 100.0f, plotRenderingInfo4, point2D5);
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list11 = projectInfo10.getContributors();
        xYPlot0.drawDomainTickBands(graphics2D8, rectangle2D9, list11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) (byte) 100, (float) 500);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        xYPlot0.datasetChanged(datasetChangeEvent14);
        xYPlot0.clearRangeMarkers((int) '#');
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        java.awt.Paint paint7 = null;
        try {
            xYPlot0.setDomainCrosshairPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Stroke stroke9 = valueMarker8.getStroke();
        java.awt.Paint paint10 = valueMarker8.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        double double16 = rectangleInsets10.calculateRightOutset((double) 2.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        double double32 = range31.getLength();
        double double33 = range31.getLowerBound();
        double double34 = range31.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 55.0d + "'", double32 == 55.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-5.0d) + "'", double33 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 50.0d + "'", double34 == 50.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraintType.RANGE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        java.awt.Color color5 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent7.setType(chartChangeEventType8);
        chartChangeEvent2.setType(chartChangeEventType8);
        org.jfree.chart.JFreeChart jFreeChart11 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNull(jFreeChart11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setWeight((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "Range[0.0,11.0]", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(255);
        java.lang.Object obj5 = objectList1.get((int) (short) 100);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperBound((double) (short) -1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        java.awt.Shape shape4 = null;
        try {
            dateAxis0.setRightArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers(layer2);
        xYPlot0.mapDatasetToRangeAxis((int) ' ', 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.util.List list1 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperBound((double) (short) -1);
        dateAxis0.setAutoRange(true);
        boolean boolean5 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setRange((double) (-524308), (-5.0d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setInverted(false);
        boolean boolean37 = dateAxis0.isAutoRange();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle2.getMargin();
        double double9 = rectangleInsets7.calculateLeftOutset(0.025d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = piePlotState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list2 = projectInfo1.getContributors();
        projectInfo0.setContributors(list2);
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        int int14 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        try {
            java.awt.Paint paint44 = xYPlot42.getQuadrantPaint((-524308));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-524308) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double double3 = dateAxis0.getUpperBound();
        java.awt.Color color5 = java.awt.Color.cyan;
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker9.setStroke(stroke10);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color5, stroke10);
        dateAxis0.setAxisLinePaint((java.awt.Paint) color5);
        double double14 = dateAxis0.getUpperBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = dateAxis0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot39.setFixedRangeAxisSpace(axisSpace40);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        try {
            categoryPlot39.addDomainMarker((int) (byte) 100, categoryMarker43, layer44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        java.awt.Color color10 = color2.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]", (double) 1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int3 = java.awt.Color.HSBtoRGB(1.0f, (float) (-524308), (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot39.setFixedRangeAxisSpace(axisSpace40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        try {
            int int43 = categoryPlot39.getRangeAxisIndex(valueAxis42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(100);
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker7.setStroke(stroke8);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener10 = null;
        valueMarker7.addChangeListener(markerChangeListener10);
        valueMarker7.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getLeft();
        double double17 = rectangleInsets14.extendHeight(0.0d);
        valueMarker7.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets14.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets14);
        double double22 = rectangleInsets14.trimWidth((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-6.0d) + "'", double22 == (-6.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ClassContext", font3, paint4, (float) (byte) 100);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font3);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font3);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-8.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        boolean boolean30 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = piePlotState1.getInfo();
        piePlotState1.setPieHRadius((double) 0.5f);
        java.awt.geom.Rectangle2D rectangle2D5 = piePlotState1.getPieArea();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertNull(rectangle2D5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) 0L, 0.0f, 0.0f);
        piePlot0.setLabelLinkPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        dateAxis0.setVisible(false);
//        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
//        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
//        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
//        dateAxis0.setDefaultAutoRange(range33);
//        org.jfree.data.Range range35 = dateAxis0.getDefaultAutoRange();
//        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
//        dateAxis36.setVisible(false);
//        dateAxis36.setLabelURL("RectangleConstraintType.RANGE");
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
//        java.awt.Graphics2D graphics2D43 = null;
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D();
//        org.jfree.chart.LegendItemCollection legendItemCollection46 = piePlot3D45.getLegendItems();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState49 = ringPlot42.initialise(graphics2D43, rectangle2D44, (org.jfree.chart.plot.PiePlot) piePlot3D45, (java.lang.Integer) 0, plotRenderingInfo48);
//        java.awt.Graphics2D graphics2D50 = null;
//        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double54 = size2D53.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) '4', (double) (byte) 1, rectangleAnchor57);
//        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot();
//        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
//        dateAxis60.setVisible(false);
//        double double63 = dateAxis60.getUpperBound();
//        java.awt.Color color65 = java.awt.Color.cyan;
//        java.awt.Color color67 = java.awt.Color.black;
//        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color67, stroke68);
//        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker69.setStroke(stroke70);
//        org.jfree.chart.plot.ValueMarker valueMarker72 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color65, stroke70);
//        dateAxis60.setAxisLinePaint((java.awt.Paint) color65);
//        dateAxis60.setRangeWithMargins((double) (-524308), (double) 1L);
//        java.awt.Shape shape77 = dateAxis60.getLeftArrow();
//        piePlot59.setLegendItemShape(shape77);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState81 = piePlot3D45.initialise(graphics2D50, rectangle2D58, piePlot59, (java.lang.Integer) 255, plotRenderingInfo80);
//        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double83 = dateAxis36.dateToJava2D(date41, rectangle2D58, rectangleEdge82);
//        dateAxis0.setMinimumDate(date41);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertNotNull(doubleArray24);
//        org.junit.Assert.assertNotNull(doubleArray29);
//        org.junit.Assert.assertNotNull(doubleArray30);
//        org.junit.Assert.assertNotNull(categoryDataset31);
//        org.junit.Assert.assertNotNull(range33);
//        org.junit.Assert.assertNotNull(range35);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(legendItemCollection46);
//        org.junit.Assert.assertNotNull(piePlotState49);
//        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.0d + "'", double54 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor57);
//        org.junit.Assert.assertNotNull(rectangle2D58);
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
//        org.junit.Assert.assertNotNull(color65);
//        org.junit.Assert.assertNotNull(color67);
//        org.junit.Assert.assertNotNull(stroke68);
//        org.junit.Assert.assertNotNull(stroke70);
//        org.junit.Assert.assertNotNull(shape77);
//        org.junit.Assert.assertNotNull(piePlotState81);
//        org.junit.Assert.assertNotNull(rectangleEdge82);
//        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.56043833244502E14d + "'", double83 == 1.56043833244502E14d);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraintType.RANGE", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot39.getDataset();
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray57 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray62 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray67 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray68 = new double[][] { doubleArray47, doubleArray52, doubleArray57, doubleArray62, doubleArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray68);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = categoryPlot39.getRendererForDataset(categoryDataset69);
        org.jfree.chart.util.SortOrder sortOrder71 = categoryPlot39.getColumnRenderingOrder();
        categoryPlot39.clearDomainMarkers((int) 'a');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNull(categoryItemRenderer70);
        org.junit.Assert.assertNotNull(sortOrder71);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setInverted(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(10.0d, range4, lengthConstraintType5, 0.0d, range7, lengthConstraintType8);
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset38, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint9.toRangeHeight(range41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint42.toFixedHeight((double) '4');
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray56 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray61 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray66 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray71 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray72 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset73, false);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset73);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint42.toRangeWidth(range76);
        org.jfree.data.Range range79 = org.jfree.data.Range.expandToInclude(range76, (double) (byte) -1);
        dateAxis0.setRange(range79, false, true);
        dateAxis0.setRange((double) 0, 55.0d);
        java.awt.Shape shape86 = null;
        try {
            dateAxis0.setRightArrow(shape86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertNotNull(range79);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double12 = size2D11.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '4', (double) (byte) 1, rectangleAnchor15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setVisible(false);
        double double21 = dateAxis18.getUpperBound();
        java.awt.Color color23 = java.awt.Color.cyan;
        java.awt.Color color25 = java.awt.Color.black;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker27.setStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color23, stroke28);
        dateAxis18.setAxisLinePaint((java.awt.Paint) color23);
        dateAxis18.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape35 = dateAxis18.getLeftArrow();
        piePlot17.setLegendItemShape(shape35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.PiePlotState piePlotState39 = piePlot3D3.initialise(graphics2D8, rectangle2D16, piePlot17, (java.lang.Integer) 255, plotRenderingInfo38);
        double double40 = piePlotState39.getLatestAngle();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(piePlotState39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 90.0d + "'", double40 == 90.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double3 = size2D2.getWidth();
        double double4 = size2D2.width;
        size2D2.width = 0.0d;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(255);
        java.lang.Object obj5 = objectList1.get((int) (byte) 100);
        objectList1.clear();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = ringPlot0.getURLGenerator();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double6 = size2D5.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) '4', (double) (byte) 1, rectangleAnchor9);
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            ringPlot0.draw(graphics2D2, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        java.awt.Paint paint4 = polarPlot0.getAngleGridlinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot0.datasetChanged(datasetChangeEvent5);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        categoryAxis0.setLowerMargin((double) 8);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        org.jfree.data.KeyToGroupMap keyToGroupMap30 = null;
        try {
            org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28, keyToGroupMap30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setRangeCrosshairValue(0.05d);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        int int8 = xYPlot0.getWeight();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace20);
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = piePlot3D22.getLegendItems();
        java.awt.Paint paint24 = piePlot3D22.getBaseSectionPaint();
        java.awt.Paint paint25 = piePlot3D22.getLabelPaint();
        xYPlot10.setOutlinePaint(paint25);
        try {
            xYPlot0.setQuadrantPaint(10, paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        piePlotState1.setPieHRadius(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        java.awt.Paint paint30 = multiplePiePlot29.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toFixedHeight((double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint39.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint39.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Stroke stroke9 = valueMarker8.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP;
        valueMarker8.setLabelAnchor(rectangleAnchor10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        boolean boolean5 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo8, point2D9);
        double double11 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray12);
        java.awt.Color color16 = java.awt.Color.black;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker18.setStroke(stroke19);
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        polarPlot21.setBackgroundAlpha((float) (short) 0);
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot21);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        xYPlot25.setRangeTickBandPaint((java.awt.Paint) color27);
        xYPlot25.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot25);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot25.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation(2, axisLocation39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot0.indexOf(xYDataset41);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = null;
        try {
            standardPieSectionLabelGenerator0.setAttributedLabel((int) (byte) -1, attributedString3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        polarPlot9.notifyListeners(plotChangeEvent10);
        boolean boolean12 = polarPlot9.isAngleLabelsVisible();
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot9);
        java.lang.String str14 = polarPlot9.getNoDataMessage();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, 100, (-1), rectangle2D5, rectangleEdge6);
        double double9 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        categoryAxis0.setUpperMargin((double) (-1L));
        categoryAxis0.setTickMarkInsideLength(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        try {
            java.util.Date date8 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot0.setRangeAxis(valueAxis14);
        boolean boolean16 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot39.setFixedRangeAxisSpace(axisSpace40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot39.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setVisible(false);
        double[] doubleArray54 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray59 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray64 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray69 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray74 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray75 = new double[][] { doubleArray54, doubleArray59, doubleArray64, doubleArray69, doubleArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray75);
        org.jfree.data.Range range78 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset76, false);
        dateAxis45.setDefaultAutoRange(range78);
        dateAxis45.setFixedAutoRange(2.0d);
        dateAxis45.setLowerMargin(0.0d);
        try {
            categoryPlot39.setRangeAxis((-524308), (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(range78);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker9.setStroke(stroke10);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke10);
        java.awt.Stroke stroke13 = valueMarker12.getStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker12.getLabelOffsetType();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        java.awt.Paint paint13 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.LegendItem legendItem9 = null;
        legendItemCollection7.add(legendItem9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot39.getDataset();
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray57 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray62 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray67 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray68 = new double[][] { doubleArray47, doubleArray52, doubleArray57, doubleArray62, doubleArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray68);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = categoryPlot39.getRendererForDataset(categoryDataset69);
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = xYPlot71.getRendererForDataset(xYDataset72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        java.awt.geom.Point2D point2D76 = null;
        xYPlot71.zoomRangeAxes((double) '#', plotRenderingInfo75, point2D76);
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis();
        dateAxis79.setUpperMargin((double) (byte) -1);
        java.awt.Color color82 = java.awt.Color.gray;
        dateAxis79.setTickMarkPaint((java.awt.Paint) color82);
        xYPlot71.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis79);
        int int85 = categoryPlot39.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis79);
        java.lang.Object obj86 = categoryPlot39.clone();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNull(categoryItemRenderer70);
        org.junit.Assert.assertNull(xYItemRenderer73);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(obj86);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setVisible(false);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        dateAxis3.setDefaultAutoRange(range36);
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range40 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        dateAxis3.setUpperBound(100.0d);
        boolean boolean43 = dateAxis3.isTickMarksVisible();
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font2);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textLine6.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Color color7 = java.awt.Color.cyan;
        java.awt.Color color9 = java.awt.Color.black;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker11.setStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color7, stroke12);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker14.getLabelTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[0.0,11.0]", graphics2D1, (float) 255, (float) 128, textAnchor4, (double) (byte) 0, textAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.title.LegendTitle legendTitle49 = null;
        try {
            jFreeChart33.addLegend(legendTitle49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double38 = size2D37.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) '4', (double) (byte) 1, rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        try {
            jFreeChart33.draw(graphics2D34, rectangle2D42, point2D43, chartRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double2 = piePlot3D0.getExplodePercent((java.lang.Comparable) 100.0f);
        double double3 = piePlot3D0.getDepthFactor();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean6 = piePlot3D5.getIgnoreNullValues();
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        double double23 = rectangleInsets17.trimWidth((double) 100L);
        piePlot3D5.setSimpleLabelOffset(rectangleInsets17);
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double28 = size2D27.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) '4', (double) (byte) 1, rectangleAnchor31);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets17.createOutsetRectangle(rectangle2D32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            piePlot3D0.draw(graphics2D4, rectangle2D33, point2D34, plotState35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12d + "'", double3 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 84.0d + "'", double23 == 84.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color16);
        valueMarker3.setLabelOffset(rectangleInsets15);
        java.lang.Class class19 = null;
        try {
            java.util.EventListener[] eventListenerArray20 = valueMarker3.getListeners(class19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot39.getDataset();
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray57 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray62 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray67 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray68 = new double[][] { doubleArray47, doubleArray52, doubleArray57, doubleArray62, doubleArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray68);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = categoryPlot39.getRendererForDataset(categoryDataset69);
        org.jfree.chart.util.SortOrder sortOrder71 = categoryPlot39.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset73 = categoryPlot39.getDataset(2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNull(categoryItemRenderer70);
        org.junit.Assert.assertNotNull(sortOrder71);
        org.junit.Assert.assertNull(categoryDataset73);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        boolean boolean5 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo8, point2D9);
        double double11 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint12 = xYPlot0.getDomainGridlinePaint();
        java.awt.Font font13 = xYPlot0.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.Plot plot14 = xYPlot0.getRootPlot();
        java.awt.Color color15 = java.awt.Color.yellow;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.lang.Object obj3 = textTitle2.clone();
        textTitle2.setURLText("java.awt.Color[r=0,g=255,b=255]");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.util.List list2 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat1);
        double double3 = numberAxis3D0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(0.0d, 8.0d, (double) (short) 100, (double) 10, (java.awt.Paint) color7);
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        java.lang.Object obj10 = textTitle2.clone();
        double double11 = textTitle2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setVisible(true);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(timeline5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", font3);
        polarPlot0.setAngleLabelFont(font3);
        polarPlot0.addCornerTextItem("java.awt.Color[r=128,g=128,b=128]");
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 0);
        double double8 = categoryAxis0.getUpperMargin();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean12 = piePlot3D11.getIgnoreNullValues();
        java.awt.Color color14 = java.awt.Color.black;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color14, stroke15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker16.setStroke(stroke17);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker16.addChangeListener(markerChangeListener19);
        valueMarker16.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double24 = rectangleInsets23.getLeft();
        double double26 = rectangleInsets23.extendHeight(0.0d);
        valueMarker16.setLabelOffset(rectangleInsets23);
        double double29 = rectangleInsets23.trimWidth((double) 100L);
        piePlot3D11.setSimpleLabelOffset(rectangleInsets23);
        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double34 = size2D33.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) '4', (double) (byte) 1, rectangleAnchor37);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets23.createOutsetRectangle(rectangle2D38);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double43 = size2D42.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '4', (double) (byte) 1, rectangleAnchor46);
        java.awt.Font font49 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("ClassContext", font49);
        java.lang.Object obj51 = textTitle50.clone();
        java.awt.Font font53 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("ClassContext", font53, paint54, (float) (byte) 100);
        textTitle50.setFont(font53);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        textTitle50.setPosition(rectangleEdge59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        try {
            org.jfree.chart.axis.AxisState axisState62 = categoryAxis0.draw(graphics2D9, (double) (byte) 100, rectangle2D39, rectangle2D47, rectangleEdge59, plotRenderingInfo61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 84.0d + "'", double29 == 84.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        java.lang.Object obj10 = textTitle2.clone();
        java.awt.Graphics2D graphics2D11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle2.arrange(graphics2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=128,g=128,b=128]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=128,g=128,b=128]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
//        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
//        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
//        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
//        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
//        boolean boolean34 = jFreeChart33.isBorderVisible();
//        java.awt.Graphics2D graphics2D35 = null;
//        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
//        dateAxis36.setVisible(false);
//        dateAxis36.setLabelURL("RectangleConstraintType.RANGE");
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
//        java.awt.Graphics2D graphics2D43 = null;
//        java.awt.geom.Rectangle2D rectangle2D44 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D();
//        org.jfree.chart.LegendItemCollection legendItemCollection46 = piePlot3D45.getLegendItems();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState49 = ringPlot42.initialise(graphics2D43, rectangle2D44, (org.jfree.chart.plot.PiePlot) piePlot3D45, (java.lang.Integer) 0, plotRenderingInfo48);
//        java.awt.Graphics2D graphics2D50 = null;
//        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double54 = size2D53.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) '4', (double) (byte) 1, rectangleAnchor57);
//        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot();
//        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
//        dateAxis60.setVisible(false);
//        double double63 = dateAxis60.getUpperBound();
//        java.awt.Color color65 = java.awt.Color.cyan;
//        java.awt.Color color67 = java.awt.Color.black;
//        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color67, stroke68);
//        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker69.setStroke(stroke70);
//        org.jfree.chart.plot.ValueMarker valueMarker72 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color65, stroke70);
//        dateAxis60.setAxisLinePaint((java.awt.Paint) color65);
//        dateAxis60.setRangeWithMargins((double) (-524308), (double) 1L);
//        java.awt.Shape shape77 = dateAxis60.getLeftArrow();
//        piePlot59.setLegendItemShape(shape77);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState81 = piePlot3D45.initialise(graphics2D50, rectangle2D58, piePlot59, (java.lang.Integer) 255, plotRenderingInfo80);
//        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double83 = dateAxis36.dateToJava2D(date41, rectangle2D58, rectangleEdge82);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo84 = null;
//        try {
//            jFreeChart33.draw(graphics2D35, rectangle2D58, chartRenderingInfo84);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertNotNull(doubleArray16);
//        org.junit.Assert.assertNotNull(doubleArray21);
//        org.junit.Assert.assertNotNull(doubleArray26);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(categoryDataset28);
//        org.junit.Assert.assertNotNull(range30);
//        org.junit.Assert.assertNotNull(range31);
//        org.junit.Assert.assertNotNull(jFreeChart33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(legendItemCollection46);
//        org.junit.Assert.assertNotNull(piePlotState49);
//        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.0d + "'", double54 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor57);
//        org.junit.Assert.assertNotNull(rectangle2D58);
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
//        org.junit.Assert.assertNotNull(color65);
//        org.junit.Assert.assertNotNull(color67);
//        org.junit.Assert.assertNotNull(stroke68);
//        org.junit.Assert.assertNotNull(stroke70);
//        org.junit.Assert.assertNotNull(shape77);
//        org.junit.Assert.assertNotNull(piePlotState81);
//        org.junit.Assert.assertNotNull(rectangleEdge82);
//        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.56043833244502E14d + "'", double83 == 1.56043833244502E14d);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
        java.lang.String str3 = rectangleInsets0.toString();
        double double4 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=255,b=255]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        polarPlot6.zoomDomainAxes((double) (short) 100, plotRenderingInfo11, point2D12, true);
        java.awt.Paint paint15 = polarPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        float float6 = valueMarker3.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(10.0d, range2, lengthConstraintType3, 0.0d, range5, lengthConstraintType6);
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray34 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset36, false);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint7.toRangeHeight(range39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint40.toFixedHeight((double) '4');
        double[] doubleArray49 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray54 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray59 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray64 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray69 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray70 = new double[][] { doubleArray49, doubleArray54, doubleArray59, doubleArray64, doubleArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray70);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset71, false);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset71);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint75 = rectangleConstraint40.toRangeWidth(range74);
        org.jfree.data.Range range77 = org.jfree.data.Range.expandToInclude(range74, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint(range77, 0.08d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = new org.jfree.chart.block.RectangleConstraint((double) (-1L), range77);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(rectangleConstraint75);
        org.junit.Assert.assertNotNull(range77);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        double double3 = piePlotState1.getPieWRadius();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        piePlotState1.setPieArea(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        double double10 = textTitle2.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = jFreeChart33.getPadding();
        try {
            java.awt.image.BufferedImage bufferedImage52 = jFreeChart33.createBufferedImage(8, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (8) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets49);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator39 = null;
        ringPlot38.setToolTipGenerator(pieToolTipGenerator39);
        java.awt.Stroke stroke41 = ringPlot38.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color44.createContext(colorModel45, rectangle46, rectangle2D47, affineTransform48, renderingHints49);
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color44);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace52);
        boolean boolean54 = ringPlot38.equals((java.lang.Object) axisSpace52);
        java.awt.Paint paint55 = ringPlot38.getSeparatorPaint();
        xYPlot0.setBackgroundPaint(paint55);
        boolean boolean57 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        double double33 = multiplePiePlot32.getLimit();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Stroke stroke3 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean5 = piePlot3D4.getIgnoreNullValues();
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker9.setStroke(stroke10);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener12 = null;
        valueMarker9.addChangeListener(markerChangeListener12);
        valueMarker9.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getLeft();
        double double19 = rectangleInsets16.extendHeight(0.0d);
        valueMarker9.setLabelOffset(rectangleInsets16);
        double double22 = rectangleInsets16.trimWidth((double) 100L);
        piePlot3D4.setSimpleLabelOffset(rectangleInsets16);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double27 = size2D26.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) '4', (double) (byte) 1, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets16.createOutsetRectangle(rectangle2D31);
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 84.0d + "'", double22 == 84.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Color color6 = java.awt.Color.black;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color6, stroke7);
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
//        categoryAxis0.setMaximumCategoryLabelLines(100);
//        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
//        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
//        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
//        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
//        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
//        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
//        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
//        dateAxis40.setVisible(false);
//        double double43 = dateAxis40.getUpperBound();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
//        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot45.getDataset();
//        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
//        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
//        dateAxis49.setVisible(false);
//        dateAxis49.setLabelURL("RectangleConstraintType.RANGE");
//        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.plot.RingPlot ringPlot55 = new org.jfree.chart.plot.RingPlot();
//        java.awt.Graphics2D graphics2D56 = null;
//        java.awt.geom.Rectangle2D rectangle2D57 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
//        org.jfree.chart.LegendItemCollection legendItemCollection59 = piePlot3D58.getLegendItems();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState62 = ringPlot55.initialise(graphics2D56, rectangle2D57, (org.jfree.chart.plot.PiePlot) piePlot3D58, (java.lang.Integer) 0, plotRenderingInfo61);
//        java.awt.Graphics2D graphics2D63 = null;
//        org.jfree.chart.util.Size2D size2D66 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double67 = size2D66.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D71 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D66, (double) '4', (double) (byte) 1, rectangleAnchor70);
//        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot();
//        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis();
//        dateAxis73.setVisible(false);
//        double double76 = dateAxis73.getUpperBound();
//        java.awt.Color color78 = java.awt.Color.cyan;
//        java.awt.Color color80 = java.awt.Color.black;
//        java.awt.Stroke stroke81 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color80, stroke81);
//        java.awt.Stroke stroke83 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker82.setStroke(stroke83);
//        org.jfree.chart.plot.ValueMarker valueMarker85 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color78, stroke83);
//        dateAxis73.setAxisLinePaint((java.awt.Paint) color78);
//        dateAxis73.setRangeWithMargins((double) (-524308), (double) 1L);
//        java.awt.Shape shape90 = dateAxis73.getLeftArrow();
//        piePlot72.setLegendItemShape(shape90);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState94 = piePlot3D58.initialise(graphics2D63, rectangle2D71, piePlot72, (java.lang.Integer) 255, plotRenderingInfo93);
//        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double96 = dateAxis49.dateToJava2D(date54, rectangle2D71, rectangleEdge95);
//        org.jfree.chart.util.RectangleEdge rectangleEdge97 = org.jfree.chart.util.RectangleEdge.RIGHT;
//        double double98 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 0L, (java.lang.Comparable) "ClassContext", categoryDataset46, (double) (short) 0, rectangle2D71, rectangleEdge97);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertNotNull(doubleArray17);
//        org.junit.Assert.assertNotNull(doubleArray22);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertNotNull(doubleArray33);
//        org.junit.Assert.assertNotNull(categoryDataset34);
//        org.junit.Assert.assertNotNull(range36);
//        org.junit.Assert.assertNotNull(range37);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
//        org.junit.Assert.assertNotNull(categoryDataset46);
//        org.junit.Assert.assertNotNull(range47);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(legendItemCollection59);
//        org.junit.Assert.assertNotNull(piePlotState62);
//        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 100.0d + "'", double67 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor70);
//        org.junit.Assert.assertNotNull(rectangle2D71);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
//        org.junit.Assert.assertNotNull(color78);
//        org.junit.Assert.assertNotNull(color80);
//        org.junit.Assert.assertNotNull(stroke81);
//        org.junit.Assert.assertNotNull(stroke83);
//        org.junit.Assert.assertNotNull(shape90);
//        org.junit.Assert.assertNotNull(piePlotState94);
//        org.junit.Assert.assertNotNull(rectangleEdge95);
//        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 1.56043833244502E14d + "'", double96 == 1.56043833244502E14d);
//        org.junit.Assert.assertNotNull(rectangleEdge97);
//        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.29083333333333344d + "'", double98 == 0.29083333333333344d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        double double2 = xYPlot0.getDomainCrosshairValue();
        xYPlot0.setForegroundAlpha(1.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        int int40 = categoryPlot39.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot39.getRangeAxisEdge((int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext", font2);
        java.lang.Object obj4 = textTitle3.clone();
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font6, paint7, (float) (byte) 100);
        textTitle3.setFont(font6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color12);
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, (java.lang.Object) 0.4d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener8 = null;
        valueMarker5.addChangeListener(markerChangeListener8);
        valueMarker5.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getLeft();
        double double15 = rectangleInsets12.extendHeight(0.0d);
        valueMarker5.setLabelOffset(rectangleInsets12);
        double double18 = rectangleInsets12.trimWidth((double) 100L);
        piePlot3D0.setSimpleLabelOffset(rectangleInsets12);
        double double20 = piePlot3D0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 84.0d + "'", double18 == 84.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08d + "'", double20 == 0.08d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot39.setFixedRangeAxisSpace(axisSpace40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot39.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        categoryPlot39.setRenderer(2, categoryItemRenderer45);
        categoryPlot39.setAnchorValue(0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", font2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ChartChangeEventType.DATASET_UPDATED", font2, paint5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        double double2 = piePlot3D0.getMinimumArcAngleToDraw();
        java.lang.Object obj3 = piePlot3D0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        polarPlot9.notifyListeners(plotChangeEvent10);
        boolean boolean12 = polarPlot9.isAngleLabelsVisible();
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot9);
        boolean boolean14 = polarPlot9.isRangeZoomable();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(100);
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker7.setStroke(stroke8);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener10 = null;
        valueMarker7.addChangeListener(markerChangeListener10);
        valueMarker7.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getLeft();
        double double17 = rectangleInsets14.extendHeight(0.0d);
        valueMarker7.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets14.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets14);
        java.awt.Font font22 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[0.0,11.0]");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            float float5 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Range[0.0,11.0]" + "'", str2.equals("Range[0.0,11.0]"));
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke40);
        int int42 = categoryPlot39.getDomainAxisCount();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        boolean boolean45 = xYPlot44.isRangeCrosshairLockedOnData();
        java.awt.Paint paint46 = xYPlot44.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = xYPlot44.getDatasetRenderingOrder();
        int int48 = xYPlot44.getDatasetCount();
        java.awt.Color color50 = java.awt.Color.black;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color50, stroke51);
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker52.setStroke(stroke53);
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot();
        polarPlot55.setBackgroundAlpha((float) (short) 0);
        valueMarker52.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot55);
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot59);
        java.awt.Color color61 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel62 = null;
        java.awt.Rectangle rectangle63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color61.createContext(colorModel62, rectangle63, rectangle2D64, affineTransform65, renderingHints66);
        xYPlot59.setRangeTickBandPaint((java.awt.Paint) color61);
        xYPlot59.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker52.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot59);
        org.jfree.chart.axis.AxisLocation axisLocation73 = xYPlot59.getRangeAxisLocation();
        xYPlot44.setRangeAxisLocation(axisLocation73);
        categoryPlot39.setRangeAxisLocation(100, axisLocation73, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(axisLocation73);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font2);
        org.jfree.chart.text.TextFragment textFragment7 = textLine6.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment8 = textLine6.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textFragment7);
        org.junit.Assert.assertNotNull(textFragment8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 0);
        categoryAxis0.setUpperMargin(50.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color12);
        xYPlot10.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot10.zoomDomainAxes((double) 128, plotRenderingInfo25, point2D26);
        xYPlot10.setDomainCrosshairValue(0.05d, true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = multiplePiePlot29.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(legendItemCollection30);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        polarPlot5.setAngleLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot5.getOrientation();
        xYPlot0.setOrientation(plotOrientation11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ClassContext", font2);
        textTitle3.setExpandToFitSpace(false);
        java.awt.Paint paint6 = null;
        textTitle3.setBackgroundPaint(paint6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle3.getHorizontalAlignment();
        textTitle3.setNotify(false);
        java.lang.Object obj11 = textTitle3.clone();
        java.awt.Font font12 = textTitle3.getFont();
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", font12);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        piePlotState1.setExplodedPieArea(rectangle2D3);
        piePlotState1.setPieCenterY(84.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Stroke stroke2 = xYPlot0.getRangeZeroBaselineStroke();
        java.lang.Object obj3 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        valueMarker3.setAlpha(0.0f);
        valueMarker3.setLabel("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        double double43 = dateAxis6.getLabelAngle();
        java.text.DateFormat dateFormat44 = dateAxis6.getDateFormatOverride();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(dateFormat44);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ClassContext", font1, paint2, (float) (byte) 100);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textFragment4.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        double[] doubleArray10 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset32, false);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset32);
        org.jfree.chart.JFreeChart jFreeChart37 = multiplePiePlot36.getPieChart();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("ClassContext", font39);
        java.lang.Object obj41 = textTitle40.clone();
        java.awt.Font font43 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ClassContext", font43, paint44, (float) (byte) 100);
        textTitle40.setFont(font43);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder(rectangleInsets48, (java.awt.Paint) color49);
        textTitle40.setFrame((org.jfree.chart.block.BlockFrame) blockBorder50);
        jFreeChart37.addSubtitle((org.jfree.chart.title.Title) textTitle40);
        chartChangeEvent2.setChart(jFreeChart37);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(jFreeChart37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double12 = size2D11.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '4', (double) (byte) 1, rectangleAnchor15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setVisible(false);
        double double21 = dateAxis18.getUpperBound();
        java.awt.Color color23 = java.awt.Color.cyan;
        java.awt.Color color25 = java.awt.Color.black;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker27.setStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color23, stroke28);
        dateAxis18.setAxisLinePaint((java.awt.Paint) color23);
        dateAxis18.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape35 = dateAxis18.getLeftArrow();
        piePlot17.setLegendItemShape(shape35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.PiePlotState piePlotState39 = piePlot3D3.initialise(graphics2D8, rectangle2D16, piePlot17, (java.lang.Integer) 255, plotRenderingInfo38);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot3D3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator40);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        boolean boolean43 = xYPlot42.isRangeCrosshairLockedOnData();
        java.awt.Paint paint44 = xYPlot42.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = xYPlot42.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot46 = xYPlot42.getParent();
        xYPlot42.setRangeCrosshairValue(0.05d);
        boolean boolean49 = xYPlot42.isRangeZoomable();
        boolean boolean50 = standardPieSectionLabelGenerator40.equals((java.lang.Object) boolean49);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(piePlotState39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str11 = basicProjectInfo10.getName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str18 = basicProjectInfo17.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str24 = basicProjectInfo23.getName();
        basicProjectInfo17.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj28 = dateAxis27.clone();
        float float29 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(true);
        java.lang.Object obj32 = dateAxis27.clone();
        boolean boolean33 = basicProjectInfo4.equals((java.lang.Object) dateAxis27);
        org.jfree.chart.ui.Library[] libraryArray34 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraintType.RANGE" + "'", str5.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraintType.RANGE" + "'", str11.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraintType.RANGE" + "'", str18.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleConstraintType.RANGE" + "'", str24.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(libraryArray34);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = piePlotState1.getInfo();
        piePlotState1.setPieHRadius((double) 0.5f);
        double double5 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot0.zoomDomainAxes((double) (-1.0f), (double) 1.0f, plotRenderingInfo40, point2D41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = xYPlot0.getRangeAxis((-524308));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(valueAxis44);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        double[] doubleArray7 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset29, false);
        boolean boolean32 = textBlockAnchor0.equals((java.lang.Object) categoryDataset29);
        boolean boolean34 = textBlockAnchor0.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        double double2 = piePlot3D0.getDepthFactor();
        java.awt.Color color4 = java.awt.Color.cyan;
        java.awt.Color color6 = java.awt.Color.black;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker8.setStroke(stroke9);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color4, stroke9);
        piePlot3D0.setLabelBackgroundPaint((java.awt.Paint) color4);
        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3D0.setOutlinePaint(paint13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean41 = piePlot3D40.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D40);
        categoryPlot39.notifyListeners(plotChangeEvent42);
        org.jfree.chart.JFreeChart jFreeChart44 = plotChangeEvent42.getChart();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(jFreeChart44);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.lang.Comparable comparable34 = multiplePiePlot32.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + "Other" + "'", comparable34.equals("Other"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(10.0d, range4, lengthConstraintType5, 0.0d, range7, lengthConstraintType8);
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset38, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint9.toRangeHeight(range41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint42.toFixedHeight((double) '4');
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray56 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray61 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray66 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray71 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray72 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset73, false);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset73);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint42.toRangeWidth(range76);
        org.jfree.data.Range range79 = org.jfree.data.Range.expandToInclude(range76, (double) (byte) -1);
        dateAxis0.setRange(range79, false, true);
        java.lang.String str83 = range79.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "Range[-5.0,50.0]" + "'", str83.equals("Range[-5.0,50.0]"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (-1.0d), (double) (-524308), (int) (short) 0, (java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 10, (double) (short) 100);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str11 = basicProjectInfo10.getName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list15 = projectInfo14.getContributors();
        projectInfo13.setContributors(list15);
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        java.lang.String str18 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraintType.RANGE" + "'", str5.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraintType.RANGE" + "'", str11.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertNotNull(projectInfo14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str18.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        java.awt.geom.Rectangle2D rectangle2D3 = piePlotState1.getLinkArea();
        piePlotState1.setPieCenterY((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Stroke stroke9 = valueMarker8.getStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker8.getLabelOffsetType();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        valueMarker8.notifyListeners(markerChangeEvent11);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        valueMarker8.setPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        xYPlot0.mapDatasetToDomainAxis((int) '#', 100);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setUpperBound((double) (short) -1);
        dateAxis7.setAutoRange(true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj13 = dateAxis12.clone();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis14.setStandardTickUnits(tickUnitSource17);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis14.setTimeline(timeline19);
        double double21 = dateAxis14.getLowerBound();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setUpperBound((double) (short) -1);
        dateAxis22.setAutoRange(true);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean33 = textAnchor31.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean37 = textAnchor35.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D28, 0.0f, (float) 100, textAnchor31, 1.0d, textAnchor35);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        dateAxis39.setVisible(false);
        double[] doubleArray48 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray69 = new double[][] { doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray69);
        org.jfree.data.Range range72 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset70, false);
        dateAxis39.setDefaultAutoRange(range72);
        dateAxis39.setAutoTickUnitSelection(false);
        boolean boolean76 = textAnchor35.equals((java.lang.Object) dateAxis39);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray77 = new org.jfree.chart.axis.ValueAxis[] { dateAxis7, dateAxis12, dateAxis14, dateAxis22, dateAxis39 };
        try {
            xYPlot0.setRangeAxes(valueAxisArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(valueAxisArray77);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("{0}", "RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", "Range[0.0,11.0]");
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setVisible(false);
        double double43 = dateAxis40.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
        boolean boolean46 = categoryPlot45.isRangeCrosshairVisible();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color52);
        int int54 = color52.getGreen();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color52, stroke55);
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        boolean boolean58 = textBlock5.equals((java.lang.Object) categoryPlot45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        categoryPlot45.setRenderer((int) 'a', categoryItemRenderer60);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 128 + "'", int54 == 128);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 50.0d + "'", number40.equals(50.0d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3, false, true);
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        double double23 = rectangleInsets17.trimWidth((double) 100L);
        dateAxis0.setTickLabelInsets(rectangleInsets17);
        dateAxis0.setLabelURL("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 84.0d + "'", double23 == 84.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis(15);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        ringPlot0.setInnerSeparatorExtension(0.08d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperBound((double) (short) -1);
        dateAxis0.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Paint paint2 = piePlot3D0.getBaseSectionPaint();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("ClassContext", font4);
        java.lang.Object obj6 = textTitle5.clone();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ClassContext", font8, paint9, (float) (byte) 100);
        textTitle5.setFont(font8);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, (java.awt.Paint) color14);
        textTitle5.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean17 = piePlot3D0.equals((java.lang.Object) blockBorder15);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(10.0d, range11, lengthConstraintType12, 0.0d, range14, lengthConstraintType15);
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray38 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray43 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray44 = new double[][] { doubleArray23, doubleArray28, doubleArray33, doubleArray38, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray44);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset45, false);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint16.toRangeHeight(range48);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint49.toFixedHeight((double) '4');
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray73 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray78 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray79 = new double[][] { doubleArray58, doubleArray63, doubleArray68, doubleArray73, doubleArray78 };
        org.jfree.data.category.CategoryDataset categoryDataset80 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray79);
        org.jfree.data.Range range82 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset80, false);
        org.jfree.data.Range range83 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset80);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint84 = rectangleConstraint49.toRangeWidth(range83);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType85 = rectangleConstraint49.getHeightConstraintType();
        boolean boolean86 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) polarPlot6, (java.lang.Object) lengthConstraintType85);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(categoryDataset80);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(rectangleConstraint84);
        org.junit.Assert.assertNotNull(lengthConstraintType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=0,b=0]", "ClassContext", "", image3, "java.awt.Color[r=128,g=128,b=128]", "ChartChangeEventType.DATASET_UPDATED", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            categoryPlot39.handleClick(0, (int) (byte) 10, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1, waferMapRenderer2);
        boolean boolean4 = unitType0.equals((java.lang.Object) waferMapRenderer2);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2, 0.0d, 90.0d, (double) (byte) -1);
        java.lang.String str10 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        java.awt.Image image4 = null;
        waferMapPlot1.setBackgroundImage(image4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        int int5 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.setForegroundAlpha((float) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = xYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = xYPlot6.getParent();
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        boolean boolean18 = xYPlot17.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = xYPlot17.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot17.getDatasetRenderingOrder();
        int int21 = xYPlot17.getDatasetCount();
        java.awt.Color color23 = java.awt.Color.black;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color23, stroke24);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker25.setStroke(stroke26);
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        polarPlot28.setBackgroundAlpha((float) (short) 0);
        valueMarker25.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot28);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.AffineTransform affineTransform38 = null;
        java.awt.RenderingHints renderingHints39 = null;
        java.awt.PaintContext paintContext40 = color34.createContext(colorModel35, rectangle36, rectangle2D37, affineTransform38, renderingHints39);
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color34);
        xYPlot32.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker25.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot32.getRangeAxisLocation();
        xYPlot17.setRangeAxisLocation(axisLocation46);
        xYPlot6.setDomainAxisLocation(axisLocation46);
        xYPlot0.setDomainAxisLocation((int) '#', axisLocation46, false);
        org.jfree.data.xy.XYDataset xYDataset51 = xYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintContext40);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(xYDataset51);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        float float34 = jFreeChart33.getBackgroundImageAlpha();
        try {
            org.jfree.chart.title.Title title36 = jFreeChart33.getSubtitle((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setRangeCrosshairValue(0.05d);
        java.awt.Color color9 = java.awt.Color.black;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker11.setStroke(stroke12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        polarPlot14.setBackgroundAlpha((float) (short) 0);
        valueMarker11.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot14);
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = xYPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker11, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toFixedHeight((double) '4');
        double[] doubleArray48 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray69 = new double[][] { doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray69);
        org.jfree.data.Range range72 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset70, false);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset70);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint39.toRangeWidth(range73);
        org.jfree.data.Range range76 = org.jfree.data.Range.expandToInclude(range73, (double) (byte) -1);
        org.jfree.data.Range range78 = org.jfree.data.Range.expandToInclude(range76, 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(range78);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean3 = polarPlot0.isAngleLabelsVisible();
        java.awt.Paint paint4 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setRangeCrosshairValue(0.05d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getMaximumCategoryLabelLines();
        categoryAxis8.setMaximumCategoryLabelLines(100);
        java.awt.Color color13 = java.awt.Color.black;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker15.setStroke(stroke16);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener18 = null;
        valueMarker15.addChangeListener(markerChangeListener18);
        valueMarker15.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double23 = rectangleInsets22.getLeft();
        double double25 = rectangleInsets22.extendHeight(0.0d);
        valueMarker15.setLabelOffset(rectangleInsets22);
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets22.getUnitType();
        categoryAxis8.setTickLabelInsets(rectangleInsets22);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = piePlot3D34.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.PiePlotState piePlotState38 = ringPlot31.initialise(graphics2D32, rectangle2D33, (org.jfree.chart.plot.PiePlot) piePlot3D34, (java.lang.Integer) 0, plotRenderingInfo37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double43 = size2D42.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '4', (double) (byte) 1, rectangleAnchor46);
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.setVisible(false);
        double double52 = dateAxis49.getUpperBound();
        java.awt.Color color54 = java.awt.Color.cyan;
        java.awt.Color color56 = java.awt.Color.black;
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color56, stroke57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker58.setStroke(stroke59);
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color54, stroke59);
        dateAxis49.setAxisLinePaint((java.awt.Paint) color54);
        dateAxis49.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape66 = dateAxis49.getLeftArrow();
        piePlot48.setLegendItemShape(shape66);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.PiePlotState piePlotState70 = piePlot3D34.initialise(graphics2D39, rectangle2D47, piePlot48, (java.lang.Integer) 255, plotRenderingInfo69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = categoryAxis8.getCategoryMiddle(255, 15, rectangle2D47, rectangleEdge71);
        try {
            xYPlot0.drawOutline(graphics2D7, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(piePlotState38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(piePlotState70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean41 = piePlot3D40.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D40);
        categoryPlot39.notifyListeners(plotChangeEvent42);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = null;
        try {
            categoryPlot39.setDomainGridlinePosition(categoryAnchor44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener8 = null;
        valueMarker5.addChangeListener(markerChangeListener8);
        valueMarker5.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getLeft();
        double double15 = rectangleInsets12.extendHeight(0.0d);
        valueMarker5.setLabelOffset(rectangleInsets12);
        double double18 = rectangleInsets12.trimWidth((double) 100L);
        piePlot3D0.setSimpleLabelOffset(rectangleInsets12);
        double double21 = rectangleInsets12.extendWidth((-6.0d));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 84.0d + "'", double18 == 84.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str2 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Other", numberArray5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset6, (java.lang.Comparable) "Other");
        try {
            java.lang.String str10 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset8, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 0.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot0.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot0.handleClick(500, (int) (short) 10, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setVisible(false);
        double double43 = dateAxis40.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
        boolean boolean46 = categoryPlot45.isRangeCrosshairVisible();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color52);
        int int54 = color52.getGreen();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color52, stroke55);
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        boolean boolean58 = textBlock5.equals((java.lang.Object) categoryPlot45);
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot45.setFixedRangeAxisSpace(axisSpace59);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 128 + "'", int54 == 128);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str11 = basicProjectInfo10.getName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str18 = basicProjectInfo17.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        java.lang.String str24 = basicProjectInfo23.getName();
        basicProjectInfo17.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj28 = dateAxis27.clone();
        float float29 = dateAxis27.getTickMarkOutsideLength();
        dateAxis27.setNegativeArrowVisible(true);
        java.lang.Object obj32 = dateAxis27.clone();
        boolean boolean33 = basicProjectInfo4.equals((java.lang.Object) dateAxis27);
        java.lang.String str34 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraintType.RANGE" + "'", str5.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraintType.RANGE" + "'", str11.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraintType.RANGE" + "'", str18.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleConstraintType.RANGE" + "'", str24.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleConstraintType.RANGE" + "'", str34.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, 100, (-1), rectangle2D5, rectangleEdge6);
        java.lang.Object obj9 = null;
        boolean boolean10 = rectangleEdge6.equals(obj9);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke40);
        int int42 = categoryPlot39.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot39.getDataset(0);
        java.awt.Paint paint45 = categoryPlot39.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setFixedAutoRange(2.0d);
        java.awt.Paint paint37 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', (double) 100.0f, plotRenderingInfo4, point2D5);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setVisible(false);
        double double43 = dateAxis40.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
        boolean boolean46 = categoryPlot45.isRangeCrosshairVisible();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color52);
        int int54 = color52.getGreen();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color52, stroke55);
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        boolean boolean58 = textBlock5.equals((java.lang.Object) categoryPlot45);
        double[] doubleArray65 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray70 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray75 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray80 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray85 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray86 = new double[][] { doubleArray65, doubleArray70, doubleArray75, doubleArray80, doubleArray85 };
        org.jfree.data.category.CategoryDataset categoryDataset87 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray86);
        org.jfree.data.Range range89 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset87, false);
        java.lang.Number number90 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset87);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer91 = categoryPlot45.getRendererForDataset(categoryDataset87);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 128 + "'", int54 == 128);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(categoryDataset87);
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertTrue("'" + number90 + "' != '" + (-1.0d) + "'", number90.equals((-1.0d)));
        org.junit.Assert.assertNull(categoryItemRenderer91);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, 0.0f, 0.0f);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) (short) -1, 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(layer7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = xYPlot0.indexOf(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.data.Range range41 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range44 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint(10.0d, range41, lengthConstraintType42, 0.0d, range44, lengthConstraintType45);
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray73 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray74 = new double[][] { doubleArray53, doubleArray58, doubleArray63, doubleArray68, doubleArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray74);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset75, false);
        org.jfree.data.Range range78 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = rectangleConstraint46.toRangeHeight(range78);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = rectangleConstraint6.toRangeHeight(range78);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = rectangleConstraint80.toFixedHeight(1.56043833244502E14d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(rectangleConstraint79);
        org.junit.Assert.assertNotNull(rectangleConstraint80);
        org.junit.Assert.assertNotNull(rectangleConstraint82);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        xYPlot0.mapDatasetToDomainAxis((int) '#', 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setVisible(false);
        double double43 = dateAxis40.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
        boolean boolean46 = categoryPlot45.isRangeCrosshairVisible();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color52);
        int int54 = color52.getGreen();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color52, stroke55);
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        boolean boolean58 = textBlock5.equals((java.lang.Object) categoryPlot45);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        categoryPlot45.setDataset(128, categoryDataset60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        boolean boolean63 = xYPlot62.isRangeCrosshairLockedOnData();
        java.awt.Paint paint64 = xYPlot62.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = xYPlot62.getDatasetRenderingOrder();
        int int66 = xYPlot62.getDatasetCount();
        java.awt.Color color68 = java.awt.Color.black;
        java.awt.Stroke stroke69 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color68, stroke69);
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker70.setStroke(stroke71);
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot();
        polarPlot73.setBackgroundAlpha((float) (short) 0);
        valueMarker70.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot73);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent78 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot77);
        java.awt.Color color79 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel80 = null;
        java.awt.Rectangle rectangle81 = null;
        java.awt.geom.Rectangle2D rectangle2D82 = null;
        java.awt.geom.AffineTransform affineTransform83 = null;
        java.awt.RenderingHints renderingHints84 = null;
        java.awt.PaintContext paintContext85 = color79.createContext(colorModel80, rectangle81, rectangle2D82, affineTransform83, renderingHints84);
        xYPlot77.setRangeTickBandPaint((java.awt.Paint) color79);
        xYPlot77.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker70.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot77);
        org.jfree.chart.axis.AxisLocation axisLocation91 = xYPlot77.getRangeAxisLocation();
        xYPlot62.setRangeAxisLocation(axisLocation91);
        categoryPlot45.setRangeAxisLocation(axisLocation91);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 128 + "'", int54 == 128);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(paintContext85);
        org.junit.Assert.assertNotNull(axisLocation91);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        piePlot3D3.setMaximumLabelWidth((double) '#');
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        piePlot3D3.setToolTipGenerator(pieToolTipGenerator10);
        piePlot3D3.setDarkerSides(false);
        piePlot3D3.setSectionOutlinesVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color17);
        piePlot3D3.setLabelPadding(rectangleInsets16);
        java.awt.Font font21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("ClassContext", font21, paint22, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        polarPlot25.notifyListeners(plotChangeEvent26);
        boolean boolean29 = polarPlot25.equals((java.lang.Object) 0.0f);
        java.awt.Color color32 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot25.setBackgroundPaint((java.awt.Paint) color32);
        boolean boolean34 = textFragment24.equals((java.lang.Object) polarPlot25);
        java.awt.Paint paint35 = textFragment24.getPaint();
        piePlot3D3.setLabelOutlinePaint(paint35);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor37 = null;
        try {
            piePlot3D3.setLabelDistributor(abstractPieLabelDistributor37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot0.getIndexOf(xYItemRenderer16);
        java.lang.Object obj18 = xYPlot0.clone();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ClassContext", font1, paint2, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot5.notifyListeners(plotChangeEvent6);
        boolean boolean9 = polarPlot5.equals((java.lang.Object) 0.0f);
        java.awt.Color color12 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot5.setBackgroundPaint((java.awt.Paint) color12);
        boolean boolean14 = textFragment4.equals((java.lang.Object) polarPlot5);
        java.awt.Stroke stroke15 = polarPlot5.getAngleGridlineStroke();
        int int16 = polarPlot5.getSeriesCount();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(10.0d, range4, lengthConstraintType5, 0.0d, range7, lengthConstraintType8);
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset38, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint9.toRangeHeight(range41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint42.toFixedHeight((double) '4');
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray56 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray61 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray66 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray71 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray72 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset73, false);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset73);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint42.toRangeWidth(range76);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType78 = rectangleConstraint42.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D79 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertNotNull(lengthConstraintType78);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        polarPlot5.setAngleLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot5.getOrientation();
        xYPlot0.setOrientation(plotOrientation11);
        java.lang.String str13 = plotOrientation11.toString();
        java.lang.String str14 = plotOrientation11.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str14.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) 0.0d);
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=0]", graphics2D1, (-1.0f), (float) '4', textAnchor4, 100.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list2 = projectInfo1.getContributors();
        projectInfo0.setContributors(list2);
        java.lang.String str4 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str4.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset35);
        dateAxis5.setDefaultAutoRange(range36);
        java.util.TimeZone timeZone38 = dateAxis5.getTimeZone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(timeZone38);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3, false, true);
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        double double23 = rectangleInsets17.trimWidth((double) 100L);
        dateAxis0.setTickLabelInsets(rectangleInsets17);
        org.jfree.data.Range range27 = new org.jfree.data.Range((double) 1L, (double) 2.0f);
        dateAxis0.setRange(range27, true, true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 84.0d + "'", double23 == 84.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = piePlot3D12.getLegendItems();
        java.awt.Paint paint14 = piePlot3D12.getBaseSectionPaint();
        java.awt.Paint paint15 = piePlot3D12.getLabelPaint();
        xYPlot0.setOutlinePaint(paint15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        xYPlot0.setRenderer(100, xYItemRenderer18, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        float float7 = dateAxis5.getTickMarkInsideLength();
        java.awt.Paint paint8 = dateAxis5.getTickLabelPaint();
        dateAxis5.setLowerBound(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot0.setRangeAxis(valueAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot0.getDomainAxisLocation();
        int int17 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot39.setFixedRangeAxisSpace(axisSpace40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot39.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        categoryPlot39.setRenderer(2, categoryItemRenderer45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        dateAxis48.setVisible(false);
        double[] doubleArray57 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray62 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray67 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray72 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray77 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray78 = new double[][] { doubleArray57, doubleArray62, doubleArray67, doubleArray72, doubleArray77 };
        org.jfree.data.category.CategoryDataset categoryDataset79 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray78);
        org.jfree.data.Range range81 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset79, false);
        dateAxis48.setDefaultAutoRange(range81);
        dateAxis48.setAutoTickUnitSelection(false);
        categoryPlot39.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis48);
        boolean boolean86 = categoryPlot39.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(categoryDataset79);
        org.junit.Assert.assertNotNull(range81);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3, false, true);
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        double double23 = rectangleInsets17.trimWidth((double) 100L);
        dateAxis0.setTickLabelInsets(rectangleInsets17);
        dateAxis0.zoomRange((double) (byte) 0, 8.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 84.0d + "'", double23 == 84.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("java.awt.Color[r=128,g=128,b=128]", "hi!");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        boolean boolean4 = valueMarker1.equals((java.lang.Object) rendererState3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        java.awt.Paint paint13 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getRangeAxisLocation(2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.mapDatasetToDomainAxis(10, 10);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        org.jfree.chart.JFreeChart jFreeChart36 = multiplePiePlot35.getPieChart();
        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("ClassContext", font38);
        java.lang.Object obj40 = textTitle39.clone();
        java.awt.Font font42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("ClassContext", font42, paint43, (float) (byte) 100);
        textTitle39.setFont(font42);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder(rectangleInsets47, (java.awt.Paint) color48);
        textTitle39.setFrame((org.jfree.chart.block.BlockFrame) blockBorder49);
        jFreeChart36.addSubtitle((org.jfree.chart.title.Title) textTitle39);
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) pieToolTipGenerator1, jFreeChart36, (int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(jFreeChart36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis0.setTickUnit(dateTickUnit3, false, true);
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        double double23 = rectangleInsets17.trimWidth((double) 100L);
        dateAxis0.setTickLabelInsets(rectangleInsets17);
        java.lang.String str25 = dateAxis0.getLabelURL();
        dateAxis0.centerRange((double) 1L);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 84.0d + "'", double23 == 84.0d);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setFixedAutoRange(2.0d);
        java.text.DateFormat dateFormat37 = null;
        dateAxis0.setDateFormatOverride(dateFormat37);
        dateAxis0.resizeRange((double) 100);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoRangeMinimumSize((double) 2, true);
        try {
            dateAxis0.setRange((double) 2.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMinimumArcAngleToDraw((double) 0.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) '4', plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            polarPlot0.zoomRangeAxes(1.56043833244502E14d, plotRenderingInfo9, point2D10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        double double8 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, 100, (-1), rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean20 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge19);
        double double21 = categoryAxis13.getCategoryJava2DCoordinate(categoryAnchor15, 100, (-1), rectangle2D18, rectangleEdge19);
        double double22 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor9, (int) '#', 255, rectangle2D12, rectangleEdge19);
        java.awt.Font font25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", font25);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0.0d, font25);
        double double28 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setAutoTickUnitSelection(false);
        java.awt.Paint paint37 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot38 = dateAxis0.getPlot();
        dateAxis0.setLabel("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(plot38);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        boolean boolean6 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot3D10.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot7.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) piePlot3D10, (java.lang.Integer) 0, plotRenderingInfo13);
        piePlot3D10.setMaximumLabelWidth((double) '#');
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator17 = null;
        piePlot3D10.setToolTipGenerator(pieToolTipGenerator17);
        piePlot3D10.setDarkerSides(false);
        piePlot3D10.setSectionOutlinesVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color24);
        piePlot3D10.setLabelPadding(rectangleInsets23);
        java.awt.Font font28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("ClassContext", font28, paint29, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        polarPlot32.notifyListeners(plotChangeEvent33);
        boolean boolean36 = polarPlot32.equals((java.lang.Object) 0.0f);
        java.awt.Color color39 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot32.setBackgroundPaint((java.awt.Paint) color39);
        boolean boolean41 = textFragment31.equals((java.lang.Object) polarPlot32);
        java.awt.Paint paint42 = textFragment31.getPaint();
        piePlot3D10.setLabelOutlinePaint(paint42);
        boolean boolean44 = numberAxis3D1.equals((java.lang.Object) piePlot3D10);
        double double46 = piePlot3D10.getExplodePercent((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Range[-5.0,50.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

